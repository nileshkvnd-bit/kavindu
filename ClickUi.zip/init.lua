-- -------------------------------------------------------------------------
-- ClickUl_Refactor/init.lua
-- Refactor entry module.
-- -------------------------------------------------------------------------

local Bootstrap = require("ClickUl_Refactor.Core.bootstrap")

Bootstrap.init()

return Bootstrap
