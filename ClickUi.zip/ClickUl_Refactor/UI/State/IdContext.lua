local IdContext = {}

local string_byte <const> = string.byte
local tostring <const> = tostring
local pairs <const> = pairs
local FNV_OFFSET_BASIS <const> = 2166136261
local FNV_PRIME <const> = 16777619

local function fnv1a_hash(str, seed)
    local hash = seed or FNV_OFFSET_BASIS
    for i = 1, #str do
        hash = hash ~ string_byte(str, i)
        hash = (hash * FNV_PRIME) & 0xFFFFFFFF
    end
    return hash
end

function IdContext.install(state)
    local id_hash_stack = { FNV_OFFSET_BASIS }
    local id_hash_stack_len = 1
    local widget_hash_counter = {}

    function state.push_id_context(name)
        local stack = state.ui.id_context_stack
        stack[#stack + 1] = name
        id_hash_stack_len = id_hash_stack_len + 1
        id_hash_stack[id_hash_stack_len] = fnv1a_hash(tostring(name), id_hash_stack[id_hash_stack_len - 1])
    end

    function state.pop_id_context()
        local stack = state.ui.id_context_stack
        if #stack > 0 then
            stack[#stack] = nil
        end
        if id_hash_stack_len > 1 then
            id_hash_stack[id_hash_stack_len] = nil
            id_hash_stack_len = id_hash_stack_len - 1
        end
    end

    function state.get_widget_id(label)
        local parent_hash = id_hash_stack[id_hash_stack_len]
        local id = fnv1a_hash(tostring(label), parent_hash)

        local count = widget_hash_counter[id] or 0
        widget_hash_counter[id] = count + 1

        if count == 0 then
            return id
        end

        return fnv1a_hash(tostring(count), id)
    end

    function state.peek_widget_id(label)
        local parent_hash = id_hash_stack[id_hash_stack_len]
        local id = fnv1a_hash(tostring(label), parent_hash)
        local count = widget_hash_counter[id] or 0
        if count == 0 then return id end
        return fnv1a_hash(tostring(count), id)
    end

    function state.reset_widget_id_counter()
        for id in pairs(widget_hash_counter) do
            widget_hash_counter[id] = nil
        end
    end

    state.clear_widget_id_cache = state.reset_widget_id_counter
end

return IdContext
