local Dependencies = {}

function Dependencies.create()
    return {
        config_sys = nil,
        logger = nil,
        lang = nil,
    }
end

function Dependencies.install(state)
    function state.set_dependency(name, value)
        state.deps[name] = value
    end
end

return Dependencies
