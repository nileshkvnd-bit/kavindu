local Cleanup = {}

local next <const> = next

local function clear_table(tbl)
    for key in next, tbl do
        tbl[key] = nil
    end
end

function Cleanup.install(state)
    function state.reset_interaction()
        local ui = state.ui
        ui.active_id = nil
        ui.active_combo = nil
        ui.text_input_active = false
    end

    function state.capture_active_id(id)
        local ui = state.ui
        ui.active_id = id
        ui.text_input_active = false
    end

    function state.cleanup_dynamic_states()
        local ui = state.ui
        clear_table(ui.combo_states)
        clear_table(ui.input_states)
        clear_table(ui.layout_cache)
        ui.menu_hint.current = nil
        ui.menu_hint.last_update = 0
        ui.menu_hint.payload = nil
        ui.menu_hint.bounds = nil
    end
end

return Cleanup
