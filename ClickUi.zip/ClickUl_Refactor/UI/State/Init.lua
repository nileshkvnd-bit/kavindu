local state = {}

local Constants = require("ClickUl_Refactor.UI.State.Constants")
local Ui = require("ClickUl_Refactor.UI.State.Ui")
local Cache = require("ClickUl_Refactor.UI.State.Cache")
local Dependencies = require("ClickUl_Refactor.UI.State.Dependencies")
local Cleanup = require("ClickUl_Refactor.UI.State.Cleanup")
local IdContext = require("ClickUl_Refactor.UI.State.IdContext")
local Scroll = require("ClickUl_Refactor.UI.State.Scroll")

state.constants = Constants.constants
state.BLOCK_CONTROLS = Constants.block_controls
state.ui = Ui.create()
state.cache = Cache.create()
state.deps = Dependencies.create()

Dependencies.install(state)
Cache.install(state)
Cleanup.install(state)
IdContext.install(state)
Scroll.install(state)

return state
