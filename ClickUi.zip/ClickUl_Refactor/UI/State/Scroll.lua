local Scroll = {}

function Scroll.install(state)
    function state.save_tab_scroll(tab_index)
        if not tab_index then return end
        local ui = state.ui
        ui.tab_scroll_positions = ui.tab_scroll_positions or {}
        ui.tab_scroll_positions[tab_index] = {
            y = ui.scroll_y,
            target = ui.scroll_target,
            content_h = ui.content_h,
            visible_h = ui.visible_h
        }
    end

    function state.restore_tab_scroll(tab_index)
        local ui = state.ui
        ui.tab_scroll_positions = ui.tab_scroll_positions or {}
        local saved = ui.tab_scroll_positions[tab_index]
        if saved then
            ui.scroll_y = saved.y or 0
            ui.scroll_target = saved.target or 0
            if saved.content_h and saved.content_h > 0 then ui.content_h = saved.content_h end
            if saved.visible_h and saved.visible_h > 0 then ui.visible_h = saved.visible_h end
            ui.skip_scroll_clamp = true
            return true
        end
        return false
    end
end

return Scroll
