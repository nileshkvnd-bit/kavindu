local Cache = {}

function Cache.create()
    return {
        text_width = {},
        text_width_size = 0,
        color_userdata = {},
        color_alpha = {},
    }
end

function Cache.install(state)
    function state.reset_cache()
        state.cache.color_userdata = {}
        state.cache.color_alpha = {}
        state.cache.text_width = {}
        state.cache.text_width_size = 0
        state.ui.sidebar_textures = {}

        local active_combo_id = state.ui.active_combo
        local active_combo_state = nil
        if active_combo_id then
            active_combo_state = state.ui.combo_states[active_combo_id]
        end

        state.ui.combo_states = {}

        if active_combo_state and active_combo_id then
            state.ui.combo_states[active_combo_id] = active_combo_state
        end

        state.ui.input_states = {}
        state.ui.click_animations = {}
        state.ui.checkbox_animations = {}
        state.ui.layout_cache = {}
    end

    function state.reset_color_cache()
        state.cache.color_userdata = {}
    end
end

return Cache
