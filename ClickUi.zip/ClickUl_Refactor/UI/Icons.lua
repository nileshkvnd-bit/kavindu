local icons = {}

local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local logger = require("ClickUl_Refactor.Core.Logger")

local pcall <const> = pcall

local icon_cache = {}

local ICON_FILES = {
    star = "star.png",

    arrow_down = "arrow_down.png",
    arrow_right = "arrow_right.png",

    checkmark = "checkmark.png",
    cross = "cross.png",
}

local load_failed = {}

function icons.load(name)
    if icon_cache[name] then
        return icon_cache[name]
    end

    if load_failed[name] then
        return nil
    end

    local filename = ICON_FILES[name]
    if not filename then
        load_failed[name] = true
        return nil
    end

    local path = renderer.get_assets_dir() .. "Images\\Icons\\" .. filename

    local ok, texture = pcall(renderer.load_image, path)
    if ok and texture then
        icon_cache[name] = texture
        return texture
    else
        logger.warn("UI.Icons", "Failed to load icon: " .. name .. " (" .. path .. ")")
        load_failed[name] = true
    end

    return nil
end

function icons.get(name)
    return icon_cache[name] or icons.load(name)
end

return icons
