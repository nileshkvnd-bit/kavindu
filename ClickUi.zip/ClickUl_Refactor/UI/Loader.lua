local Loader = {}

local action_registry = require("ClickUl_Refactor.Core.ActionRegistry")
local favorites = require("ClickUl_Refactor.Core.Favorites")
local favorites_page = require("ClickUl_Refactor.Features.Favorites.Init")

local LOAD_ORDER = {
    { key = "settings", name = "ClickUl_Refactor.Config.Settings" },
    { key = "hotkey_settings", name = "ClickUl_Refactor.Config.HotkeySettings" },
    { key = "theme", name = "ClickUl_Refactor.UI.Theme" },
    { key = "state", name = "ClickUl_Refactor.UI.State.Init" },
    { key = "renderer", name = "ClickUl_Refactor.UI.Renderer.Init" },
    { key = "input", name = "ClickUl_Refactor.UI.Input" },
    { key = "hotkeys", name = "ClickUl_Refactor.Core.Hotkeys" },
    { key = "layout", name = "ClickUl_Refactor.UI.Layout.Init" },
    { key = "widgets", name = "ClickUl_Refactor.UI.Widgets" },
    { key = "notification", name = "ClickUl_Refactor.UI.Notification" },
    { key = "fonts", name = "ClickUl_Refactor.UI.Fonts" },
    { key = "icons", name = "ClickUl_Refactor.UI.Icons" },
    { key = "settings_page", name = "ClickUl_Refactor.UI.Settings.Init" },
    { key = "app_menu", name = "ClickUl_Refactor.UI.AppMenu" },
    { key = "self", name = "ClickUl_Refactor.Features.Self.Init" },
    { key = "spawn", name = "ClickUl_Refactor.Features.Spawn.Init" },
    { key = "vehicle", name = "ClickUl_Refactor.Features.Vehicle.Init" },
    { key = "world", name = "ClickUl_Refactor.Features.World.Init" },
    { key = "teleport", name = "ClickUl_Refactor.Features.Teleport.Init" },
    { key = "game", name = "ClickUl_Refactor.Features.Game.Init" },
    { key = "core", name = "ClickUl_Refactor.UI.Core" },
}

local function log(ctx, level, tag, message)
    ctx.logger[level](tag, message)
end

local function require_module(ctx, spec)
    local module = require(spec.name)
    log(ctx, "verbose", "UI.Loader", "loaded " .. spec.name)
    return module
end

function Loader.load(ctx)
    log(ctx, "info", "UI.Loader", "loading UI")

    local modules = {}
    for _, spec in ipairs(LOAD_ORDER) do
        modules[spec.key] = require_module(ctx, spec)
    end

    local settings = modules.settings
    local i18n = ctx.i18n
    settings.init()
    modules.hotkey_settings.init()
    i18n.init({ settings = settings })
    modules.hotkeys.init({
        settings = modules.hotkey_settings,
        input = modules.input,
    })
    action_registry.clear()
    favorites.init({
        action_registry = action_registry,
        logger = ctx.logger,
    })

    local theme = modules.theme
    theme.init({ lang = i18n, settings = settings })
    theme.load()

    modules.notification.init({ lang = i18n })
    modules.renderer.set_fonts(modules.fonts)
    modules.layout.init({
        widgets = modules.widgets,
        settings = settings,
    })

    local ui = modules.core
    ui.init({
        theme = theme,
        settings = settings,
        hotkeys = modules.hotkeys,
        lang = i18n,
    })
    modules.hotkeys.set_trigger_notifier(function(action, binding, state_value)
        local label = i18n.get(action.label)
        local key_name = modules.hotkeys.format_binding(binding)
        local message = i18n.get("Feature") .. ": " .. label .. "\n" .. i18n.get("Key") .. ": " .. key_name
        if state_value ~= nil then
            message = message .. "\n" .. i18n.get("State") .. ": " .. i18n.get(state_value and "On" or "Off")
        end
        ui.notify(message, "Hotkey")
    end)

    local fonts = modules.fonts
    fonts.init({ logger = ctx.logger })

    modules.hotkeys.register_action({
        id = "system.toggle_menu",
        label = "Toggle Menu",
        group = "System",
        when = "always",
        allow_text_input = true,
        always_enabled = true,
        callback = function()
            ui.toggle_menu()
        end,
    })
    modules.hotkeys.register_action({
        id = "favorites.toggle_hovered",
        label = "Toggle Favorite",
        group = "Favorites",
        when = "open",
        allow_text_input = true,
        notify_on_trigger = false,
        callback = function()
            local target = ui.get_favorite_target()
            if not target then
                ui.notify(i18n.get("No favorite target"), "Info")
                return nil
            end

            local label = target.label or target.action_id
            local added, reason = favorites.toggle(target.action_id)
            if added == nil then
                ui.notify(i18n.get("Favorite unavailable") .. ": " .. label, "Warning")
                return nil, reason
            end

            if added then
                ui.notify(i18n.get("Added to favorites") .. ": " .. label, "Success")
            else
                ui.notify(i18n.get("Removed from favorites") .. ": " .. label, "Info")
            end
            return added
        end,
    })

    local settings_page = modules.settings_page
    settings_page.init({
        ui = ui,
        theme = theme,
        lang = i18n,
        settings = settings,
        input = modules.input,
        hotkeys = modules.hotkeys,
    })

    local app_menu = modules.app_menu
    app_menu.init({
        ui = ui,
        lang = i18n,
    })
    favorites_page.init({
        ui = ui,
        lang = i18n,
        favorites = favorites,
        action_registry = action_registry,
    })

    local self = modules.self
    self.init({ ui = ui, lang = i18n, logger = ctx.logger, hotkeys = modules.hotkeys, action_registry = action_registry, favorites = favorites })
    local spawn = modules.spawn
    spawn.init({ ui = ui, lang = i18n, logger = ctx.logger, settings = settings, action_registry = action_registry, favorites = favorites })
    local vehicle = modules.vehicle
    vehicle.init({ ui = ui, lang = i18n, logger = ctx.logger, settings = settings, hotkeys = modules.hotkeys, action_registry = action_registry, favorites = favorites })
    local world = modules.world
    world.init({ ui = ui, lang = i18n, logger = ctx.logger, settings = settings, action_registry = action_registry, favorites = favorites })
    local teleport = modules.teleport
    teleport.init({ ui = ui, lang = i18n, logger = ctx.logger, hotkeys = modules.hotkeys, action_registry = action_registry, favorites = favorites })
    local game = modules.game
    game.init({ ui = ui, lang = i18n, logger = ctx.logger, settings = settings })
    app_menu.register({
        key = "favorites",
        label = "Favorites",
        file = "Favorites",
        module = favorites_page,
        sidebar = false,
    })
    app_menu.register({
        key = "self",
        label = "Self",
        file = "Self",
        module = self,
    })
    app_menu.register({
        key = "spawn",
        label = "Spawn",
        file = "Spawn",
        module = spawn,
    })
    app_menu.register({
        key = "vehicle",
        label = "Vehicle",
        file = "Vehicle",
        module = vehicle,
    })
    app_menu.register({
        key = "world",
        label = "World",
        file = "World",
        module = world,
    })
    app_menu.register({
        key = "teleport",
        label = "Teleport",
        file = "Teleport",
        module = teleport,
    })
    app_menu.register({
        key = "game",
        label = "Game",
        file = "Game",
        module = game,
    })
    app_menu.register({
        key = "setting",
        label = "Setting",
        file = "Setting",
        module = settings_page,
    })
    ui.set_settings_tab_index(app_menu.get_tab_index("setting"))
    ui.set_header_star({
        is_active = function()
            return app_menu.is_special_open("favorites")
        end,
        on_click = function()
            app_menu.toggle_special("favorites")
        end,
    })

    ui.draw_menu = function()
        return app_menu.draw()
    end
    ui.get_sidebar_tabs = function()
        return app_menu.get_sidebar_specs()
    end
    ui.on_menu_open = function()
        app_menu.on_menu_open()
    end
    ui.on_menu_close = function()
        app_menu.on_menu_close()
    end
    ui.on_shutdown = function()
        app_menu.on_shutdown()
    end

    log(ctx, "info", "UI.Loader", "UI ready")
    return ui
end

return Loader
