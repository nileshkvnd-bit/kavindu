local notification = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local lang = nil

local math_floor <const> = math.floor
local math_max <const> = math.max
local math_min <const> = math.min
local math_abs <const> = math.abs
local math_exp <const> = math.exp
local get_time <const> = runtime.now
local table_insert <const> = table.insert
local table_remove <const> = table.remove
local ipairs <const> = ipairs
local string_find <const> = string.find
local tostring <const> = tostring

local icon_cache = {}
local icon_cache_count = 0
local ICON_CACHE_LIMIT <const> = 50
local icon_clock = 0

local failed_icon_cache = {}

local function _T(text)
    local lang_module = assert(lang, "[Notification] language module is required")
    return lang_module.get(text)
end

function notification.init(ctx)
    lang = assert(ctx.lang, "[Notification] language module is required")
    return true
end

local STATIC_WHITE <const> = {r=255, g=255, b=255, a=255}

local TMP_FLASH_COLOR = {r=255, g=255, b=255, a=0}
local TMP_TRACK_COLOR = {r=0, g=0, b=0, a=0}
local TMP_BAR_COLOR = {r=0, g=0, b=0, a=255}

local TIME_BAR_GRADIENT_LUT <const> = {}
for i = 0, 100 do
    local t = i / 100
    TIME_BAR_GRADIENT_LUT[i] = {
        r = math_floor(255 + (220 - 255) * (1 - t)),
        g = math_floor(255 + (53 - 255) * (1 - t)),
        b = math_floor(255 + (69 - 255) * (1 - t)),
        a = 255
    }
end

local s_func <const> = renderer.s
local get_vec2 <const> = renderer.get_vec2
local get_color_alpha <const> = renderer.get_color_alpha
local get_color <const> = renderer.get_color
local draw_rect_ex <const> = renderer.draw_rect_ex
local draw_text_ex <const> = renderer.draw_text_ex
local draw_image <const> = renderer.draw_image
local draw_wrapped_text <const> = renderer.draw_wrapped_text
local load_image <const> = renderer.load_image

local function ease_out_back(x)
    local c1 = 1.70158
    local c3 = c1 + 1
    return 1 + c3 * ((x - 1) ^ 3) + c1 * ((x - 1) ^ 2)
end

local function ease_in_cubic(x)
    return x * x * x
end

local NOTIF_COLOR_MAP <const> = {
    ["Info"] = "Notification Background",
    ["Hotkey"] = "Notification Hotkey",
    ["Success"] = "Notification Success",
    ["Warning"] = "Notification Warning",
    ["Error"] = "Notification Error",
    ["Join"] = "Notification Join",
    ["Leave"] = "Notification Leave",
    ["Spectator"] = "Notification Spectator",
    ["Modder"] = "Notification Modder",
    ["Script Event"] = "Notification Script Event",
    ["Network Event"] = "Notification Network Event",
    ["Protection"] = "Notification Protection",
    ["Player Manager"] = "Notification Player Manager",
}

function notification.notify(msg, type_str)
    local config_sys = assert(state.deps.config_sys, "[Notification] config module is required")
    local ui = state.ui
    local base = config_sys.data.base

    type_str = type_str or "Info"

    local color_key = NOTIF_COLOR_MAP[type_str]
    if not color_key then
        if config_sys.data.colors["Notification " .. type_str] then
            color_key = "Notification " .. type_str
        else
            color_key = "Notification Background"
        end
    end

    local icon_tex = nil
    local icon_filename = "logo.png"
    local icons = config_sys.data.notification_icons

    if icons then
        local icon_key = type_str
        if icons[icon_key] then
            icon_filename = icons[icon_key]
        end
    end

    if icon_filename and icon_filename ~= "None" and icon_filename ~= "" then
        local cached_icon = icon_cache[icon_filename]
        if cached_icon then
            icon_tex = cached_icon.tex
            icon_clock = icon_clock + 1
            cached_icon.last_used = icon_clock
        elseif not failed_icon_cache[icon_filename] then
            local path = renderer.get_assets_dir() .. "Images\\" .. icon_filename
            local status, tex = pcall(load_image, path)
            if status and tex then
                if icon_cache_count >= ICON_CACHE_LIMIT then
                    local oldest_key = nil
                    local oldest_used = nil
                    for key, entry in pairs(icon_cache) do
                        if not oldest_used or entry.last_used < oldest_used then
                            oldest_key = key
                            oldest_used = entry.last_used
                        end
                    end
                    if oldest_key then
                        icon_cache[oldest_key] = nil
                        icon_cache_count = icon_cache_count - 1
                    end
                end
                icon_clock = icon_clock + 1
                icon_tex = tex
                icon_cache[icon_filename] = { tex = tex, last_used = icon_clock }
                icon_cache_count = icon_cache_count + 1
            else
                failed_icon_cache[icon_filename] = true
            end
        end
    end

    local notif_w = s_func(base.notif_width or 320)
    local padding = s_func(base.notif_padding or 6)
    local icon_size = s_func(base.notif_icon_size or 32)
    local min_h_no_icon = s_func(base.notif_min_height or 60)
    local duration = base.notif_duration or 5.0
    local flash_cooldown = base.notif_flash_cooldown or state.constants.NOTIFICATION_FLASH_COOLDOWN or 1.5

    local f_title = base.notif_title_size or 17
    local f_msg = base.notif_message_size or 14

    local text_start_x = padding
    if icon_tex then text_start_x = padding + icon_size + padding end
    local max_text_w = notif_w - text_start_x - padding

    local title_h = s_func(f_title) + s_func(2)
    local msg_h = s_func(f_msg)

    local dims = renderer.wrapped_text_size(msg, f_msg, max_text_w)
    if dims.y > 0 then msg_h = dims.y end

    if msg and msg ~= "" and msg_h < s_func(f_msg) then msg_h = s_func(f_msg) end

    local min_h = icon_tex and (icon_size + padding * 2) or min_h_no_icon
    local content_h = padding + title_h + msg_h + padding

    if base.notif_time_bar_enabled ~= false then
        content_h = content_h + s_func(base.notif_time_bar_height or 2) + s_func(2)
    end

    local final_h = math_max(min_h, content_h)

    for _, notif in ipairs(ui.notifications) do
        if notif.text == msg and notif.title == type_str and notif.state ~= "out" then
            local now = get_time()
            notif.start_time = now
            notif.count = (notif.count or 1) + 1
            notif.color_key = color_key
            notif.icon = icon_tex

            local time_since_last_flash = now - (notif.last_flash_time or 0)
            if time_since_last_flash >= flash_cooldown then
                notif.flash_intensity = 0.8
                notif.last_flash_time = now
            end
            return
        end
    end

    local max_count = base.notif_max_count or 12
    while #ui.notifications >= max_count do table_remove(ui.notifications, 1) end

    table_insert(ui.notifications, {
        title = type_str,
        text = msg,
        color_key = color_key,
        icon = icon_tex,
        start_time = get_time(),
        duration = duration,
        state = "in",
        progress = 0.0,
        current_y = nil,
        count = 1,
        flash_intensity = 0.0,
        last_flash_time = get_time(),
        height = final_h,
        width = notif_w,
        padding = padding,
        icon_size = icon_size,
        text_start_x = text_start_x,
        f_title = f_title,
        f_msg = f_msg,
        max_text_w = max_text_w
    })
end

function notification.draw()
    local ui = state.ui
    if #ui.notifications == 0 then return end

    local config_sys = assert(state.deps.config_sys, "[Notification] config module is required")

    if not ui.open then renderer.update_scale() end 

    local now = get_time()
    local dt = ui.delta_time or 0.016
    local screen_w = ui.screen_res.x
    local screen_h = ui.screen_res.y

    local base = config_sys.data.base
    local margin_x = s_func(base.notif_margin_x or 20)
    local margin_y = s_func(base.notif_margin_y or 20)
    local stack_spacing = s_func(base.notif_spacing or 8)
    local radius = s_func(base.notif_radius or 8)

    local anim_speed_in = base.notif_anim_speed_in or 4.0
    local anim_stack_speed = base.notif_anim_stack_speed or 15.0
    local default_padding = s_func(base.notif_padding or 6)

    local position = config_sys.data.notification_position or "bottom_right"
    local is_top = string_find(position, "top") ~= nil
    local is_left = string_find(position, "left") ~= nil

    local k = 1
    while k <= #ui.notifications do
        local notif = ui.notifications[k]
        local elapsed = now - notif.start_time

        if (notif.state == "in" or notif.state == "stay") and elapsed > notif.duration then
            notif.state = "out"
        end

        local target = (notif.state == "out") and 0.0 or 1.0
        local diff = target - notif.progress

        local exit_speed_mult = base.notif_exit_speed_multiplier or 1.5
        local speed = (notif.state == "out") and (anim_speed_in * exit_speed_mult) or anim_speed_in
        notif.progress = notif.progress + (diff * (1.0 - math_exp(-speed * dt)))

        if math_abs(target - notif.progress) < 0.005 then notif.progress = target end

        local flash_decay_speed = base.notif_flash_decay_speed or 6.0
        if notif.flash_intensity and notif.flash_intensity > 0.01 then
            notif.flash_intensity = notif.flash_intensity * math_exp(-flash_decay_speed * dt)
        else
            notif.flash_intensity = 0
        end

        if notif.state == "out" and notif.progress <= 0.01 then
            table_remove(ui.notifications, k)
        else
            k = k + 1
        end
    end

    local current_stack_y = is_top and margin_y or (screen_h - margin_y)
    
    for i = #ui.notifications, 1, -1 do
        local notif = ui.notifications[i]
        
        if notif.progress > 0.01 then
            local pad = notif.padding or default_padding
            
            local target_y
            if is_top then
                target_y = current_stack_y
                current_stack_y = current_stack_y + notif.height + stack_spacing
            else
                target_y = current_stack_y - notif.height
                current_stack_y = current_stack_y - notif.height - stack_spacing
            end

            if not notif.current_y then notif.current_y = target_y end
            local y_diff = target_y - notif.current_y
            if math_abs(y_diff) > 0.5 then
                notif.current_y = notif.current_y + (y_diff * (1.0 - math_exp(-anim_stack_speed * dt)))
            else
                notif.current_y = target_y
            end

            local full_slide_dist = notif.width + margin_x + s_func(20)

            local slide_offset = 0
            if notif.state == "out" then
                local t = 1.0 - notif.progress
                slide_offset = full_slide_dist * ease_in_cubic(t)
            else
                slide_offset = full_slide_dist * (1.0 - ease_out_back(notif.progress))
            end

            local x_pos = is_left and (margin_x - slide_offset) or (screen_w - margin_x - notif.width + slide_offset)

            local rx, ry = math_floor(x_pos), math_floor(notif.current_y)

            local content_alpha = notif.progress
            if notif.state == "out" then
                content_alpha = math_min(1.0, notif.progress * 2.0)
            end
            local text_alpha = content_alpha * content_alpha

            draw_rect_ex(rx, ry, notif.width, notif.height,
                notif.color_key, radius, nil, notif.progress)

            if notif.flash_intensity and notif.flash_intensity > 0.01 then
                local flash_color = get_color("Notification Flash") or STATIC_WHITE
                local f_alpha = math_floor(notif.flash_intensity * (flash_color.a or 150) * content_alpha)
                if f_alpha > 0 then
                    TMP_FLASH_COLOR.r = flash_color.r or 255
                    TMP_FLASH_COLOR.g = flash_color.g or 255
                    TMP_FLASH_COLOR.b = flash_color.b or 255
                    TMP_FLASH_COLOR.a = f_alpha
                    draw_rect_ex(rx, ry, notif.width, notif.height, nil, radius, nil, nil, TMP_FLASH_COLOR)
                end
            end

            if notif.icon then
                local iy = ry + (notif.height - notif.icon_size) / 2
                if base.notif_time_bar_enabled ~= false then
                    iy = iy - s_func(2)
                end
                local tint = get_color_alpha(STATIC_WHITE, content_alpha)
                draw_image(notif.icon, rx + pad, iy, notif.icon_size, notif.icon_size, tint)
            end

            local tx, ty = rx + notif.text_start_x, ry + pad

            draw_text_ex(_T(notif.title), tx, ty, notif.f_title, nil, nil, nil, text_alpha, STATIC_WHITE)

            local my = ty + s_func(notif.f_title) + s_func(1)

            draw_wrapped_text(notif.text, tx, my, notif.f_msg, nil, notif.max_text_w, text_alpha, STATIC_WHITE)

            if notif.count > 1 then
                if notif.count_str_for ~= notif.count then
                    notif.count_str = "x" .. tostring(notif.count)
                    notif.count_str_for = notif.count
                end
                local c_str = notif.count_str
                local cw = renderer.get_text_width(c_str, notif.f_msg)
                draw_text_ex(c_str, rx + notif.width - cw - pad, ry + pad,
                    notif.f_msg, nil, nil, nil, text_alpha, STATIC_WHITE)
            end

            if base.notif_time_bar_enabled ~= false and notif.state ~= "out" and notif.duration and notif.duration > 0 then
                local remaining_pct = 1.0 - ((now - notif.start_time) / notif.duration)
                if remaining_pct > 0 then
                    local bar_h = s_func(base.notif_time_bar_height or 2)
                    local bar_margin = s_func(4)
                    local max_bar_w = notif.width - (bar_margin * 2)
                    local bar_w = max_bar_w * remaining_pct
                    local bar_x = rx + bar_margin
                    local bar_y = ry + notif.height - bar_h - s_func(3)

                    local lut_idx = math_floor(remaining_pct * 100)
                    if lut_idx > 100 then lut_idx = 100 elseif lut_idx < 0 then lut_idx = 0 end
                    local bar_color_src = TIME_BAR_GRADIENT_LUT[lut_idx]
                    local bar_opacity = base.notif_time_bar_opacity or 180
                    TMP_BAR_COLOR.r = bar_color_src.r
                    TMP_BAR_COLOR.g = bar_color_src.g
                    TMP_BAR_COLOR.b = bar_color_src.b
                    TMP_BAR_COLOR.a = math_floor(bar_opacity * content_alpha)

                    TMP_TRACK_COLOR.a = math_floor(40 * content_alpha)
                    draw_rect_ex(bar_x, bar_y, max_bar_w, bar_h, nil, s_func(1), nil, nil, TMP_TRACK_COLOR)

                    draw_rect_ex(bar_x, bar_y, bar_w, bar_h, nil, s_func(1), nil, nil, TMP_BAR_COLOR)
                end
            end

        else
            local eff_h = notif.height + stack_spacing
            if is_top then current_stack_y = current_stack_y + eff_h else current_stack_y = current_stack_y - eff_h end
        end
    end
end

function notification.clear_cache()
    icon_cache = {}
    icon_cache_count = 0
    icon_clock = 0
    failed_icon_cache = {}
end

return notification
