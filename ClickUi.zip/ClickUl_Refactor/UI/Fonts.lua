local fonts = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local logger = require("ClickUl_Refactor.Core.Logger")
local fs = require("ClickUl_Refactor.Adapters.Fs")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")

local pairs <const> = pairs
local pcall <const> = pcall
local math_floor <const> = math.floor
local get_time <const> = runtime.now

fonts.loaded = {}
fonts.by_size = {}
fonts.font_path = nil
fonts.default = nil
fonts.rebuild_pending = false
fonts.last_rebuild_time = 0
fonts.rebuild_delay = 0.25

local function log_verbose(msg)
    logger.verbose("Fonts", tostring(msg))
end

local function log_info(msg)
    logger.info("Fonts", tostring(msg))
end

local rebuild_failure_logged = false

local function rebuild_font_atlas()
    local ok, err = pcall(renderer.rebuild)
    fonts.last_rebuild_time = get_time()
    if ok then
        fonts.rebuild_pending = false
        rebuild_failure_logged = false
    elseif not rebuild_failure_logged then
        rebuild_failure_logged = true
        logger.warn("Fonts", "font atlas rebuild failed", { error = tostring(err) })
    end
    return ok
end

local function queue_rebuild()
    fonts.rebuild_pending = true
end

function fonts.flush_rebuild(force)
    if not fonts.rebuild_pending then return true end
    if not force and get_time() - fonts.last_rebuild_time < fonts.rebuild_delay then
        return false
    end
    return rebuild_font_atlas()
end

local function get_fonts_dir()
    return fs.fonts_dir()
end

function fonts.init(ctx)
    assert(ctx.logger, "[Fonts] logger is required")
    log_info("Font system initialized")

    local config_sys = assert(state.deps.config_sys, "[Fonts] config module is required")
    local font_path = config_sys.data.base.custom_font_path
    if font_path and font_path ~= "" then
        fonts.set_font_path(font_path)
    end

    return true
end

function fonts.get(name)
    if not name then
        return fonts.default
    end
    return fonts.loaded[name]
end

function fonts.get_for_size(size)
    if not fonts.font_path then
        return nil
    end

    local int_size = math_floor(size)
    if int_size < 8 then int_size = 8 end
    if int_size > 48 then int_size = 48 end

    if fonts.by_size[int_size] then
        return fonts.by_size[int_size]
    end

    local full_path = fonts.font_path
    if not full_path:match("^[A-Za-z]:") and not full_path:match("^[\\/]") then
        full_path = get_fonts_dir() .. full_path
    end

    local ok, font_obj = pcall(renderer.load_font, full_path, int_size)
    if ok and font_obj then
        fonts.by_size[int_size] = font_obj
        log_verbose("Font loaded for size " .. int_size .. "px")

        queue_rebuild()

        return font_obj
    end

    return nil
end

function fonts.set_font_path(path)
    if fonts.font_path ~= path then
        fonts.by_size = {}
        fonts.font_path = path
        queue_rebuild()
        log_info("Font path set: " .. (path or "nil"))
    end
end

function fonts.clear()
    for k in pairs(fonts.loaded) do fonts.loaded[k] = nil end
    for k in pairs(fonts.by_size) do fonts.by_size[k] = nil end
    fonts.font_path = nil
    fonts.default = nil
    log_verbose("All fonts cleared")

    queue_rebuild()
end

function fonts.list_available()
    local available = {}

    local fonts_path = get_fonts_dir()

    fs.ensure_dir(fonts_path)

    for _, f in ipairs(fs.list(fonts_path, "ttf")) do
        local name = f:match("([^\\]+)%.ttf$") or f:match("([^/]+)%.ttf$") or f:match("(.+)$")
        if name then
            available[#available + 1] = name:match("%.ttf$") and name or (name .. ".ttf")
        end
    end

    for _, f in ipairs(fs.list(fonts_path, "otf")) do
        local name = f:match("([^\\]+)%.otf$") or f:match("([^/]+)%.otf$") or f:match("(.+)$")
        if name then
            available[#available + 1] = name:match("%.otf$") and name or (name .. ".otf")
        end
    end

    return available
end

return fonts
