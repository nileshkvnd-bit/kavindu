local Hints = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")

local type <const> = type
local pairs <const> = pairs
local tostring <const> = tostring
local get_time <const> = runtime.now

local HINT_TTL <const> = 0.1
local HINT_KEYS <const> = { text = true, description = true, hotkey = true, favorite = true }
local HOTKEY_KEYS <const> = { action_id = true, label = true, path = true }
local FAVORITE_KEYS <const> = { action_id = true, label = true, path = true, is_favorite = true }


local function clear_hint(hint_state)
    hint_state.current = nil
    hint_state.last_update = 0
    hint_state.payload = nil
    hint_state.bounds = nil
end

local function validate_hint(hint)
    assert(type(hint) == "table", "[Hints] hint table is required")
    for key in pairs(hint) do
        if HINT_KEYS[key] ~= true then
            error("[Hints] unsupported hint field: " .. tostring(key), 0)
        end
    end
    assert(type(hint.text) == "string" and hint.text ~= "", "[Hints] hint.text is required")

    if hint.description ~= nil then
        assert(type(hint.description) == "string", "[Hints] hint.description must be a string")
    end

    if hint.hotkey ~= nil then
        assert(type(hint.hotkey) == "table", "[Hints] hint.hotkey must be a table")
        for key in pairs(hint.hotkey) do
            if HOTKEY_KEYS[key] ~= true then
                error("[Hints] unsupported hint.hotkey field: " .. tostring(key), 0)
            end
        end
        assert(type(hint.hotkey.action_id) == "string" and hint.hotkey.action_id ~= "", "[Hints] hint.hotkey.action_id is required")
        if hint.hotkey.label ~= nil then
            assert(type(hint.hotkey.label) == "string", "[Hints] hint.hotkey.label must be a string")
        end
        if hint.hotkey.path ~= nil then
            assert(type(hint.hotkey.path) == "string", "[Hints] hint.hotkey.path must be a string")
        end
    end

    if hint.favorite ~= nil then
        assert(type(hint.favorite) == "table", "[Hints] hint.favorite must be a table")
        for key in pairs(hint.favorite) do
            if FAVORITE_KEYS[key] ~= true then
                error("[Hints] unsupported hint.favorite field: " .. tostring(key), 0)
            end
        end
        assert(type(hint.favorite.action_id) == "string" and hint.favorite.action_id ~= "", "[Hints] hint.favorite.action_id is required")
        if hint.favorite.label ~= nil then
            assert(type(hint.favorite.label) == "string", "[Hints] hint.favorite.label must be a string")
        end
        if hint.favorite.path ~= nil then
            assert(type(hint.favorite.path) == "string", "[Hints] hint.favorite.path must be a string")
        end
        if hint.favorite.is_favorite ~= nil then
            assert(type(hint.favorite.is_favorite) == "boolean", "[Hints] hint.favorite.is_favorite must be a boolean")
        end
    end
end

function Hints.update(hint, x, y, w, h)
    validate_hint(hint)

    local hint_state = state.ui.menu_hint
    hint_state.current = hint.text
    hint_state.payload = hint
    hint_state.last_update = get_time()

    local bounds = hint_state.bounds
    if not bounds then
        bounds = {}
        hint_state.bounds = bounds
    end
    bounds.x = x or 0
    bounds.y = y or 0
    bounds.w = w or 0
    bounds.h = h or 0
    return true
end

function Hints.clear()
    clear_hint(state.ui.menu_hint)
end

function Hints.expire(now)
    local hint_state = state.ui.menu_hint
    if not hint_state or not hint_state.current then return false end
    if (now or get_time()) - hint_state.last_update <= HINT_TTL then return false end
    clear_hint(hint_state)
    return true
end

function Hints.get_hotkey_target()
    local hint_state = state.ui.menu_hint
    if not hint_state or not hint_state.payload then return nil end
    if Hints.expire() then return nil end

    local hotkey = hint_state.payload.hotkey
    if not hotkey or not hotkey.action_id then return nil end

    local b = hint_state.bounds
    return {
        action_id = hotkey.action_id,
        label = hotkey.label,
        path = hotkey.path,
        description = hint_state.payload.description,
        bounds = b and { x = b.x, y = b.y, w = b.w, h = b.h } or nil,
    }
end

function Hints.get_favorite_target()
    local hint_state = state.ui.menu_hint
    if not hint_state or not hint_state.payload then return nil end
    if Hints.expire() then return nil end

    local favorite = hint_state.payload.favorite
    if not favorite or not favorite.action_id then return nil end

    local b = hint_state.bounds
    return {
        action_id = favorite.action_id,
        label = favorite.label,
        path = favorite.path,
        is_favorite = favorite.is_favorite == true,
        description = hint_state.payload.description,
        bounds = b and { x = b.x, y = b.y, w = b.w, h = b.h } or nil,
    }
end

return Hints
