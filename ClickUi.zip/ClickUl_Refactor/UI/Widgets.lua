local widgets = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local layout = require("ClickUl_Refactor.UI.Layout.Init")
local utf8_utils = require("ClickUl_Refactor.Core.Utf8")
local icons = require("ClickUl_Refactor.UI.Icons")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local string_id = require("ClickUl_Refactor.Core.StringId")
local hints = require("ClickUl_Refactor.UI.Hints")

local math_floor <const> = math.floor
local math_max <const> = math.max
local math_min <const> = math.min
local math_abs <const> = math.abs
local string_len <const> = string.len
local string_sub <const> = string.sub
local string_find <const> = string.find
local string_format <const> = string.format
local get_time <const> = runtime.now
local table_insert <const> = table.insert
local table_concat <const> = table.concat
local ipairs <const> = ipairs
local tostring <const> = tostring
local type <const> = type

local get_clean_label <const> = renderer.get_clean_label
local get_text_width <const> = renderer.get_text_width
local get_color <const> = renderer.get_color
local draw_rect <const> = renderer.draw_rect
local draw_rect_ex <const> = renderer.draw_rect_ex
local draw_text <const> = renderer.draw_text
local draw_text_ex <const> = renderer.draw_text_ex
local draw_text_right <const> = renderer.draw_text_right
local draw_widget_background <const> = renderer.draw_widget_background
local draw_slider_background <const> = renderer.draw_slider_background
local draw_image <const> = renderer.draw_image
local push_clip <const> = renderer.push_clip
local pop_clip <const> = renderer.pop_clip
local get_visual_y <const> = renderer.get_visual_y
local is_item_visible <const> = renderer.is_item_visible
local s_func <const> = renderer.s
local is_mouse_in <const> = input_module.is_mouse_in
local is_mouse_in_scroll_bounds <const> = input_module.is_mouse_in_scroll_bounds

local slider_value_cache = {}
local get_str_id <const> = string_id.concat

local cp_hex_cache = {}

local function is_interaction_blocked(ui, id)
    if ui.sticky_header_hover then return true end
    if ui.active_combo and ui.active_combo ~= id then return true end
    if ui.active_id and ui.active_id ~= id and not ui.text_input_active then return true end
    return false
end

local function widget_hover(ui, x, y, w, h, id, check_scroll_bounds)
    if is_interaction_blocked(ui, id) then return false end
    if check_scroll_bounds and not is_mouse_in_scroll_bounds() then return false end
    return is_mouse_in(x, y, w, h)
end

local function draw_toggle_switch(tx, ty, tw, th, anim_progress, track_rounding, knob_size, knob_offset, knob_rounding)
    if anim_progress < 0.01 then
        draw_rect(tx, ty, tw, th, "Toggle Inactive", track_rounding)
    elseif anim_progress > 0.99 then
        draw_rect(tx, ty, tw, th, "Toggle Active", track_rounding)
    else
        draw_rect(tx, ty, tw, th, "Toggle Inactive", track_rounding)
        draw_rect_ex(tx, ty, tw, th, "Toggle Active", track_rounding, nil, anim_progress)
    end
    local kx_off = tx + knob_offset
    local kx_on = tx + tw - knob_size - knob_offset
    local kx = kx_off + (kx_on - kx_off) * anim_progress
    local knob_color = anim_progress > 0.5 and "Knob Active" or "Knob Inactive"
    draw_rect(kx, ty + (th - knob_size) * 0.5, knob_size, knob_size, knob_color, knob_rounding or knob_size * 0.5)
end

local progress_pct_cache = {}
for i = 0, 100 do
    progress_pct_cache[i] = tostring(i) .. "%"
end

local function trigger_click_anim(x, y, w, h)
    table_insert(state.ui.click_animations, {
        x = x, y = y, w = w, h = h,
        start_time = get_time(),
        duration = state.constants.CLICK_ANIMATION_DURATION
    })
end

local function get_checkbox_anim(id)
    local anims = state.ui.checkbox_animations
    if not anims[id] then
        anims[id] = { progress = 0, target = 0, last_update = 0 }
    end
    return anims[id]
end

local function update_checkbox_anim(id, is_checked)
    local anim = get_checkbox_anim(id)
    local target = is_checked and 1 or 0
    if anim.target ~= target then
        anim.target = target
        anim.last_update = get_time()
    end
    local diff = anim.target - anim.progress
    if math_abs(diff) > 0.001 then
        local dt = state.ui.delta_time or 0.016
        anim.progress = anim.progress + diff * math_min(1, 8 * dt)
    else
        anim.progress = anim.target
    end
    return anim.progress
end

local function draw_combo_dropdown(args)
    local ui = state.ui
    local c_state = ui.combo_states[args.id]
    if not c_state then return end

    local x, y, w, h = args.x, args.y, args.w, args.h
    local options = args.options
    local count = #options
    local vis_count = math_min(count, args.max_visible)
    local list_h = vis_count * h
    local ly = y + h + args.gap

    draw_rect_ex(x, ly, w, list_h, "Combo Background", args.rounding)

    local start_idx = c_state.scroll_idx
    local has_scrollbar = count > args.max_visible
    local sb_hit_x, sb_hit_w, sb_hit_h = 0, 0, 0
    if has_scrollbar then
        local max_scroll = count - vis_count

        if is_mouse_in(x, ly, w, list_h) then
             local delta = input_module.get_scroll_delta()
             if delta ~= 0 then
                 c_state.scroll_idx = math_max(1, math_min(max_scroll + 1, math_floor(c_state.scroll_idx + delta)))
                 ui.scroll_consumed = true
             end
        end

        local sb_w = args.sb_width
        local bar_x = x + w - sb_w - s_func(2)
        local bar_h = list_h - args.gap
        local sb_id = get_str_id(args.id, "_sb")
        sb_hit_x, sb_hit_w, sb_hit_h = bar_x - 5, sb_w + 10, bar_h

        local is_hover = is_mouse_in(sb_hit_x, ly, sb_hit_w, sb_hit_h)
        if ui["input"].mouse_left_pressed and is_hover and not ui.active_id then
            state.capture_active_id(sb_id)
        end

        if ui.active_id == sb_id then
            if not ui["input"].mouse_left_pressed then ui.active_id = nil
            else
                local r = (ui["input"].mouse_pos.y - ly) / bar_h
                c_state.scroll_idx = math_floor(r * max_scroll) + 1
            end
        end

        c_state.scroll_idx = math_max(1, math_min(c_state.scroll_idx, max_scroll + 1))
        start_idx = c_state.scroll_idx

        local ratio = vis_count / count
        local th = math_max(args.thumb_min, bar_h * ratio)
        local ty_offset = ((bar_h - th) * ((start_idx - 1) / max_scroll))
        local sb_col = (ui.active_id == sb_id) and "Scrollbar Hover" or "Scrollbar"
        draw_rect_ex(bar_x, ly + ty_offset, sb_w, th, sb_col, s_func(2))
    end

    local end_idx = math_min(count, start_idx + vis_count - 1)
    for i = start_idx, end_idx do
        local rel_i = i - start_idx
        local iy = ly + (rel_i * h)

        if is_mouse_in(x, iy, w, h) then
            draw_rect_ex(x, iy, w, h, "Combo Highlight", args.gap)
            if ui["input"].mouse_left_just_pressed
               and not (has_scrollbar and is_mouse_in(sb_hit_x, ly, sb_hit_w, sb_hit_h)) then
                c_state.pending_selection = i
                ui.active_combo = nil
            end
        end

        local col = (i == args.current_index) and "Accent" or "Text Primary"
        draw_text_ex(options[i], x + args.padding, iy, args.font, col, nil, h)
    end

    if ui["input"].mouse_left_just_pressed and not is_mouse_in(x, ly, w, list_h) and not is_mouse_in(x, y, w, h) then
        ui.active_combo = nil
    end
end

function widgets.ButtonWithStar(label, is_favorite, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.button_h or cfg.item_h
    local vy = get_visual_y()
    local button_clicked = false
    local star_clicked = false

    local star_size = h * 0.45
    local star_x = ui.cx + w - star_size - 6
    local star_y = vy + (h - star_size) / 2

    if is_item_visible(vy, h) then
        local star_hover = widget_hover(ui, star_x, star_y, star_size, star_size, nil, true)

        local btn_hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if btn_hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if ui_input.mouse_left_just_pressed then
            if star_hover then
                star_clicked = true
                trigger_click_anim(star_x, star_y, star_size, star_size)
            elseif btn_hover then
                button_clicked = true
                trigger_click_anim(ui.cx, vy, w, h)
            end
        end

        draw_widget_background(ui.cx, vy, w, h, btn_hover and not star_hover)

        draw_text(get_clean_label(label), ui.cx, vy, cfg.font_widget, btn_hover and "Text Primary" or "Text Secondary", w, h)

        local star_texture = icons.get("star")
        if star_texture then
            local star_color = is_favorite and "Accent" or (star_hover and "Text Primary" or "Text Secondary")
            local icon_col = get_color(star_color)
            draw_image(star_texture, star_x, star_y, star_size, star_size, icon_col)
        end
    end

    ui.cy = ui.cy + h + cfg.item_spacing
    return button_clicked, star_clicked
end

function widgets.Button(label, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.button_h or cfg.item_h
    local vy = get_visual_y()
    local clicked = false

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if hover and ui_input.mouse_left_just_pressed then
            clicked = true
            trigger_click_anim(ui.cx, vy, w, h)
        end

        draw_widget_background(ui.cx, vy, w, h, hover)
        draw_text(get_clean_label(label), ui.cx, vy, cfg.font_widget, hover and "Text Primary" or "Text Secondary", w, h)
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return clicked
end

function widgets.Checkbox(label, value, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if hover and ui_input.mouse_left_just_pressed then
            value = not value
            trigger_click_anim(ui.cx, vy, w, h)
        end

        draw_widget_background(ui.cx, vy, w, h, hover)

        local anim_id = state.get_widget_id(label)

        if cfg.checkbox_use_toggle_style then
            draw_text(get_clean_label(label), ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, (value or hover) and "Text Primary" or "Text Secondary", nil, h)

            local cw = cfg.checkbox_width
            local ch = cfg.checkbox_height
            local tx = ui.cx + w - cw - cfg.widget_text_padding
            local ty = vy + (h - ch) * 0.5

            local anim_progress = update_checkbox_anim(anim_id, value)

            draw_toggle_switch(tx, ty, cw, ch, anim_progress,
                cfg.checkbox_track_rounding, cfg.checkbox_knob_size, cfg.checkbox_knob_offset)
        else
            local box_size = cfg.checkbox_height
            local box_rounding = cfg.checkbox_knob_rounding
            local box_x = ui.cx + cfg.widget_text_padding
            local box_y = vy + (h - box_size) * 0.5

            local anim_progress = update_checkbox_anim(anim_id, value)

            draw_rect(box_x, box_y, box_size, box_size, "Checkbox Inactive", box_rounding)

            if anim_progress > 0.01 then
                local inner_margin = 3
                local inner_size = (box_size - inner_margin * 2) * anim_progress
                local inner_offset = (box_size - inner_size) * 0.5
                draw_rect(
                    box_x + inner_offset,
                    box_y + inner_offset,
                    inner_size,
                    inner_size,
                    "Checkbox Active",
                    math_max(1, box_rounding * anim_progress)
                )
            end

            local text_x = box_x + box_size + cfg.widget_text_padding
            draw_text(get_clean_label(label), text_x, vy, cfg.font_widget, (value or hover) and "Text Primary" or "Text Secondary", nil, h)
        end
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return value
end

function widgets.Toggle(label, value, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if hover and ui_input.mouse_left_just_pressed then
            value = not value
            trigger_click_anim(ui.cx, vy, w, h)
        end

        draw_widget_background(ui.cx, vy, w, h, hover)

        draw_text(get_clean_label(label), ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, (value or hover) and "Text Primary" or "Text Secondary", nil, h)

        local tw = cfg.toggle_width or cfg.checkbox_width
        local th = cfg.toggle_height or cfg.checkbox_height
        local tx = ui.cx + w - tw - cfg.widget_text_padding
        local ty = vy + (h - th) * 0.5

        local anim_progress = update_checkbox_anim(state.get_widget_id(label), value)

        draw_toggle_switch(tx, ty, tw, th, anim_progress,
            cfg.toggle_track_rounding, cfg.toggle_knob_size, cfg.toggle_knob_offset, cfg.toggle_knob_rounding)
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return value
end

function widgets.Slider(label, value, min, max, step, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    step = (type(step) == "number" and step > 0) and step or 1
    local w, h = layout.GetWidth(), cfg.item_h + cfg.slider_extra_height
    local vy = get_visual_y()
    local id_source = label
    local hash_at = string_find(label, "##", 1, true)
    if hash_at then id_source = string_sub(label, hash_at) end
    local id = state.get_widget_id(id_source)

    if is_item_visible(vy, h) or ui.active_id == id then
        local hover = widget_hover(ui, ui.cx, vy, w, h, id, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if hover and ui_input.mouse_left_just_pressed then state.capture_active_id(id) end

        local padding = cfg.widget_text_padding
        local track_x = ui.cx + padding
        local track_w = w - (padding * 2)

        if ui.active_id == id then
            if not ui_input.mouse_left_pressed then ui.active_id = nil
            else
                local r = (ui_input.mouse_pos.x - track_x) / track_w
                value = min + (math_max(0, math_min(1, r)) * (max - min))
                if step > 0 then value = math_floor((value / step) + 0.5) * step end
            end
        end

        value = math_max(min, math_min(value, max))

        draw_slider_background(ui.cx, vy, w, h, (ui.active_id == id or hover))
        draw_text(get_clean_label(label), track_x, vy + s_func(4), cfg.font_small, "Text Secondary")

        local st = slider_value_cache[id]
        if not st then
            st = { last_val = nil, text_cache = "" }
            slider_value_cache[id] = st
        end

        local PRECISION = 1000000
        local rounded_val = math_floor(value * PRECISION + 0.5) / PRECISION

        local vs = st.text_cache
        if st.last_val ~= rounded_val then
            if step % 1 == 0 then
                vs = tostring(math_floor(value))
            else
                vs = string_format("%.2f", value)
            end
            st.text_cache = vs
            st.last_val = rounded_val
        end

        draw_text_right(vs, ui.cx + w - padding, vy + s_func(4), cfg.font_small, "Accent")

        local sy = vy + cfg.slider_track_offset
        local sh = cfg.slider_height

        draw_rect(track_x, sy, track_w, sh, "Slider Empty", s_func(2))

        local ratio = (max ~= min) and ((value - min) / (max - min)) or 0
        local fill_w = ratio <= 0 and 0 or math_max(cfg.widget_rounding, track_w * ratio)
        local col = (ui.active_id == id or hover) and "Slider Filled Hover" or "Slider Filled"
        if fill_w > 0 then draw_rect(track_x, sy, fill_w, sh, col, s_func(2)) end
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return value
end

function widgets.Combo(label, current_index, options, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()

    if not options or #options == 0 then
        if is_item_visible(vy, h) then
            draw_widget_background(ui.cx, vy, w, h, false)
            draw_text("(Empty)", ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, "Text Secondary", nil, h)
        end
        ui.cy = ui.cy + h + cfg.item_spacing
        return current_index or 1
    end

    current_index = current_index or 1

    local id = state.get_widget_id(label)
    if not ui.combo_states[id] then
        ui.combo_states[id] = { scroll_idx = 1, dragging_sb = false }
    end
    local combo_state = ui.combo_states[id]

    if combo_state.pending_selection then
        current_index = combo_state.pending_selection
        combo_state.pending_selection = nil
    end

    if is_item_visible(vy, h) then
        local active = (ui.active_combo == id)
        local hover = widget_hover(ui, ui.cx, vy, w, h, id, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        draw_widget_background(ui.cx, vy, w, h, active or hover)
        draw_text(options[current_index] or "", ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, "Text Primary", nil, h)

        local clean = get_clean_label(label)
        draw_text_right(clean, ui.cx + w - cfg.widget_text_padding, vy, cfg.font_small, "Text Secondary", h)

        if active then
            if not combo_state.render_payload then
                combo_state.render_payload = {
                    func = draw_combo_dropdown,
                    args = {}
                }
            end

            local a = combo_state.render_payload.args
            a.id = id; a.options = options; a.current_index = current_index
            a.x = ui.cx; a.y = vy; a.w = w; a.h = h
            a.max_visible = cfg.combo_max_visible
            a.gap = cfg.combo_dropdown_gap; a.padding = cfg.widget_text_padding
            a.font = cfg.font_widget; a.rounding = cfg.widget_rounding
            a.thumb_min = cfg.combo_thumb_min; a.sb_width = cfg.scrollbar_width

            table_insert(ui.post_draw_queue, combo_state.render_payload)
        elseif hover and ui_input.mouse_left_just_pressed then
            ui.active_combo = id
            combo_state.scroll_idx = 1
            if current_index > (cfg.combo_max_visible) then
                combo_state.scroll_idx = math_max(1, current_index - 2)
            end
        end
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return current_index
end

local function ti_has_selection(st)
    return st.sel_start and st.sel_end and st.sel_start ~= st.sel_end
end

local function ti_get_selection_bounds(st)
    if not ti_has_selection(st) then return nil, nil end
    local s, e = st.sel_start, st.sel_end
    if s > e then s, e = e, s end
    return s, e
end

local function ti_delete_selection(st)
    if not ti_has_selection(st) then return false end
    local s, e = ti_get_selection_bounds(st)
    st.text = string_sub(st.text, 1, s) .. string_sub(st.text, e + 1)
    st.cursor_pos = s
    st.sel_start, st.sel_end = nil, nil
    return true
end

local function ti_get_selected_text(st)
    if not ti_has_selection(st) then return "" end
    local s, e = ti_get_selection_bounds(st)
    return string_sub(st.text, s + 1, e)
end

local function ti_calc_cursor_from_mouse(st, mouse_x, text_x, font_size)
    local rel_x = mouse_x - text_x
    if rel_x <= 0 then return 0 end
    local total_w, prev_w, pos = 0, 0, 0
    for char in st.text:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
        local next_pos = pos + #char
        total_w = total_w + get_text_width(char, font_size)
        if total_w > rel_x then
            return (rel_x - prev_w) < (total_w - rel_x) and pos or next_pos
        end
        prev_w = total_w
        pos = next_pos
    end
    return string_len(st.text)
end

local REPEAT_DELAY <const> = 0.4
local REPEAT_RATE <const> = 0.05

local function ti_should_repeat(st, key_func, key_code, time_field, now)
    local key_state = key_func(key_code)
    if key_state.just_pressed then
        st[time_field] = now
        return true
    elseif key_state.pressed then
        local elapsed = now - st[time_field]
        if elapsed > REPEAT_DELAY then
            local repeat_count = math_floor((elapsed - REPEAT_DELAY) / REPEAT_RATE)
            local last_repeat = st[time_field .. "_last"] or 0
            if repeat_count > last_repeat then
                st[time_field .. "_last"] = repeat_count
                return true
            end
        end
    else
        st[time_field] = 0
        st[time_field .. "_last"] = 0
    end
    return false
end

local function ti_activate(ui, st, id)
    ui.active_id = id
    st.active = true
    st.blink_time = get_time()
    ui.text_input_active = true
end

local function ti_deactivate(ui, st)
    ui.active_id = nil
    st.active = false
    ui.text_input_active = false
    st.sel_start, st.sel_end = nil, nil
    st.dragging = false
end

function widgets.TextInput(label, text, max_len)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()

    local id = state.get_widget_id(label)

    if not ui.input_states[id] then
        local initial = text or ""
        ui.input_states[id] = {
            text = initial,
            cursor_pos = utf8_utils.clamp_cursor_pos(initial, string_len(initial)),
            active = false,
            blink_time = 0,
            backspace_time = 0,
            delete_time = 0,
            left_time = 0,
            right_time = 0,
            sel_start = nil,
            sel_end = nil,
            dragging = false,
            scroll_x = 0
        }
    end
    local st = ui.input_states[id]
    local external_text = text or ""
    if not st.active and st.text ~= external_text then
        st.text = external_text
        st.cursor_pos = utf8_utils.clamp_cursor_pos(st.text, string_len(st.text))
        st.sel_start, st.sel_end = nil, nil
        st.scroll_x = 0
    end

    local active = (ui.active_id == id)
    if active and not is_item_visible(vy, h) then
        ti_deactivate(ui, st)
        active = false
    end

    if not active and st.active then
        st.active = false
        st.sel_start, st.sel_end = nil, nil
        st.dragging = false
    end

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, id, true)
        local tx = ui.cx + cfg.widget_text_padding

        if hover and ui["input"].mouse_left_just_pressed then
            if not active then
                ti_activate(ui, st, id)
            end
            local scroll_offset = st.scroll_x or 0
            local click_pos = ti_calc_cursor_from_mouse(st, ui["input"].mouse_pos.x, tx - scroll_offset, cfg.font_widget)
            st.cursor_pos = click_pos
            st.sel_start = click_pos
            st.sel_end = click_pos
            st.dragging = true
        elseif active and ui["input"].mouse_left_just_pressed and not hover then
            ti_deactivate(ui, st)
        end

        if active and st.dragging then
            if ui["input"].mouse_left_pressed then
                local scroll_offset = st.scroll_x or 0
                local drag_pos = ti_calc_cursor_from_mouse(st, ui["input"].mouse_pos.x, tx - scroll_offset, cfg.font_widget)
                st.cursor_pos = drag_pos
                st.sel_end = drag_pos
            else
                st.dragging = false
            end
        end

        if active then
            st.cursor_pos = utf8_utils.clamp_cursor_pos(st.text, st.cursor_pos)
        end

        if active then
            local key_func = input_module.get_key_state
            st.cursor_pos = utf8_utils.clamp_cursor_pos(st.text, st.cursor_pos)
            local text_len_bytes = string_len(st.text)
            local now = get_time()
            local max_chars = max_len or 64

            local ctrl = key_func(0x11).pressed or key_func(0xA2).pressed or key_func(0xA3).pressed
            local shift = key_func(0x10).pressed or key_func(0xA0).pressed or key_func(0xA1).pressed
            local caps_state = key_func(0x14)
            if caps_state and caps_state.just_pressed then
                ui.caps_lock = not ui.caps_lock
            end
            local caps = ui.caps_lock

            if ctrl and key_func(0x43).just_pressed then
                if ti_has_selection(st) then
                    local sel_text = ti_get_selected_text(st)
                    if sel_text ~= "" then
                        input_module.copy_to_clipboard(sel_text)
                    end
                end
            elseif ctrl and key_func(0x58).just_pressed then
                if ti_has_selection(st) then
                    local sel_text = ti_get_selected_text(st)
                    if sel_text ~= "" and input_module.copy_to_clipboard(sel_text) then
                        ti_delete_selection(st)
                    end
                end
            elseif ctrl and key_func(0x56).just_pressed then
                local clipboard = input_module.get_from_clipboard()
                if clipboard and clipboard ~= "" then
                    local PASTE_LIMIT = 2000
                    if #clipboard > PASTE_LIMIT then
                        clipboard = string_sub(clipboard, 1, PASTE_LIMIT)
                    end
                    clipboard = clipboard:gsub("[\r\n]", "")
                    ti_delete_selection(st)
                    local cur_chars = utf8_utils.char_count(st.text)
                    local paste_chars = utf8_utils.char_count(clipboard)
                    local available = max_chars - cur_chars
                    if available > 0 then
                        if paste_chars > available then
                            local truncated_parts = {}
                            local count = 0
                            for char in clipboard:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
                                if count >= available then break end
                                count = count + 1
                                truncated_parts[count] = char
                            end
                            clipboard = table_concat(truncated_parts)
                        end
                        st.text = string_sub(st.text, 1, st.cursor_pos) .. clipboard .. string_sub(st.text, st.cursor_pos + 1)
                        st.cursor_pos = st.cursor_pos + #clipboard
                    end
                end
            elseif ctrl and key_func(0x41).just_pressed then
                st.sel_start = 0
                st.sel_end = text_len_bytes
                st.cursor_pos = text_len_bytes
            elseif ti_should_repeat(st, key_func, 0x08, "backspace_time", now) then
                if ti_has_selection(st) then
                    ti_delete_selection(st)
                elseif st.cursor_pos > 0 then
                    local prev_pos = utf8_utils.prev_char_pos(st.text, st.cursor_pos)
                    st.text = string_sub(st.text, 1, prev_pos) .. string_sub(st.text, st.cursor_pos + 1)
                    st.cursor_pos = prev_pos
                end
            elseif ti_should_repeat(st, key_func, 0x2E, "delete_time", now) then
                if ti_has_selection(st) then
                    ti_delete_selection(st)
                elseif st.cursor_pos < text_len_bytes then
                    local next_pos = utf8_utils.next_char_pos(st.text, st.cursor_pos)
                    st.text = string_sub(st.text, 1, st.cursor_pos) .. string_sub(st.text, next_pos + 1)
                end
            elseif ti_should_repeat(st, key_func, 0x25, "left_time", now) and st.cursor_pos > 0 then
                local new_pos = utf8_utils.prev_char_pos(st.text, st.cursor_pos)
                if shift then
                    if not st.sel_start then st.sel_start = st.cursor_pos end
                    st.sel_end = new_pos
                else
                    st.sel_start, st.sel_end = nil, nil
                end
                st.cursor_pos = new_pos
            elseif ti_should_repeat(st, key_func, 0x27, "right_time", now) and st.cursor_pos < text_len_bytes then
                local new_pos = utf8_utils.next_char_pos(st.text, st.cursor_pos)
                if shift then
                    if not st.sel_start then st.sel_start = st.cursor_pos end
                    st.sel_end = new_pos
                else
                    st.sel_start, st.sel_end = nil, nil
                end
                st.cursor_pos = new_pos
            elseif key_func(0x24).just_pressed then
                if shift then
                    if not st.sel_start then st.sel_start = st.cursor_pos end
                    st.sel_end = 0
                else
                    st.sel_start, st.sel_end = nil, nil
                end
                st.cursor_pos = 0
            elseif key_func(0x23).just_pressed then
                if shift then
                    if not st.sel_start then st.sel_start = st.cursor_pos end
                    st.sel_end = text_len_bytes
                else
                    st.sel_start, st.sel_end = nil, nil
                end
                st.cursor_pos = text_len_bytes
            elseif key_func(0x0D).just_pressed or key_func(0x1B).just_pressed then
                ti_deactivate(ui, st)
            elseif not (ctrl and (key_func(0x43).pressed or key_func(0x56).pressed or
                                   key_func(0x58).pressed or key_func(0x41).pressed)) then
                for _, input_char in ipairs(input_module.get_text_chars()) do
                    local char = input_char
                    if type(input_char) == "table" then
                        local use_shift = shift
                        if input_char.code >= 0x41 and input_char.code <= 0x5A then
                            use_shift = (shift ~= caps)
                        end
                        char = use_shift and input_char.shift or input_char.char
                    end

                    if char and char ~= "" then
                        if ti_has_selection(st) then ti_delete_selection(st) end
                        if utf8_utils.char_count(st.text) < max_chars then
                            st.text = string_sub(st.text, 1, st.cursor_pos) .. char .. string_sub(st.text, st.cursor_pos + 1)
                            st.cursor_pos = st.cursor_pos + #char
                        end
                    end
                end
            end
        end

        draw_widget_background(ui.cx, vy, w, h, active or hover)

        local clean = get_clean_label(label)
        local lw = get_text_width(clean, cfg.font_small)

        local text_area_w
        if active then
            text_area_w = w - cfg.widget_text_padding * 2
        else
            draw_text_right(clean, ui.cx + w - cfg.widget_text_padding, vy, cfg.font_small, "Text Secondary", h)
            text_area_w = w - lw - cfg.widget_text_padding * 3
        end

        local disp = st.text
        if string_len(disp) == 0 and not active then
            draw_text("...", tx, vy, cfg.font_widget, "Text Secondary", nil, h)
        else
            if not st.scroll_x then st.scroll_x = 0 end

            local cursor_x = 0
            if active then
                cursor_x = get_text_width(string_sub(st.text, 1, st.cursor_pos), cfg.font_widget)
                local visible_start = st.scroll_x
                local visible_end = st.scroll_x + text_area_w

                if cursor_x < visible_start then
                    st.scroll_x = cursor_x
                elseif cursor_x > visible_end - s_func(2) then
                    st.scroll_x = cursor_x - text_area_w + s_func(2)
                end

                st.scroll_x = math_max(0, st.scroll_x)
            end

            push_clip(tx, vy, text_area_w, h)

            if active and ti_has_selection(st) then
                local sel_s, sel_e = ti_get_selection_bounds(st)
                local sel_x1 = tx + get_text_width(string_sub(st.text, 1, sel_s), cfg.font_widget) - st.scroll_x
                local sel_x2 = tx + get_text_width(string_sub(st.text, 1, sel_e), cfg.font_widget) - st.scroll_x
                draw_rect(sel_x1, vy + s_func(4), sel_x2 - sel_x1, h - s_func(8), "Accent")
            end

            draw_text(disp, tx - st.scroll_x, vy, cfg.font_widget, "Text Primary", nil, h)

            if active and not ti_has_selection(st) and ((get_time() - st.blink_time) % 1.0 < 0.5) then
                local cw = cursor_x - st.scroll_x
                draw_rect(tx + cw, vy + s_func(4), s_func(2), h - s_func(8), "Accent")
            end

            pop_clip()
        end
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return st.text, st.active
end

local cp_labels_cache = {}
local cp_expanded_state = {}

local function rgb_to_hex(r, g, b)
    return string_format("#%02X%02X%02X", math_floor(r), math_floor(g), math_floor(b))
end

function widgets.ColorPicker(label, tbl, key)
    if not tbl[key] then return false end

    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local c = tbl[key]
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()
    local is_expanded = cp_expanded_state[key] or false

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if hover and ui_input.mouse_left_just_pressed then
            cp_expanded_state[key] = not is_expanded
            is_expanded = cp_expanded_state[key]
            trigger_click_anim(ui.cx, vy, w, h)
        end

        draw_widget_background(ui.cx, vy, w, h, hover)

        local clean_label = get_clean_label(label)
        draw_text(clean_label, ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, hover and "Text Primary" or "Text Secondary", nil, h)

        local color_square_size = cfg.color_preview_height
        local padding = cfg.widget_text_padding
        local square_x = ui.cx + w - color_square_size - padding
        local square_y = vy + (h - color_square_size) * 0.5

        draw_rect(square_x, square_y, color_square_size, color_square_size, c, cfg.color_preview_rounding)

        local hex_text
        local hc = cp_hex_cache[key]
        if hc and hc.r == c.r and hc.g == c.g and hc.b == c.b then
            hex_text = hc.hex
        else
            hex_text = rgb_to_hex(c.r, c.g, c.b)
            cp_hex_cache[key] = { r = c.r, g = c.g, b = c.b, hex = hex_text }
        end
        local hex_w = get_text_width(hex_text, cfg.font_small)
        local hex_x = square_x - hex_w - s_func(8)
        draw_text(hex_text, hex_x, vy, cfg.font_small, "Text Secondary", nil, h)
    end

    ui.cy = ui.cy + h + cfg.item_spacing

    if is_expanded then
        if not cp_labels_cache[key] then
            cp_labels_cache[key] = { r="R##"..key, g="G##"..key, b="B##"..key, a="A##"..key }
        end
        local l = cp_labels_cache[key]

        local r = widgets.Slider(l.r, c.r, 0, 255, 1)
        local g = widgets.Slider(l.g, c.g, 0, 255, 1)
        local b = widgets.Slider(l.b, c.b, 0, 255, 1)
        local a = widgets.Slider(l.a, c.a, 0, 255, 1)

        if r~=c.r or g~=c.g or b~=c.b or a~=c.a then
            c.r,c.g,c.b,c.a = r,g,b,a
            renderer.invalidate_color(key)
            return true
        end
    end
    return false
end

function widgets.Selectable(label, selected, tags, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w, h = layout.GetWidth(), cfg.item_h
    local vy = get_visual_y()
    local clicked = false

    if is_item_visible(vy, h) then
        local hover = widget_hover(ui, ui.cx, vy, w, h, nil, true)

        if hover and hint then
            hints.update(hint, ui.cx, vy, w, h)
        end

        if hover and ui_input.mouse_left_just_pressed then
            clicked = true
            trigger_click_anim(ui.cx, vy, w, h)
        end

        local bg = selected and "Player Selected Background" or (hover and "Widget Hover" or "Widget Background")
        draw_rect(ui.cx, vy, w, h, bg, cfg.widget_rounding)

        local col = selected and "Accent" or (hover and "Text Primary" or "Text Secondary")
        draw_text(get_clean_label(label), ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, col, nil, h)

        if tags then
            local tx = ui.cx + w - cfg.widget_text_padding
            local f_small = cfg.font_small
            local ts = s_func(4)
            for i = #tags, 1, -1 do
                local tag = tags[i]
                local tw = get_text_width(tag.text, f_small)
                tx = tx - tw - ts
                if tx > ui.cx + s_func(100) then
                    renderer.draw_text_ex(tag.text, tx, vy, f_small, tag.color or "Text Secondary", nil, h, 1.0, nil, get_str_id("tag:", tag.text))
                end
            end
        end
    end
    ui.cy = ui.cy + h + cfg.item_spacing
    return clicked
end

local inline_tab_widths = {}

function widgets.InlineTabBar(options, current_idx)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local h = cfg.inline_tab_height
    local vy = get_visual_y()
    local font_size = cfg.font_small
    local indicator_h = cfg.inline_tab_indicator_height

    if is_item_visible(vy, h) then
        local gap = cfg.inline_tab_gap

        for i = 1, #inline_tab_widths do inline_tab_widths[i] = nil end
        for i, name in ipairs(options) do
            inline_tab_widths[i] = get_text_width(name, font_size) + s_func(16)
        end

        local tx = ui.cx
        for i, name in ipairs(options) do
            local tab_w = inline_tab_widths[i]
            local active = (i == current_idx)
            local hover = widget_hover(ui, tx, vy, tab_w, h, nil, true)

            local col = active and "Inline Tab Active" or (hover and "Text Primary" or "Inline Tab Inactive")
            draw_text(name, tx, vy, font_size, col, tab_w, h - indicator_h)

            if active then
                draw_rect(tx, vy + h - indicator_h, tab_w, indicator_h, "Inline Tab Indicator", s_func(1))
            end

            if hover and ui_input.mouse_left_just_pressed and i ~= current_idx then
                current_idx = i
                state.reset_interaction()
            end

            tx = tx + tab_w + gap
        end
    end

    ui.cy = ui.cy + h + (cfg.item_spacing)
    return current_idx
end

function widgets.Text(text, color_key)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local h = cfg.item_h
    local vy = get_visual_y()

    if is_item_visible(vy, h) then
        draw_text(text, ui.cx + cfg.widget_text_padding, vy, cfg.font_widget, color_key or "Text Secondary", nil, h)
    end

    ui.cy = ui.cy + h + cfg.item_spacing
end

function widgets.Separator(label)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local w = layout.GetWidth()
    local line_h = cfg.separator_height
    local margin = cfg.separator_margin
    local font_size = cfg.font_small
    local vy = get_visual_y()

    local total_h = margin * 2 + (label and label ~= "" and font_size or line_h)
    local center_y = vy + total_h * 0.5
    local line_y = center_y - line_h * 0.5

    if is_item_visible(vy, total_h) then
        if label and label ~= "" then
            local text_w = get_text_width(label, font_size)
            local text_padding = s_func(8)
            local text_x = ui.cx + (w - text_w) * 0.5

            local left_w = text_x - text_padding - ui.cx
            if left_w > 0 then
                draw_rect(ui.cx, line_y, left_w, line_h, "Separator Line")
            end

            draw_text(label, text_x, vy, font_size, "Separator Text", text_w, total_h)

            local right_x = text_x + text_w + text_padding
            local right_w = ui.cx + w - right_x
            if right_w > 0 then
                draw_rect(right_x, line_y, right_w, line_h, "Separator Line")
            end
        else
            draw_rect(ui.cx, line_y, w, line_h, "Separator Line")
        end
    end

    ui.cy = ui.cy + total_h + cfg.item_spacing
end

function widgets.ProgressBar(label, value, color_key)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local w = layout.GetWidth()
    local h = cfg.progress_height
    local item_h = cfg.item_h
    local vy = get_visual_y()

    value = math_max(0, math_min(1, value or 0))

    if is_item_visible(vy, item_h) then
        local padding = cfg.widget_text_padding
        local bar_y = vy + (item_h - h) * 0.5
        local bar_rounding = cfg.progress_rounding

        draw_rect(ui.cx, bar_y, w, h, "Progress Background", bar_rounding)

        local fill_w = value <= 0 and 0 or math_max(bar_rounding, w * value)
        if fill_w > 0 then draw_rect(ui.cx, bar_y, fill_w, h, color_key or "Progress Fill", bar_rounding) end

        if label and label ~= "" then
            draw_text(label, ui.cx + padding, vy, cfg.font_small, "Text Secondary", nil, item_h * 0.5)
        end

        local pct_int = math_floor(value * 100)
        local pct_str = progress_pct_cache[pct_int] or (tostring(pct_int) .. "%")
        local pct_w = get_text_width(pct_str, cfg.font_small)
        draw_text(pct_str, ui.cx + w - pct_w - padding, vy, cfg.font_small, "Text Primary", nil, item_h * 0.5)
    end

    ui.cy = ui.cy + item_h + (cfg.item_spacing)
    return value
end

function widgets.ToggleSlider(label, toggle, value, min, max, step, hint)
    local ui = state.ui
    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local ui_input = ui["input"]
    local w = layout.GetWidth()
    local total_h = cfg.toggle_slider_height
    
    local id = state.get_widget_id(label)
    local vy = get_visual_y()
    
    local new_toggle = toggle
    local new_value = value
    
    local visible = is_item_visible(vy, total_h)
    
    local slider_id = get_str_id("slider_", tostring(id))
    if visible or ui.active_id == slider_id then
        local hover = widget_hover(ui, ui.cx, vy, w, total_h, slider_id, true)
        
        if hover and hint then
            hints.update(hint, ui.cx, vy, w, total_h)
        end
        
        draw_slider_background(ui.cx, vy, w, total_h, hover or ui.active_id == slider_id)
        
        local padding = cfg.toggle_slider_padding
        local top_y = vy + s_func(4)
        local label_offset = cfg.toggle_slider_label_offset
        local track_offset = cfg.toggle_slider_track_offset
        local sy = vy + track_offset
        local sh = cfg.toggle_slider_track_height
        local box_size = cfg.toggle_slider_checkbox_size
        local box_rounding = cfg.toggle_slider_checkbox_rounding
        local box_x = ui.cx + padding
        local box_y = sy + (sh - box_size) * 0.5
        local track_x = box_x + box_size + label_offset
        local track_w = w - (track_x - ui.cx) - padding
        
        local anim_progress = update_checkbox_anim(id, toggle)
        
        draw_rect(box_x, box_y, box_size, box_size, "Checkbox Inactive", box_rounding)
        
        if anim_progress > 0.01 then
            local inner_margin = 3
            local inner_size = (box_size - inner_margin * 2) * anim_progress
            local inner_offset = (box_size - inner_size) * 0.5
            draw_rect(
                box_x + inner_offset,
                box_y + inner_offset,
                inner_size,
                inner_size,
                "Checkbox Active",
                math_max(1, box_rounding * anim_progress)
            )
        end
        
        draw_text(get_clean_label(label), ui.cx + padding, top_y, cfg.font_small, "Text Secondary")
        
        local vt = slider_value_cache[slider_id]
        if not vt then
            vt = { last_val = nil, text_cache = "" }
            slider_value_cache[slider_id] = vt
        end
        if vt.last_val ~= value then
            vt.text_cache = string_format("%.1f", value)
            vt.last_val = value
        end
        draw_text_right(vt.text_cache, ui.cx + w - padding, top_y, cfg.font_small, "Accent")
        
        draw_rect(track_x, sy, track_w, sh, "Slider Empty", s_func(2))
        
        local ratio = (max ~= min) and ((new_value - min) / (max - min)) or 0
        ratio = math_max(0, math_min(1, ratio))
        local fill_w = ratio <= 0 and 0 or math_max(cfg.widget_rounding, track_w * ratio)
        local col = (ui.active_id == slider_id or hover) and "Slider Filled Hover" or "Slider Filled"
        if fill_w > 0 then
            draw_rect(track_x, sy, fill_w, sh, col, s_func(2))
        end
        
        local slider_hover = widget_hover(ui, track_x, sy - s_func(10), track_w, sh + s_func(20), slider_id, true)
        if ui_input.mouse_left_just_pressed then
            if slider_hover then
                state.capture_active_id(slider_id)
            elseif hover then
                new_toggle = not toggle
            end
        end
        
        if ui.active_id == slider_id then
            if ui_input.mouse_left_pressed then
                local mouse_x = ui_input.mouse_pos.x
                local rel_x = mouse_x - track_x
                local new_normalized = math_max(0, math_min(1, rel_x / track_w))
                new_value = min + new_normalized * (max - min)
                if step > 0 then
                    new_value = math_floor((new_value / step) + 0.5) * step
                end
                new_value = math_max(min, math_min(max, new_value))
            else
                ui.active_id = nil
            end
        end
    end
    
    ui.cy = ui.cy + total_h + cfg.item_spacing
    return new_toggle, new_value
end

function widgets.clear_cache()
    slider_value_cache = {}
    cp_labels_cache = {}
    cp_hex_cache = {}
    if state.ui and state.ui.checkbox_animations then
        state.ui.checkbox_animations = {}
    end
end

return widgets
