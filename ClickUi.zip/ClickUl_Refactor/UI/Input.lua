local input_module = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local input_adapter = require("ClickUl_Refactor.Adapters.Input")
local events_adapter = require("ClickUl_Refactor.Adapters.Events")
local key_codes = require("ClickUl_Refactor.Core.KeyCodes")

local tostring <const> = tostring
local pairs <const> = pairs

local event_subscriptions = {}
local pending_key_pressed = nil
local pending_char_pressed = nil
local pending_text_chars = {}
local pending_scroll_delta = 0
local text_chars = {}

local function subscribe_event(name, event_type, callback)
    if event_subscriptions[name] then return end
    event_subscriptions[name] = events_adapter.subscribe(event_type, callback)
end

function input_module.init_events()
    local evt = events_adapter.event

    subscribe_event("key_press", evt.key_press, function(data)
        pending_key_pressed = data.key
    end)

    subscribe_event("char_press", evt.char_press, function(data)
        pending_char_pressed = data.char
        if data.char and data.char ~= "" then
            pending_text_chars[#pending_text_chars + 1] = data.char
        end
    end)

    subscribe_event("scroll", evt.scroll, function(data)
        pending_scroll_delta = pending_scroll_delta + (data.offset or 0)
    end)

    return true
end

function input_module.shutdown_events()
    for name, id in pairs(event_subscriptions) do
        if id ~= nil then events_adapter.unsubscribe(id) end
        event_subscriptions[name] = nil
    end

    pending_key_pressed = nil
    pending_char_pressed = nil
    pending_text_chars = {}
    pending_scroll_delta = 0
    text_chars = {}

    local inp = state.ui["input"]
    inp.key_pressed = nil
    inp.char_pressed = nil
    inp.text_chars = text_chars
    inp.scroll_delta = 0
end

function input_module.clear_frame_events()
    local inp = state.ui["input"]
    inp.key_pressed = pending_key_pressed
    inp.char_pressed = pending_char_pressed

    local previous = text_chars
    text_chars = pending_text_chars
    pending_text_chars = previous
    for i = #previous, 1, -1 do previous[i] = nil end

    inp.text_chars = text_chars
    inp.scroll_delta = pending_scroll_delta
    pending_key_pressed = nil
    pending_char_pressed = nil
    pending_scroll_delta = 0
end

function input_module.get_key_pressed()
    return state.ui["input"].key_pressed
end

function input_module.get_text_chars()
    return state.ui["input"].text_chars or {}
end

function input_module.get_scroll_delta()
    return state.ui["input"].scroll_delta or 0
end

function input_module.get_key_name(vk_code)
    return key_codes.get_key_name(vk_code)
end

function input_module.get_vk_names()
    return key_codes.get_vk_names()
end

function input_module.is_modifier_key(vk_code)
    return key_codes.is_modifier_key(vk_code)
end

function input_module.format_keybind(vk_code, ctrl, shift, alt)
    return key_codes.format_keybind(vk_code, ctrl, shift, alt)
end

function input_module.get_vk_list()
    return key_codes.get_vk_list()
end

function input_module.get_key_lookup()
    return key_codes.get_key_lookup()
end

local cached_mouse_pos = nil
local cached_mouse_state = nil

function input_module.update_mouse_state()
    cached_mouse_pos = input_adapter.mouse_position()
    if cached_mouse_pos then
        state.ui["input"].mouse_pos.x = cached_mouse_pos.x
        state.ui["input"].mouse_pos.y = cached_mouse_pos.y
    end
    cached_mouse_state = input_adapter.mouse(1)
    if cached_mouse_state then
        state.ui["input"].mouse_left_pressed = cached_mouse_state.pressed
        state.ui["input"].mouse_left_just_pressed = cached_mouse_state.just_pressed
    end
end

function input_module.get_key_state(vk)
    return input_adapter.key(vk)
end

function input_module.is_mouse_left_just_pressed()
    local ms = cached_mouse_state
    return ms and ms.just_pressed or false
end

function input_module.is_mouse_in(x, y, w, h)
    local mx, my = state.ui["input"].mouse_pos.x, state.ui["input"].mouse_pos.y
    return mx >= x and mx <= x + w and my >= y and my <= y + h
end

function input_module.is_mouse_in_scroll_bounds()
    local ui = state.ui
    if not ui.scroll_ctx then return true end
    local my = ui["input"].mouse_pos.y
    local content_y = ui.scroll_ctx.content_y
    local view_h = ui.scroll_ctx.view_h
    return my >= content_y and my <= content_y + view_h
end

function input_module.block_game_controls()
    input_adapter.disable_input(state.ui.open and state.ui.block_input and state.ui.block_input_toggle)
end

function input_module.handle_dragging(x, y, w, h)
    local ui = state.ui
    if ui["input"].mouse_left_pressed and input_module.is_mouse_in(x, y, w, h) then
        if not ui.dragging then
            ui.dragging = true
            ui.drag_offset.x = ui["input"].mouse_pos.x - x
            ui.drag_offset.y = ui["input"].mouse_pos.y - y
        end
    elseif not ui["input"].mouse_left_pressed then
        if ui.dragging then
            ui.dragging = false
            state.deps.config_sys.mark_autosave_dirty()
        end
    end

    if ui.dragging then
        local config_sys = state.deps.config_sys
        config_sys.data.base.x = ui["input"].mouse_pos.x - ui.drag_offset.x
        config_sys.data.base.y = ui["input"].mouse_pos.y - ui.drag_offset.y
    end
end

function input_module.copy_to_clipboard(text)
    if not text then return false end

    input_adapter.set_clipboard_text(tostring(text))
    return true
end

function input_module.get_from_clipboard()
    return input_adapter.get_clipboard_text()
end

return input_module
