local HotkeyEditor = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local hints = require("ClickUl_Refactor.UI.Hints")
local gui_adapter = require("ClickUl_Refactor.Adapters.Gui")

local ROUND_TOP <const> = gui_adapter.rounding.top_left + gui_adapter.rounding.top_right
local ROUND_BOTTOM <const> = gui_adapter.rounding.bottom_left + gui_adapter.rounding.bottom_right

local BACKDROP_COLOR <const> = { r = 0, g = 0, b = 0, a = 130 }

local hotkeys = nil
local lang = nil
local notify = nil

local F10 <const> = 0x79
local ESC <const> = 0x1B
local BACKSPACE <const> = 0x08
local DELETE <const> = 0x2E
local ACTIVE_ID <const> = "hotkey_editor"
local SLOT_LABEL_KEYS <const> = { "Slot 1", "Slot 2" }

local dialog = {
    open = false,
    target = nil,
}

local card_cache = { action_id = nil, revision = nil }

local desc_cache = { text = nil, wrap = nil, h = 0 }

local function slot_binding_text(action_id, slot)
    local rev = hotkeys.get_revision()
    if card_cache.action_id ~= action_id or card_cache.revision ~= rev then
        card_cache.action_id = action_id
        card_cache.revision = rev
        card_cache[1] = nil
        card_cache[2] = nil
    end
    local text = card_cache[slot]
    if text == nil then
        local binding = hotkeys.get_binding(action_id, slot)
        text = binding and hotkeys.format_binding(binding) or false
        card_cache[slot] = text
    end
    return text
end

local function _T(text)
    return lang.get(text)
end

local function clear_active_id()
    if state.ui.active_id == ACTIVE_ID then
        state.ui.active_id = nil
    end
end

local function close_dialog(cancel_capture)
    dialog.open = false
    dialog.target = nil
    clear_active_id()
    if cancel_capture and hotkeys then
        hotkeys.cancel_capture()
    end
end

local function open_target(target)
    if not target or not target.action_id then return false end
    if not hotkeys.get_action(target.action_id) then return false end

    dialog.open = true
    dialog.target = target
    state.capture_active_id(ACTIVE_ID)
    return true
end

local function describe_capture_result(result)
    if not result then return end

    if result.status == "saved" then
        notify(_T("Hotkey saved") .. ": " .. hotkeys.format_binding(result.binding), "Success")
    elseif result.status == "cleared" then
        notify(_T("Hotkey cleared"), "Info")
    elseif result.status == "cancelled" then
        notify(_T("Hotkey capture cancelled"), "Info")
    elseif result.status == "protected" then
        notify(_T("Cannot clear the last binding of the menu key"), "Warning")
    elseif result.status == "reserved" then
        notify(_T("F10 is reserved for the hotkey editor"), "Warning")
    elseif result.status == "conflict" then
        local conflict = result.conflict
        local action = conflict and conflict.action
        local label = action and _T(action.label) or tostring(conflict and conflict.action_id or "")
        notify(_T("Hotkey conflict") .. ": " .. label, "Warning")
    end
end

local function consume_capture_result(result)
    if result then
        hotkeys.consume_capture_result()
        describe_capture_result(result)
        return true
    end

    result = hotkeys.consume_capture_result()
    if result then
        describe_capture_result(result)
        return true
    end

    return false
end

local function button(x, y, w, h, label)
    local ui = state.ui
    local cfg = ui.cfg_current or state.deps.config_sys.data.current
    local hover = input_module.is_mouse_in(x, y, w, h)
    renderer.draw_rect_ex(x, y, w, h, hover and "Widget Hover" or "Widget Background", cfg.widget_rounding)
    renderer.draw_text(label, x, y, cfg.font_small, hover and "Text Primary" or "Text Secondary", w, h)
    return hover and input_module.is_mouse_left_just_pressed()
end

local function slot_card(x, y, w, h, action_id, slot)
    local ui = state.ui
    local cfg = ui.cfg_current or state.deps.config_sys.data.current
    local s = renderer.s
    local capture = hotkeys.get_capture()
    local capturing = capture ~= nil and capture.action_id == action_id and capture.slot == slot
    local binding_text = slot_binding_text(action_id, slot)
    local hover = input_module.is_mouse_in(x, y, w, h)

    local border = capturing and "Accent" or "Separator Line"
    local bg = "Widget Background"
    if capturing or hover then bg = "Widget Hover" end
    renderer.draw_rect_ex(x, y, w, h, border, cfg.widget_rounding)
    renderer.draw_rect_ex(x + s(1), y + s(1), w - s(2), h - s(2), bg, cfg.widget_rounding)

    renderer.draw_text(_T(SLOT_LABEL_KEYS[slot]), x, y + s(9), cfg.font_small, "Text Secondary", w, s(14))

    local key_text, key_color
    if capturing then
        key_text = _T("Press a key")
        key_color = "Text Primary"
    elseif binding_text then
        key_text = binding_text
        key_color = "Text Primary"
    else
        key_text = _T("Unbound")
        key_color = "Text Secondary"
    end
    renderer.draw_text(key_text, x, y + s(30), cfg.font_group, key_color, w, s(22))

    if hover and binding_text and not capturing then
        local zone = s(22)
        local zx, zy = x + w - zone - s(2), y + s(2)
        local zone_hover = input_module.is_mouse_in(zx, zy, zone, zone)
        renderer.draw_text("×", zx, zy, cfg.font_group, zone_hover and "Text Primary" or "Text Secondary", zone, zone)
        if zone_hover and input_module.is_mouse_left_just_pressed() then return "clear" end
    end

    if hover and input_module.is_mouse_left_just_pressed() then return "capture" end
    return nil
end

local function run_slot_action(kind, action_id, slot)
    if kind == "capture" then
        hotkeys.begin_capture(action_id, slot)
        return
    end
    if kind ~= "clear" then return end
    local action = hotkeys.get_action(action_id)
    local other = slot == 1 and 2 or 1
    if action and action.always_enabled and not hotkeys.get_binding(action_id, other) then
        notify(_T("Cannot clear the last binding of the menu key"), "Warning")
        return
    end
    hotkeys.clear_binding(action_id, slot)
    notify(_T("Hotkey cleared"), "Info")
end

function HotkeyEditor.init(ctx)
    hotkeys = assert(ctx.hotkeys, "[HotkeyEditor] hotkeys is required")
    lang = assert(ctx.lang, "[HotkeyEditor] lang is required")
    notify = assert(ctx.notify, "[HotkeyEditor] notify function is required")
    return true
end

function HotkeyEditor.close()
    close_dialog(true)
end

function HotkeyEditor.open(target)
    return open_target(target)
end

function HotkeyEditor.is_open()
    return dialog.open
end

function HotkeyEditor.handle_frame(capture_result)
    if not state.ui.open then
        if dialog.open then close_dialog(true) end
        return false
    end

    local handled_capture = consume_capture_result(capture_result)
    local key = input_module.get_key_pressed()

    if state.ui.text_input_active then
        return key == F10 or handled_capture
    end

    if dialog.open then
        state.capture_active_id(ACTIVE_ID)
        if key == ESC then
            close_dialog(true)
        elseif (key == BACKSPACE or key == DELETE) and not capture_result and dialog.target then
            local _, mode = hotkeys.clear_action(dialog.target.action_id)
            notify(mode == "defaults" and _T("Hotkeys reset") or _T("Hotkey cleared"), "Info")
        end
        return true
    end

    if key ~= F10 then return handled_capture end

    open_target(hints.get_hotkey_target())
    return true
end

function HotkeyEditor.draw()
    if not dialog.open or not dialog.target then return end

    local ui = state.ui
    local cfg = ui.cfg_current or state.deps.config_sys.data.current
    local s = renderer.s
    local target = dialog.target
    local action = hotkeys.get_action(target.action_id)
    if not action then
        close_dialog(true)
        return
    end

    local pad = s(16)
    local gap = s(10)
    local path_text = target.path
    local has_path = path_text ~= nil and path_text ~= ""
    local header_h = has_path and s(52) or s(34)
    local card_h = s(62)
    local button_h = s(30)
    local footer_h = s(32)

    local panel_w = s(440)
    local avail_w = panel_w - pad * 2

    local desc = target.description or action.description
    local has_desc = desc ~= nil and desc ~= ""
    local desc_h = 0
    if has_desc then
        if desc_cache.text ~= desc or desc_cache.wrap ~= avail_w then
            local dims = renderer.wrapped_text_size(desc, cfg.font_small, avail_w)
            desc_cache.text = desc
            desc_cache.wrap = avail_w
            desc_cache.h = (dims and dims.y and dims.y > 0) and dims.y or s(18)
        end
        desc_h = desc_cache.h + s(10)
    end

    local panel_h = header_h + s(14) + desc_h + card_h + s(16) + button_h + s(14) + footer_h

    local screen = ui.screen_res
    renderer.draw_rect_ex(0, 0, screen.x, screen.y, nil, 0, nil, nil, BACKDROP_COLOR)

    local x = math.floor((screen.x - panel_w) * 0.5)
    local y = math.floor((screen.y - panel_h) * 0.5)

    renderer.draw_rect_ex(x, y, panel_w, panel_h, "Group Background", cfg.group_rounding)
    renderer.draw_rect_ex(x, y, panel_w, header_h, "Widget Background", cfg.group_rounding, ROUND_TOP)
    renderer.draw_rect_ex(x, y + header_h, panel_w, s(1), "Accent", 0)

    local title = target.label or _T(action.label) or target.action_id
    renderer.draw_text(title, x + pad, y + s(9), cfg.font_group, "Text Primary")
    if has_path then
        renderer.draw_text(path_text, x + pad, y + s(30), cfg.font_small, "Text Secondary")
    end

    local cy = y + header_h + s(14)
    if has_desc then
        renderer.draw_wrapped_text(desc, x + pad, cy, cfg.font_small, "Text Secondary", avail_w)
        cy = cy + desc_h
    end

    local card_w = (avail_w - gap) / 2
    run_slot_action(slot_card(x + pad, cy, card_w, card_h, target.action_id, 1), target.action_id, 1)
    run_slot_action(slot_card(x + pad + card_w + gap, cy, card_w, card_h, target.action_id, 2), target.action_id, 2)
    cy = cy + card_h + s(16)

    local btn_w = s(86)
    local bx = x + panel_w - pad - (btn_w * 3 + gap * 2)
    if button(bx, cy, btn_w, button_h, _T("Clear")) then
        local _, mode = hotkeys.clear_action(target.action_id)
        notify(mode == "defaults" and _T("Hotkeys reset") or _T("Hotkey cleared"), "Info")
    end
    bx = bx + btn_w + gap
    if button(bx, cy, btn_w, button_h, _T("Reset")) then
        hotkeys.reset_action(target.action_id)
        notify(_T("Hotkeys reset"), "Warning")
    end
    bx = bx + btn_w + gap
    if button(bx, cy, btn_w, button_h, _T("Close")) then
        close_dialog(true)
    end
    cy = cy + button_h + s(14)

    renderer.draw_rect_ex(x, cy, panel_w, footer_h, "Widget Background", cfg.group_rounding, ROUND_BOTTOM)
    local capture = hotkeys.get_capture()
    local footer_text = capture and _T("Press any key to bind · ESC to cancel · Backspace to clear this slot")
        or _T("Click a slot to rebind · ESC to cancel · Backspace to clear all hotkeys")
    renderer.draw_text(footer_text, x + pad, cy, cfg.font_small, "Text Secondary", panel_w - pad * 2, footer_h)

    if not capture and input_module.is_mouse_left_just_pressed()
        and not input_module.is_mouse_in(x, y, panel_w, panel_h) then
        close_dialog(true)
    end
end

return HotkeyEditor
