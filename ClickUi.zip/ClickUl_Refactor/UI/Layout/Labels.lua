local Labels = {}

local string_find <const> = string.find
local string_gsub <const> = string.gsub
local string_sub <const> = string.sub

local stable_cache = {}
local display_cache = {}
local collapsible_cache = {}
local cache_count = 0
local CACHE_LIMIT <const> = 6000

local function check_limit()
    if cache_count < CACHE_LIMIT then return end
    stable_cache = {}
    display_cache = {}
    collapsible_cache = {}
    cache_count = 0
end

function Labels.stable_id(label)
    if not label then return "unknown" end
    local cached = stable_cache[label]
    if cached ~= nil then return cached end
    check_limit()
    local s, e = string_find(label, "###", 1, true)
    local result = s and string_sub(label, e + 1) or label
    stable_cache[label] = result
    cache_count = cache_count + 1
    return result
end

function Labels.display_label(label)
    if not label then return "" end
    local cached = display_cache[label]
    if cached ~= nil then return cached end
    check_limit()
    local s = string_find(label, "##", 1, true)
    local result = s and string_sub(label, 1, s - 1) or label
    display_cache[label] = result
    cache_count = cache_count + 1
    return result
end

function Labels.collapsible_id(label)
    local cached = collapsible_cache[label]
    if cached ~= nil then return cached end
    check_limit()
    local result
    local hash_pos = string_find(label, "###", 1, true)
    if hash_pos then
        result = string_sub(label, hash_pos + 3)
    else
        result = (string_gsub(label, " %(%d+%)$", ""))
    end
    collapsible_cache[label] = result
    cache_count = cache_count + 1
    return result
end

return Labels
