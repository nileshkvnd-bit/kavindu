local Navigation = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local input_module = require("ClickUl_Refactor.UI.Input")

local ipairs <const> = ipairs
local get_visual_y <const> = renderer.get_visual_y
local is_item_visible <const> = renderer.is_item_visible
local truncate_text <const> = renderer.truncate_text
local draw_rect <const> = renderer.draw_rect
local draw_text <const> = renderer.draw_text
local s_func <const> = renderer.s
local load_image <const> = renderer.load_image
local get_make_color <const> = renderer.get_color
local push_clip <const> = renderer.push_clip
local pop_clip <const> = renderer.pop_clip
local is_mouse_in <const> = input_module.is_mouse_in

local failed_sidebar_textures = {}

function Navigation.clear_failed_sidebar_textures()
    failed_sidebar_textures = {}
end

function Navigation.install(layout)
    function layout.Sidebar(tabs, keys)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local x, y, hh = state.deps.config_sys.data.base.x, state.deps.config_sys.data.base.y, cfg.header_h
        local sw = cfg.sidebar_w
        local start_y = y + hh + cfg.content_padding_y
        local btn_h = sw - cfg.sidebar_btn_margin * 2
        local icons = state.deps.config_sys.data.sidebar_icons or {}
        local clicked = false

        for i, label in ipairs(tabs) do
            local btn_y = start_y + ((i - 1) * (btn_h + cfg.sidebar_btn_spacing))
            local active = (ui.active_tab == i)
            local hover = is_mouse_in(x, btn_y, sw, btn_h)

            draw_rect(x + cfg.sidebar_btn_margin, btn_y, btn_h, btn_h, active and "Tab Background Active" or (hover and "Tab Background Hover" or "Tab Background"), cfg.sidebar_btn_rounding)

            local tab_key = keys and keys[i]
            local img = tab_key and icons[tab_key]
            local drawn = false
            if img and img ~= "None" and not failed_sidebar_textures[img] then
                 if not ui.sidebar_textures[tab_key] then
                     local path = renderer.get_assets_dir() .. "Images\\" .. img
                     local s, t = pcall(load_image, path)
                     if s and t then
                         ui.sidebar_textures[tab_key] = t
                     else
                         failed_sidebar_textures[img] = true
                     end
                 end
                 if ui.sidebar_textures[tab_key] then
                     local isz = cfg.sidebar_icon_size
                     renderer.draw_image(ui.sidebar_textures[tab_key], x+(sw-isz)*0.5, btn_y+(btn_h-isz)*0.5, isz, isz, get_make_color(active and "Tab Text Active" or "Text Primary"))
                     drawn = true
                 end
            end
            if not drawn then
                 draw_text(label, x, btn_y, cfg.font_tab, active and "Tab Text Active" or "Tab Text Inactive", sw, btn_h)
            end

            if hover and ui["input"].mouse_left_just_pressed then
                if not ui.active_special_page then
                    state.save_tab_scroll(ui.active_tab)
                end
                ui.active_tab = i
                clicked = true
                state.reset_interaction()
                if not state.restore_tab_scroll(i) then
                    ui.scroll_y = 0
                    ui.scroll_target = 0
                end
            end
        end

        if not ui.is_clipped then
            push_clip(ui.clip_rect.x, ui.clip_rect.y, ui.clip_rect.w, ui.clip_rect.h)
            ui.is_clipped = true
        end
        return clicked
    end

    function layout.SubTabBar(options, current_idx)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current

        if not options or #options == 0 then return current_idx or 1 end

        local w = layout.GetWidth()
        local h = cfg.subtab_height
        local font_size = cfg.font_subtab
        local is_in_scroll = ui.in_scroll_context

        local vy
        if is_in_scroll then
            vy = get_visual_y()
        else
            vy = ui.header_end_y
            if ui.is_clipped then
                pop_clip()
                ui.is_clipped = false
            end
        end

        local count = #options
        local gap = cfg.subtab_gap
        local tab_w = (w - (count-1)*gap) / count
        local padding = cfg.subtab_text_padding or s_func(8)
        local max_text_w = tab_w - padding

        local should_draw = true
        if is_in_scroll then
            should_draw = is_item_visible(vy, h)
        end

        if should_draw then
            for i, name in ipairs(options) do
                local tx = ui.cx + (i-1)*(tab_w+gap)
                local active = (i == current_idx)
                local hover = is_mouse_in(tx, vy, tab_w, h)
                draw_rect(tx, vy, tab_w, h, active and "Subtab Active" or (hover and "Subtab Hover" or "Subtab Background"), cfg.subtab_rounding)
                local truncated = truncate_text(name, font_size, max_text_w)
                draw_text(truncated, tx, vy, font_size, active and "Subtab Text Active" or "Subtab Text Inactive", tab_w, h)
                if hover and ui["input"].mouse_left_just_pressed and i ~= current_idx then
                    current_idx = i
                    state.reset_interaction()
                end
            end
        end

        local subtab_total_h = h + cfg.subtab_spacing_after

        if not is_in_scroll then
            local new_clip_y = ui.clip_rect.y + subtab_total_h
            local new_clip_h = ui.clip_rect.h - subtab_total_h
            if new_clip_h > 0 then
                push_clip(ui.clip_rect.x, new_clip_y, ui.clip_rect.w, new_clip_h)
                ui.is_clipped = true
                ui.subtab_offset = subtab_total_h
            end
        end

        if ui.cy < subtab_total_h then
            ui.cy = subtab_total_h
        end
        return current_idx
    end

    function layout.SubTabBar2(options, current_idx)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current

        if not options or #options == 0 then return current_idx or 1 end
        local w = layout.GetWidth()
        local h = cfg.subtab_height
        local font_size = cfg.font_subtab
        local vy = ui.header_end_y + (ui.subtab_offset or 0)

        if ui.is_clipped then
            pop_clip()
            ui.is_clipped = false
        end

        local count = #options
        local gap = cfg.subtab_gap
        local tab_w = (w - (count-1)*gap) / count
        local padding = cfg.subtab_text_padding or s_func(8)
        local max_text_w = tab_w - padding

        for i, name in ipairs(options) do
            local tx = ui.cx + (i-1)*(tab_w+gap)
            local active = (i == current_idx)
            local hover = is_mouse_in(tx, vy, tab_w, h)
            draw_rect(tx, vy, tab_w, h, active and "Subtab Active" or (hover and "Subtab Hover" or "Subtab Background"), cfg.subtab_rounding)
            local truncated = truncate_text(name, font_size, max_text_w)
            draw_text(truncated, tx, vy, font_size, active and "Subtab Text Active" or "Subtab Text Inactive", tab_w, h)
            if hover and ui["input"].mouse_left_just_pressed and i ~= current_idx then
                current_idx = i
                state.reset_interaction()
            end
        end

        local subtab_total_h = h + cfg.subtab_spacing_after
        local new_offset = (ui.subtab_offset or 0) + subtab_total_h
        local new_clip_y = ui.clip_rect.y + new_offset
        local new_clip_h = ui.clip_rect.h - new_offset
        if new_clip_h > 0 then
            push_clip(ui.clip_rect.x, new_clip_y, ui.clip_rect.w, new_clip_h)
            ui.is_clipped = true
            ui.subtab_offset = new_offset
        end

        if ui.cy < new_offset then
            ui.cy = new_offset
        end

        return current_idx
    end
end

return Navigation
