local Window = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local logger = require("ClickUl_Refactor.Core.Logger")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local gui_adapter = require("ClickUl_Refactor.Adapters.Gui")
local metrics = require("ClickUl_Refactor.UI.Layout.Metrics")
local icons = require("ClickUl_Refactor.UI.Icons")

local math_floor <const> = math.floor
local math_max <const> = math.max
local math_min <const> = math.min
local math_exp <const> = math.exp
local get_time <const> = runtime.now
local table_remove <const> = table.remove
local ipairs <const> = ipairs
local type <const> = type

local draw_rect <const> = renderer.draw_rect
local draw_rect_ex <const> = renderer.draw_rect_ex
local draw_text <const> = renderer.draw_text
local draw_image <const> = renderer.draw_image
local get_make_color <const> = renderer.get_color
local s_func <const> = renderer.s
local vn_func <const> = renderer.vn
local pop_clip <const> = renderer.pop_clip
local is_mouse_in <const> = input_module.is_mouse_in
local get_color_alpha <const> = renderer.get_color_alpha

local ROUND_TOP_LEFT <const> = gui_adapter.rounding.top_left
local ROUND_TOP_RIGHT <const> = gui_adapter.rounding.top_right
local ROUND_BOTTOM_LEFT <const> = gui_adapter.rounding.bottom_left
local ROUND_BOTTOM_RIGHT <const> = gui_adapter.rounding.bottom_right

local anim_color_cache = {r=255, g=255, b=255, a=0}

local star_bounds_scratch = {}

local function header_star_bounds(ui, x, y, w, hh)
    local spec = ui.header_star
    if not spec or type(spec.on_click) ~= "function" then return nil end

    local size = math_min(hh * 0.60, s_func(24))
    local right_margin = s_func(4)
    local hit_pad = s_func(8)
    local bx = x + w - size - right_margin
    local hit_x = bx - hit_pad

    local b = star_bounds_scratch
    b.x = hit_x
    b.y = y
    b.w = (x + w) - hit_x
    b.h = hh
    b.icon_x = bx
    b.icon_y = y + (hh - size) * 0.5
    b.size = size
    return b
end

local function draw_header_star(ui, x, y, w, hh)
    local spec = ui.header_star
    if not spec or type(spec.on_click) ~= "function" then return nil end

    local bounds = header_star_bounds(ui, x, y, w, hh)
    if not bounds then return nil end

    local hover = is_mouse_in(bounds.x, bounds.y, bounds.w, bounds.h)
    if hover and ui["input"].mouse_left_just_pressed then
        spec.on_click()
    end

    local active = type(spec.is_active) == "function" and spec.is_active() or spec.active == true
    local texture = icons.get("star")
    if texture then
        local color_key = active and "Accent" or (hover and "Text Primary" or "Header Text")
        draw_image(texture, bounds.icon_x, bounds.icon_y, bounds.size, bounds.size, get_make_color(color_key))
    end

    return bounds
end

local function reset_frame_state(ui)
    local pdq = ui.post_draw_queue
    for i = 1, #pdq do pdq[i] = nil end
    ui.layout_counter = 0
    ui.scroll_consumed = false
    ui.subtab_offset = 0
    ui.sticky_header_hover = false
    ui.sticky_stack_offset = 0

    state.reset_widget_id_counter()

    local delta_time = runtime.delta_time()
    if delta_time <= 0 then delta_time = 0.016 end
    ui.delta_time = delta_time
end

local function setup_content_area(ui, cfg_current, x, y, w, h, hh, sw)
    local content_rect = ui.content_rect
    if not content_rect then
        content_rect = { x = 0, y = 0, w = 0, h = 0 }
        ui.content_rect = content_rect
    end
    content_rect.x = x + sw; content_rect.y = y + hh
    content_rect.w = w - sw; content_rect.h = h - hh

    local content_padding_y = cfg_current.content_padding_y
    local clip_y = content_rect.y + content_padding_y
    local clip_h = content_rect.h - (content_padding_y * 2)

    ui.visible_h = clip_h
    ui.header_end_y = clip_y
    local cr = ui.clip_rect
    cr.x = content_rect.x; cr.y = clip_y; cr.w = content_rect.w; cr.h = clip_h
    ui.is_clipped = false

    return clip_y, clip_h
end

local function draw_window_chrome(ui, cfg, cfg_current, title, x, y, w, h, hh, sw)
    local r_tl = s_func(cfg.base.window_rounding_tl or 12)
    local r_tr = s_func(cfg.base.window_rounding_tr or 12)
    local r_bl = s_func(cfg.base.window_rounding_bl or 12)
    local r_br = s_func(cfg.base.window_rounding_br or 12)

    local max_r = math_max(r_tl, r_tr, r_bl, r_br)
    local r_flags = 0
    if r_tl > 0 then r_flags = r_flags + ROUND_TOP_LEFT end
    if r_tr > 0 then r_flags = r_flags + ROUND_TOP_RIGHT end
    if r_bl > 0 then r_flags = r_flags + ROUND_BOTTOM_LEFT end
    if r_br > 0 then r_flags = r_flags + ROUND_BOTTOM_RIGHT end

    if ui.bg_texture then
        local user_alpha = cfg.bg_image_opacity or 255
        local bg_col = get_color_alpha("Background Tint", user_alpha * (1 / 255))
        renderer.draw_image_rounded(ui.bg_texture, x, y, w, h, max_r, bg_col, r_flags)
    else
        draw_rect(x, y, w, h, "Window Background", max_r, r_flags)
    end

    local h_r_tl = s_func(cfg.base.header_rounding_tl or 12)
    local h_r_tr = s_func(cfg.base.header_rounding_tr or 12)
    local h_max_r = math_max(h_r_tl, h_r_tr)
    local h_flags = 0
    if h_r_tl > 0 then h_flags = h_flags + ROUND_TOP_LEFT end
    if h_r_tr > 0 then h_flags = h_flags + ROUND_TOP_RIGHT end
    draw_rect(x, y, w, hh, "Header Background", h_max_r, h_flags)

    local f_header = vn_func(cfg_current.font_header) > 0 and cfg_current.font_header or 17
    draw_text(title, x, y, f_header, "Header Text", w, hh)
    draw_header_star(ui, x, y, w, hh)

    local div_w = cfg_current.divider_width
    local div_padding_y = cfg_current.divider_padding
    local gap_start = x + sw - cfg_current.sidebar_btn_margin
    local gap_end = x + sw + (cfg_current.padding * 0.5)
    local div_x = (gap_start + gap_end) * 0.5
    local div_y1 = y + hh + div_padding_y
    local div_y2 = y + h - div_padding_y
    renderer.draw_line(div_x, div_y1, div_x, div_y2, div_w, "Group Header Line")
end

local function update_main_scroll(ui, cfg_current, clip_y, clip_h, delta_time)
    local content_rect = ui.content_rect
    local adjusted_clip_y = clip_y + (ui.subtab_offset or 0)
    local adjusted_clip_h = clip_h - (ui.subtab_offset or 0)
    local max_scroll = math_max(0, vn_func(ui.content_h) - vn_func(ui.visible_h) + s_func(20))
    local sb_w = cfg_current.scrollbar_width

    if max_scroll > 0 then
        if is_mouse_in(content_rect.x, content_rect.y, content_rect.w, content_rect.h)
           and not ui.scroll_consumed
           and not ui.active_combo
        then
            local speed = cfg_current.scroll_speed
            local delta = input_module.get_scroll_delta()
            if delta ~= 0 then
                ui.scroll_target = ui.scroll_target + delta * speed
            end
        end

        local sb_hit_w = math_max(sb_w, cfg_current.scrollbar_hit_width)
        local is_hovering = is_mouse_in(content_rect.x + content_rect.w - sb_w - s_func(2) - (sb_hit_w - sb_w), adjusted_clip_y, sb_hit_w, adjusted_clip_h)

        if ui["input"].mouse_left_pressed and is_hovering and not ui.active_id and not ui.active_combo then
            state.capture_active_id("window_scrollbar")
        end

        if ui.active_id == "window_scrollbar" then
            if not ui["input"].mouse_left_pressed then ui.active_id = nil
            else
                local ratio = (ui["input"].mouse_pos.y - adjusted_clip_y) / adjusted_clip_h
                ui.scroll_target = math_max(0, math_min(1, ratio)) * max_scroll
            end
        end
    end

    if ui.skip_scroll_clamp then
        ui.skip_scroll_clamp = false
    else
        if ui.scroll_target < 0 then ui.scroll_target = 0 elseif ui.scroll_target > max_scroll then ui.scroll_target = max_scroll end
    end
    local smooth = 1.0 - math_exp(-10.0 * delta_time)
    ui.scroll_y = vn_func(ui.scroll_y) + (vn_func(ui.scroll_target) - vn_func(ui.scroll_y)) * smooth

    if max_scroll > 0 then
        local ratio = ui.visible_h / (ui.content_h + s_func(20))
        if ratio > 1 then ratio = 1 end
        local kh = math_max(cfg_current.scrollbar_thumb_min, adjusted_clip_h * ratio)
        local ky = adjusted_clip_y + ((adjusted_clip_h - kh) * (ui.scroll_y / max_scroll))
        local sb_x = content_rect.x + content_rect.w - sb_w - s_func(2)
        local sb_col = (ui.active_id == "window_scrollbar") and "Scrollbar Hover" or "Scrollbar"
        draw_rect(sb_x, ky, sb_w, kh, sb_col, s_func(2))
    end
end

local function run_post_draw(ui, cfg_current)
    for _, item in ipairs(ui.post_draw_queue) do
        if type(item) == "function" then item()
        elseif item.func then item.func(item.args) end
    end

    local now = get_time()
    for i = #ui.click_animations, 1, -1 do
        local anim = ui.click_animations[i]
        local progress = (now - anim.start_time) / cfg_current.click_anim_duration
        if progress >= 1 then table_remove(ui.click_animations, i)
        else
            anim_color_cache.a = math_floor((1 - progress) * cfg_current.click_anim_alpha)
            draw_rect_ex(anim.x, anim.y, anim.w, anim.h, nil, cfg_current.widget_rounding, nil, nil, anim_color_cache)
        end
    end
end

function Window.install(layout)
    function layout.draw_window(title, content_callback)
        local ui = state.ui
        local config_sys = state.deps.config_sys

        if not ui.open then return end

        metrics.reset_width_cache()

        local logging_enabled = logger.get_config().enabled
        if logging_enabled then logger.mark_start("ui_draw_window") end

        renderer.update_scale()
        local cfg = config_sys.data
        local cfg_current = cfg.current
        if not cfg_current.w then
            if logging_enabled then logger.mark_end("ui_draw_window") end
            return
        end

        ui.cfg_current = cfg_current

        reset_frame_state(ui)

        local x, y = cfg.base.x, cfg.base.y
        local w, h = cfg_current.w, cfg_current.h
        local hh = cfg_current.header_h
        local sw = cfg_current.sidebar_w

        local star_bounds = header_star_bounds(ui, x, y, w, hh)
        if not (star_bounds and is_mouse_in(star_bounds.x, star_bounds.y, star_bounds.w, star_bounds.h)) then
            input_module.handle_dragging(x, y, w, hh)
        elseif not ui["input"].mouse_left_pressed then
            ui.dragging = false
        end

        local clip_y, clip_h = setup_content_area(ui, cfg_current, x, y, w, h, hh, sw)

        draw_window_chrome(ui, cfg, cfg_current, title, x, y, w, h, hh, sw)

        ui.cx = ui.content_rect.x + (cfg_current.padding * 0.5)
        ui.window_y_start = clip_y + cfg_current.window_content_offset
        ui.cy = 0
        ui.width_override = nil

        if content_callback then
            content_callback()
        end

        update_main_scroll(ui, cfg_current, clip_y, clip_h, ui.delta_time)

        run_post_draw(ui, cfg_current)

        if ui.is_clipped then pop_clip(); ui.is_clipped = false end
        ui.content_h = ui.cy

        layout.draw_menu_hints()

        if logging_enabled then logger.mark_end("ui_draw_window") end
    end
end

return Window
