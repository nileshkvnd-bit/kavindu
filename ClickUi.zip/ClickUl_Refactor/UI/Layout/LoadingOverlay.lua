local LoadingOverlay = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")

local pairs <const> = pairs
local string_format <const> = string.format
local math_max <const> = math.max
local math_min <const> = math.min
local math_floor <const> = math.floor
local get_time <const> = runtime.now
local s_func <const> = renderer.s
local draw_rect_ex <const> = renderer.draw_rect_ex
local draw_text_px <const> = renderer.draw_text_px
local get_make_color <const> = renderer.get_color

local MIN_LOADING_DISPLAY_TIME <const> = 2.0
local LOADING_TIMEOUT <const> = 5.0

local settings_store = nil

local function is_enabled()
    return settings_store.get_loading_overlay_enabled()
end

function LoadingOverlay.init(ctx)
    settings_store = assert(ctx.settings, "[LoadingOverlay] settings module is required")
end

function LoadingOverlay.show(label, progress)
    if not is_enabled() then return end
    local loading = state.ui.loading
    loading.items[label] = { progress = progress or 0, last_update = get_time() }
    loading.start_time = loading.start_time or get_time()
    loading.hide_requested = false
end

function LoadingOverlay.hide()
    local loading = state.ui.loading
    loading.hide_requested = true
    for _, v in pairs(loading.items) do
        v.progress = 1.0
    end
end

function LoadingOverlay.draw()
    if not is_enabled() then return end
    local loading = state.ui.loading
    local now = get_time()
    local item_count = 0
    for _ in pairs(loading.items) do item_count = item_count + 1 end

    if item_count == 0 then return end

    if loading.hide_requested then
        local elapsed = now - (loading.start_time or now)
        if elapsed >= MIN_LOADING_DISPLAY_TIME then
            loading.items = {}
            loading.hide_requested = false
            loading.start_time = nil
            return
        end
    end

    for k, v in pairs(loading.items) do
        if now - (v.last_update or now) > LOADING_TIMEOUT then
            loading.items[k] = nil
        end
    end

    local margin = s_func(20)
    local width = s_func(220)
    local item_height = s_func(36)
    local spacing = s_func(4)
    local padding = s_func(8)
    local rounding = s_func(6)
    local bar_height = s_func(4)

    local bg_color = get_make_color("Menu Hints Background")
    local text_color = get_make_color("Menu Hints Text")
    local track_color = get_make_color("Progress Background")
    local fill_color = get_make_color("Accent")

    local idx = 0
    for label, item in pairs(loading.items) do
        local ox = margin
        local oy = margin + idx * (item_height + spacing)

        draw_rect_ex(ox, oy, width, item_height, nil, rounding, nil, nil, bg_color)

        local font_size = s_func(12)
        local pct = math_floor(item.progress * 100 + 0.5)
        if item.pct_text_for ~= pct then
            item.pct_text = string_format("%s %d%%", label, pct)
            item.pct_text_for = pct
        end
        draw_text_px(item.pct_text, ox + padding, oy + padding, font_size, text_color)

        local bar_y = oy + item_height - bar_height - padding
        local bar_w = width - padding * 2
        draw_rect_ex(ox + padding, bar_y, bar_w, bar_height, nil, s_func(2), nil, nil, track_color)

        local fill_w = bar_w * math_max(0, math_min(1, item.progress))
        if fill_w > 0 then
            draw_rect_ex(ox + padding, bar_y, fill_w, bar_height, nil, s_func(2), nil, nil, fill_color)
        end

        idx = idx + 1
    end
end

function LoadingOverlay.install(layout)
    layout.show_loading = LoadingOverlay.show
    layout.hide_loading = LoadingOverlay.hide
    layout.draw_loading_overlay = LoadingOverlay.draw
end

return LoadingOverlay
