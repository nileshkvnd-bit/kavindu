local Groups = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local icons_module = require("ClickUl_Refactor.UI.Icons")
local string_id = require("ClickUl_Refactor.Core.StringId")
local labels = require("ClickUl_Refactor.UI.Layout.Labels")

local string_sub <const> = string.sub
local table_insert <const> = table.insert
local math_max <const> = math.max
local draw_rect <const> = renderer.draw_rect
local draw_text <const> = renderer.draw_text
local get_visual_y <const> = renderer.get_visual_y
local is_item_visible <const> = renderer.is_item_visible
local get_make_color <const> = renderer.get_color
local s_func <const> = renderer.s
local is_mouse_in <const> = input_module.is_mouse_in
local get_str_id <const> = string_id.concat
local get_display_label <const> = labels.display_label
local get_collapsible_id <const> = labels.collapsible_id

local function draw_collapsible_header(x, y, w, header_h, content_pad, group_rounding, header_font, display_label, expanded, hover)
    local header_color = hover and "Widget Hover" or "Collapsible Header"
    draw_rect(x, y, w, header_h, header_color, group_rounding)

    local arrow_texture = icons_module.get(expanded and "arrow_down" or "arrow_right")
    local arrow_x = x + content_pad
    local arrow_size = header_h * 0.4
    if arrow_texture then
        renderer.draw_image(arrow_texture, arrow_x, y + (header_h - arrow_size) / 2, arrow_size, arrow_size, get_make_color("Accent"))
    end

    draw_text(display_label, arrow_x + s_func(18), y, header_font, hover and "Text Primary" or "Group Header Text", nil, header_h)
end

local function render_sticky_header(args)
    local a = args
    draw_collapsible_header(a.cx, a.sticky_y, a.w, a.header_h, a.content_pad, a.group_rounding, a.header_font, a.display_label, a.expanded, a.hover)
end

local sticky_payload_cache = {}
local function get_sticky_payload(id)
    local payload = sticky_payload_cache[id]
    if payload then return payload end
    payload = { func = render_sticky_header, args = {} }
    sticky_payload_cache[id] = payload
    return payload
end

local function run_collapsible_content(layout, ui, label, content, args, w, content_pad, header_h, cache_id, group_spacing)
    local sy = ui.cy
    ui.cy = ui.cy + header_h
    local ox, ow = ui.cx, ui.width_override
    ui.cx = ui.cx + content_pad
    layout.OverrideWidth(w - (content_pad * 2))

    state.push_id_context(label)
    if args then content(args) else content() end
    state.pop_id_context()

    ui.cx = ox
    layout.OverrideWidth(ow)

    local content_height = ui.cy - sy - header_h
    ui.layout_cache[cache_id] = content_height

    local total_h = header_h + content_height + content_pad
    ui.cy = sy + total_h + group_spacing
end

function Groups.install(layout)
    function layout.Group(label, content, args)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local group_rounding = cfg.group_rounding
        local header_font = cfg.font_group

        local is_hidden_title = string_sub(label, 1, 2) == "##"
        local header_h = is_hidden_title and s_func(10) or cfg.group_header_height

        ui.layout_counter = ui.layout_counter + 1
        local id = get_str_id("grp_", label)
        local ch = ui.layout_cache[id]

        if ch and not is_item_visible(vy, ch) and not ui.active_id then
            ui.cy = ui.cy + ch + group_spacing
            return
        end

        local bg_h = ch or math_max(header_h, (ui.header_end_y + ui.visible_h) - vy)
        draw_rect(ui.cx, vy, w, bg_h, "Group Background", group_rounding)

        if not is_hidden_title then
            draw_text(label, ui.cx + content_pad, vy, header_font, "Group Header Text", nil, header_h)
        end

        local sy = ui.cy
        ui.cy = ui.cy + header_h
        local ox, ow = ui.cx, ui.width_override
        ui.cx = ui.cx + content_pad
        layout.OverrideWidth(w - (content_pad * 2))

        state.push_id_context(label)

        if content then if args then content(args) else content() end end

        state.pop_id_context()

        ui.cx = ox; layout.OverrideWidth(ow)

        local content_span = ui.cy - sy
        local total_h = math_max(header_h + content_pad, content_span + content_pad - cfg.item_spacing)
        ui.layout_cache[id] = total_h
        ui.cy = sy + total_h + group_spacing
    end

    function layout.Collapsible(label, content, args, default_expanded)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local header_h = cfg.group_header_height
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local group_rounding = cfg.group_rounding
        local header_font = cfg.font_group

        local id = get_collapsible_id(label)
        if ui.collapsible_states[id] == nil then
            ui.collapsible_states[id] = default_expanded or false
        end
        local expanded = ui.collapsible_states[id]

        ui.layout_counter = ui.layout_counter + 1
        local cache_id = get_str_id("col_", id)
        local cached_content_h = ui.layout_cache[cache_id]

        local force_render = expanded and (cached_content_h == nil)
        cached_content_h = cached_content_h or 0

        local total_h = expanded and (header_h + cached_content_h + content_pad) or header_h

        if not force_render and not is_item_visible(vy, total_h) and not ui.active_id then
            ui.cy = ui.cy + total_h + group_spacing
            return expanded
        end

        draw_rect(ui.cx, vy, w, total_h, "Group Background", group_rounding)

        local header_hover = is_mouse_in(ui.cx, vy, w, header_h)
        draw_collapsible_header(ui.cx, vy, w, header_h, content_pad, group_rounding, header_font, get_display_label(label), expanded, header_hover)

        if header_hover and ui["input"].mouse_left_just_pressed and not ui.active_combo and not ui.sticky_header_hover then
            expanded = not expanded
            ui.collapsible_states[id] = expanded
        end

        if expanded and content then
            run_collapsible_content(layout, ui, label, content, args, w, content_pad, header_h, cache_id, group_spacing)
        else
            ui.cy = ui.cy + header_h + group_spacing
        end

        return expanded
    end

    function layout.StickyCollapsible(label, content, args, default_expanded)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local header_h = cfg.group_header_height
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local group_rounding = cfg.group_rounding
        local header_font = cfg.font_group

        local id = get_collapsible_id(label)
        if ui.collapsible_states[id] == nil then
            ui.collapsible_states[id] = default_expanded or false
        end
        local expanded = ui.collapsible_states[id]

        ui.layout_counter = ui.layout_counter + 1
        local cache_id = get_str_id("col_", id)
        local cached_content_h = ui.layout_cache[cache_id]

        local force_render = expanded and (cached_content_h == nil)
        cached_content_h = cached_content_h or 0

        local total_h = expanded and (header_h + cached_content_h + content_pad) or header_h

        local scroll_ctx = ui.scroll_ctx
        local needs_sticky = false
        local sticky_y = 0

        if scroll_ctx and expanded then
            local effective_top = scroll_ctx.content_y + (ui.sticky_stack_offset or 0)
            local header_top = vy
            local content_bottom = vy + total_h

            if header_top < effective_top and content_bottom > effective_top + header_h then
                needs_sticky = true
                sticky_y = effective_top

                if is_mouse_in(ui.cx, sticky_y, w, header_h) then
                    ui.sticky_header_hover = true
                end
            end
        end

        if not force_render and not is_item_visible(vy, total_h) and not ui.active_id and not needs_sticky then
            ui.cy = ui.cy + total_h + group_spacing
            return expanded
        end

        draw_rect(ui.cx, vy, w, total_h, "Group Background", group_rounding)

        local header_hover = is_mouse_in(ui.cx, vy, w, header_h)
        if not needs_sticky then
            draw_collapsible_header(ui.cx, vy, w, header_h, content_pad, group_rounding, header_font, get_display_label(label), expanded, header_hover)
        end

        local clicked = false
        if not needs_sticky and header_hover and ui["input"].mouse_left_just_pressed
           and not ui.active_combo and not ui.sticky_header_hover then
            clicked = true
        end

        if needs_sticky then
            ui.sticky_stack_offset = (ui.sticky_stack_offset or 0) + header_h
        end

        if expanded and content then
            run_collapsible_content(layout, ui, label, content, args, w, content_pad, header_h, cache_id, group_spacing)
        else
            ui.cy = ui.cy + header_h + group_spacing
        end

        if needs_sticky then
            ui.sticky_stack_offset = (ui.sticky_stack_offset or 0) - header_h
        end

        if needs_sticky then
            local cx_capture = ui.cx
            local sticky_hover = is_mouse_in(cx_capture, sticky_y, w, header_h)

            if sticky_hover and ui["input"].mouse_left_just_pressed and not ui.active_combo then
                clicked = true
            end

            local payload = get_sticky_payload(id)
            local a = payload.args
            a.cx = cx_capture; a.sticky_y = sticky_y; a.w = w; a.header_h = header_h
            a.group_rounding = group_rounding; a.content_pad = content_pad
            a.header_font = header_font; a.expanded = expanded; a.hover = sticky_hover
            a.display_label = get_display_label(label)
            table_insert(ui.post_draw_queue, payload)
        end

        if clicked then
            expanded = not expanded
            ui.collapsible_states[id] = expanded
        end

        return expanded
    end
end

return Groups
