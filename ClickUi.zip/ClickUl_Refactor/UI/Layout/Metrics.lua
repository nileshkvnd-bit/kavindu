local Metrics = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")

local s_func <const> = renderer.s

local frame_width_cache = nil

function Metrics.reset_width_cache()
    frame_width_cache = nil
end

function Metrics.install(layout)
    function layout.GetWidth()
        local ui = state.ui
        if ui.width_override then return ui.width_override end
        if frame_width_cache then return frame_width_cache end

        local config_sys = state.deps.config_sys
        local cfg_current = config_sys.data.current
        frame_width_cache = cfg_current.w - cfg_current.sidebar_w - cfg_current.padding - s_func(8)
        return frame_width_cache
    end

    function layout.OverrideWidth(w)
        state.ui.width_override = w
    end
end

return Metrics
