local ScrollGroups = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local string_id = require("ClickUl_Refactor.Core.StringId")
local labels = require("ClickUl_Refactor.UI.Layout.Labels")

local math_max <const> = math.max
local math_min <const> = math.min
local math_exp <const> = math.exp
local draw_rect <const> = renderer.draw_rect
local draw_text <const> = renderer.draw_text
local get_visual_y <const> = renderer.get_visual_y
local is_item_visible <const> = renderer.is_item_visible
local s_func <const> = renderer.s
local push_clip <const> = renderer.push_clip
local pop_clip <const> = renderer.pop_clip
local is_mouse_in <const> = input_module.is_mouse_in
local get_str_id <const> = string_id.concat
local get_stable_id <const> = labels.stable_id
local get_display_label <const> = labels.display_label

local scroll_ctx_pool = {}

local function calc_scroll_render_height(fixed_h, stable_id, vy, header_h, content_pad)
    local ui = state.ui
    if fixed_h == "auto" then
        local cache_id = get_str_id("scr_h_", stable_id)
        local bottom_y = ui.header_end_y + ui.visible_h
        local max_avail = math_max(s_func(100), bottom_y - vy)
        local last_content_h = ui.layout_cache[cache_id] or s_func(50)
        local needed = last_content_h + header_h + content_pad + s_func(15)
        return math_min(math_max(s_func(100), needed), max_avail), true
    elseif fixed_h == -1 then
        local bottom_y = ui.header_end_y + ui.visible_h
        return math_max(s_func(100), bottom_y - vy), false
    end
    return fixed_h, false
end

local function handle_scroll_input(ui, cfg, s_state, content_y, view_h, w)
    if is_mouse_in(ui.cx, content_y, w, view_h) and not ui.active_combo then
        local speed = cfg.scroll_group_speed
        local delta = input_module.get_scroll_delta()
        if delta ~= 0 then
            s_state.target = s_state.target + delta * speed
            ui.scroll_consumed = true
            return
        end
    end
end

local function handle_scrollbar_drag(ui, cfg, s_state, content_y, view_h, w, sb_id, max_s, exclude_id)
    local sb_w = cfg.scrollbar_width
    local bar_x = ui.cx + w + s_func(2)
    local sb_hit_w = math_max(sb_w, cfg.scrollbar_hit_width)
    local sb_hit_x = bar_x - (sb_hit_w - sb_w)

    if max_s > 0 and ui["input"].mouse_left_pressed and is_mouse_in(sb_hit_x, content_y, sb_hit_w, view_h)
       and (not ui.active_id or ui.active_id == exclude_id) and not ui.active_combo then
        state.capture_active_id(sb_id)
    end
    if ui.active_id == sb_id then
        if not ui["input"].mouse_left_pressed then ui.active_id = nil
        else
            local r = (ui["input"].mouse_pos.y - content_y) / view_h
            s_state.target = math_max(0, math_min(1, r)) * max_s
        end
    end
    return bar_x, sb_w
end

local function update_scroll_state(s_state, max_s, delta_time)
    s_state.target = math_max(0, math_min(s_state.target, max_s))
    s_state.y = s_state.y + (s_state.target - s_state.y) * (1.0 - math_exp(-10.0 * delta_time))
end

local function run_scroll_content(content_func, ui, content_y, view_h, s_state, w, content_pad)
    local was_in_scroll = ui.in_scroll_context
    local old_scroll_ctx = ui.scroll_ctx
    local old_sticky_offset = ui.sticky_stack_offset
    local depth = (ui.scroll_ctx_depth or 0) + 1
    local scroll_ctx = scroll_ctx_pool[depth]
    if not scroll_ctx then
        scroll_ctx = {}
        scroll_ctx_pool[depth] = scroll_ctx
    end

    ui.in_scroll_context = true
    ui.scroll_ctx_depth = depth
    scroll_ctx.content_y = content_y
    scroll_ctx.view_h = view_h
    scroll_ctx.scroll_y = s_state.y
    scroll_ctx.cx = ui.cx
    scroll_ctx.width = w - (content_pad * 2)
    scroll_ctx.content_pad = content_pad
    ui.scroll_ctx = scroll_ctx
    ui.sticky_stack_offset = 0

    content_func()

    ui.scroll_ctx = old_scroll_ctx
    ui.scroll_ctx_depth = depth - 1
    ui.in_scroll_context = was_in_scroll
    ui.sticky_stack_offset = old_sticky_offset
end

local function draw_scrollbar(ui, cfg, s_state, content_y, view_h, bar_x, sb_w, sb_id, max_s)
    if max_s > 0 then
        local r = view_h / s_state.content_h
        local bh = math_max(cfg.scrollbar_thumb_min, view_h * math_min(1, r))
        local by = content_y + ((view_h - bh) * (s_state.y / max_s))
        draw_rect(bar_x, by, sb_w, bh, (ui.active_id == sb_id) and "Scrollbar Hover" or "Scrollbar", s_func(2))
    end
end

local function begin_scroll_group(ui, cfg, vy, w, render_h, group_spacing)
    ui.layout_counter = ui.layout_counter + 1
    if not is_item_visible(vy, render_h) and not ui.active_id then
        ui.cy = ui.cy + render_h + group_spacing
        return false
    end

    draw_rect(ui.cx, vy, w, render_h, "Group Background", cfg.group_rounding)
    return true
end

local function draw_scroll_group_title(ui, cfg, label, vy, content_pad, header_h)
    draw_text(get_display_label(label), ui.cx + content_pad, vy, cfg.font_group, "Group Header Text", nil, header_h)
end

function ScrollGroups.install(layout, deps)
    local widgets = deps.widgets
    assert(widgets, "[ScrollGroups] widgets module is required")

    local function scroll_group_core(ui, cfg, stable_id, is_auto, content_y, view_h, w, content_pad, content_func, exclude_id, content_start_cy)
        local state_id = get_str_id(stable_id, "_scroll")
        local sb_id = get_str_id(state_id, "_drag")

        if not ui.scroll_states[state_id] then ui.scroll_states[state_id] = { y=0, target=0, content_h=0 } end
        local s_state = ui.scroll_states[state_id]
        local max_s = math_max(0, s_state.content_h - view_h)

        handle_scroll_input(ui, cfg, s_state, content_y, view_h, w)
        local bar_x, sb_w = handle_scrollbar_drag(ui, cfg, s_state, content_y, view_h, w, sb_id, max_s, exclude_id)
        update_scroll_state(s_state, max_s, ui.delta_time)

        push_clip(ui.cx, content_y, w, view_h)

        local oy, ox, ow = ui.cy, ui.cx, ui.width_override
        ui.cx = ui.cx + content_pad
        layout.OverrideWidth(w - (content_pad * 2))
        ui.cy = content_start_cy - s_state.y

        if content_func then
            run_scroll_content(content_func, ui, content_y, view_h, s_state, w, content_pad)
        end

        s_state.content_h = (ui.cy + s_state.y) - content_start_cy
        if is_auto then ui.layout_cache[get_str_id("scr_h_", stable_id)] = s_state.content_h end

        max_s = math_max(0, s_state.content_h - view_h)
        s_state.target = math_max(0, math_min(s_state.target, max_s))
        s_state.y = math_max(0, math_min(s_state.y, max_s))

        ui.cx = ox; layout.OverrideWidth(ow)
        pop_clip()

        draw_scrollbar(ui, cfg, s_state, content_y, view_h, bar_x, sb_w, sb_id, max_s)
        return oy, s_state.content_h
    end

    function layout.ScrollGroup(label, fixed_h, content_func)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local header_h = cfg.group_header_height

        local stable_id = get_stable_id(label)
        local is_auto = (fixed_h == "auto")
        local render_h = (is_auto or fixed_h == -1) and calc_scroll_render_height(fixed_h, stable_id, vy, header_h, content_pad) or fixed_h

        if not begin_scroll_group(ui, cfg, vy, w, render_h, group_spacing) then return end
        draw_scroll_group_title(ui, cfg, label, vy, content_pad, header_h)

        local content_y = vy + header_h
        local view_h = render_h - header_h - content_pad
        local oy = scroll_group_core(ui, cfg, stable_id, is_auto, content_y, view_h, w, content_pad, content_func, nil, ui.cy + header_h)
        ui.cy = oy + render_h + group_spacing
    end

    function layout.ScrollGroupEx(label, fixed_h, content_func, header_right_func)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local header_h = cfg.group_header_height

        local stable_id = get_stable_id(label)
        local is_auto = (fixed_h == "auto")
        local render_h = (is_auto or fixed_h == -1) and calc_scroll_render_height(fixed_h, stable_id, vy, header_h, content_pad) or fixed_h

        if not begin_scroll_group(ui, cfg, vy, w, render_h, group_spacing) then return end
        draw_scroll_group_title(ui, cfg, label, vy, content_pad, header_h)

        if header_right_func then
            local title_w = s_func(80)
            local widget_w = w - title_w - content_pad * 2
            local ox, oy_save, ow = ui.cx, ui.cy, ui.width_override
            ui.cx = ui.cx + title_w
            ui.cy = oy_save + (header_h - s_func(28)) / 2
            layout.OverrideWidth(widget_w)
            header_right_func()
            ui.cx = ox; ui.cy = oy_save; layout.OverrideWidth(ow)
        end

        local content_y = vy + header_h
        local view_h = render_h - header_h - content_pad
        local oy = scroll_group_core(ui, cfg, stable_id, is_auto, content_y, view_h, w, content_pad, content_func, nil, ui.cy + header_h)
        ui.cy = oy + render_h + group_spacing
    end

    function layout.ScrollGroupWithSearch(label, fixed_h, content_func, search_state, search_key, search_hint)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing
        local header_h = cfg.group_header_height

        local stable_id = get_stable_id(label)
        local render_h = (fixed_h == -1) and math_max(s_func(100), ui.header_end_y + ui.visible_h - vy) or fixed_h

        if not begin_scroll_group(ui, cfg, vy, w, render_h, group_spacing) then return end
        draw_scroll_group_title(ui, cfg, label, vy, content_pad, header_h)

        local search_w = cfg.search_box_width
        local search_h = cfg.search_box_height
        local saved_cx, saved_cy, saved_width = ui.cx, ui.cy, ui.width_override
        local saved_item_h, saved_item_spacing = cfg.item_h, cfg.item_spacing

        ui.cx = ui.cx + w - search_w - content_pad
        ui.cy = saved_cy + (header_h - search_h) / 2
        ui.width_override = search_w
        cfg.item_h = search_h
        cfg.item_spacing = 0

        local search_label = search_hint and get_str_id(search_hint, "###", stable_id, "_search") or get_str_id("Search ", stable_id, "###", stable_id, "_search")
        local search_id = state.peek_widget_id(search_label)
        local current_query = search_state and search_key and search_state[search_key] or ""
        local new_query = widgets.TextInput(search_label, current_query, 64)

        if search_state and search_key and new_query ~= current_query then
            search_state[search_key] = new_query
        end

        ui.cx = saved_cx; ui.cy = saved_cy; ui.width_override = saved_width
        cfg.item_h = saved_item_h; cfg.item_spacing = saved_item_spacing
        local content_y = vy + header_h
        local view_h = render_h - header_h - content_pad
        local oy = scroll_group_core(ui, cfg, stable_id, false, content_y, view_h, w, content_pad, content_func, search_id, ui.cy + header_h)
        ui.cy = oy + render_h + group_spacing
    end

    function layout.ScrollGroupWithHeader(label, fixed_h, header_func, content_func)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local vy = get_visual_y()
        local w = layout.GetWidth()
        local content_pad = cfg.group_content_padding
        local group_spacing = cfg.group_spacing

        local stable_id = get_stable_id(label)
        local is_auto = (fixed_h == "auto")
        local render_h

        if is_auto then
            local cache_id = get_str_id("scr_h_", stable_id)
            local bottom_y = ui.header_end_y + ui.visible_h
            local max_avail = math_max(s_func(100), bottom_y - vy)
            local last_content_h = ui.layout_cache[cache_id] or s_func(50)
            local needed = last_content_h + (content_pad * 2) + s_func(15)
            render_h = math_min(math_max(s_func(100), needed), max_avail)
        elseif fixed_h == -1 then
            render_h = math_max(s_func(100), ui.header_end_y + ui.visible_h - vy)
        else
            render_h = fixed_h
        end

        if not begin_scroll_group(ui, cfg, vy, w, render_h, group_spacing) then return end

        local header_start_cy = ui.cy + content_pad
        local header_start_y = ui.window_y_start + header_start_cy - ui.scroll_y
        local header_content_h = 0

        if header_func then
            local ox, oy, ow = ui.cx, ui.cy, ui.width_override
            ui.cy = header_start_cy
            ui.cx = ui.cx + content_pad
            layout.OverrideWidth(w - (content_pad * 2))

            header_func()

            header_content_h = ui.cy - header_start_cy
            ui.cx = ox; ui.cy = oy; layout.OverrideWidth(ow)
        end

        local content_y = header_start_y + header_content_h
        local view_h = math_max(s_func(20), render_h - header_content_h - (content_pad * 2))
        local oy, core_content_h = scroll_group_core(ui, cfg, stable_id, is_auto, content_y, view_h, w, content_pad, content_func, nil, header_start_cy + header_content_h)

        if is_auto then ui.layout_cache[get_str_id("scr_h_", stable_id)] = core_content_h + header_content_h end

        ui.cy = oy + render_h + group_spacing
    end
end

return ScrollGroups
