local layout = {}

local metrics = require("ClickUl_Refactor.UI.Layout.Metrics")
local background = require("ClickUl_Refactor.UI.Layout.Background")
local navigation = require("ClickUl_Refactor.UI.Layout.Navigation")
local groups = require("ClickUl_Refactor.UI.Layout.Groups")
local flow = require("ClickUl_Refactor.UI.Layout.Flow")
local overlays = require("ClickUl_Refactor.UI.Layout.Overlays")
local loading_overlay = require("ClickUl_Refactor.UI.Layout.LoadingOverlay")
local virtual_list = require("ClickUl_Refactor.UI.Layout.VirtualList")
local window = require("ClickUl_Refactor.UI.Layout.Window")
local scroll_groups = require("ClickUl_Refactor.UI.Layout.ScrollGroups")

local widgets = nil
local settings_store = nil

function layout.init(ctx)
    widgets = assert(ctx.widgets, "[Layout] widgets module is required")
    settings_store = assert(ctx.settings, "[Layout] settings module is required")

    loading_overlay.init({ settings = settings_store })
    flow.install(layout, { widgets = widgets })
    scroll_groups.install(layout, { widgets = widgets })
end

function layout.clear_failed_images()
    background.clear_failed_images()
    navigation.clear_failed_sidebar_textures()
end

metrics.install(layout)
background.install(layout)
navigation.install(layout)
groups.install(layout)
overlays.install(layout)
loading_overlay.install(layout)
virtual_list.install(layout)
window.install(layout)

return layout
