local Background = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")

local load_image <const> = renderer.load_image

local failed_images = {}

function Background.refresh()
    local ui = state.ui
    local config_sys = state.deps.config_sys

    local cfg_data = config_sys.data
    if not cfg_data.bg_image_enabled then
        ui.bg_texture = nil
        ui.bg_path_loaded = nil
        return
    end

    local filename = cfg_data.bg_image_file
    if not filename or filename == "" then
        ui.bg_texture = nil
        return
    end

    local full_path = renderer.get_assets_dir() .. "Images\\" .. filename
    if failed_images[full_path] then return end
    if ui.bg_texture and ui.bg_path_loaded == full_path then return end

    local status, tex = pcall(load_image, full_path)
    if status and tex then
        ui.bg_texture = tex
        ui.bg_path_loaded = full_path
        return
    end

    ui.bg_texture = nil
    ui.bg_path_loaded = nil
    failed_images[full_path] = true
end

function Background.clear_failed_images()
    failed_images = {}
end

function Background.install(layout)
    layout.refresh_background = Background.refresh
end

return Background
