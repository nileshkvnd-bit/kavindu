local VirtualList = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")

local math_floor <const> = math.floor
local math_max <const> = math.max
local math_min <const> = math.min
local get_visual_y <const> = renderer.get_visual_y

local function get_visible_range(scroll_ctx, item_height, spacing, count)
    local total_h = item_height + spacing
    local view_h = scroll_ctx.view_h
    local content_y = scroll_ctx.content_y
    local ctx_scroll_y = scroll_ctx.scroll_y

    local list_screen_y = get_visual_y()
    local list_offset_in_content = list_screen_y - content_y + ctx_scroll_y
    local visible_start = ctx_scroll_y - list_offset_in_content

    local first_visible = math_floor((visible_start + 0.001) / total_h) + 1
    local visible_count = math_floor(view_h / total_h) + 3
    local last_visible = math_min(count, first_visible + visible_count - 1)
    first_visible = math_max(1, math_min(first_visible, count))
    last_visible = math_max(first_visible, last_visible)

    return first_visible, last_visible, total_h
end

function VirtualList.items(items, item_height, render_callback)
    local ui = state.ui
    local scroll_ctx = ui.scroll_ctx
    if not scroll_ctx or not items or #items == 0 then
        if items then
            for i = 1, #items do render_callback(i, items[i]) end
        end
        return
    end

    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local spacing = cfg.item_spacing
    local count = #items
    local first_visible, last_visible, total_h = get_visible_range(scroll_ctx, item_height, spacing, count)

    if first_visible > 1 then
        ui.cy = ui.cy + (first_visible - 1) * total_h
    end

    for i = first_visible, last_visible do
        render_callback(i, items[i])
    end

    if last_visible < count then
        ui.cy = ui.cy + (count - last_visible) * total_h
    end
end

function VirtualList.count(count, item_height, render_callback)
    local ui = state.ui
    local scroll_ctx = ui.scroll_ctx
    if not scroll_ctx or count <= 0 then
        for i = 1, count do render_callback(i) end
        return
    end

    local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
    local spacing = cfg.item_spacing
    local first_visible, last_visible, total_h = get_visible_range(scroll_ctx, item_height, spacing, count)

    if first_visible > 1 then
        ui.cy = ui.cy + (first_visible - 1) * total_h
    end

    for i = first_visible, last_visible do
        render_callback(i)
    end

    if last_visible < count then
        ui.cy = ui.cy + (count - last_visible) * total_h
    end
end

function VirtualList.install(layout)
    layout.VirtualList = VirtualList.items
    layout.VirtualListEx = VirtualList.count
end

return VirtualList
