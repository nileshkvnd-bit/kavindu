local Overlays = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local hints = require("ClickUl_Refactor.UI.Hints")

local s_func <const> = renderer.s
local draw_rect_ex <const> = renderer.draw_rect_ex
local draw_wrapped_text <const> = renderer.draw_wrapped_text

local lines = {}
local line_heights = {}
local measure_cache = {}
local measure_cache_count = 0
local MEASURE_CACHE_MAX <const> = 256

local function measure_line_height(text, base_size, scaled_size, wrap_w)
    local entry = measure_cache[text]
    if entry and entry.size == scaled_size and entry.wrap == wrap_w then
        return entry.h
    end

    local dims = renderer.wrapped_text_size(text, base_size, wrap_w)
    local h = (dims and dims.y and dims.y > 0) and dims.y or scaled_size

    if measure_cache_count >= MEASURE_CACHE_MAX then
        measure_cache = {}
        measure_cache_count = 0
    end
    if not entry then
        entry = {}
        measure_cache[text] = entry
        measure_cache_count = measure_cache_count + 1
    end
    entry.size = scaled_size
    entry.wrap = wrap_w
    entry.h = h
    return h
end

local function _T(text)
    local lang = state.deps.lang
    return lang and lang.get(text) or text
end

function Overlays.draw_menu_hints()
    local ui = state.ui
    local hint_state = ui.menu_hint
    if not hint_state or not hint_state.current then return end

    if hints.expire() then return end

    local cfg = state.deps.config_sys.data
    local base = cfg.base
    local current = cfg.current

    local payload = hint_state.payload
    local has_hotkey = payload and payload.hotkey and payload.hotkey.action_id
    local has_favorite = payload and payload.favorite and payload.favorite.action_id

    local width = current.w
    local padding = current.menu_hints_padding
    local avail_w = width - padding * 2
    local font_size = current.menu_hints_font_size
    local base_font = base.menu_hints_font_size or font_size
    local gap = s_func(4)

    local line_count = 1
    lines[1] = (payload and payload.description) or hint_state.current
    if has_favorite then
        local favorited = payload.favorite.is_favorite
        line_count = line_count + 1
        lines[line_count] = favorited and _T("Press F9 to remove favorite") or _T("Press F9 to favorite")
    end
    if has_hotkey then
        line_count = line_count + 1
        lines[line_count] = _T("Press F10 to set hotkey")
    end
    for i = line_count + 1, #lines do lines[i] = nil end

    local total_h = 0
    for i = 1, line_count do
        local lh = measure_line_height(lines[i], base_font, font_size, avail_w)
        line_heights[i] = lh
        total_h = total_h + lh
        if i > 1 then total_h = total_h + gap end
    end

    local ox = base.x
    local oy = base.y + current.h + current.menu_hints_offset_y
    local height = math.max(current.menu_hints_height, total_h + s_func(12))
    draw_rect_ex(ox, oy, width, height, "Menu Hints Background", current.menu_hints_rounding)

    local y = oy + (height - total_h) * 0.5
    for i = 1, line_count do
        draw_wrapped_text(lines[i], ox + padding, y, base_font, "Menu Hints Text", avail_w)
        y = y + line_heights[i] + gap
    end
end

function Overlays.install(layout)
    layout.draw_menu_hints = Overlays.draw_menu_hints
end

return Overlays
