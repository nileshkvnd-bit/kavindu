local Flow = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")

local ipairs <const> = ipairs
local math_max <const> = math.max
local get_visual_y <const> = renderer.get_visual_y
local is_item_visible <const> = renderer.is_item_visible

local EMPTY_OPTS <const> = {}

function Flow.install(layout, deps)
    local widgets = deps.widgets
    assert(widgets, "[Flow] widgets module is required")

    function layout.DualColumn(l, r)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local sy, scx = ui.cy, ui.cx
        local gap = cfg.dual_column_gap
        local w = (layout.GetWidth() - gap) * 0.5

        layout.OverrideWidth(w)
        if l then l() end
        local ly = ui.cy

        ui.cy = sy
        ui.cx = scx + w + gap
        layout.OverrideWidth(w)
        if r then r() end
        local ry = ui.cy

        ui.cx = scx
        ui.cy = math_max(ly, ry) + cfg.dual_column_bottom_margin
        layout.OverrideWidth(nil)
    end

    function layout.DualColumn_FixedLeft(l, r)
        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local sy, scx = ui.cy, ui.cx
        local gap = cfg.dual_column_gap
        local w = (layout.GetWidth() - gap) * 0.5

        local saved_scroll = ui.scroll_y
        ui.scroll_y = 0
        layout.OverrideWidth(w)
        if l then l() end
        ui.scroll_y = saved_scroll

        ui.cy = sy
        ui.cx = scx + w + gap
        layout.OverrideWidth(w)
        if r then r() end
        local ry = ui.cy

        ui.cx = scx
        ui.cy = ry + cfg.dual_column_bottom_margin
        layout.OverrideWidth(nil)
    end

    function layout.Row(items, options)
        if not items or #items == 0 then return end

        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local count = #items
        local opts = options or EMPTY_OPTS
        local gap = opts.gap or cfg.row_gap
        local equal_width = (opts.equal_width ~= false)

        local total_w = layout.GetWidth()
        local item_w
        if equal_width then
            item_w = (total_w - (count - 1) * gap) / count
        else
            item_w = total_w
        end

        local start_cy = ui.cy
        local start_cx = ui.cx
        local original_override = ui.width_override
        local max_cy = start_cy

        for i, render_func in ipairs(items) do
            ui.cy = start_cy
            ui.cx = start_cx + (i - 1) * (item_w + gap)

            if equal_width then
                layout.OverrideWidth(item_w)
            end

            if render_func then
                render_func()
            end

            if ui.cy > max_cy then
                max_cy = ui.cy
            end
        end

        ui.cx = start_cx
        ui.cy = max_cy
        layout.OverrideWidth(original_override)
    end

    function layout.ButtonRow(labels, options)
        if not labels or #labels == 0 then return nil end

        local ui = state.ui
        local cfg = state.ui.cfg_current or state.deps.config_sys.data.current
        local h = cfg.item_h
        local vy = get_visual_y()

        if not is_item_visible(vy, h) then
            ui.cy = ui.cy + h + cfg.row_gap
            return nil
        end

        local count = #labels
        local gap = (options and options.gap) or cfg.row_gap
        local start_cx, start_cy = ui.cx, ui.cy
        local original_override = ui.width_override
        local max_cy = start_cy
        local total_w = layout.GetWidth()
        local item_w = (total_w - (count - 1) * gap) / count

        local clicked_idx = nil

        for i = 1, count do
            ui.cy = start_cy
            ui.cx = start_cx + (i - 1) * (item_w + gap)
            layout.OverrideWidth(item_w)

            if widgets.Button(labels[i]) then
                clicked_idx = i
            end

            if ui.cy > max_cy then max_cy = ui.cy end
        end

        ui.cx = start_cx
        ui.cy = max_cy
        layout.OverrideWidth(original_override)

        return clicked_idx
    end
end

return Flow
