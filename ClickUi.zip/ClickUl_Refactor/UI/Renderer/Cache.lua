local Cache = {}

local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")

local math_floor <const> = math.floor
local string_find <const> = string.find
local string_sub <const> = string.sub
local next <const> = next
local type <const> = type

local function clamp_byte(v)
    v = math_floor(v or 0)
    if v < 0 then return 0 end
    if v > 255 then return 255 end
    return v
end

local function color_hash(r, g, b, a)
    return r + (g * 256) + (b * 65536) + (a * 16777216)
end

local function count_pairs(tbl)
    local count = 0
    for _ in pairs(tbl) do
        count = count + 1
    end
    return count
end

local function install_vec2(renderer, ctx)
    function ctx.get_vec2(x, y)
        return ctx.vec2(math_floor(x), math_floor(y))
    end

    renderer.get_vec2 = ctx.get_vec2
end

local function install_clean_label(renderer, ctx)
    local clean_label_cache = {}
    local clean_label_count = 0
    local clean_label_max <const> = ctx.constants.CLEAN_LABEL_CACHE_LIMIT or 2048

    function renderer.get_clean_label(str)
        if not str then return "" end
        local cached = clean_label_cache[str]
        if cached then return cached end

        local result = str
        local s_idx = string_find(str, "##", 1, true)
        if s_idx then result = string_sub(str, 1, s_idx - 1) end

        clean_label_count = CacheUtils.evict_pairs(clean_label_cache, clean_label_count, clean_label_max, 0.3)
        clean_label_cache[str] = result
        clean_label_count = clean_label_count + 1
        return result
    end

    function ctx.clear_clean_label_cache()
        clean_label_cache = {}
        clean_label_count = 0
    end
end

local function install_color(renderer, ctx)
    local color_alpha_count = 0
    local color_alpha_limit <const> = ctx.constants.COLOR_ALPHA_CACHE_LIMIT or 2000

    local function remove_color_alpha_entry(cache, key, value)
        if key == "_transparent" then return 0 end

        cache[key] = nil
        if type(value) == "table" then
            return count_pairs(value)
        end
        return 1
    end

    local function evict_color_alpha_cache()
        color_alpha_count = CacheUtils.evict_pairs(
            ctx.state.cache.color_alpha,
            color_alpha_count,
            color_alpha_limit,
            0.3,
            remove_color_alpha_entry
        )
    end

    function renderer.get_color(col_key)
        local cache = ctx.state.cache
        if type(col_key) == "string" then
            if cache.color_userdata[col_key] then return cache.color_userdata[col_key] end
            local c = ctx.state.deps.config_sys.data.colors[col_key]
            if c then
                local new_col = ctx.color(c.r, c.g, c.b, c.a)
                cache.color_userdata[col_key] = new_col
                return new_col
            end
            return ctx.color(255, 255, 255, 255)
        end

        if type(col_key) == "userdata" then return col_key end
        return ctx.color(col_key.r or 255, col_key.g or 255, col_key.b or 255, col_key.a or 255)
    end

    function renderer.get_color_alpha(col_key, alpha_mult)
        if not alpha_mult or alpha_mult >= 0.99 then return renderer.get_color(col_key) end
        if alpha_mult <= 0.01 then
            if not ctx.state.cache.color_alpha._transparent then
                ctx.state.cache.color_alpha._transparent = ctx.color(0, 0, 0, 0)
            end
            return ctx.state.cache.color_alpha._transparent
        end

        local a_idx = math_floor(alpha_mult * 100 + 0.5)
        local t = type(col_key)
        if t == "string" then
            local by_key = ctx.state.cache.color_alpha[col_key]
            if not by_key then
                by_key = {}
                ctx.state.cache.color_alpha[col_key] = by_key
            end
            if by_key[a_idx] then return by_key[a_idx] end

            local c = ctx.state.deps.config_sys.data.colors[col_key]
            local base = c and c.a or 255
            local new_col = c and ctx.color(c.r, c.g, c.b, math_floor(base * alpha_mult)) or renderer.get_color(col_key)

            if color_alpha_count >= color_alpha_limit then
                evict_color_alpha_cache()
                by_key = ctx.state.cache.color_alpha[col_key]
                if not by_key then
                    by_key = {}
                    ctx.state.cache.color_alpha[col_key] = by_key
                end
            end
            by_key[a_idx] = new_col
            color_alpha_count = color_alpha_count + 1
            return new_col
        elseif t == "table" then
            local r = clamp_byte(col_key.r or 255)
            local g = clamp_byte(col_key.g or 255)
            local b = clamp_byte(col_key.b or 255)
            local base_a = clamp_byte(col_key.a or 255)
            local a = clamp_byte(base_a * alpha_mult)
            local hash_key = color_hash(r, g, b, a)
            local cached = ctx.state.cache.color_alpha[hash_key]
            if cached then return cached end

            cached = ctx.color(r, g, b, a)
            if color_alpha_count >= color_alpha_limit then
                evict_color_alpha_cache()
            end
            ctx.state.cache.color_alpha[hash_key] = cached
            color_alpha_count = color_alpha_count + 1
            return cached
        end
        return renderer.get_color(col_key)
    end

    function renderer.reset_color_cache()
        ctx.state.cache.color_userdata = {}
        ctx.clear_color_alpha_cache()
    end

    function renderer.invalidate_color(key)
        ctx.state.cache.color_userdata[key] = nil
        local bucket = ctx.state.cache.color_alpha[key]
        if bucket ~= nil then
            ctx.state.cache.color_alpha[key] = nil
            color_alpha_count = color_alpha_count - (type(bucket) == "table" and count_pairs(bucket) or 1)
            if color_alpha_count < 0 then color_alpha_count = 0 end
        end
    end

    function renderer.preload_theme_colors()
        local colors = ctx.state.deps.config_sys.data.colors
        local cache = ctx.state.cache.color_userdata
        for key, c in pairs(colors) do
            if not cache[key] and c.r then
                cache[key] = ctx.color(c.r, c.g, c.b, c.a)
            end
        end
    end

    function ctx.clear_color_alpha_cache()
        ctx.state.cache.color_alpha = {}
        color_alpha_count = 0
    end
end

function Cache.install(renderer, ctx)
    install_vec2(renderer, ctx)
    install_clean_label(renderer, ctx)
    install_color(renderer, ctx)

    function ctx.clear_renderer_caches()
        ctx.clear_clean_label_cache()
        ctx.clear_text_object_cache()
        ctx.state.cache.text_width = {}
        ctx.state.cache.text_width_size = 0
        renderer.clear_ellipsis_cache()
        renderer.clear_fold_cache()
        renderer.reset_color_cache()
    end
end

return Cache
