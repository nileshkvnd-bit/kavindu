local Draw = {}

local math_floor <const> = math.floor

function Draw.install(renderer, ctx)
    local clip_depth = 0

    function renderer.push_clip(x, y, w, h)
        ctx.gui_adapter.push_clip(ctx.get_vec2(math_floor(x), math_floor(y)), ctx.get_vec2(math_floor(w), math_floor(h)))
        clip_depth = clip_depth + 1
    end

    function renderer.pop_clip()
        if clip_depth <= 0 then return end
        ctx.gui_adapter.pop_clip()
        clip_depth = clip_depth - 1
    end

    function renderer.capture_ui_frame()
        local ui = ctx.state.ui
        return {
            cx = ui.cx,
            cy = ui.cy,
            width_override = ui.width_override,
            scroll_y = ui.scroll_y,
            scroll_ctx = ui.scroll_ctx,
            scroll_ctx_depth = ui.scroll_ctx_depth,
            in_scroll_context = ui.in_scroll_context,
            sticky_stack_offset = ui.sticky_stack_offset,
            clip_depth = clip_depth,
            id_context_depth = #ui.id_context_stack,
            post_draw_len = #ui.post_draw_queue,
        }
    end

    function renderer.restore_ui_frame(snap)
        local ui = ctx.state.ui
        ui.cx = snap.cx
        ui.cy = snap.cy
        ui.width_override = snap.width_override
        ui.scroll_y = snap.scroll_y
        ui.scroll_ctx = snap.scroll_ctx
        ui.scroll_ctx_depth = snap.scroll_ctx_depth
        ui.in_scroll_context = snap.in_scroll_context
        ui.sticky_stack_offset = snap.sticky_stack_offset

        while clip_depth > snap.clip_depth do
            renderer.pop_clip()
        end

        while #ui.id_context_stack > snap.id_context_depth do
            ctx.state.pop_id_context()
        end

        local queue = ui.post_draw_queue
        for i = #queue, snap.post_draw_len + 1, -1 do
            queue[i] = nil
        end
    end

    function renderer.load_image(path)
        return ctx.gui_adapter.load_image(path)
    end

    function renderer.load_font(path, scale)
        return ctx.gui_adapter.load_font(path, scale)
    end

    function renderer.rebuild()
        return ctx.gui_adapter.rebuild()
    end

    function renderer.draw_rect_ex(x, y, w, h, col_key, round, round_flags, alpha_mult, override_color_vec)
        local rx, ry = math_floor(x), math_floor(y)
        local rw, rh = math_floor(w), math_floor(h)
        if rw <= 0 or rh <= 0 then return end

        local r_obj = ctx.gui_adapter.rect(ctx.get_vec2(rx, ry), ctx.get_vec2(rw, rh))
        r_obj:filled()

        if override_color_vec then
            local a = override_color_vec.a or 255
            if alpha_mult then a = a * alpha_mult end
            r_obj:color(ctx.color(override_color_vec.r or 255, override_color_vec.g or 255, override_color_vec.b or 255, a))
        else
            if alpha_mult and alpha_mult < 1.0 then
                r_obj:color(renderer.get_color_alpha(col_key, alpha_mult))
            else
                r_obj:color(renderer.get_color(col_key))
            end
        end

        if round and round > 0 then
            r_obj:rounding(math_floor(round), round_flags)
        end
        r_obj:draw()
    end

    function renderer.draw_rect(x, y, w, h, col_key, round, round_flags)
        local rx, ry = math_floor(x), math_floor(y)
        local rw, rh = math_floor(w), math_floor(h)
        if rw <= 0 or rh <= 0 then return end
        local r_obj = ctx.gui_adapter.rect(ctx.get_vec2(rx, ry), ctx.get_vec2(rw, rh))
        r_obj:filled()
        r_obj:color(renderer.get_color(col_key))
        if round and round > 0 then
            r_obj:rounding(math_floor(round), round_flags)
        end
        r_obj:draw()
    end

    function renderer.draw_widget_background(x, y, w, h, hover)
        renderer.draw_rect(x, y, w, h, hover and "Widget Hover" or "Widget Background", renderer.s(6))
    end

    function renderer.draw_slider_background(x, y, w, h, hover)
        renderer.draw_rect(x, y, w, h, hover and "Slider Background Hover" or "Slider Background", renderer.s(6))
    end

    function renderer.draw_image(texture, x, y, w, h, col)
        if not texture then return end
        local draw_col = col or renderer.get_color("Text Primary") or ctx.color(255, 255, 255, 255)
        ctx.gui_adapter.image(texture, ctx.get_vec2(math_floor(x), math_floor(y)), ctx.get_vec2(math_floor(w), math_floor(h)), draw_col)
    end

    function renderer.draw_image_rounded(texture, x, y, w, h, rounding, col, flags)
        if not texture then return end
        local draw_col = col or renderer.get_color("Text Primary") or ctx.color(255, 255, 255, 255)
        ctx.gui_adapter.image_rounded(texture, ctx.get_vec2(math_floor(x), math_floor(y)), ctx.get_vec2(math_floor(w), math_floor(h)), draw_col, rounding, flags)
    end

    function renderer.draw_line(x1, y1, x2, y2, thickness, col_key, alpha_mult)
        local col = alpha_mult and renderer.get_color_alpha(col_key, alpha_mult) or renderer.get_color(col_key)
        ctx.gui_adapter.line(ctx.get_vec2(math_floor(x1), math_floor(y1)), ctx.get_vec2(math_floor(x2), math_floor(y2)), thickness or 1, col)
    end

    function renderer.get_visual_y()
        return ctx.state.ui.window_y_start + ctx.state.ui.cy - ctx.state.ui.scroll_y
    end

    function renderer.is_item_visible(y, h)
        local ui = ctx.state.ui
        local min_y = ui.header_end_y + (ui.subtab_offset or 0)
        local max_y = ui.header_end_y + ui.visible_h
        return (y + (h or 0) > min_y) and (y < max_y)
    end

    function renderer.get_assets_dir()
        return ctx.state.deps.config_sys.get_base_dir()
    end
end

return Draw
