local Text = {}

local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")

local math_floor <const> = math.floor
local string_len <const> = string.len
local string_match <const> = string.match
local string_sub <const> = string.sub
local tostring <const> = tostring
local type <const> = type
local utf8_len <const> = utf8.len
local utf8_offset <const> = utf8.offset

local static_text_set = {}
local static_text_count = 0
local STATIC_TEXT_LIMIT <const> = 8000

local function is_dynamic_text(str)
    if static_text_set[str] then return false end
    if string_match(str, "%d%d") then return true end
    if string_match(str, "[%(%[:]%s*%d") then return true end
    if string_match(str, "%d[%%/%]%)]") then return true end
    if string_len(str) > 64 then return true end
    if string_match(str, "###") then return true end
    if static_text_count >= STATIC_TEXT_LIMIT then
        static_text_set = {}
        static_text_count = 0
    end
    static_text_set[str] = true
    static_text_count = static_text_count + 1
    return false
end

local function install_text_width(renderer, ctx)
    local text_width_opts = { wrap = 0 }

    local function evict_text_width_bucket(_, _, font_tbl, remaining, ratio)
        return CacheUtils.evict_nested_pairs(font_tbl, remaining, ratio)
    end

    function renderer.get_text_width(str, size, font_name)
        local cache = ctx.state.cache
        local size_key = size or 0

        local resolved_font_name = font_name or ctx.get_default_font_name()

        local font_bucket = resolved_font_name or ""
        local by_font = cache.text_width[font_bucket]
        if not by_font then
            by_font = {}
            cache.text_width[font_bucket] = by_font
        end
        local by_size = by_font[size_key]
        if not by_size then
            by_size = {}
            by_font[size_key] = by_size
        end

        if by_size[str] then return by_size[str] end

        text_width_opts.wrap = 0
        text_width_opts.font = nil
        if font_name then
            local font_obj = ctx.fonts_module.get(font_name)
            if font_obj then
                text_width_opts.font = font_obj
            end
        elseif resolved_font_name then
            local font_obj = ctx.fonts_module.get_for_size(math_floor(renderer.s(size)))
            if font_obj then
                text_width_opts.font = font_obj
            end
        end
        local dims = ctx.gui_adapter.text_size(str, renderer.s(size), text_width_opts)
        local width = dims.x

        local limit = ctx.constants.TEXT_WIDTH_CACHE_LIMIT or 3000
        local ratio = ctx.constants.TEXT_WIDTH_CACHE_EVICT_PERCENTAGE or 0.3

        if cache.text_width_size >= limit then
            cache.text_width_size = CacheUtils.evict_pairs(cache.text_width, cache.text_width_size, limit, ratio, evict_text_width_bucket)
            by_font = cache.text_width[font_bucket]
            if not by_font then
                by_font = {}
                cache.text_width[font_bucket] = by_font
            end
            by_size = by_font[size_key]
            if not by_size then
                by_size = {}
                by_font[size_key] = by_size
            end
        end

        by_size[str] = width
        cache.text_width_size = cache.text_width_size + 1
        return width
    end

    local fold_cache = {}
    local fold_cache_count = 0
    local FOLD_CACHE_MAX <const> = 512
    local utf8_charpattern <const> = utf8.charpattern
    local utf8_codepoint <const> = utf8.codepoint

    local function is_cjk(cp)
        return cp >= 0x2E80
    end

    local function fold_segment(segment, size, wrap_width, font_name, out)
        local line, line_w = nil, 0
        local word = nil

        local function push_unit(unit)
            local unit_w = renderer.get_text_width(unit, size, font_name)
            if not line then
                if unit ~= " " then
                    line, line_w = unit, unit_w
                end
                return
            end
            if line_w + unit_w > wrap_width then
                local exact_w = renderer.get_text_width(line .. unit, size, font_name)
                if exact_w <= wrap_width then
                    line = line .. unit
                    line_w = exact_w
                    return
                end
                out[#out + 1] = line
                if unit == " " then
                    line, line_w = nil, 0
                else
                    line, line_w = unit, unit_w
                end
            else
                line = line .. unit
                line_w = line_w + unit_w
            end
        end

        local function flush_word()
            if word then
                push_unit(word)
                word = nil
            end
        end

        for ch in string.gmatch(segment, utf8_charpattern) do
            if ch == " " then
                flush_word()
                push_unit(" ")
            elseif is_cjk(utf8_codepoint(ch)) then
                flush_word()
                push_unit(ch)
            else
                word = word and (word .. ch) or ch
            end
        end
        flush_word()
        out[#out + 1] = line or ""
    end

    function renderer.fold_text(str, size, wrap_width, font_name)
        str = tostring(str or "")
        if not wrap_width or wrap_width <= 0 or str == "" then return str end

        local wrap_key = math_floor(wrap_width)
        local by_font = fold_cache[font_name or ""]
        local by_size = by_font and by_font[size]
        local by_wrap = by_size and by_size[wrap_key]
        local cached = by_wrap and by_wrap[str]
        if cached then return cached end

        local out = {}
        for segment in string.gmatch(str .. "\n", "([^\n]*)\n") do
            fold_segment(segment, size, wrap_width, font_name, out)
        end
        local folded = table.concat(out, "\n")

        if fold_cache_count >= FOLD_CACHE_MAX then
            fold_cache = {}
            fold_cache_count = 0
            by_font, by_size, by_wrap = nil, nil, nil
        end
        if not by_font then
            by_font = fold_cache[font_name or ""] or {}
            fold_cache[font_name or ""] = by_font
        end
        if not by_size then
            by_size = by_font[size] or {}
            by_font[size] = by_size
        end
        if not by_wrap then
            by_wrap = by_size[wrap_key] or {}
            by_size[wrap_key] = by_wrap
        end
        by_wrap[str] = folded
        fold_cache_count = fold_cache_count + 1
        return folded
    end

    function renderer.clear_fold_cache()
        fold_cache = {}
        fold_cache_count = 0
    end
end

local function install_text_objects(renderer, ctx)
    local text_obj_cache = {}
    local text_cache_order = {}
    local text_cache_count = 0
    local text_cache_limit <const> = ctx.constants.TEXT_CACHE_LIMIT or 1500

    local function remove_text_cache_entry(_, entry)
        if not entry then return end
        if type(entry) == "table" then
            local by_size = text_obj_cache[entry.size]
            if by_size then by_size[entry.key] = nil end
        else
            text_obj_cache[entry] = nil
        end
    end

    local function evict_text_cache()
        text_cache_count = CacheUtils.evict_ordered(
            text_obj_cache,
            text_cache_order,
            text_cache_limit,
            0.3,
            remove_text_cache_entry,
            text_cache_count,
            true
        )
    end

    local function get_cached_text_object(cache_id, s_size, use_custom_font)
        if use_custom_font then
            local by_size = text_obj_cache[s_size]
            return by_size and by_size[cache_id] or nil
        end
        return text_obj_cache[cache_id]
    end

    local function store_text_object(cache_id, s_size, use_custom_font, t_obj)
        if text_cache_count >= text_cache_limit then
            evict_text_cache()
        end

        if use_custom_font then
            local by_size = text_obj_cache[s_size]
            if not by_size then
                by_size = {}
                text_obj_cache[s_size] = by_size
            end
            by_size[cache_id] = t_obj
        else
            text_obj_cache[cache_id] = t_obj
        end
        text_cache_count = text_cache_count + 1
        text_cache_order[text_cache_count] = use_custom_font and { size = s_size, key = cache_id } or cache_id
    end

    function ctx.get_text_object(cache_id, safe_str, s_size, use_custom_font)
        local should_cache = not is_dynamic_text(cache_id)
        local t_obj = should_cache and get_cached_text_object(cache_id, s_size, use_custom_font) or nil
        if not t_obj then
            t_obj = ctx.gui_adapter.text(safe_str)
            if should_cache then
                store_text_object(cache_id, s_size, use_custom_font, t_obj)
            end
        end
        return t_obj
    end

    function ctx.clear_text_object_cache()
        text_obj_cache = {}
        text_cache_order = {}
        text_cache_count = 0
    end
end

local function install_draw_text(renderer, ctx)
    local function get_draw_font(s_size)
        local use_custom_font = ctx.get_default_font_name() ~= nil
        if not use_custom_font then return nil, false end

        local font_obj = ctx.fonts_module.get_for_size(s_size)
        ctx.fonts_module.flush_rebuild(false)
        return font_obj, true
    end

    local function apply_text_color(t_obj, col_key, alpha_mult, override_color_vec)
        if override_color_vec then
            local a = override_color_vec.a
            if alpha_mult then a = a * alpha_mult end
            t_obj:color(ctx.color(override_color_vec.r, override_color_vec.g, override_color_vec.b, a))
            return
        end

        if alpha_mult and alpha_mult < 1.0 then
            t_obj:color(renderer.get_color_alpha(col_key, alpha_mult))
            return
        end

        t_obj:color(renderer.get_color(col_key))
    end

    local function apply_text_basics(t_obj, fx, fy, s_size, justify)
        t_obj:position(ctx.get_vec2(fx, fy))
        t_obj:scale(s_size)
        t_obj:justify(justify)
    end

    local wrapped_size_opts = { wrap = 0 }
    function renderer.wrapped_text_size(str, size, wrap_width, font_name)
        local folded = renderer.fold_text(str, size, wrap_width, font_name)
        local s_size = math_floor(renderer.s(size))
        wrapped_size_opts.wrap = wrap_width or 0
        wrapped_size_opts.font = nil
        if font_name then
            wrapped_size_opts.font = ctx.fonts_module.get(font_name)
        elseif ctx.get_default_font_name() ~= nil then
            wrapped_size_opts.font = ctx.fonts_module.get_for_size(s_size)
        end
        return ctx.gui_adapter.text_size(folded, s_size, wrapped_size_opts)
    end

    function renderer.draw_text_px(str, x, y, pixel_size, col_key, alpha_mult, override_color_vec)
        local t_obj = ctx.gui_adapter.text(tostring(str or ""))
        t_obj:position(ctx.get_vec2(math_floor(x), math_floor(y)))
        t_obj:scale(math_floor(pixel_size or 0))
        if override_color_vec then
            local a = override_color_vec.a or 255
            if alpha_mult then a = a * alpha_mult end
            t_obj:color(ctx.color(override_color_vec.r or 255, override_color_vec.g or 255, override_color_vec.b or 255, a))
        else
            t_obj:color((alpha_mult and alpha_mult < 1.0) and renderer.get_color_alpha(col_key, alpha_mult) or renderer.get_color(col_key))
        end
        t_obj:draw()
    end

    function renderer.draw_wrapped_text(str, x, y, size, col_key, wrap_width, alpha_mult, override_color_vec, font_name)
        local folded = renderer.fold_text(str, size, wrap_width, font_name)
        local s_size = math_floor(renderer.s(size))

        local font_obj = nil
        local use_custom_font = false
        if font_name then
            font_obj = ctx.fonts_module.get(font_name)
        elseif ctx.get_default_font_name() ~= nil then
            font_obj = ctx.fonts_module.get_for_size(s_size)
            ctx.fonts_module.flush_rebuild(false)
            use_custom_font = true
        end

        local t_obj = ctx.get_text_object(folded, folded, s_size, use_custom_font)
        t_obj:position(ctx.get_vec2(math_floor(x), math_floor(y)))
        t_obj:scale(s_size)
        t_obj:wrap(wrap_width or 0)
        t_obj:justify(ctx.justify_left)
        if font_obj then t_obj:font(font_obj) end

        if override_color_vec then
            local a = override_color_vec.a or 255
            if alpha_mult then a = a * alpha_mult end
            t_obj:color(ctx.color(override_color_vec.r or 255, override_color_vec.g or 255, override_color_vec.b or 255, a))
        else
            t_obj:color((alpha_mult and alpha_mult < 1.0) and renderer.get_color_alpha(col_key, alpha_mult) or renderer.get_color(col_key))
        end
        t_obj:draw()
    end

    function renderer.draw_text_ex(str, x, y, size, col_key, align_w, align_h, alpha_mult, override_color_vec, cache_key, font_name)
        local s_size = math_floor(renderer.s(size))
        local safe_str = tostring(str or "")
        local fx, fy = math_floor(x), math_floor(y)
        local use_justify = 0

        local font_obj, use_custom_font = get_draw_font(s_size)

        if align_h and align_h > 0 then
            fy = fy + math_floor((align_h - s_size) * 0.5) - renderer.s(1)
        end

        if align_w and align_w > 0 then
            use_justify = 1
            fx = fx + math_floor(align_w * 0.5)
        elseif align_w and align_w < 0 then
            use_justify = 2
            fx = fx + (-align_w)
        end

        local cache_id = cache_key or safe_str
        local t_obj = ctx.get_text_object(cache_id, safe_str, s_size, use_custom_font)

        local justify = ctx.justify_left
        if use_justify == 1 then
            justify = ctx.justify_center
        elseif use_justify == 2 then
            justify = ctx.justify_right
        end
        apply_text_basics(t_obj, fx, fy, s_size, justify)

        if font_obj then
            t_obj:font(font_obj)
        end

        apply_text_color(t_obj, col_key, alpha_mult, override_color_vec)
        t_obj:draw()
    end

    function renderer.draw_text(str, x, y, size, col_key, align_w, align_h)
        renderer.draw_text_ex(str, x, y, size, col_key, align_w, align_h, 1.0)
    end

    function renderer.draw_text_right(str, right_x, y, size, col_key, align_h, alpha_mult)
        local s_size = math_floor(renderer.s(size))
        local safe_str = tostring(str or "")
        local fx = math_floor(right_x)
        local fy = math_floor(y)

        if align_h and align_h > 0 then
            fy = fy + math_floor((align_h - s_size) * 0.5) - renderer.s(1)
        end

        local font_obj, use_custom_font = get_draw_font(s_size)

        local t_obj = ctx.get_text_object(safe_str, safe_str, s_size, use_custom_font)

        apply_text_basics(t_obj, fx, fy, s_size, ctx.justify_right)
        if font_obj then t_obj:font(font_obj) end

        apply_text_color(t_obj, col_key, alpha_mult, nil)
        t_obj:draw()
    end
end

local function install_truncate(renderer, ctx)
    local ellipsis_cache = {}
    local ellipsis_cache_count = 0
    local ellipsis_cache_limit <const> = ctx.constants.ELLIPSIS_CACHE_LIMIT or 512

    local function store_truncated(cache_key, result)
        ellipsis_cache_count = CacheUtils.evict_pairs(ellipsis_cache, ellipsis_cache_count, ellipsis_cache_limit, 0.3)
        ellipsis_cache[cache_key] = result
        ellipsis_cache_count = ellipsis_cache_count + 1
        return result
    end

    function renderer.truncate_text(text, font_size, max_width)
        if not text or text == "" then return "" end
        if not max_width or max_width <= 0 then return text end

        local cache_key = text .. "\0" .. (font_size * 100000 + math_floor(max_width))
        local cached = ellipsis_cache[cache_key]
        if cached then return cached end

        local text_w = renderer.get_text_width(text, font_size)
        if text_w <= max_width then
            return store_truncated(cache_key, text)
        end

        local ellipsis = "..."
        local ellipsis_w = renderer.get_text_width(ellipsis, font_size)
        local available_w = max_width - ellipsis_w

        if available_w <= 0 then
            return store_truncated(cache_key, ellipsis)
        end

        local char_count = utf8_len(text)
        if not char_count then
            return store_truncated(cache_key, ellipsis)
        end

        local low, high = 1, char_count
        local best_end = 0

        while low <= high do
            local mid = math_floor((low + high) / 2)
            local next_start = utf8_offset(text, mid + 1)
            local byte_end = next_start and (next_start - 1) or string_len(text)
            local sub_w = renderer.get_text_width(string_sub(text, 1, byte_end), font_size)

            if sub_w <= available_w then
                best_end = byte_end
                low = mid + 1
            else
                high = mid - 1
            end
        end

        if best_end > 0 then
            return store_truncated(cache_key, string_sub(text, 1, best_end) .. ellipsis)
        end
        return store_truncated(cache_key, ellipsis)
    end

    function renderer.clear_ellipsis_cache()
        ellipsis_cache = {}
        ellipsis_cache_count = 0
    end
end

function Text.install(renderer, ctx)
    install_text_width(renderer, ctx)
    install_text_objects(renderer, ctx)
    install_draw_text(renderer, ctx)
    install_truncate(renderer, ctx)
end

return Text
