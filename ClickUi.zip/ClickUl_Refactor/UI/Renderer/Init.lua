local renderer = {}

local state = require("ClickUl_Refactor.UI.State.Init")
local gui_adapter = require("ClickUl_Refactor.Adapters.Gui")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")

local Cache = require("ClickUl_Refactor.UI.Renderer.Cache")
local Text = require("ClickUl_Refactor.UI.Renderer.Text")
local Draw = require("ClickUl_Refactor.UI.Renderer.Draw")

local ctx = {
    state = state,
    gui_adapter = gui_adapter,
    runtime = runtime,
    constants = state.constants,
    vec2 = gui_adapter.vec2,
    color = gui_adapter.color,
    justify_left = gui_adapter.justify.left,
    justify_center = gui_adapter.justify.center,
    justify_right = gui_adapter.justify.right,
    fonts_module = nil,
}

local cached_scale_factor = 0
local scale_configs_dirty = true
local cached_use_custom_font = nil

local RAW_BASE_KEYS <const> = {
    font_header = true, font_tab = true, font_subtab = true,
    font_group = true, font_widget = true, font_small = true,
    combo_max_visible = true,
    click_anim_duration = true, click_anim_alpha = true,
}

function renderer.set_fonts(fonts)
    ctx.fonts_module = fonts
end

function ctx.get_default_font_name()
    if cached_use_custom_font ~= nil then
        return cached_use_custom_font or nil
    end
    local config_sys = state.deps.config_sys
    if config_sys.data and config_sys.data.base then
        local base = config_sys.data.base
        if base.custom_font_enabled and base.custom_font_path and base.custom_font_path ~= "" then
            cached_use_custom_font = "default"
            return "default"
        end
    end
    cached_use_custom_font = false
    return nil
end

function renderer.invalidate_font_cache()
    cached_use_custom_font = nil
    state.cache.text_width = {}
    state.cache.text_width_size = 0
    renderer.clear_ellipsis_cache()
    renderer.clear_fold_cache()
    ctx.clear_text_object_cache()
end

function renderer.mark_scale_dirty()
    scale_configs_dirty = true
end

function renderer.vn(v) return v or 0 end

function renderer.s(val)
    if cached_scale_factor == 0 then
        renderer.update_scale()
    end
    return (val or 0) * cached_scale_factor
end

function renderer.update_scale()
    local ui = state.ui
    local config_sys = state.deps.config_sys

    if ui.scale_factor == 0 then
        local res = runtime.resolution()
        ui.screen_res.x = res.x
        ui.screen_res.y = res.y
        ui.scale_factor = ui.screen_res.y / ctx.constants.SCREEN_DEFAULT_HEIGHT
        if ui.scale_factor < ctx.constants.SCREEN_MIN_SCALE then
            ui.scale_factor = ctx.constants.SCREEN_MIN_SCALE
        end
        if type(ui.scale_factor) == "number" then
            cached_scale_factor = ui.scale_factor
        else
            cached_scale_factor = 1
        end
    end

    if config_sys.data and scale_configs_dirty then
        scale_configs_dirty = false
        local b = config_sys.data.base
        local c = config_sys.data.current
        local s = renderer.s

        for k, v in pairs(b) do
            if type(v) == "number" and not RAW_BASE_KEYS[k] then
                c[k] = s(v)
            else
                c[k] = v
            end
        end

        c.checkbox_use_toggle_style = b.checkbox_use_toggle_style == true
    end
end

function renderer.force_update_scale()
    state.ui.scale_factor = 0
    scale_configs_dirty = true
    cached_use_custom_font = nil
    state.cache.text_width = {}
    state.cache.text_width_size = 0
    renderer.clear_ellipsis_cache()
    renderer.clear_fold_cache()
    renderer.update_scale()
end

Cache.install(renderer, ctx)
Text.install(renderer, ctx)
Draw.install(renderer, ctx)

function renderer.clear_caches()
    ctx.clear_renderer_caches()
end

return renderer
