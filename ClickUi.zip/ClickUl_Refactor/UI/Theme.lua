local theme = {}
local json_adapter = require("ClickUl_Refactor.Adapters.Json")
local fs = require("ClickUl_Refactor.Adapters.Fs")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")
local logger = require("ClickUl_Refactor.Core.Logger")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local lang = nil

local function _T(text)
    local lang_module = assert(lang, "[Theme] language module is required")
    return lang_module.get(text)
end

local function get_base_dir()
    return fs.root_dir()
end

local function get_themes_dir()
    return fs.themes_dir()
end

local settings_store = nil
local autosave_dirty = false

local type <const> = type
local pairs <const> = pairs
local get_time <const> = runtime.now

local last_save_time = 0
local SAVE_THROTTLE_INTERVAL <const> = 0.5

function theme.get_base_dir()
    return get_base_dir()
end

local function encode_json(tbl)
    return json_adapter.encode_document(tbl, 2)
end

local cached_default_config = nil

local function create_default_config()
    local cfg = {
        bg_image_enabled = false,
        bg_image_file = "",
        bg_image_opacity = 255,
        sidebar_icons = {
            self = "Self.png",
            spawn = "Spawn.png",
            vehicle = "Vehicle.png",
            world = "World.png",
            teleport = "Teleport.png",
            game = "Game.png",
            setting = "Setting.png",
        },
        notification_icons = {
            ["Success"] = "logo.png",
            ["Warning"] = "logo.png",
            ["Error"] = "logo.png",
            ["Info"] = "logo.png",
            ["Hotkey"] = "logo.png",
            ["Spectator"] = "logo.png",
            ["Join"] = "logo.png",
            ["Leave"] = "logo.png",
            ["Modder"] = "logo.png",
            ["Script Event"] = "logo.png",
            ["Network Event"] = "logo.png",
            ["Protection"] = "logo.png",
            ["Player Manager"] = "logo.png"
        },
        notification_position = "bottom_right",
         base = {
             x = 901, y = 287,
             w = 700, h = 600,
             header_h = 24,
             sidebar_w = 56,
             padding = 5,
             item_h = 35,
             button_h = 40,
             item_spacing = 8,

             window_rounding_tl = 8,
             window_rounding_tr = 8,
             window_rounding_bl = 8,
             window_rounding_br = 8,
             header_rounding_tl = 8,
             header_rounding_tr = 8,

            font_header = 17,
            font_tab = 15,
            font_subtab = 13,
            font_group = 14,
            font_widget = 14,
            font_small = 13,
            font_notif = 14,
            custom_font_enabled = false,
            custom_font_path = "",
            custom_font_size = 16,

            slider_height = 5,
            slider_track_offset = 30,
            slider_extra_height = 10,

            scrollbar_width = 6,
            scrollbar_thumb_min = 20,
            scrollbar_hit_width = 16,

            checkbox_width = 40,
            checkbox_height = 22,
            checkbox_knob_size = 18,
            checkbox_knob_offset = 2,
            checkbox_track_rounding = 11,
            checkbox_knob_rounding = 4,
            checkbox_use_toggle_style = false,

            toggle_width = 40,
            toggle_height = 22,
            toggle_knob_size = 18,
            toggle_knob_offset = 2,
            toggle_track_rounding = 11,
            toggle_knob_rounding = 9,

            toggle_slider_height = 50,
            toggle_slider_checkbox_size = 22,
            toggle_slider_checkbox_rounding = 4,
            toggle_slider_padding = 10,
            toggle_slider_label_offset = 10,
            toggle_slider_track_height = 5,
            toggle_slider_track_offset = 32,

            widget_rounding = 6,
            widget_text_padding = 10,

             group_header_height = 36,
             group_content_padding = 10,
             group_spacing = 8,
             group_rounding = 8,

            search_box_width = 105,
            search_box_height = 22,

            sidebar_btn_margin = 6,
            sidebar_icon_size = 32,
            sidebar_btn_spacing = 4,
            sidebar_btn_rounding = 6,

             subtab_height = 30,
             subtab_gap = 8,
             subtab_rounding = 6,
             subtab_spacing_after = 6,

            inline_tab_height = 24,
            inline_tab_gap = 4,
            inline_tab_indicator_height = 2,

            separator_height = 1,
            separator_margin = 8,

            progress_height = 8,
            progress_rounding = 4,

            dual_column_gap = 10,
            dual_column_bottom_margin = 10,

            combo_max_visible = 5,
            combo_dropdown_gap = 4,
            combo_thumb_min = 20,

            scroll_speed = 60,
            scroll_group_speed = 40,

            click_anim_duration = 0.25,
            click_anim_alpha = 40,

            content_padding_y = 8,
            window_content_offset = 2,
            divider_width = 1,
            divider_padding = 8,

            overlay_font_size = 14,
            overlay_radius = 4,
            overlay_offset_x = -10,

             notif_radius = 8,
             notif_title_size = 17,
             notif_message_size = 14,
             notif_spacing = 8,
             notif_margin_x = 20,
             notif_margin_y = 20,
             notif_max_count = 12,
             notif_width = 320,
             notif_padding = 6,
             notif_icon_size = 32,
             notif_min_height = 60,
             notif_duration = 5.0,
             notif_anim_speed_in = 4.0,
             notif_anim_stack_speed = 15.0,
             notif_flash_cooldown = 1.5,
             notif_exit_speed_multiplier = 1.5,
             notif_flash_decay_speed = 6.0,
             notif_time_bar_enabled = true,
             notif_time_bar_height = 2,
             notif_time_bar_opacity = 180,

            color_preview_height = 22,
            color_preview_rounding = 4,

            row_gap = 8,

            menu_hints_font_size = 16,
            menu_hints_offset_y = 2,
            menu_hints_height = 30,
            menu_hints_padding = 10,
            menu_hints_rounding = 8,
        },
        current = {},
        colors = {
            ["Window Background"] = {r=24, g=24, b=29, a=250},
            ["Sidebar Background"] = {r=18, g=18, b=22, a=255},
            ["Header Background"] = {r=14, g=14, b=18, a=255},
            ["Background Tint"] = {r=255, g=255, b=255, a=255},
            ["Header Text"] = {r=255, g=255, b=255, a=255},
            ["Text Primary"] = {r=240, g=240, b=245, a=255},
            ["Text Secondary"] = {r=140, g=140, b=155, a=255},
            ["Accent"] = {r=114, g=137, b=218, a=255},
            ["Group Background"] = {r=32, g=32, b=38, a=220},
            ["Group Header Text"] = {r=200, g=200, b=210, a=255},
            ["Group Header Line"] = {r=60, g=60, b=70, a=255},
            ["Collapsible Header"] = {r=40, g=40, b=46, a=255},
            ["Widget Background"] = {r=40, g=40, b=46, a=255},
            ["Widget Hover"] = {r=55, g=55, b=62, a=255},
            ["Player Selected Background"] = {r=60, g=65, b=80, a=255},
            ["Checkbox Active"] = {r=114, g=137, b=218, a=255},
            ["Checkbox Inactive"] = {r=55, g=55, b=62, a=255},
            ["Toggle Active"] = {r=114, g=137, b=218, a=255},
            ["Toggle Inactive"] = {r=70, g=72, b=80, a=255},
            ["Knob"] = {r=255, g=255, b=255, a=255},
            ["Knob Active"] = {r=255, g=255, b=255, a=255},
            ["Knob Inactive"] = {r=140, g=140, b=140, a=255},
            ["Slider Empty"] = {r=25, g=25, b=30, a=255},
            ["Slider Filled"] = {r=114, g=137, b=218, a=255},
            ["Slider Filled Hover"] = {r=170, g=190, b=255, a=255},
            ["Slider Background"] = {r=40, g=40, b=46, a=255},
            ["Slider Background Hover"] = {r=55, g=55, b=62, a=255},
            ["Combo Background"] = {r=32, g=32, b=38, a=255},
            ["Combo Highlight"] = {r=114, g=137, b=218, a=100},
            ["Tab Background"] = {r=28, g=28, b=34, a=255},
            ["Tab Background Hover"] = {r=40, g=40, b=48, a=255},
            ["Tab Background Active"] = {r=114, g=137, b=218, a=255},
            ["Tab Text Inactive"] = {r=100, g=100, b=110, a=255},
            ["Tab Text Active"] = {r=255, g=255, b=255, a=255},
            ["Tab Indicator"] = {r=114, g=137, b=218, a=255},
            ["Subtab Background"] = {r=32, g=32, b=38, a=255},
            ["Subtab Hover"] = {r=45, g=45, b=52, a=255},
            ["Subtab Active"] = {r=114, g=137, b=218, a=255},
            ["Subtab Text Inactive"] = {r=160, g=160, b=170, a=255},
            ["Subtab Text Active"] = {r=255, g=255, b=255, a=255},
            ["Scrollbar"] = {r=114, g=137, b=218, a=150},
            ["Scrollbar Hover"] = {r=160, g=180, b=255, a=255},
            ["Notification Background"] = {r=50, g=55, b=65, a=200},
            ["Notification Hotkey"] = {r=114, g=137, b=218, a=180},
            ["Notification Success"] = {r=75, g=181, b=67, a=180},
            ["Notification Warning"] = {r=250, g=170, b=50, a=180},
            ["Notification Error"] = {r=220, g=53, b=69, a=180},
            ["Notification Spectator"] = {r=220, g=53, b=69, a=180},
            ["Notification Flash"] = {r=255, g=255, b=255, a=150},
            ["Notification Join"] = {r=90, g=160, b=255, a=180},
            ["Notification Leave"] = {r=250, g=170, b=50, a=180},
            ["Notification Modder"] = {r=220, g=53, b=69, a=180},
            ["Notification Script Event"] = {r=220, g=53, b=69, a=180},
            ["Notification Network Event"] = {r=220, g=53, b=69, a=180},
            ["Notification Protection"] = {r=220, g=53, b=69, a=180},
            ["Notification Player Manager"] = {r=100, g=220, b=150, a=180},
            ["Overlay Background"] = {r=24, g=24, b=29, a=250},
            ["Overlay Text"] = {r=255, g=255, b=255, a=255},
            ["Overlay Divider"] = {r=100, g=150, b=255, a=255},
            ["Tag ME"] = {r=90, g=220, b=90, a=255},
            ["Tag Friend"] = {r=90, g=160, b=255, a=255},
            ["Tag Modder"] = {r=255, g=90, b=90, a=255},
            ["Tag God"] = {r=255, g=60, b=60, a=255},
            ["Tag Spectating"] = {r=190, g=100, b=255, a=255},
            ["Tag Modded"] = {r=200, g=80, b=255, a=255},
            ["Tag Bounty"] = {r=255, g=140, b=40, a=255},
            ["Tag Script Host"] = {r=255, g=215, b=0, a=255},
            ["Tag Session Host"] = {r=255, g=230, b=80, a=255},
            ["Tag Vehicle"] = {r=255, g=200, b=60, a=255},
            ["Tag Next Host"] = {r=255, g=110, b=200, a=255},
            ["Tag CEO"] = {r=80, g=240, b=240, a=255},
            ["Tag Dead"] = {r=140, g=140, b=150, a=255},
            ["Tag Interior"] = {r=160, g=160, b=170, a=255},
            ["Tag Controller"] = {r=150, g=150, b=160, a=255},
            ["Inline Tab Active"] = {r=114, g=137, b=218, a=255},
            ["Inline Tab Inactive"] = {r=140, g=140, b=155, a=255},
            ["Inline Tab Indicator"] = {r=114, g=137, b=218, a=255},
            ["Separator Line"] = {r=60, g=60, b=70, a=255},
            ["Separator Text"] = {r=100, g=100, b=110, a=255},
            ["Progress Background"] = {r=40, g=40, b=46, a=255},
            ["Progress Fill"] = {r=114, g=137, b=218, a=255},
            ["Menu Hints Background"] = {r=24, g=24, b=29, a=250},
            ["Menu Hints Text"] = {r=240, g=240, b=245, a=255},
        }
    }

    for k,v in pairs(cfg.base) do
        cfg.current[k] = v
    end

    return cfg
end

local function get_default_config()
    if not cached_default_config then
        cached_default_config = create_default_config()
    end
    return cached_default_config
end

local function copy_string_map(src)
    local out = {}
    if type(src) ~= "table" then return out end
    for k, v in pairs(src) do
        out[k] = v
    end
    return out
end

local function merge_colors_from_decoded(decoded_colors)
    if not decoded_colors then return end

    local defaults = get_default_config().colors
    for k, v in pairs(defaults) do
        if theme.data.colors[k] == nil then
            theme.data.colors[k] = v
        end
    end

    for k, v in pairs(theme.data.colors) do
        local c = decoded_colors[k]
        if c and type(c) == "table" then
            theme.data.colors[k] = {
                r = tonumber(c.r) or v.r,
                g = tonumber(c.g) or v.g,
                b = tonumber(c.b) or v.b,
                a = tonumber(c.a) or v.a
            }
        end
    end

end

local function build_save_data()
    return {
        bg_image_enabled = theme.data.bg_image_enabled,
        bg_image_file = theme.data.bg_image_file or "",
        bg_image_opacity = theme.data.bg_image_opacity or 255,
        sidebar_icons = theme.data.sidebar_icons or {},
        notification_icons = theme.data.notification_icons or {},
        notification_position = theme.data.notification_position or "bottom_right",
        base = theme.data.base,
        colors = theme.data.colors
    }
end

local function apply_decoded_metadata(decoded)
    if decoded.bg_image_enabled ~= nil then
        if type(decoded.bg_image_enabled) == "number" then
            theme.data.bg_image_enabled = (decoded.bg_image_enabled == 1)
        else
            theme.data.bg_image_enabled = decoded.bg_image_enabled
        end
    end

    if decoded.bg_image_file then theme.data.bg_image_file = decoded.bg_image_file end
    if decoded.bg_image_opacity then theme.data.bg_image_opacity = decoded.bg_image_opacity end

    if decoded.sidebar_icons and type(decoded.sidebar_icons) == "table" then
        local icons = {}
        for k, v in pairs(decoded.sidebar_icons) do
            if type(k) == "string" and not k:match("^%d+$") and type(v) == "string" then
                icons[k] = v
            end
        end
        theme.data.sidebar_icons = icons
    end

    if decoded.notification_icons and type(decoded.notification_icons) == "table" then
        local defaults = get_default_config().notification_icons
        for k, v in pairs(defaults) do
            if decoded.notification_icons[k] == nil then
                decoded.notification_icons[k] = v
            end
        end
        theme.data.notification_icons = decoded.notification_icons
    else
        theme.data.notification_icons = copy_string_map(get_default_config().notification_icons)
    end

    if decoded.notification_position and type(decoded.notification_position) == "string" then
        theme.data.notification_position = decoded.notification_position
    else
        theme.data.notification_position = "bottom_right"
    end

    if decoded.base then
        local defaults = get_default_config().base
        for k, v in pairs(defaults) do
            if decoded.base[k] ~= nil then
                theme.data.base[k] = tonumber(decoded.base[k]) or decoded.base[k]
            else
                theme.data.base[k] = v
            end
        end
        for k, v in pairs(theme.data.base) do
            theme.data.current[k] = v
        end
    end

    merge_colors_from_decoded(decoded.colors)
end

local function apply_builtin_defaults()
    theme.data = create_default_config()
end

function theme.init(ctx)
    lang = assert(ctx.lang, "[Theme] language module is required")
    settings_store = assert(ctx.settings, "[Theme] settings module is required")
    logger.info("Theme", "Theme system initializing")
    if not theme.data then apply_builtin_defaults() end
end

function theme.reset()
    autosave_dirty = false
    apply_builtin_defaults()
    theme.set_current_theme_name("Default")
end

function theme.set_base(key, value)
    assert(theme.data and theme.data.base, "[Theme] theme data is not initialized")
    if theme.data.base[key] == value then return false end
    theme.data.base[key] = value
    return true
end

function theme.set_value(key, value)
    assert(theme.data, "[Theme] theme data is not initialized")
    if theme.data[key] == value then return false end
    theme.data[key] = value
    return true
end

function theme.load()
    logger.mark_start("theme_load")
    apply_builtin_defaults()

    local current_name = theme.get_current_theme_name()
    if current_name ~= "Default" then
        if not theme.load_theme(current_name) then
            logger.warn("Theme", "Saved theme not found, using built-in Default", { theme = current_name })
        end
    end

    logger.mark_end("theme_load")
    return true
end

function theme.get_current_theme_name()
    local store = assert(settings_store, "[Theme] settings module is required")
    return store.get_theme_name()
end

function theme.set_current_theme_name(name)
    local store = assert(settings_store, "[Theme] settings module is required")
    store.set_theme_name(name)
end

function theme.list_themes()
    local themes = {}

    local themes_path = get_themes_dir()
    fs.ensure_dir(themes_path)

    for _, f in ipairs(fs.list(themes_path, "json")) do
        local name = f:match("([^\\]+)%.json$") or f:match("([^/]+)%.json$")
        if name and name ~= "Default" and name ~= "clickui_theme" then
            table.insert(themes, name)
        end
    end

    return themes
end

local function is_safe_theme_name(name)
    if type(name) ~= "string" or name == "" then return false end
    if name:find("[/\\:]") or name:find("%.%.") then return false end
    return true
end

function theme.save_as_immediate(theme_name)
    if not is_safe_theme_name(theme_name) or theme_name == "Default" then
        return false, _T("Invalid theme name")
    end

    local themes_path = get_themes_dir()
    local full_path = themes_path .. theme_name .. ".json"

    fs.ensure_dir(themes_path)

    local save_data = build_save_data()

    local content = encode_json(save_data)

    if fs.write_text(full_path, content) then
        theme.set_current_theme_name(theme_name)
        logger.info("Theme", "Theme saved as: " .. theme_name)
        return true
    end

    return false, _T("Theme write failed")
end

function theme.mark_autosave_dirty()
    autosave_dirty = true
end

function theme.auto_save()
    if not autosave_dirty then return true end

    local name = theme.get_current_theme_name()
    if name == "Default" then
        autosave_dirty = false
        return true
    end

    local now = get_time()
    if now - last_save_time < SAVE_THROTTLE_INTERVAL then return true end
    last_save_time = now
    autosave_dirty = false

    io_queue.queue_save(function()
        if theme.get_current_theme_name() ~= name then return true end
        return (theme.save_as_immediate(name))
    end, "theme_autosave")
    return true
end

function theme.force_save()
    if not autosave_dirty then return true end
    autosave_dirty = false

    local name = theme.get_current_theme_name()
    if name == "Default" then return true end
    return (theme.save_as_immediate(name))
end

function theme.load_theme(theme_name)
    if not is_safe_theme_name(theme_name) then
        return false, _T("Invalid theme name")
    end

    theme.force_save()

    local themes_path = get_themes_dir()
    local full_path = themes_path .. theme_name .. ".json"
    local decoded = fs.read_json_value(full_path)

    if not decoded then
        logger.verbose("Theme", "Theme read failed", {path = full_path})
    end

    if not decoded then
        return false, _T("Theme file not found or empty")
    end

    apply_decoded_metadata(decoded)

    theme.set_current_theme_name(theme_name)
    logger.info("Theme", "Theme loaded: " .. theme_name)
    return true
end

return theme
