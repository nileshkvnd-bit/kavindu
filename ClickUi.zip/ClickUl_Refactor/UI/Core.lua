local UI = {}

local pairs <const> = pairs
local collectgarbage <const> = collectgarbage

local state = require("ClickUl_Refactor.UI.State.Init")
local input_module = require("ClickUl_Refactor.UI.Input")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")
local notification = require("ClickUl_Refactor.UI.Notification")
local layout = require("ClickUl_Refactor.UI.Layout.Init")
local widgets = require("ClickUl_Refactor.UI.Widgets")
local hotkey_editor = require("ClickUl_Refactor.UI.HotkeyEditor")
local hints = require("ClickUl_Refactor.UI.Hints")
local logger = require("ClickUl_Refactor.Core.Logger")
local input_adapter = require("ClickUl_Refactor.Adapters.Input")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")
local string_id = require("ClickUl_Refactor.Core.StringId")

local settings_store = nil

local function bind_public_api()
    UI.Sidebar = layout.Sidebar
    UI.SubTabBar = layout.SubTabBar
    UI.SubTabBar2 = layout.SubTabBar2
    UI.Group = layout.Group
    UI.Collapsible = layout.Collapsible
    UI.StickyCollapsible = layout.StickyCollapsible
    UI.ScrollGroup = layout.ScrollGroup
    UI.ScrollGroupEx = layout.ScrollGroupEx
    UI.ScrollGroupWithHeader = layout.ScrollGroupWithHeader
    UI.ScrollGroupWithSearch = layout.ScrollGroupWithSearch
    UI.DualColumn = layout.DualColumn
    UI.DualColumn_FixedLeft = layout.DualColumn_FixedLeft
    UI.Row = layout.Row
    UI.ButtonRow = layout.ButtonRow
    UI.VirtualList = layout.VirtualList
    UI.VirtualListEx = layout.VirtualListEx

    UI.Button = widgets.Button
    UI.ButtonWithStar = widgets.ButtonWithStar
    UI.Checkbox = widgets.Checkbox
    UI.Toggle = widgets.Toggle
    UI.Slider = widgets.Slider
    UI.Combo = widgets.Combo
    UI.TextInput = widgets.TextInput
    UI.ColorPicker = widgets.ColorPicker
    UI.Selectable = widgets.Selectable
    UI.InlineTabBar = widgets.InlineTabBar
    UI.Separator = widgets.Separator
    UI.Text = widgets.Text
    UI.ProgressBar = widgets.ProgressBar
    UI.ToggleSlider = widgets.ToggleSlider
end

function UI.init(ctx)
    local config_sys = assert(ctx.theme, "[UI.Core] theme module is required")
    local settings_module = assert(ctx.settings, "[UI.Core] settings module is required")
    local hotkeys_module = assert(ctx.hotkeys, "[UI.Core] hotkeys module is required")
    local lang_module = assert(ctx.lang, "[UI.Core] language module is required")

    state.set_dependency("config_sys", config_sys)
    state.set_dependency("logger", logger)
    state.set_dependency("lang", lang_module)

    input_module.init_events()

    settings_store = settings_module
    hotkey_editor.init({ hotkeys = hotkeys_module, lang = lang_module, notify = notification.notify })

    bind_public_api()
    logger.info("UI.Core", "Initialized")
end

function UI.toggle_menu()
    state.ui.open = not state.ui.open
    if state.ui.open then
        input_adapter.show_cursor(true)
        input_adapter.disable_input(state.ui.block_input and state.ui.block_input_toggle)
        renderer.force_update_scale()
        renderer.preload_theme_colors()
        layout.refresh_background()
        state.ui.active_id = nil
        state.ui.active_combo = nil
        state.ui.text_input_active = false
        state.ui.scroll_consumed = false
        state.ui.tooltip_text = nil

        state.restore_tab_scroll(state.ui.active_tab)
        state.ui.scroll_y = state.ui.scroll_target

        for _, s_state in pairs(state.ui.scroll_states) do
            if s_state.y and s_state.target then s_state.y = s_state.target end
        end

        if UI.on_menu_open then UI.on_menu_open() end
    else
        input_adapter.show_cursor(false)
        input_adapter.disable_input(false)
        hotkey_editor.close()
        state.save_tab_scroll(state.ui.active_tab)

        state.ui.active_id = nil
        state.ui.active_combo = nil
        state.ui.text_input_active = false

        if not state.deps.config_sys.force_save() then
            logger.error("UI.Core", "theme save failed on menu close")
        end
        if not settings_store.force_save() then
            logger.error("UI.Core", "settings save failed on menu close")
        end
        io_queue.flush_saves()
        UI.clear_cache()
        state.cleanup_dynamic_states()

        if UI.on_menu_close then UI.on_menu_close() end
    end
end

function UI.shutdown()
    if state.ui.open then
        state.save_tab_scroll(state.ui.active_tab)
    end

    state.ui.open = false
    state.ui.active_id = nil
    state.ui.active_combo = nil
    state.ui.text_input_active = false
    state.ui.scroll_consumed = false
    state.ui.tooltip_text = nil

    input_adapter.show_cursor(false)
    input_adapter.disable_input(false)
    input_module.shutdown_events()
    hotkey_editor.close()

    if UI.on_shutdown then UI.on_shutdown() end

    if not state.deps.config_sys.force_save() then
        logger.error("UI.Core", "theme save failed during shutdown")
    end
    if settings_store and not settings_store.force_save() then
        logger.error("UI.Core", "settings save failed during shutdown")
    end
    io_queue.flush_saves()
    UI.clear_cache()
    state.cleanup_dynamic_states()
end

function UI.is_open() return state.ui.open end
function UI.draw_window(title, content_callback) layout.draw_window(title, content_callback) end
function UI.draw_hotkey_editor() hotkey_editor.draw() end
function UI.draw_notifications() notification.draw() end
function UI.notify(msg, type_str) notification.notify(msg, type_str) end
function UI.show_loading(label, progress) layout.show_loading(label, progress) end
function UI.hide_loading() layout.hide_loading() end
function UI.draw_loading_overlay() layout.draw_loading_overlay() end
function UI.handle_hotkey_editor(capture_result) return hotkey_editor.handle_frame(capture_result) end
function UI.clear_frame_events() input_module.clear_frame_events() end
function UI.update_input() input_module.update_mouse_state() end
function UI.block_game_controls() input_module.block_game_controls() end

function UI.get_active_tab() return state.ui.active_tab end
function UI.get_block_input() return state.ui.block_input end
function UI.set_block_input(val) state.ui.block_input = val end
function UI.is_text_input_active() return state.ui.text_input_active end
function UI.get_clipboard() return input_module.get_from_clipboard() end
function UI.set_settings_tab_index(idx) state.ui.settings_tab_index = idx end
function UI.get_button_h()
    local cfg = state.deps.config_sys.data.current
    return cfg.button_h or cfg.item_h
end

function UI.get_item_h()
    return state.deps.config_sys.data.current.item_h
end

function UI.get_favorite_target() return hints.get_favorite_target() end

function UI.set_active_special_page(key) state.ui.active_special_page = key end

function UI.set_header_star(spec) state.ui.header_star = spec end
function UI.clear_cache()
    state.reset_cache()
    renderer.clear_caches()
    notification.clear_cache()
    layout.clear_failed_images()
    hotkey_editor.close()
    hints.clear()
    widgets.clear_cache()
    string_id.clear()

    collectgarbage("step", 100)
end

function UI.update_colors()
    state.reset_color_cache()
    renderer.reset_color_cache()
    renderer.preload_theme_colors()
end

function UI.force_update_scale() renderer.force_update_scale() end
function UI.mark_scale_dirty() renderer.mark_scale_dirty() end
function UI.invalidate_font_cache() renderer.invalidate_font_cache() end
function UI.refresh_background() layout.refresh_background() end
function UI.clear_failed_images() layout.clear_failed_images() end

function UI.auto_save_settings()
    state.deps.config_sys.auto_save()
    return settings_store.auto_save()
end

return UI
