local module = {}

local ui = nil
local config = nil
local lang = nil
local logger = require("ClickUl_Refactor.Core.Logger")
local fs = require("ClickUl_Refactor.Adapters.Fs")
local fonts_module = require("ClickUl_Refactor.UI.Fonts")
local settings_state = require("ClickUl_Refactor.UI.Settings.State")
local color_categories = require("ClickUl_Refactor.UI.Settings.ColorCategories")
local general_page = require("ClickUl_Refactor.UI.Settings.GeneralPage")
local layout_page = require("ClickUl_Refactor.UI.Settings.LayoutPage")
local theme_page = require("ClickUl_Refactor.UI.Settings.ThemePage")
local icons_page = require("ClickUl_Refactor.UI.Settings.IconsPage")
local notification_page = require("ClickUl_Refactor.UI.Settings.NotificationPage")
local player_info_page = require("ClickUl_Refactor.UI.Settings.PlayerInfoPage")
local hotkeys_page = require("ClickUl_Refactor.UI.Settings.HotkeysPage")
local logging_page = require("ClickUl_Refactor.UI.Settings.LoggingPage")
local settings_store = nil
local input_module = nil
local theme_module = require("ClickUl_Refactor.UI.Theme")

local table_insert <const> = table.insert
local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

local function set_theme_base(key, value)
    local changed = theme_module.set_base(key, value)
    if changed then
        ui.mark_scale_dirty()
        theme_module.mark_autosave_dirty()
    end
    return changed
end

local function set_theme_value(key, value)
    local changed = theme_module.set_value(key, value)
    if changed then theme_module.mark_autosave_dirty() end
    return changed
end

local function set_theme_table_value(tbl, key, value)
    if tbl[key] == value then return false end
    tbl[key] = value
    theme_module.mark_autosave_dirty()
    return true
end

local function color_picker(label, tbl, key)
    local changed = ui.ColorPicker(label, tbl, key)
    if changed then theme_module.mark_autosave_dirty() end
    return changed
end

local state = nil
local NONE_VALUE <const> = settings_state.NONE_VALUE

local function sync_logging_settings()
    local cfg = logger.get_config()

    settings_store.set_logging_config({
        enabled = cfg.enabled,
        log_level = cfg.log_level,
        show_timestamp = cfg.show_timestamp,
        show_memory = cfg.show_memory,
        show_performance = cfg.show_performance,
        log_to_file = cfg.log_to_file,
        print_to_console = cfg.print_to_console,
        module_filter = cfg.module_filter
    })
end

local function rebuild_color_cache()
    local categories = color_categories.build_existing(config.data.colors)

    state.color_keys_window = categories.window
    state.color_keys_group = categories.group
    state.color_keys_text = categories.text
    state.color_keys_tab = categories.tab
    state.color_keys_subtab = categories.subtab
    state.color_keys_controls = categories.controls
    state.color_keys_slider = categories.slider
    state.color_keys_combo = categories.combo
    state.color_keys_scrollbar = categories.scrollbar
    state.color_keys_inline = categories.inline
    state.color_keys_progress = categories.progress
    state.color_keys_menu_hints = categories.menu_hints
    state.color_keys_tags = categories.tags
    state.color_keys_overlay = categories.overlay
    state.color_keys_notify_left = categories.notify_left
    state.color_keys_notify_right = categories.notify_right
    state.color_keys_other = categories.other
end

local function refresh_theme_list(force)
    if state.themes_cached and not force then
        return
    end

    state.available_themes = config.list_themes()

    local current_name = config.get_current_theme_name()
    state.current_theme_idx = 1
    for i, theme_name in ipairs(state.available_themes) do
        if theme_name == current_name then
            state.current_theme_idx = i
            break
        end
    end

    state.themes_cached = true
end

local function display_image_name(name)
    return name == NONE_VALUE and _T("None") or name
end

local function display_value_list(values)
    local labels = {}
    for i, name in ipairs(values) do
        labels[i] = display_image_name(name)
    end
    return labels
end

local function invalidate_display_lists()
    state.bg_image_labels = nil
    state.available_font_labels = nil
end

local function image_value_from_index(index)
    return state.bg_images[index] or NONE_VALUE
end

local function image_combo(label, current_idx)
    if not state.bg_image_labels then
        state.bg_image_labels = display_value_list(state.bg_images)
    end
    return ui.Combo(label, current_idx, state.bg_image_labels)
end

local function font_combo(label, current_idx)
    if not state.available_font_labels then
        state.available_font_labels = display_value_list(state.available_fonts)
    end
    return ui.Combo(label, current_idx, state.available_font_labels)
end

local function refresh_image_list(force)
    if state.images_cached and not force then
        return
    end

    state.bg_images = {NONE_VALUE}
    state.bg_image_labels = nil

    local img_path = fs.images_dir()

    fs.ensure_dir(img_path)

    for _, ext in ipairs({"png", "jpg", "gif"}) do
        for _, f in ipairs(fs.list(img_path, ext)) do
            local name = f:match("([^\\]+)$") or f:match("([^/]+)$") or f
            table_insert(state.bg_images, name)
        end
    end

    local current = config.data.bg_image_file
    state.bg_idx = 1
    if current and current ~= "" then
        for i, name in ipairs(state.bg_images) do
            if name == current then
                state.bg_idx = i
                break
            end
        end
    end

    state.images_cached = true
end

local function refresh_font_list(force)
    if state.fonts_cached and not force then
        return
    end

    state.available_fonts = {NONE_VALUE}
    state.available_font_labels = nil

    local available = fonts_module.list_available()
    if available then
        for _, font_file in ipairs(available) do
            table.insert(state.available_fonts, font_file)
        end
    end

    local current_font = config.data.base.custom_font_path or ""
    state.font_idx = 1
    if current_font ~= "" then
        for i, name in ipairs(state.available_fonts) do
            if name == current_font then
                state.font_idx = i
                break
            end
        end
    end

    state.fonts_cached = true
end

function module.init(ctx)
    ui = assert(ctx.ui, "[Setting] UI library is required")
    config = assert(ctx.theme, "[Setting] theme module is required")
    lang = assert(ctx.lang, "[Setting] language module is required")
    settings_store = assert(ctx.settings, "[Setting] settings module is required")
    input_module = assert(ctx.input, "[Setting] input module is required")
    local hotkeys_module = assert(ctx.hotkeys, "[Setting] hotkeys module is required")

    state = settings_state.create()

    general_page.init({
        ui = ui,
        config = config,
        lang = lang,
        settings = settings_store,
        fonts = fonts_module,
        state = state,
        none_value = NONE_VALUE,
        refresh_font_list = refresh_font_list,
        invalidate_display_lists = invalidate_display_lists,
        font_combo = font_combo,
        set_theme_base = set_theme_base,
    })
    layout_page.init({ ui = ui, config = config, lang = lang, state = state, set_theme_base = set_theme_base })
    theme_page.init({
        ui = ui,
        config = config,
        lang = lang,
        state = state,
        rebuild_color_cache = rebuild_color_cache,
        refresh_theme_list = refresh_theme_list,
        refresh_image_list = refresh_image_list,
        color_picker = color_picker,
    })
    icons_page.init({
        ui = ui,
        config = config,
        lang = lang,
        fs = fs,
        input = input_module,
        state = state,
        none_value = NONE_VALUE,
        image_combo = image_combo,
        image_value_from_index = image_value_from_index,
        refresh_image_list = refresh_image_list,
        set_theme_value = set_theme_value,
        set_theme_table_value = set_theme_table_value,
    })
    notification_page.init({
        ui = ui,
        config = config,
        lang = lang,
        state = state,
        rebuild_color_cache = rebuild_color_cache,
        color_picker = color_picker,
        set_theme_base = set_theme_base,
        set_theme_value = set_theme_value,
    })
    player_info_page.init({
        ui = ui,
        config = config,
        lang = lang,
        state = state,
        rebuild_color_cache = rebuild_color_cache,
        color_picker = color_picker,
        set_theme_base = set_theme_base,
    })
    hotkeys_page.init({ ui = ui, lang = lang, hotkeys = hotkeys_module })
    logging_page.init({ ui = ui, lang = lang, logger = logger, sync_logging_settings = sync_logging_settings })

    logger.info("UI.Settings", "Module initialized successfully")

    rebuild_color_cache()

    if not config.data.sidebar_icons then
        set_theme_value("sidebar_icons", {})
    end
    refresh_image_list()
    refresh_theme_list()
    refresh_font_list()

    if config.data.base.custom_font_enabled and config.data.base.custom_font_path and config.data.base.custom_font_path ~= "" then
        fonts_module.set_font_path(config.data.base.custom_font_path)
        logger.info("UI.Settings", "Custom font enabled: " .. config.data.base.custom_font_path)
    end

    sync_logging_settings()

    return true
end

function module.on_menu_open()
    if not state.color_keys_window then
        rebuild_color_cache()
    end
end

function module.on_menu_close()
    sync_logging_settings()
end

local SUBTAB_KEYS <const> = {
    "General", "Layout", "Theme", "Icons", "Notify", "Player Info", "Logging", "Hotkeys",
}

function module.draw()
    state.subtab_idx = ui.SubTabBar(lang.translate_list(SUBTAB_KEYS), state.subtab_idx or 1)

    if state.subtab_idx == 1 then
        general_page.draw()

    elseif state.subtab_idx == 2 then
        layout_page.draw()

    elseif state.subtab_idx == 3 then
        theme_page.draw()

    elseif state.subtab_idx == 4 then
        icons_page.draw()

    elseif state.subtab_idx == 5 then
        notification_page.draw()

    elseif state.subtab_idx == 6 then
        player_info_page.draw()

    elseif state.subtab_idx == 7 then
        logging_page.draw()
    elseif state.subtab_idx == 8 then
        hotkeys_page.draw()
    end
end

return module
