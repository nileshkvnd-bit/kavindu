local SidebarIconsSection = {}

local ui = nil
local config = nil
local lang = nil
local image_combo = nil
local image_value_from_index = nil
local image_index_for = nil
local set_theme_value = nil
local set_theme_table_value = nil

local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

function SidebarIconsSection.init(ctx)
    ui = assert(ctx.ui, "[Settings.SidebarIconsSection] UI library is required")
    config = assert(ctx.config, "[Settings.SidebarIconsSection] config module is required")
    lang = assert(ctx.lang, "[Settings.SidebarIconsSection] language module is required")
    image_combo = assert(ctx.image_combo, "[Settings.SidebarIconsSection] image_combo is required")
    image_value_from_index = assert(ctx.image_value_from_index, "[Settings.SidebarIconsSection] image_value_from_index is required")
    image_index_for = assert(ctx.image_index_for, "[Settings.SidebarIconsSection] image_index_for is required")
    set_theme_value = assert(ctx.set_theme_value, "[Settings.SidebarIconsSection] set_theme_value is required")
    set_theme_table_value = assert(ctx.set_theme_table_value, "[Settings.SidebarIconsSection] set_theme_table_value is required")
    return true
end

local slot_labels = {}
local slot_labels_language = nil

local function slot_label(tab)
    if slot_labels_language ~= lang.get_language() then
        slot_labels = {}
        slot_labels_language = lang.get_language()
    end
    local label = slot_labels[tab.key]
    if not label then
        label = _T(tab.label .. " Icon")
        slot_labels[tab.key] = label
    end
    return label
end

local function draw_slots()
    local tabs = ui.get_sidebar_tabs()

    local icons = config.data.sidebar_icons
    if not icons then
        set_theme_value("sidebar_icons", {})
        icons = config.data.sidebar_icons
    end

    for _, tab in ipairs(tabs) do
        local current_val = icons[tab.key] or "None"
        local current_idx = image_index_for(current_val)
        local new_idx = image_combo(slot_label(tab), current_idx)

        if new_idx ~= current_idx then
            local selected = image_value_from_index(new_idx)
            set_theme_table_value(icons, tab.key, selected)
            ui.clear_cache()
        end
    end
end

function SidebarIconsSection.draw()
    ui.Group(_T("Sidebar Icons"), draw_slots)
end

return SidebarIconsSection
