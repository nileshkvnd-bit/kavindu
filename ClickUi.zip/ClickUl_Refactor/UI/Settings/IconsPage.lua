local IconsPage = {}

local sidebar_icons_section = require("ClickUl_Refactor.UI.Settings.SidebarIconsSection")
local background_image_section = require("ClickUl_Refactor.UI.Settings.BackgroundImageSection")
local notification_icons_section = require("ClickUl_Refactor.UI.Settings.NotificationIconsSection")

local ui = nil
local lang = nil
local state = nil

local ipairs <const> = ipairs

local function create_image_index_for(state_ref)
    return function(value)
        local current_idx = 1
        for idx, img in ipairs(state_ref.bg_images) do
            if img == value then
                current_idx = idx
                break
            end
        end
        return current_idx
    end
end

function IconsPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.IconsPage] UI library is required")
    lang = assert(ctx.lang, "[Settings.IconsPage] language module is required")
    state = assert(ctx.state, "[Settings.IconsPage] state table is required")

    local image_ctx = {
        ui = ui,
        config = assert(ctx.config, "[Settings.IconsPage] config module is required"),
        lang = lang,
        state = state,
        image_combo = assert(ctx.image_combo, "[Settings.IconsPage] image_combo is required"),
        image_value_from_index = assert(ctx.image_value_from_index, "[Settings.IconsPage] image_value_from_index is required"),
        image_index_for = create_image_index_for(state),
        set_theme_value = assert(ctx.set_theme_value, "[Settings.IconsPage] set_theme_value is required"),
        set_theme_table_value = assert(ctx.set_theme_table_value, "[Settings.IconsPage] set_theme_table_value is required"),
    }

    sidebar_icons_section.init({
        ui = image_ctx.ui,
        config = image_ctx.config,
        lang = image_ctx.lang,
        image_combo = image_ctx.image_combo,
        image_value_from_index = image_ctx.image_value_from_index,
        image_index_for = image_ctx.image_index_for,
        set_theme_value = image_ctx.set_theme_value,
        set_theme_table_value = image_ctx.set_theme_table_value,
    })

    background_image_section.init({
        ui = image_ctx.ui,
        config = image_ctx.config,
        lang = image_ctx.lang,
        fs = assert(ctx.fs, "[Settings.IconsPage] fs adapter is required"),
        input = assert(ctx.input, "[Settings.IconsPage] input module is required"),
        state = image_ctx.state,
        none_value = assert(ctx.none_value, "[Settings.IconsPage] none value is required"),
        image_combo = image_ctx.image_combo,
        image_value_from_index = image_ctx.image_value_from_index,
        refresh_image_list = assert(ctx.refresh_image_list, "[Settings.IconsPage] refresh_image_list is required"),
        set_theme_value = image_ctx.set_theme_value,
    })

    notification_icons_section.init({
        ui = image_ctx.ui,
        config = image_ctx.config,
        lang = image_ctx.lang,
        image_combo = image_ctx.image_combo,
        image_value_from_index = image_ctx.image_value_from_index,
        image_index_for = image_ctx.image_index_for,
        set_theme_value = image_ctx.set_theme_value,
        set_theme_table_value = image_ctx.set_theme_table_value,
    })

    return true
end

local SUBTAB_KEYS <const> = { "Sidebar", "Notification" }

function IconsPage.draw()
    state.icons_subtab_idx = ui.SubTabBar2(lang.translate_list(SUBTAB_KEYS), state.icons_subtab_idx or 1)

    if state.icons_subtab_idx == 1 then
        ui.DualColumn(sidebar_icons_section.draw, background_image_section.draw)
    elseif state.icons_subtab_idx == 2 then
        notification_icons_section.draw()
    end
end

return IconsPage
