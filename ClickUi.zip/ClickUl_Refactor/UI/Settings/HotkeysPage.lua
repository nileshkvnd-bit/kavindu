local HotkeysPage = {}

local hotkey_editor = require("ClickUl_Refactor.UI.HotkeyEditor")

local ipairs <const> = ipairs

local ui = nil
local lang = nil
local hotkeys = nil

local state = {
    subtab_idx = 1,
}

local function _T(text)
    return lang.get(text)
end

local function action_label(action)
    if not action then return "" end
    return _T(action.label)
end

local label_cache = { revision = nil, labels = {} }

local function slot_label(action_id, slot)
    local rev = hotkeys.get_revision()
    if label_cache.revision ~= rev then
        label_cache.revision = rev
        for k in pairs(label_cache.labels) do label_cache.labels[k] = nil end
    end
    local slots = label_cache.labels[action_id]
    if not slots then
        slots = {}
        label_cache.labels[action_id] = slots
    end
    local text = slots[slot]
    if text == nil then
        local binding = hotkeys.get_binding(action_id, slot)
        text = binding and hotkeys.format_binding(binding) or false
        slots[slot] = text
    end
    return text
end

local function hotkey_button_label(action_id, slot)
    local capture = hotkeys.get_capture()
    if capture and capture.action_id == action_id and capture.slot == slot then
        return _T("Press a key")
    end

    return slot_label(action_id, slot) or _T("Unbound")
end

local function open_hotkey_editor(action)
    hotkey_editor.open({
        action_id = action.id,
        label = action_label(action),
        path = action.path or action.label,
        description = action.description,
    })
end

local action_row_cache = {}

local function get_action_row(action)
    local entry = action_row_cache[action.id]
    if entry then return entry end

    entry = {
        row = {},
        opts = { gap = 6 },
        slot1 = function()
            if ui.Button(hotkey_button_label(action.id, 1)) then
                open_hotkey_editor(action)
            end
        end,
        slot2 = function()
            if ui.Button(hotkey_button_label(action.id, 2)) then
                open_hotkey_editor(action)
            end
        end,
        edit = function()
            if ui.Button(_T("Edit")) then
                open_hotkey_editor(action)
            end
        end,
    }
    action_row_cache[action.id] = entry
    return entry
end

local function render_hotkey_action(action)
    ui.Text(action_label(action), "Text Primary")

    local entry = get_action_row(action)
    local row = entry.row
    local count = 1
    row[1] = entry.slot1

    if slot_label(action.id, 2) then
        count = 2
        row[2] = entry.slot2
    end
    count = count + 1
    row[count] = entry.edit
    for i = count + 1, #row do row[i] = nil end

    ui.Row(row, entry.opts)
    return true
end

local current_group_actions = nil
local function draw_group_actions()
    for _, action in ipairs(current_group_actions) do
        render_hotkey_action(action)
    end
end

local function render_hotkey_group(title, actions)
    if #actions == 0 then return false end

    current_group_actions = actions
    ui.Group(_T(title), draw_group_actions)
    return true
end

local SUBTAB_KEYS <const> = { "Settings", "Hotkey Management" }

local function draw_hotkey_controls()
    local enabled = hotkeys.is_enabled()
    local new_enabled = ui.Checkbox(_T("Enable Feature Hotkeys"), enabled)
    if new_enabled ~= enabled then
        hotkeys.set_enabled(new_enabled)
    end

    local notify_enabled = hotkeys.is_trigger_notification_enabled()
    local new_notify_enabled = ui.Checkbox(_T("Hotkey Trigger Notifications"), notify_enabled)
    if new_notify_enabled ~= notify_enabled then
        hotkeys.set_trigger_notification_enabled(new_notify_enabled)
    end

    if ui.Button(_T("Reset Hotkeys")) then
        hotkeys.reset_defaults()
        ui.notify(_T("Hotkeys reset"), "Warning")
    end
end

local function render_hotkey_controls()
    ui.Group(_T("Hotkeys"), draw_hotkey_controls)
end

local function render_hotkey_column(tab_entry, column)
    if not tab_entry then return end

    for _, group_name in ipairs(tab_entry.group_order) do
        local group_column = tab_entry.group_columns[group_name] or 1
        if group_column == column then
            local actions = tab_entry.groups[group_name]
            render_hotkey_group(group_name, actions)
        end
    end
end

local function render_tab_groups(tab_entry)
    if not tab_entry then return end
    for _, group_name in ipairs(tab_entry.group_order) do
        render_hotkey_group(group_name, tab_entry.groups[group_name])
    end
end

local managed_tabs = {}
local function draw_left_column()
    for i = 1, #managed_tabs do render_hotkey_column(managed_tabs[i], 1) end
end
local function draw_right_column()
    for i = 1, #managed_tabs do render_hotkey_column(managed_tabs[i], 2) end
end

local settings_tabs = nil
local function draw_settings_left() render_hotkey_controls() end
local function draw_settings_right()
    render_tab_groups(settings_tabs and settings_tabs["System"])
    render_tab_groups(settings_tabs and settings_tabs["Favorites"])
end

function HotkeysPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.HotkeysPage] UI library is required")
    lang = assert(ctx.lang, "[Settings.HotkeysPage] language module is required")
    hotkeys = assert(ctx.hotkeys, "[Settings.HotkeysPage] hotkeys module is required")
    return true
end

function HotkeysPage.draw()
    local tabs, tab_order = hotkeys.get_tabbed_actions()

    state.subtab_idx = ui.SubTabBar2(lang.translate_list(SUBTAB_KEYS), state.subtab_idx or 1)

    if state.subtab_idx == 1 then
        settings_tabs = tabs
        ui.DualColumn(draw_settings_left, draw_settings_right)
        return
    end

    local count = 0
    for _, tab_name in ipairs(tab_order) do
        if tab_name ~= "System" and tab_name ~= "Favorites" then
            count = count + 1
            managed_tabs[count] = tabs[tab_name]
        end
    end
    for i = count + 1, #managed_tabs do managed_tabs[i] = nil end
    ui.DualColumn(draw_left_column, draw_right_column)
end

return HotkeysPage
