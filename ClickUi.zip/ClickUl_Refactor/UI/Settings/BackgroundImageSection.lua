local BackgroundImageSection = {}

local ui = nil
local config = nil
local lang = nil
local fs = nil
local input_module = nil
local state = nil
local none_value = nil
local image_combo = nil
local image_value_from_index = nil
local refresh_image_list = nil
local set_theme_value = nil

local function _T(text)
    return lang.get(text)
end

function BackgroundImageSection.init(ctx)
    ui = assert(ctx.ui, "[Settings.BackgroundImageSection] UI library is required")
    config = assert(ctx.config, "[Settings.BackgroundImageSection] config module is required")
    lang = assert(ctx.lang, "[Settings.BackgroundImageSection] language module is required")
    fs = assert(ctx.fs, "[Settings.BackgroundImageSection] fs adapter is required")
    input_module = assert(ctx.input, "[Settings.BackgroundImageSection] input module is required")
    state = assert(ctx.state, "[Settings.BackgroundImageSection] state table is required")
    none_value = assert(ctx.none_value, "[Settings.BackgroundImageSection] none value is required")
    image_combo = assert(ctx.image_combo, "[Settings.BackgroundImageSection] image_combo is required")
    image_value_from_index = assert(ctx.image_value_from_index, "[Settings.BackgroundImageSection] image_value_from_index is required")
    refresh_image_list = assert(ctx.refresh_image_list, "[Settings.BackgroundImageSection] refresh_image_list is required")
    set_theme_value = assert(ctx.set_theme_value, "[Settings.BackgroundImageSection] set_theme_value is required")
    return true
end

function BackgroundImageSection.draw()
    ui.Group(_T("Background Image"), function()
        local is_enabled = config.data.bg_image_enabled
        local new_enabled = ui.Checkbox(_T("Enable Background"), is_enabled)

        if new_enabled ~= is_enabled then
            set_theme_value("bg_image_enabled", new_enabled)
            ui.refresh_background()
        end

        if config.data.bg_image_enabled then
            local new_idx = image_combo(_T("Image File"), state.bg_idx)
            if new_idx ~= state.bg_idx then
                state.bg_idx = new_idx
                local selected = image_value_from_index(new_idx)
                set_theme_value("bg_image_file", selected == none_value and "" or selected)
                ui.refresh_background()
            end

            local opacity = config.data.bg_image_opacity or 255
            local new_opacity = ui.Slider(_T("Opacity"), opacity, 0, 255, 1)
            if new_opacity ~= opacity then
                set_theme_value("bg_image_opacity", new_opacity)
            end

            if ui.Button(_T("Reload Images List")) then
                refresh_image_list(true)
                ui.notify(_T("Images refreshed"), "Success")
            end

            if #state.bg_images <= 1 then
                ui.Button(_T("Put images in: ClickUl_Refactor/Images/"))
            end
        end
    end)

    ui.Group(_T("Help & Info"), function()
        ui.Button(_T("Formats: .png, .jpg, .gif"))

        if ui.Button(_T("Copy Image Folder Path")) then
            input_module.copy_to_clipboard(fs.images_dir())
            ui.notify(_T("Copied to clipboard"), "Success")
        end

        ui.Button(_T("Tip: Click 'Reload' after adding files"))
    end)
end

return BackgroundImageSection
