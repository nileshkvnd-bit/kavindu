local LayoutPage = {}

local ui = nil
local config = nil
local lang = nil
local state = nil
local set_theme_base = nil

local math_floor <const> = math.floor

local function _T(text)
    return lang.get(text)
end


local function group_interface_layout()
    set_theme_base("w", ui.Slider(_T("Menu Width"), config.data.base.w, 500, 1000, 10))
    set_theme_base("h", ui.Slider(_T("Menu Height"), config.data.base.h, 300, 1080, 10))
    set_theme_base("header_h", ui.Slider(_T("Header Height"), config.data.base.header_h, 20, 100, 1))
    set_theme_base("sidebar_w", ui.Slider(_T("Sidebar Width"), config.data.base.sidebar_w, 40, 150, 1))
    set_theme_base("padding", ui.Slider(_T("Padding"), config.data.base.padding or 5, 5, 40, 1))
    set_theme_base("item_h", ui.Slider(_T("Item Height"), config.data.base.item_h or 40, 24, 60, 1))
    set_theme_base("button_h", ui.Slider(_T("Button Height"), config.data.base.button_h or 40, 24, 60, 1))
    set_theme_base("item_spacing", ui.Slider(_T("Item Spacing"), config.data.base.item_spacing or 8, 2, 20, 1))
end

local function group_corner_rounding()
    local old_rounding = config.data.base.window_rounding or 8
    local rounding = ui.Slider(_T("Window Rounding"), old_rounding, 0, 30, 1)
    if rounding ~= old_rounding then
        set_theme_base("window_rounding", rounding)
        set_theme_base("window_rounding_tl", rounding)
        set_theme_base("window_rounding_tr", rounding)
        set_theme_base("window_rounding_bl", rounding)
        set_theme_base("window_rounding_br", rounding)
        set_theme_base("header_rounding_tl", rounding)
        set_theme_base("header_rounding_tr", rounding)
    end
end

local function group_sidebar()
    set_theme_base("sidebar_btn_margin", ui.Slider(_T("Button Margin"), config.data.base.sidebar_btn_margin or 6, 2, 16, 1))
    set_theme_base("sidebar_icon_size", ui.Slider(_T("Icon Size"), config.data.base.sidebar_icon_size or 32, 16, 48, 1))
    set_theme_base("sidebar_btn_spacing", ui.Slider(_T("Button Spacing"), config.data.base.sidebar_btn_spacing or 4, 0, 12, 1))
    set_theme_base("sidebar_btn_rounding", ui.Slider(_T("Button Rounding"), config.data.base.sidebar_btn_rounding or 6, 0, 20, 1))
end

local function group_subtab_bar()
    set_theme_base("subtab_height", ui.Slider(_T("Height"), config.data.base.subtab_height or 30, 20, 50, 1))
    set_theme_base("subtab_gap", ui.Slider(_T("Gap"), config.data.base.subtab_gap or 8, 2, 20, 1))
    set_theme_base("subtab_rounding", ui.Slider(_T("Rounding"), config.data.base.subtab_rounding or 6, 0, 20, 1))
    set_theme_base("subtab_spacing_after", ui.Slider(_T("Spacing After"), config.data.base.subtab_spacing_after or 6, 0, 30, 1))
end

local function group_font_sizes()
    set_theme_base("font_header", ui.Slider(_T("Header Font"), config.data.base.font_header, 14, 32, 1))
    set_theme_base("font_tab", ui.Slider(_T("Tab Font"), config.data.base.font_tab or 15, 14, 32, 1))
    set_theme_base("font_subtab", ui.Slider(_T("SubTab Font"), config.data.base.font_subtab or 13, 10, 24, 1))
    set_theme_base("font_group", ui.Slider(_T("Group Font"), config.data.base.font_group, 10, 24, 1))
    set_theme_base("font_widget", ui.Slider(_T("Widget Font"), config.data.base.font_widget, 10, 24, 1))
    set_theme_base("font_small", ui.Slider(_T("Small Text Font"), config.data.base.font_small, 8, 20, 1))
end

local function group_group_settings()
    set_theme_base("group_header_height", ui.Slider(_T("Header Height"), config.data.base.group_header_height or 36, 24, 60, 1))
    set_theme_base("group_content_padding", ui.Slider(_T("Content Padding"), config.data.base.group_content_padding or 10, 4, 24, 1))
    set_theme_base("group_spacing", ui.Slider(_T("Spacing"), config.data.base.group_spacing or 8, 4, 32, 1))
    set_theme_base("group_rounding", ui.Slider(_T("Rounding"), config.data.base.group_rounding or 8, 0, 20, 1))
end

local function group_search_box()
    set_theme_base("search_box_width", ui.Slider(_T("Width"), config.data.base.search_box_width or 255, 50, 400, 5))
    set_theme_base("search_box_height", ui.Slider(_T("Height"), config.data.base.search_box_height or 50, 16, 100, 1))
end

local function group_widget_general()
    set_theme_base("widget_rounding", ui.Slider(_T("Rounding"), config.data.base.widget_rounding or 6, 0, 16, 1))
    set_theme_base("widget_text_padding", ui.Slider(_T("Text Padding"), config.data.base.widget_text_padding or 10, 4, 24, 1))
end

local function interface_left()
    ui.Group(_T("Interface Layout"), group_interface_layout)
    ui.Group(_T("Corner Rounding"), group_corner_rounding)
    ui.Group(_T("Sidebar"), group_sidebar)
    ui.Group(_T("SubTab Bar"), group_subtab_bar)
end

local function interface_right()
    ui.Group(_T("Font Sizes"), group_font_sizes)
    ui.Group(_T("Group Settings"), group_group_settings)
    ui.Group(_T("Search Box"), group_search_box)
    ui.Group(_T("Widget General"), group_widget_general)
end

local function render_interface_parameters()
    ui.DualColumn(interface_left, interface_right)
end


local function group_slider_settings()
    set_theme_base("slider_height", ui.Slider(_T("Thickness"), config.data.base.slider_height, 2, 12, 1))
    set_theme_base("slider_track_offset", ui.Slider(_T("Vertical Offset"), config.data.base.slider_track_offset, 20, 50, 1))
    set_theme_base("slider_extra_height", ui.Slider(_T("Extra Height"), config.data.base.slider_extra_height or 20, 10, 40, 1))
end

local function group_scrollbar()
    set_theme_base("scrollbar_width", ui.Slider(_T("Scrollbar Width"), config.data.base.scrollbar_width, 2, 20, 1))
    set_theme_base("scrollbar_thumb_min", ui.Slider(_T("Thumb Min Size"), config.data.base.scrollbar_thumb_min or 20, 10, 50, 1))
    set_theme_base("scrollbar_hit_width", ui.Slider(_T("Hit Width"), config.data.base.scrollbar_hit_width or 16, 8, 30, 1))
end

local function group_checkbox()
    set_theme_base("checkbox_width", ui.Slider(_T("Width"), config.data.base.checkbox_width or 40, 30, 60, 1))
    set_theme_base("checkbox_height", ui.Slider(_T("Height"), config.data.base.checkbox_height or 22, 16, 36, 1))
    set_theme_base("checkbox_knob_size", ui.Slider(_T("Knob Size"), config.data.base.checkbox_knob_size or 18, 10, 30, 1))
    set_theme_base("checkbox_knob_offset", ui.Slider(_T("Knob Offset"), config.data.base.checkbox_knob_offset or 2, 0, 6, 1))
    set_theme_base("checkbox_track_rounding", ui.Slider(_T("Track Rounding"), config.data.base.checkbox_track_rounding or 11, 0, 20, 1))
    set_theme_base("checkbox_knob_rounding", ui.Slider(_T("Knob Rounding"), config.data.base.checkbox_knob_rounding or 9, 0, 18, 1))
end

local function group_toggle()
    set_theme_base("toggle_width", ui.Slider(_T("Width"), config.data.base.toggle_width or 40, 30, 60, 1))
    set_theme_base("toggle_height", ui.Slider(_T("Height"), config.data.base.toggle_height or 22, 16, 36, 1))
    set_theme_base("toggle_knob_size", ui.Slider(_T("Knob Size"), config.data.base.toggle_knob_size or 18, 10, 30, 1))
    set_theme_base("toggle_knob_offset", ui.Slider(_T("Knob Offset"), config.data.base.toggle_knob_offset or 2, 0, 6, 1))
    set_theme_base("toggle_track_rounding", ui.Slider(_T("Track Rounding"), config.data.base.toggle_track_rounding or 11, 0, 20, 1))
    set_theme_base("toggle_knob_rounding", ui.Slider(_T("Knob Rounding"), config.data.base.toggle_knob_rounding or 9, 0, 18, 1))
end

local function group_toggle_slider()
    set_theme_base("toggle_slider_height", ui.Slider(_T("Height"), config.data.base.toggle_slider_height or 60, 40, 100, 1))
    set_theme_base("toggle_slider_checkbox_size", ui.Slider(_T("Checkbox Size"), config.data.base.toggle_slider_checkbox_size or 22, 16, 36, 1))
    set_theme_base("toggle_slider_checkbox_rounding", ui.Slider(_T("Checkbox Rounding"), config.data.base.toggle_slider_checkbox_rounding or 4, 0, 18, 1))
    set_theme_base("toggle_slider_padding", ui.Slider(_T("Padding"), config.data.base.toggle_slider_padding or 10, 5, 20, 1))
    set_theme_base("toggle_slider_label_offset", ui.Slider(_T("Label Offset"), config.data.base.toggle_slider_label_offset or 10, 5, 20, 1))
    set_theme_base("toggle_slider_track_height", ui.Slider(_T("Track Height"), config.data.base.toggle_slider_track_height or 5, 2, 12, 1))
    set_theme_base("toggle_slider_track_offset", ui.Slider(_T("Track Offset"), config.data.base.toggle_slider_track_offset or 32, 20, 50, 1))
end

local function group_combo()
    set_theme_base("combo_max_visible", ui.Slider(_T("Max Visible Items"), config.data.base.combo_max_visible or 5, 3, 10, 1))
    set_theme_base("combo_dropdown_gap", ui.Slider(_T("Dropdown Gap"), config.data.base.combo_dropdown_gap or 4, 0, 12, 1))
    set_theme_base("combo_thumb_min", ui.Slider(_T("Thumb Min Size"), config.data.base.combo_thumb_min or 20, 10, 40, 1))
end

local function group_scroll_animation()
    set_theme_base("scroll_speed", ui.Slider(_T("Scroll Speed"), config.data.base.scroll_speed or 60, 20, 120, 5))
    set_theme_base("scroll_group_speed", ui.Slider(_T("Group Scroll Speed"), config.data.base.scroll_group_speed or 40, 10, 80, 5))
    local anim_dur_display = math_floor((config.data.base.click_anim_duration or 0.25) * 100 + 0.5)
    local new_anim_dur = ui.Slider(_T("Click Anim Duration (ms*10)"), anim_dur_display, 10, 50, 5)
    set_theme_base("click_anim_duration", new_anim_dur / 100)
    set_theme_base("click_anim_alpha", ui.Slider(_T("Click Anim Alpha"), config.data.base.click_anim_alpha or 40, 10, 100, 5))
end

local function group_content_area()
    set_theme_base("content_padding_y", ui.Slider(_T("Padding Y"), config.data.base.content_padding_y or 8, 0, 24, 1))
    set_theme_base("window_content_offset", ui.Slider(_T("Content Offset"), config.data.base.window_content_offset or 2, 0, 10, 1))
    set_theme_base("divider_width", ui.Slider(_T("Divider Width"), config.data.base.divider_width or 1, 0, 4, 1))
    set_theme_base("divider_padding", ui.Slider(_T("Divider Padding"), config.data.base.divider_padding or 8, 0, 20, 1))
end

local function group_color_picker()
    set_theme_base("color_preview_height", ui.Slider(_T("Preview Height"), config.data.base.color_preview_height or 12, 6, 24, 1))
    set_theme_base("color_preview_rounding", ui.Slider(_T("Preview Rounding"), config.data.base.color_preview_rounding or 4, 0, 12, 1))
end

local function group_menu_hints()
    set_theme_base("menu_hints_font_size", ui.Slider(_T("Font Size"), config.data.base.menu_hints_font_size or 16, 10, 40, 1))
    set_theme_base("menu_hints_offset_y", ui.Slider(_T("Offset Y (below menu)"), config.data.base.menu_hints_offset_y or 2, 0, 20, 1))
    set_theme_base("menu_hints_height", ui.Slider(_T("Height"), config.data.base.menu_hints_height or 30, 20, 60, 1))
    set_theme_base("menu_hints_padding", ui.Slider(_T("Padding"), config.data.base.menu_hints_padding or 10, 4, 20, 1))
    set_theme_base("menu_hints_rounding", ui.Slider(_T("Rounding"), config.data.base.menu_hints_rounding or 8, 0, 20, 1))
end

local function group_inline_tab_bar()
    set_theme_base("inline_tab_height", ui.Slider(_T("Height"), config.data.base.inline_tab_height or 24, 16, 40, 1))
    set_theme_base("inline_tab_gap", ui.Slider(_T("Gap"), config.data.base.inline_tab_gap or 4, 0, 16, 1))
    set_theme_base("inline_tab_indicator_height", ui.Slider(_T("Indicator Height"), config.data.base.inline_tab_indicator_height or 2, 1, 6, 1))
end

local function group_separator()
    set_theme_base("separator_height", ui.Slider(_T("Line Height"), config.data.base.separator_height or 1, 1, 4, 1))
    set_theme_base("separator_margin", ui.Slider(_T("Margin"), config.data.base.separator_margin or 8, 2, 20, 1))
end

local function group_progress_bar()
    set_theme_base("progress_height", ui.Slider(_T("Bar Height"), config.data.base.progress_height or 8, 4, 20, 1))
    set_theme_base("progress_rounding", ui.Slider(_T("Rounding"), config.data.base.progress_rounding or 4, 0, 12, 1))
end

local function group_dual_column()
    set_theme_base("dual_column_gap", ui.Slider(_T("Gap"), config.data.base.dual_column_gap or 10, 2, 20, 1))
    set_theme_base("dual_column_bottom_margin", ui.Slider(_T("Bottom Margin"), config.data.base.dual_column_bottom_margin or 10, 0, 30, 1))
end

local function group_row_layout()
    set_theme_base("row_gap", ui.Slider(_T("Row Gap"), config.data.base.row_gap or 8, 2, 20, 1))
end

local function advanced_left()
    ui.Group(_T("Slider Settings"), group_slider_settings)
    ui.Group(_T("Scrollbar"), group_scrollbar)
    ui.Group(_T("Checkbox"), group_checkbox)
    ui.Group(_T("Toggle"), group_toggle)
    ui.Group(_T("ToggleSlider"), group_toggle_slider)
    ui.Group(_T("Combo / Dropdown"), group_combo)
    ui.Group(_T("Scroll & Animation"), group_scroll_animation)
end

local function advanced_right()
    ui.Group(_T("Content Area"), group_content_area)
    ui.Group(_T("Color Picker"), group_color_picker)
    ui.Group(_T("Menu Hints"), group_menu_hints)
    ui.Group(_T("Inline Tab Bar"), group_inline_tab_bar)
    ui.Group(_T("Separator"), group_separator)
    ui.Group(_T("Progress Bar"), group_progress_bar)
    ui.Group(_T("Dual Column"), group_dual_column)
    ui.Group(_T("Row Layout"), group_row_layout)
end

local function render_advanced_options()
    ui.DualColumn(advanced_left, advanced_right)
end

function LayoutPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.LayoutPage] UI library is required")
    config = assert(ctx.config, "[Settings.LayoutPage] config module is required")
    lang = assert(ctx.lang, "[Settings.LayoutPage] language module is required")
    state = assert(ctx.state, "[Settings.LayoutPage] state table is required")
    set_theme_base = assert(ctx.set_theme_base, "[Settings.LayoutPage] set_theme_base is required")
    return true
end

local SUBTAB_KEYS <const> = { "Interface Parameters", "Advanced Options" }

function LayoutPage.draw()
    state.layout_subtab_idx = ui.SubTabBar2(lang.translate_list(SUBTAB_KEYS), state.layout_subtab_idx or 1)

    if state.layout_subtab_idx == 1 then
        render_interface_parameters()
    elseif state.layout_subtab_idx == 2 then
        render_advanced_options()
    end
end

return LayoutPage
