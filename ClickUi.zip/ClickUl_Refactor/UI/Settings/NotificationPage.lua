local NotificationPage = {}

local ui = nil
local config = nil
local lang = nil
local state = nil
local rebuild_color_cache = nil
local color_picker = nil
local set_theme_base = nil
local set_theme_value = nil

local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

local function group_notification_colors()
    color_picker(_T("Notification Info"), config.data.colors, "Notification Background")
    color_picker(_T("Hotkey"), config.data.colors, "Notification Hotkey")
    if state.color_keys_notify_right then
        for _, key in ipairs(state.color_keys_notify_right) do
            color_picker(_T(key), config.data.colors, key)
        end
    end
end

local function group_flash_effect()
    color_picker(_T("Notification Flash"), config.data.colors, "Notification Flash")
end

local function group_online_colors()
    color_picker(_T("Player Join"), config.data.colors, "Notification Join")
    color_picker(_T("Player Leave"), config.data.colors, "Notification Leave")
    color_picker(_T("Spectator Detection"), config.data.colors, "Notification Spectator")
    color_picker(_T("Modder Detection"), config.data.colors, "Notification Modder")
    color_picker(_T("Script Event"), config.data.colors, "Notification Script Event")
    color_picker(_T("Network Event"), config.data.colors, "Notification Network Event")
    color_picker(_T("Protection"), config.data.colors, "Notification Protection")
    color_picker(_T("Player Manager"), config.data.colors, "Notification Player Manager")
end

local function colors_left()
    ui.Group(_T("Notification Colors"), group_notification_colors)
    ui.Group(_T("Flash Effect"), group_flash_effect)
end

local function colors_right()
    ui.Group(_T("Online Notification Colors"), group_online_colors)
end

local function render_colors()
    ui.DualColumn(colors_left, colors_right)
end

local function ensure_defaults()
    local base = config.data.base

    if base.notif_radius == nil then set_theme_base("notif_radius", 8) end
    if base.notif_title_size == nil then set_theme_base("notif_title_size", 17) end
    if base.notif_message_size == nil then set_theme_base("notif_message_size", 14) end
    if base.notif_spacing == nil then set_theme_base("notif_spacing", 8) end
    if base.notif_margin_x == nil then set_theme_base("notif_margin_x", 20) end
    if base.notif_margin_y == nil then set_theme_base("notif_margin_y", 20) end
    if base.notif_max_count == nil then set_theme_base("notif_max_count", 12) end
    if base.notif_width == nil then set_theme_base("notif_width", 320) end
    if base.notif_padding == nil then set_theme_base("notif_padding", 6) end
    if base.notif_icon_size == nil then set_theme_base("notif_icon_size", 32) end
    if base.notif_min_height == nil then set_theme_base("notif_min_height", 60) end
    if base.notif_duration == nil then set_theme_base("notif_duration", 5.0) end
    if base.notif_anim_speed_in == nil then set_theme_base("notif_anim_speed_in", 4.0) end
    if base.notif_anim_stack_speed == nil then set_theme_base("notif_anim_stack_speed", 15.0) end
    if base.notif_flash_cooldown == nil then set_theme_base("notif_flash_cooldown", 1.5) end
    if base.notif_time_bar_enabled == nil then set_theme_base("notif_time_bar_enabled", true) end
    if base.notif_time_bar_height == nil then set_theme_base("notif_time_bar_height", 2) end
    if base.notif_time_bar_opacity == nil then set_theme_base("notif_time_bar_opacity", 180) end
    if base.notif_exit_speed_multiplier == nil then set_theme_base("notif_exit_speed_multiplier", 1.5) end
    if base.notif_flash_decay_speed == nil then set_theme_base("notif_flash_decay_speed", 6.0) end
end

local function group_notification_style()
    set_theme_base("notif_radius", ui.Slider(_T("Corner Radius"), config.data.base.notif_radius, 0, 20, 1))
    set_theme_base("notif_title_size", ui.Slider(_T("Title Font Size"), config.data.base.notif_title_size, 12, 24, 1))
    set_theme_base("notif_message_size", ui.Slider(_T("Message Font Size"), config.data.base.notif_message_size, 10, 20, 1))
    set_theme_base("notif_spacing", ui.Slider(_T("Spacing Between"), config.data.base.notif_spacing, 0, 30, 1))
    set_theme_base("notif_margin_x", ui.Slider(_T("Screen Margin X"), config.data.base.notif_margin_x, 0, 200, 5))
    set_theme_base("notif_margin_y", ui.Slider(_T("Screen Margin Y"), config.data.base.notif_margin_y, 0, 200, 5))
    set_theme_base("notif_max_count", ui.Slider(_T("Max Count"), config.data.base.notif_max_count, 1, 30, 1))
    set_theme_base("notif_width", ui.Slider(_T("Width"), config.data.base.notif_width, 200, 600, 10))
    set_theme_base("notif_padding", ui.Slider(_T("Inner Padding"), config.data.base.notif_padding, 0, 30, 1))
    set_theme_base("notif_icon_size", ui.Slider(_T("Icon Size"), config.data.base.notif_icon_size, 0, 64, 1))
    set_theme_base("notif_min_height", ui.Slider(_T("Min Height (No Icon)"), config.data.base.notif_min_height, 0, 200, 5))
    set_theme_base("notif_duration", ui.Slider(_T("Duration (s)"), config.data.base.notif_duration, 0.5, 15.0, 0.5))
    set_theme_base("notif_anim_speed_in", ui.Slider(_T("Anim Speed In"), config.data.base.notif_anim_speed_in, 1.0, 30.0, 0.5))
    set_theme_base("notif_anim_stack_speed", ui.Slider(_T("Anim Stack Speed"), config.data.base.notif_anim_stack_speed, 1.0, 30.0, 0.5))
    set_theme_base("notif_flash_cooldown", ui.Slider(_T("Flash Cooldown (s)"), config.data.base.notif_flash_cooldown, 0.0, 5.0, 0.1))
end

local function group_time_bar()
    local old_enabled = config.data.base.notif_time_bar_enabled
    local new_enabled = ui.Checkbox(_T("Enable Time Bar"), old_enabled)
    if new_enabled ~= old_enabled then
        set_theme_base("notif_time_bar_enabled", new_enabled)
    end
    set_theme_base("notif_time_bar_height", ui.Slider(_T("Bar Height (px)"), config.data.base.notif_time_bar_height, 1, 8, 1))
    set_theme_base("notif_time_bar_opacity", ui.Slider(_T("Bar Opacity"), config.data.base.notif_time_bar_opacity, 0, 255, 5))
end

local function group_animation_enhancements()
    set_theme_base("notif_exit_speed_multiplier", ui.Slider(
        _T("Exit Speed Multiplier"),
        config.data.base.notif_exit_speed_multiplier,
        1.0, 3.0, 0.1
    ))

    set_theme_base("notif_flash_decay_speed", ui.Slider(
        _T("Flash Decay Speed"),
        config.data.base.notif_flash_decay_speed,
        1.0, 20.0, 0.5
    ))
end

local function style_left()
    ui.Group(_T("Notification Style"), group_notification_style)
end

local function style_right()
    ui.Group(_T("Notification Time Bar"), group_time_bar)
    ui.Group(_T("Animation Enhancements"), group_animation_enhancements)
end

local function render_style()
    ui.DualColumn(style_left, style_right)
end

local POSITION_KEYS <const> = { "Bottom Right", "Bottom Left", "Top Right", "Top Left" }
local POSITION_VALUES <const> = { "bottom_right", "bottom_left", "top_right", "top_left" }

local function group_position()
    local position_options = lang.translate_list(POSITION_KEYS)
    local position_values = POSITION_VALUES

    local current_position = config.data.notification_position or "bottom_right"
    local current_idx = 1
    for i, val in ipairs(position_values) do
        if val == current_position then
            current_idx = i
            break
        end
    end

    local new_idx = ui.Combo(_T("Position"), current_idx, position_options)

    if new_idx ~= current_idx then
        set_theme_value("notification_position", position_values[new_idx])
        ui.notify(_T("Notification position changed to") .. " " .. position_options[new_idx], "Info")
    end
end

local function group_test_notifications()
    if ui.Button(_T("Test All Notifications")) then
        ui.notify(_T("Success notification"), "Success")
        ui.notify(_T("Warning notification"), "Warning")
        ui.notify(_T("Error notification"), "Error")
        ui.notify(_T("Info notification"), "Info")
        ui.notify(_T("Player is joined"), "Join")
        ui.notify(_T("Player is left"), "Leave")
        ui.notify(_T("Spectator Detected"), "Spectator")
        ui.notify(_T("Modder Detected"), "Modder")
        ui.notify(_T("Script Event Blocked"), "Script Event")
        ui.notify(_T("Network Event Blocked"), "Network Event")
        ui.notify(_T("Protection Triggered"), "Protection")
        ui.notify(_T("Player Manager Action"), "Player Manager")
    end

    if ui.Button(_T("Test Long Notification")) then
        ui.notify(_T("This is a very long notification message to test text wrapping. The notification system should automatically wrap this text to multiple lines and adjust the background height accordingly."), "Info")
    end
end

local function layout_left()
    ui.Group(_T("Notification Position"), group_position)
end

local function layout_right()
    ui.Group(_T("Test Notifications"), group_test_notifications)
end

local function render_layout()
    ui.DualColumn(layout_left, layout_right)
end

function NotificationPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.NotificationPage] UI library is required")
    config = assert(ctx.config, "[Settings.NotificationPage] config module is required")
    lang = assert(ctx.lang, "[Settings.NotificationPage] language module is required")
    state = assert(ctx.state, "[Settings.NotificationPage] state table is required")
    rebuild_color_cache = assert(ctx.rebuild_color_cache, "[Settings.NotificationPage] rebuild_color_cache is required")
    color_picker = assert(ctx.color_picker, "[Settings.NotificationPage] color_picker is required")
    set_theme_base = assert(ctx.set_theme_base, "[Settings.NotificationPage] set_theme_base is required")
    set_theme_value = assert(ctx.set_theme_value, "[Settings.NotificationPage] set_theme_value is required")
    ensure_defaults()
    return true
end

local SUBTAB_KEYS <const> = { "Colors", "Style & Animation", "Layout" }

function NotificationPage.draw()
    if not state.color_keys_notify_left then rebuild_color_cache() end

    state.notify_subtab_idx = ui.SubTabBar2(lang.translate_list(SUBTAB_KEYS), state.notify_subtab_idx or 1)

    if state.notify_subtab_idx == 1 then
        render_colors()
    elseif state.notify_subtab_idx == 2 then
        render_style()
    elseif state.notify_subtab_idx == 3 then
        render_layout()
    end
end

return NotificationPage
