local PlayerInfoPage = {}

local ui = nil
local config = nil
local lang = nil
local state = nil
local rebuild_color_cache = nil
local color_picker = nil
local set_theme_base = nil

local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

local function ensure_defaults()
    local base = config.data.base

    if base.overlay_font_size == nil then set_theme_base("overlay_font_size", 14) end
    if base.overlay_radius == nil then set_theme_base("overlay_radius", 4) end
    if base.overlay_offset_x == nil then set_theme_base("overlay_offset_x", 10) end
end

function PlayerInfoPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.PlayerInfoPage] UI library is required")
    config = assert(ctx.config, "[Settings.PlayerInfoPage] config module is required")
    lang = assert(ctx.lang, "[Settings.PlayerInfoPage] language module is required")
    state = assert(ctx.state, "[Settings.PlayerInfoPage] state table is required")
    rebuild_color_cache = assert(ctx.rebuild_color_cache, "[Settings.PlayerInfoPage] rebuild_color_cache is required")
    color_picker = assert(ctx.color_picker, "[Settings.PlayerInfoPage] color_picker is required")
    set_theme_base = assert(ctx.set_theme_base, "[Settings.PlayerInfoPage] set_theme_base is required")
    ensure_defaults()
    return true
end

local function group_overlay_colors()
    if state.color_keys_overlay and #state.color_keys_overlay > 0 then
        for _, key in ipairs(state.color_keys_overlay) do
            color_picker(_T(key), config.data.colors, key)
        end
    else
        ui.Button(_T("No Overlay colors found"))
    end
end

local function group_layout_settings()
    set_theme_base("overlay_font_size", ui.Slider(_T("Font Size"), config.data.base.overlay_font_size, 10, 24, 1))
    set_theme_base("overlay_radius", ui.Slider(_T("Corner Radius"), config.data.base.overlay_radius, 0, 20, 1))
    set_theme_base("overlay_offset_x", ui.Slider(_T("Horizontal Offset"), config.data.base.overlay_offset_x, -50, 200, 5))
end

local function draw_left()
    ui.Group(_T("Overlay Colors"), group_overlay_colors)
end

local function draw_right()
    ui.Group(_T("Layout Settings"), group_layout_settings)
end

function PlayerInfoPage.draw()
    if not state.color_keys_overlay then rebuild_color_cache() end
    ui.DualColumn(draw_left, draw_right)
end

return PlayerInfoPage
