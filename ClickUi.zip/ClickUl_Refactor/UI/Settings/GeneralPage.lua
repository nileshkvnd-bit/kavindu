local GeneralPage = {}

local ui = nil
local config = nil
local lang = nil
local settings_store = nil
local fonts = nil
local state = nil
local none_value = nil
local refresh_font_list = nil
local invalidate_display_lists = nil
local font_combo = nil
local set_theme_base = nil

local function _T(text)
    return lang.get(text)
end

local function group_settings()
    local enabled = settings_store.is_enabled()
    local new_enabled = ui.Checkbox(_T("Auto Save Settings"), enabled)
    if new_enabled ~= enabled then
        settings_store.set_enabled(new_enabled)
        if new_enabled then
            ui.notify(_T("Auto save enabled"), "Success")
        else
            ui.notify(_T("Auto save disabled"), "Info")
        end
    end

    if ui.Button(_T("Save Now")) then
        if settings_store.force_save() then
            ui.notify(_T("Settings saved"), "Success")
        else
            ui.notify(_T("Save failed"), "Error")
        end
    end

    if ui.Button(_T("Reset Settings")) then
        settings_store.reset()
        ui.notify(_T("Settings reset"), "Warning")
    end
end

local function render_settings()
    ui.Group(_T("Settings"), group_settings)
end

local function group_language()
    local current_idx = lang.get_lang_index()
    local lang_list = lang.get_lang_list()

    local new_lang_idx = ui.Combo(_T("Language"), current_idx, lang_list)
    if new_lang_idx ~= current_idx then
        if lang.set_lang_by_index(new_lang_idx) then
            invalidate_display_lists()
            ui.toggle_menu()
            ui.notify(_T("Language changed"), "Success")
        else
            ui.notify(_T("Failed to load language"), "Error")
        end
    end

    if ui.Button(_T("Refresh Language")) then
        lang.refresh_available()
        invalidate_display_lists()
        if lang.reload() then
            ui.notify(_T("Language Reloaded"), "Success")
        else
            ui.notify(_T("Failed to reload language"), "Error")
        end
    end
end

local function render_language()
    ui.Group(_T("Language"), group_language)
end

local function group_loading_overlay()
    local loading_enabled = settings_store.get_loading_overlay_enabled()
    local new_loading = ui.Checkbox(_T("Show Loading Overlay"), loading_enabled)
    if new_loading ~= loading_enabled then
        settings_store.set_loading_overlay_enabled(new_loading)
    end
end

local function render_loading_overlay()
    ui.Group(_T("Loading Overlay"), group_loading_overlay)
end

local function group_input()
    local old_blocked = ui.get_block_input()
    local new_blocked = ui.Checkbox(_T("Block Input"), old_blocked)
    if new_blocked ~= old_blocked then
        ui.set_block_input(new_blocked)
    end
end

local function render_input()
    ui.Group(_T("Input"), group_input)
end

local function group_ui_style()
    local old_style = config.data.base.checkbox_use_toggle_style or false
    local new_style = ui.Toggle(
        _T("Checkbox Toggle Style"),
        old_style
    )
    if new_style ~= old_style then
        set_theme_base("checkbox_use_toggle_style", new_style)
    end
end

local function render_ui_style()
    ui.Group(_T("UI Style"), group_ui_style)
end

local font_hint = { text = nil }
local font_hint_language = nil

local function group_custom_font()
    refresh_font_list()

    if font_hint_language ~= lang.get_language() then
        font_hint.text = _T("Put .ttf/.otf fonts in ClickUl_Refactor/Fonts/, then Refresh")
        font_hint_language = lang.get_language()
    end

    local old_enabled = config.data.base.custom_font_enabled or false
    local new_enabled = ui.Checkbox(_T("Enable Custom Font"), old_enabled, font_hint)
    if new_enabled ~= old_enabled then
        set_theme_base("custom_font_enabled", new_enabled)
        if new_enabled and config.data.base.custom_font_path and config.data.base.custom_font_path ~= "" then
            fonts.set_font_path(config.data.base.custom_font_path)
            ui.notify(_T("Custom font enabled"), "Success")
        else
            fonts.clear()
            ui.notify(_T("Custom font disabled"), "Info")
        end
        ui.invalidate_font_cache()
    end

    if #state.available_fonts > 1 then
        local new_font_idx = font_combo(_T("Font File"), state.font_idx)
        if new_font_idx ~= state.font_idx then
            state.font_idx = new_font_idx
            local selected = state.available_fonts[new_font_idx]

            if selected == none_value then
                set_theme_base("custom_font_path", "")
                set_theme_base("custom_font_enabled", false)
                fonts.clear()
                ui.invalidate_font_cache()
                ui.notify(_T("Custom font disabled"), "Info")
            else
                set_theme_base("custom_font_path", selected)
                set_theme_base("custom_font_enabled", true)
                fonts.set_font_path(selected)
                ui.invalidate_font_cache()
                ui.notify(_T("Font loaded") .. ": " .. selected, "Success")
            end
        end
    end

    if ui.Button(_T("Refresh Font List")) then
        refresh_font_list(true)
        ui.notify(_T("Font list refreshed"), "Info")
    end
end

local function render_custom_font()
    ui.Group(_T("Custom Font"), group_custom_font)
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.GeneralPage] UI library is required")
    config = assert(ctx.config, "[Settings.GeneralPage] config module is required")
    lang = assert(ctx.lang, "[Settings.GeneralPage] language module is required")
    settings_store = assert(ctx.settings, "[Settings.GeneralPage] settings module is required")
    fonts = assert(ctx.fonts, "[Settings.GeneralPage] fonts module is required")
    state = assert(ctx.state, "[Settings.GeneralPage] state table is required")
    none_value = assert(ctx.none_value, "[Settings.GeneralPage] none value is required")
    refresh_font_list = assert(ctx.refresh_font_list, "[Settings.GeneralPage] refresh_font_list is required")
    invalidate_display_lists = assert(ctx.invalidate_display_lists, "[Settings.GeneralPage] invalidate_display_lists is required")
    font_combo = assert(ctx.font_combo, "[Settings.GeneralPage] font_combo is required")
    set_theme_base = assert(ctx.set_theme_base, "[Settings.GeneralPage] set_theme_base is required")
    return true
end

local function draw_left_column()
    render_settings()
    render_language()
    render_loading_overlay()
end

local function draw_right_column()
    render_input()
    render_ui_style()
    render_custom_font()
end

function GeneralPage.draw()
    ui.DualColumn(draw_left_column, draw_right_column)
end

return GeneralPage
