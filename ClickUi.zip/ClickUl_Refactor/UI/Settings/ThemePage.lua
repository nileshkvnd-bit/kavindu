local ThemePage = {}

local ui = nil
local config = nil
local lang = nil
local state = nil
local rebuild_color_cache = nil
local refresh_theme_list = nil
local refresh_image_list = nil
local color_picker = nil

local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

local function noop() end

local current_group_keys = nil

local function draw_color_group_body()
    for _, key in ipairs(current_group_keys) do
        color_picker(_T(key), config.data.colors, key)
    end
end

local function render_color_group(title, keys)
    if not keys or #keys == 0 then return end

    current_group_keys = keys
    ui.Group(_T(title), draw_color_group_body)
end

local function draw_theme_management()
    refresh_theme_list()

    local new_theme_idx = ui.Combo(_T("Load Theme"), state.current_theme_idx, state.available_themes)
    if new_theme_idx ~= state.current_theme_idx then
        local theme_name = state.available_themes[new_theme_idx]
        local result = config.load_theme(theme_name)
        if result ~= false then
            state.current_theme_idx = new_theme_idx
            rebuild_color_cache()
            ui.force_update_scale()
            ui.update_colors()
            ui.refresh_background()
            ui.clear_cache()
            refresh_image_list(true)
            refresh_theme_list(true)
            ui.notify(_T("Theme loaded") .. ": " .. theme_name, "Success")
        else
            ui.notify(_T("Failed to load theme"), "Error")
        end
    end

    local new_name = ui.TextInput(_T("Theme Name"), state.new_theme_name, 32)
    state.new_theme_name = new_name

    if ui.Button(_T("Save Theme As")) then
        if state.new_theme_name and #state.new_theme_name > 0 then
            local result = config.save_as_immediate(state.new_theme_name)
            if result ~= false then
                refresh_theme_list(true)
                ui.notify(_T("Theme saved") .. ": " .. state.new_theme_name, "Success")
                state.new_theme_name = ""
            else
                ui.notify(_T("Failed to save theme"), "Error")
            end
        else
            ui.notify(_T("Please enter a theme name"), "Warning")
        end
    end

    if ui.Button(_T("Refresh Theme List")) then
        refresh_theme_list(true)
        ui.notify(_T("Theme list refreshed"), "Info")
    end

    if ui.Button(_T("Reset to Defaults")) then
        config.reset()
        rebuild_color_cache()
        ui.force_update_scale()
        ui.update_colors()
        ui.refresh_background()
        ui.clear_cache()
        refresh_image_list(true)
        refresh_theme_list(true)
        ui.notify(_T("Reset to default theme"), "Warning")
    end
end

local function manager_left()
    ui.Group(_T("Theme Management"), draw_theme_management)
end

local function render_manager()
    ui.DualColumn(manager_left, noop)
end

local function window_left()
    render_color_group("Window Colors", state.color_keys_window)
end

local function window_right()
    render_color_group("Group Colors", state.color_keys_group)
end

local function render_window_colors()
    ui.DualColumn(window_left, window_right)
end

local function widget_left()
    render_color_group("Checkbox Colors", state.color_keys_controls)
    render_color_group("Slider Colors", state.color_keys_slider)
    render_color_group("Combo Colors", state.color_keys_combo)
end

local function widget_right()
    render_color_group("Scrollbar Colors", state.color_keys_scrollbar)
    render_color_group("Inline Tab Colors", state.color_keys_inline)
    render_color_group("Progress Colors", state.color_keys_progress)
end

local function render_widget_colors()
    ui.DualColumn(widget_left, widget_right)
end

local function tab_left()
    render_color_group("Text Colors", state.color_keys_text)
    render_color_group("Sidebar Tab Colors", state.color_keys_tab)
    render_color_group("SubTab Colors", state.color_keys_subtab)
end

local function tab_right()
    render_color_group("Player Tags", state.color_keys_tags)
    render_color_group("Menu Hints Colors", state.color_keys_menu_hints)
    render_color_group("Other Colors", state.color_keys_other)
end

local function render_tab_colors()
    ui.DualColumn(tab_left, tab_right)
end

function ThemePage.init(ctx)
    ui = assert(ctx.ui, "[Settings.ThemePage] UI library is required")
    config = assert(ctx.config, "[Settings.ThemePage] config module is required")
    lang = assert(ctx.lang, "[Settings.ThemePage] language module is required")
    state = assert(ctx.state, "[Settings.ThemePage] state table is required")
    rebuild_color_cache = assert(ctx.rebuild_color_cache, "[Settings.ThemePage] rebuild_color_cache is required")
    refresh_theme_list = assert(ctx.refresh_theme_list, "[Settings.ThemePage] refresh_theme_list is required")
    refresh_image_list = assert(ctx.refresh_image_list, "[Settings.ThemePage] refresh_image_list is required")
    color_picker = assert(ctx.color_picker, "[Settings.ThemePage] color_picker is required")
    return true
end

local SUBTAB_KEYS <const> = { "Manager", "Window", "Widget", "Tab" }

function ThemePage.draw()
    if not state.color_keys_window then rebuild_color_cache() end

    state.theme_subtab_idx = ui.SubTabBar2(lang.translate_list(SUBTAB_KEYS), state.theme_subtab_idx or 1)

    if state.theme_subtab_idx == 1 then
        render_manager()
    elseif state.theme_subtab_idx == 2 then
        render_window_colors()
    elseif state.theme_subtab_idx == 3 then
        render_widget_colors()
    elseif state.theme_subtab_idx == 4 then
        render_tab_colors()
    end
end

return ThemePage
