local ColorCategories = {}

local ORDERED_CATEGORIES <const> = {
    window = {
        "Window Background", "Sidebar Background", "Header Background",
        "Header Text", "Background Tint"
    },
    group = {
        "Group Background", "Group Header Text", "Group Header Line",
        "Collapsible Header", "Widget Background", "Widget Hover"
    },
    text = {
        "Text Primary", "Text Secondary", "Accent"
    },
    tab = {
        "Tab Background", "Tab Background Hover", "Tab Background Active",
        "Tab Text Inactive", "Tab Text Active", "Tab Indicator"
    },
    subtab = {
        "Subtab Background", "Subtab Hover", "Subtab Active",
        "Subtab Text Inactive", "Subtab Text Active"
    },
    controls = {
        "Checkbox Active", "Checkbox Inactive",
        "Toggle Active", "Toggle Inactive", "Knob Active", "Knob Inactive", "Knob"
    },
    slider = {
        "Slider Background", "Slider Background Hover",
        "Slider Empty", "Slider Filled", "Slider Filled Hover"
    },
    combo = {
        "Combo Background", "Combo Highlight", "Player Selected Background"
    },
    scrollbar = {
        "Scrollbar", "Scrollbar Hover"
    },
    inline = {
        "Inline Tab Active", "Inline Tab Inactive", "Inline Tab Indicator",
        "Separator Line", "Separator Text"
    },
    progress = {
        "Progress Background", "Progress Fill"
    },
    menu_hints = {
        "Menu Hints Background", "Menu Hints Text"
    },
    tags = {
        "Tag ME", "Tag Friend", "Tag Modder", "Tag God",
        "Tag Spectating", "Tag Modded", "Tag Bounty",
        "Tag Script Host", "Tag Session Host", "Tag Vehicle",
        "Tag Next Host", "Tag CEO", "Tag Dead", "Tag Interior", "Tag Controller"
    },
    overlay = {
        "Overlay Background", "Overlay Text", "Overlay Divider"
    },
    notify_left = {
        "Notification Background", "Notification Hotkey", "Notification Join", "Notification Leave"
    },
    notify_right = {
        "Notification Success", "Notification Warning", "Notification Error"
    }
}

local CLAIMED_ELSEWHERE <const> = {
    "Notification Spectator", "Notification Flash", "Notification Modder",
    "Notification Script Event", "Notification Network Event",
    "Notification Protection", "Notification Player Manager",
}

function ColorCategories.build_existing(colors)
    local result = {}

    for name, keys in pairs(ORDERED_CATEGORIES) do
        local filtered = {}
        for i = 1, #keys do
            local key = keys[i]
            if colors[key] then
                filtered[#filtered + 1] = key
            end
        end
        result[name] = filtered
    end

    local known = {}
    for _, keys in pairs(ORDERED_CATEGORIES) do
        for i = 1, #keys do
            known[keys[i]] = true
        end
    end
    for i = 1, #CLAIMED_ELSEWHERE do
        known[CLAIMED_ELSEWHERE[i]] = true
    end

    local other = {}
    for key in pairs(colors) do
        if not known[key] then
            other[#other + 1] = key
        end
    end
    table.sort(other)
    result.other = other

    return result
end

return ColorCategories
