local State = {}

local NONE_VALUE <const> = "None"

function State.create()
    return {
        subtab_idx = 1,
        layout_subtab_idx = 1,
        theme_subtab_idx = 1,
        icons_subtab_idx = 1,
        notify_subtab_idx = 1,
        color_keys_window = nil,
        color_keys_group = nil,
        color_keys_text = nil,
        color_keys_tab = nil,
        color_keys_subtab = nil,
        color_keys_controls = nil,
        color_keys_slider = nil,
        color_keys_combo = nil,
        color_keys_scrollbar = nil,
        color_keys_inline = nil,
        color_keys_progress = nil,
        color_keys_menu_hints = nil,
        color_keys_tags = nil,
        color_keys_overlay = nil,
        color_keys_notify_left = nil,
        color_keys_notify_right = nil,
        color_keys_other = nil,
        bg_images = {NONE_VALUE},
        bg_image_labels = nil,
        bg_idx = 1,
        images_cached = false,
        available_themes = {},
        themes_cached = false,
        current_theme_idx = 1,
        new_theme_name = "",
        available_fonts = {},
        available_font_labels = nil,
        fonts_cached = false,
        font_idx = 1,
    }
end

State.NONE_VALUE = NONE_VALUE

return State
