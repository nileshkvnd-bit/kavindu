local NotificationIconsSection = {}

local ui = nil
local config = nil
local lang = nil
local image_combo = nil
local image_value_from_index = nil
local image_index_for = nil
local set_theme_value = nil
local set_theme_table_value = nil

local ipairs <const> = ipairs

local function _T(text)
    return lang.get(text)
end

local BASIC_NOTIF_TYPES <const> = {
    {key = "Success", label_key = "Success Icon"},
    {key = "Warning", label_key = "Warning Icon"},
    {key = "Error", label_key = "Error Icon"},
    {key = "Info", label_key = "Info Icon"},
    {key = "Hotkey", label_key = "Hotkey Icon"},
    {key = "Spectator", label_key = "Spectator Icon"},
    {key = "Modder", label_key = "Modder Detection Icon"},
}

local EVENT_NOTIF_TYPES <const> = {
    {key = "Join", label_key = "Player Join Icon"},
    {key = "Leave", label_key = "Player Leave Icon"},
    {key = "Script Event", label_key = "Script Event Icon"},
    {key = "Network Event", label_key = "Network Event Icon"},
    {key = "Protection", label_key = "Protection Icon"},
    {key = "Player Manager", label_key = "Player Manager Icon"},
}

local function render_icon_picker(item, icons, default_icon)
    local current_val = icons[item.key] or default_icon
    local current_idx = image_index_for(current_val)
    local new_idx = image_combo(_T(item.label_key), current_idx)

    if new_idx ~= current_idx then
        local selected = image_value_from_index(new_idx)
        set_theme_table_value(icons, item.key, selected)
        ui.clear_cache()
    end
end

function NotificationIconsSection.init(ctx)
    ui = assert(ctx.ui, "[Settings.NotificationIconsSection] UI library is required")
    config = assert(ctx.config, "[Settings.NotificationIconsSection] config module is required")
    lang = assert(ctx.lang, "[Settings.NotificationIconsSection] language module is required")
    image_combo = assert(ctx.image_combo, "[Settings.NotificationIconsSection] image_combo is required")
    image_value_from_index = assert(ctx.image_value_from_index, "[Settings.NotificationIconsSection] image_value_from_index is required")
    image_index_for = assert(ctx.image_index_for, "[Settings.NotificationIconsSection] image_index_for is required")
    set_theme_value = assert(ctx.set_theme_value, "[Settings.NotificationIconsSection] set_theme_value is required")
    set_theme_table_value = assert(ctx.set_theme_table_value, "[Settings.NotificationIconsSection] set_theme_table_value is required")
    return true
end

function NotificationIconsSection.draw()
    if not config.data.notification_icons then
        set_theme_value("notification_icons", {})
    end
    local icons = config.data.notification_icons

    ui.DualColumn(
        function()
            ui.Group(_T("Basic Notification Icons"), function()
                for _, item in ipairs(BASIC_NOTIF_TYPES) do
                    render_icon_picker(item, icons, "logo.png")
                end
            end)
        end,
        function()
            ui.Group(_T("Event Notification Icons"), function()
                for _, item in ipairs(EVENT_NOTIF_TYPES) do
                    render_icon_picker(item, icons, "logo.png")
                end
            end)
        end
    )
end

return NotificationIconsSection
