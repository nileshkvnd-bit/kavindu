local LoggingPage = {}

local ui = nil
local lang = nil
local logger = nil
local sync_logging_settings = nil

local function _T(text)
    return lang.get(text)
end

local LEVEL_KEYS <const> = { "VERBOSE", "INFO", "WARN", "ERROR" }

local function render_logging_system()
    ui.Group(_T("Logging System"), function()
        local cfg = logger.get_config()

        local new_enabled = ui.Checkbox(_T("Enable Logging System"), cfg.enabled)
        if new_enabled ~= cfg.enabled then
            if new_enabled then
                logger.enable()
                ui.notify(_T("Logging system enabled"), "Success")
                logger.info("UI.Settings", "Logging system enabled by user")
            else
                logger.disable()
                ui.notify(_T("Logging system disabled"), "Info")
            end
            sync_logging_settings()
        end

        if cfg.enabled then
            local level_names = lang.translate_list(LEVEL_KEYS)
            local current_level_idx = cfg.log_level
            local new_level_idx = ui.Combo(_T("Log Level"), current_level_idx, level_names)
            if new_level_idx ~= current_level_idx then
                logger.set_level(new_level_idx)
                ui.notify(string.format(_T("Log level: %s"), level_names[new_level_idx]), "Info")
                logger.info("UI.Settings", "Log level changed", {level = level_names[new_level_idx]})
                sync_logging_settings()
            end

            local new_log_to_file = ui.Checkbox(_T("Log to File"), cfg.log_to_file)
            if new_log_to_file ~= cfg.log_to_file then
                logger.set_log_to_file(new_log_to_file)
                sync_logging_settings()
            end

            local new_print_console = ui.Checkbox(_T("Print to Console"), cfg.print_to_console)
            if new_print_console ~= cfg.print_to_console then
                logger.set_print_to_console(new_print_console)
                sync_logging_settings()
            end

            local current_filter = cfg.module_filter or ""
            local new_filter = ui.TextInput(_T("Module Filter"), current_filter, 32)
            if new_filter ~= current_filter then
                logger.set_module_filter(new_filter)
                sync_logging_settings()
            end
        end
    end)
end

local function render_display_options()
    local cfg = logger.get_config()
    if not cfg.enabled then return end

    ui.Group(_T("Display Options"), function()
        local new_timestamp = ui.Checkbox(_T("Show Timestamp"), cfg.show_timestamp)
        if new_timestamp ~= cfg.show_timestamp then
            logger.set_show_timestamp(new_timestamp)
            sync_logging_settings()
        end

        local new_memory = ui.Checkbox(_T("Show Memory Usage"), cfg.show_memory)
        if new_memory ~= cfg.show_memory then
            logger.set_show_memory(new_memory)
            sync_logging_settings()
        end

        local new_perf = ui.Checkbox(_T("Show Performance"), cfg.show_performance)
        if new_perf ~= cfg.show_performance then
            logger.set_show_performance(new_perf)
            sync_logging_settings()
        end
    end)

    ui.Group(_T("Utilities"), function()
        if ui.Button(_T("Clear Log History")) then
            local count = logger.clear_history()
            ui.notify(string.format(_T("Cleared %d log entries"), count or 0), "Success")
        end

        if ui.Button(_T("Dump History to File")) then
            local count = logger.get_history_count()
            if count > 0 then
                local log_path = logger.dump_history()
                if log_path then
                    ui.notify(string.format(_T("Wrote %d entries to: %s"), count, log_path), "Success")
                else
                    ui.notify(_T("Failed to write log history"), "Error")
                end
            else
                ui.notify(_T("No log history to dump (history is empty)"), "Warning")
            end
        end

        if ui.Button(_T("Show Current Memory")) then
            local mem = logger.get_memory()
            ui.notify(string.format(_T("Memory: %.2f MB (%.0f KB)"), mem.mb, mem.kb), "Info")
        end

        if ui.Button(_T("Force Garbage Collection")) then
            local before = logger.get_memory()
            logger.force_gc()
            local after = logger.get_memory()
            local freed = before.kb - after.kb
            ui.notify(string.format(_T("GC: %.0f KB freed (%.2f MB -> %.2f MB)"), freed, before.mb, after.mb), "Success")
        end
    end)
end

function LoggingPage.init(ctx)
    ui = assert(ctx.ui, "[Settings.LoggingPage] UI library is required")
    lang = assert(ctx.lang, "[Settings.LoggingPage] language module is required")
    logger = assert(ctx.logger, "[Settings.LoggingPage] logger module is required")
    sync_logging_settings = assert(ctx.sync_logging_settings, "[Settings.LoggingPage] sync function is required")
    return true
end

function LoggingPage.draw()
    ui.DualColumn(
        render_logging_system,
        render_display_options
    )
end

return LoggingPage
