local app_menu = {}

local logger = require("ClickUl_Refactor.Core.Logger")
local state = require("ClickUl_Refactor.UI.State.Init")
local renderer = require("ClickUl_Refactor.UI.Renderer.Init")

local ui = nil
local lang = nil
local modules = {}
local module_order = {}
local sidebar_tabs = {}
local sidebar_index = {}
local active_special_key = nil
local lifecycle_hooks = {
    on_menu_open = {},
    on_menu_close = {},
    on_shutdown = {},
}

local tab_order = {}

local lifecycle_events <const> = {
    "on_menu_open",
    "on_menu_close",
    "on_shutdown",
}

local function _T(text)
    return lang.get(text)
end

local function has_key(list, key)
    for _, item in ipairs(list) do
        if item == key then return true end
    end
    return false
end

local function reset_modules()
    modules = {}
    module_order = {}
    tab_order = {}
    active_special_key = nil
end

local sidebar_labels = {}
local sidebar_labels_language = nil

local sidebar_keys = {}

local function rebuild_sidebar()
    sidebar_tabs = {}
    sidebar_keys = {}
    sidebar_index = {}
    sidebar_labels_language = nil

    for _, key in ipairs(tab_order) do
        local info = modules[key]
        if info and info.sidebar ~= false then
            sidebar_tabs[#sidebar_tabs + 1] = info
            sidebar_keys[#sidebar_keys + 1] = key
            sidebar_index[key] = #sidebar_tabs
        end
    end
end

function app_menu.get_sidebar_specs()
    return sidebar_tabs
end

local function get_sidebar_labels()
    if sidebar_labels_language == lang.get_language() then
        return sidebar_labels
    end

    for i, tab in ipairs(sidebar_tabs) do
        sidebar_labels[i] = _T(tab.label)
    end
    for i = #sidebar_tabs + 1, #sidebar_labels do sidebar_labels[i] = nil end

    sidebar_labels_language = lang.get_language()
    return sidebar_labels
end

local function rebuild_lifecycle()
    lifecycle_hooks = {
        on_menu_open = {},
        on_menu_close = {},
        on_shutdown = {},
    }

    for _, key in ipairs(module_order) do
        local info = modules[key]
        local module = info and info.module
        if type(module) == "table" then
            for _, event_name in ipairs(lifecycle_events) do
                local fn = module[event_name]
                if type(fn) == "function" then
                    local hooks = lifecycle_hooks[event_name]
                    hooks[#hooks + 1] = {
                        key = info.key,
                        file = info.file,
                        fn = fn,
                    }
                end
            end
        end
    end
end

local function rebuild_registry()
    rebuild_sidebar()
    rebuild_lifecycle()
end

local function special_scroll_key(key)
    return "special:" .. tostring(key)
end

local function emit(event_name)
    local hooks = lifecycle_hooks[event_name]
    if not hooks or #hooks == 0 then return end

    for _, hook in ipairs(hooks) do
        local ok, err = pcall(hook.fn)
        if not ok then
            logger.error("UI.AppMenu", "lifecycle failed", {
                module = hook.key,
                file = hook.file,
                event = event_name,
                error = err,
            })
        end
    end
end

function app_menu.init(ctx)
    ui = assert(ctx.ui, "[UI.AppMenu] UI library is required")
    lang = assert(ctx.lang, "[UI.AppMenu] language module is required")
    reset_modules()
    return true
end

function app_menu.register(spec)
    assert(type(spec) == "table" and spec.key, "[UI.AppMenu] register requires a spec table with key")

    local key = spec.key
    local module = spec.module
    assert(type(module) == "table", "module requires module table: " .. tostring(key))
    assert(type(module.draw) == "function", "module requires draw(): " .. tostring(key))

    local info = modules[key] or {
        key = key,
        file = spec.file or spec.label or key,
        label = spec.label or key,
        module = nil,
    }

    info.file = spec.file or info.file
    info.label = spec.label or info.label
    info.module = module or info.module
    if spec.sidebar ~= nil then
        info.sidebar = spec.sidebar ~= false
    elseif info.sidebar == nil then
        info.sidebar = true
    end
    modules[key] = info

    if not has_key(module_order, key) then
        module_order[#module_order + 1] = key
    end

    if info.sidebar ~= false and not has_key(tab_order, key) then
        tab_order[#tab_order + 1] = key
    end

    rebuild_registry()
    return true
end

function app_menu.on_menu_open()
    emit("on_menu_open")
end

function app_menu.on_menu_close()
    emit("on_menu_close")
end

function app_menu.on_shutdown()
    emit("on_shutdown")
end

function app_menu.draw()
    local clicked_sidebar = ui.Sidebar(get_sidebar_labels(), sidebar_keys)
    if clicked_sidebar and active_special_key then
        state.save_tab_scroll(special_scroll_key(active_special_key))
        active_special_key = nil
        ui.set_active_special_page(nil)
    end

    local active = active_special_key and modules[active_special_key] or nil
    if not active then
        local active_idx = ui.get_active_tab()
        active = sidebar_tabs[active_idx] or sidebar_tabs[1]
    end
    local module = active and active.module
    assert(active and module and type(module.draw) == "function", "sidebar module is not registered: " .. tostring(active and active.key))

    local frame = renderer.capture_ui_frame()
    local ok, err = pcall(module.draw)
    if not ok then
        renderer.restore_ui_frame(frame)
        logger.error("UI.AppMenu", "tab draw failed", { tab = active.key, error = err })
        ui.Group(_T("Module Error"), function()
            ui.Button(_T("Error") .. ": " .. tostring(err))
        end)
    end
end

function app_menu.open_special(key)
    local info = modules[key]
    if not info or info.sidebar ~= false then return false end
    if active_special_key then
        state.save_tab_scroll(special_scroll_key(active_special_key))
    else
        state.save_tab_scroll(ui.get_active_tab())
    end
    active_special_key = key
    ui.set_active_special_page(key)
    state.reset_interaction()
    if not state.restore_tab_scroll(special_scroll_key(key)) then
        state.ui.scroll_y = 0
        state.ui.scroll_target = 0
    end
    return true
end

function app_menu.close_special(key)
    if not active_special_key then return false end
    if key and active_special_key ~= key then return false end

    state.save_tab_scroll(special_scroll_key(active_special_key))
    active_special_key = nil
    ui.set_active_special_page(nil)
    state.reset_interaction()
    if not state.restore_tab_scroll(ui.get_active_tab()) then
        state.ui.scroll_y = 0
        state.ui.scroll_target = 0
    end
    return true
end

function app_menu.toggle_special(key)
    if app_menu.is_special_open(key) then return app_menu.close_special(key) end
    return app_menu.open_special(key)
end

function app_menu.is_special_open(key)
    if key then return active_special_key == key end
    return active_special_key ~= nil
end

function app_menu.get_tab_index(key)
    return sidebar_index[key]
end

return app_menu
