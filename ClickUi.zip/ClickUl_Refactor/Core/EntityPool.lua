local EntityPool = {}
local Pools = require("ClickUl_Refactor.Adapters.Pools")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Util = require("ClickUl_Refactor.Core.Util")
local PedData = require("ClickUl_Refactor.Core.Data.Ped")
local PedMemory = require("ClickUl_Refactor.Core.PedMemory")

local PED_TYPE_ANIMAL <const> = 28
local PED_TYPE_COP <const> = 6
local PED_TYPE_SWAT <const> = 27
local PED_TYPE_ARMY <const> = 29
local REL_HATE <const> = 5
local MODEL_NAME_CACHE_MAX <const> = 1000
local DEFAULT_DEAD_REFRESH_MS <const> = 300
local DEFAULT_HOSTILITY_REFRESH_MS <const> = 300

local CATEGORY_ORDER <const> = { "animal", "cop", "hostile", "npc" }

local CONSUMER_EXPIRE_FRAMES <const> = 60

local DEFAULT_CONSUMER <const> = {}

local ENUMERATE_INTERVAL_FRAMES <const> = 3

local REFRESH_CENTER_DRIFT_SQ <const> = 25.0 * 25.0

local state = {
    frame = nil,
    enum_frame = nil,
    enum_pos = nil,
    my_ped = 0,
    my_pos = nil,
    wanted_level = 0,
    max_distance = 0,
    ped_handles = {},
    vehicle_handles = {},
    ped_data = {},
    vehicle_data = {},
    request = nil,
    consumers = {},
    peds_by_category = {
        animal = {},
        cop = {},
        hostile = {},
        npc = {},
    },
    model_name_cache = {},
    model_name_count = 0,
}

local function clear_list(list)
    for i = 1, #list do list[i] = nil end
end

local function clear_categories()
    clear_list(state.peds_by_category.animal)
    clear_list(state.peds_by_category.cop)
    clear_list(state.peds_by_category.hostile)
    clear_list(state.peds_by_category.npc)
end

local function all_categories()
    return { animal = true, cop = true, hostile = true, npc = true }
end

local function normalize_enabled(source)
    if type(source) ~= "table" then return all_categories() end
    local enabled = {}
    for i = 1, #CATEGORY_ORDER do
        local category = CATEGORY_ORDER[i]
        enabled[category] = source[category] and true or false
    end
    return enabled
end

local function needs_hostility(enabled, explicit)
    if explicit ~= nil then return explicit and true or false end
    return enabled.hostile or enabled.npc
end

local function refresh_ms(value, fallback)
    local number = tonumber(value)
    if not number then return fallback end
    if number < 0 then return 0 end
    return number
end

local function normalize_request(options)
    options = options or {}
    local enabled = normalize_enabled(options.enabled_categories)
    local request = {
        enabled_categories = enabled,
        include_vehicles = options.include_vehicles ~= false,
        needs_dead = options.needs_dead and true or false,
        needs_hostility = needs_hostility(enabled, options.needs_hostility),
        needs_model = options.needs_model and true or false,
        dead_refresh_ms = refresh_ms(options.dead_refresh_ms, DEFAULT_DEAD_REFRESH_MS),
        hostility_refresh_ms = refresh_ms(options.hostility_refresh_ms, DEFAULT_HOSTILITY_REFRESH_MS),
    }
    return request
end

local function request_covers(current, requested)
    if not current then return false end
    if requested.include_vehicles and not current.include_vehicles then return false end
    if requested.needs_dead and not current.needs_dead then return false end
    if requested.needs_hostility and not current.needs_hostility then return false end
    if requested.needs_model and not current.needs_model then return false end
    if requested.needs_dead and requested.dead_refresh_ms < current.dead_refresh_ms then return false end
    if requested.needs_hostility and requested.hostility_refresh_ms < current.hostility_refresh_ms then return false end

    local current_enabled = current.enabled_categories
    local requested_enabled = requested.enabled_categories
    for i = 1, #CATEGORY_ORDER do
        local category = CATEGORY_ORDER[i]
        if requested_enabled[category] and not current_enabled[category] then return false end
    end
    return true
end

local function widen_request(target, other)
    target.include_vehicles = target.include_vehicles or other.include_vehicles
    target.needs_dead = target.needs_dead or other.needs_dead
    target.needs_hostility = target.needs_hostility or other.needs_hostility
    target.needs_model = target.needs_model or other.needs_model
    if other.needs_dead and other.dead_refresh_ms < target.dead_refresh_ms then
        target.dead_refresh_ms = other.dead_refresh_ms
    end
    if other.needs_hostility and other.hostility_refresh_ms < target.hostility_refresh_ms then
        target.hostility_refresh_ms = other.hostility_refresh_ms
    end
    local enabled = target.enabled_categories
    local other_enabled = other.enabled_categories
    for i = 1, #CATEGORY_ORDER do
        local category = CATEGORY_ORDER[i]
        enabled[category] = enabled[category] or other_enabled[category]
    end
end

local function clone_request(shape)
    local enabled = {}
    for i = 1, #CATEGORY_ORDER do
        local category = CATEGORY_ORDER[i]
        enabled[category] = shape.enabled_categories[category]
    end
    return {
        enabled_categories = enabled,
        include_vehicles = shape.include_vehicles,
        needs_dead = shape.needs_dead,
        needs_hostility = shape.needs_hostility,
        needs_model = shape.needs_model,
        dead_refresh_ms = shape.dead_refresh_ms,
        hostility_refresh_ms = shape.hostility_refresh_ms,
    }
end

local function dist_sq(a, b)
    if not a or not b then return math.huge end
    local dx = a.x - b.x
    local dy = a.y - b.y
    local dz = a.z - b.z
    return dx * dx + dy * dy + dz * dz
end

local function same_position(a, b)
    if not a or not b then return false end
    return a.x == b.x and a.y == b.y and a.z == b.z
end

local function current_frame()
    return Native.call("get_frame_count")
end

local function now_ms()
    return Runtime.get_tick_count()
end

local function expired(time, last_time, interval)
    if not last_time then return true end
    if interval <= 0 then return true end
    local delta = time - last_time
    return delta >= interval or delta < 0
end

local function is_law(ped_type)
    return ped_type == PED_TYPE_COP or ped_type == PED_TYPE_SWAT
end

local function read_ped_type(record, ped)
    if record.ped_type ~= nil then return record.ped_type end
    record.ped_type = Native.call("get_ped_type", ped) or -1
    return record.ped_type
end

local function read_player(record, ped)
    if record.is_player ~= nil then return record.is_player end
    record.is_player = Native.call("is_ped_a_player", ped) and true or false
    return record.is_player
end

local function read_dead(record, entity, time, interval)
    if expired(time, record.dead_time, interval) then
        if record.is_vehicle then
            record.is_dead = Native.call("is_entity_dead", entity, false) and true or false
        else
            record.is_dead = PedMemory.is_dead(entity)
        end
        record.dead_time = time
    end
    return record.is_dead
end

local function read_model_hash(record, entity)
    if record.model_hash_read then return record.model_hash end
    record.model_hash = Native.get_entity_model(entity) or 0
    record.model_hash_read = true
    return record.model_hash
end

local DEFAULT_IN_VEHICLE_REFRESH_MS <const> = 200

local function read_in_vehicle(record, ped, time, interval)
    if expired(time, record.in_vehicle_time, interval) then
        record.in_vehicle = Native.call("is_ped_in_any_vehicle", ped, false) and true or false
        record.in_vehicle_time = time
    end
    return record.in_vehicle
end

local BLIP_COLOUR_RED <const> = 1
local HUD_COLOUR_RED <const> = 6

local function has_enemy_blip(ped)
    local blip = Native.call("get_blip_from_entity", ped)
    if not blip or blip == 0 or Native.does_blip_exist(blip) ~= true then return false end
    if Native.get_blip_colour(blip) == BLIP_COLOUR_RED then return true end
    return Native.call("get_blip_hud_colour", blip) == HUD_COLOUR_RED
end

local function read_enemy(record, ped, ped_type, time, interval)
    if not state.my_ped or state.my_ped == 0 then return false end
    if ped_type == PED_TYPE_ARMY and state.wanted_level > 0 then return true end
    if not expired(time, record.hostility_time, interval) and record.hostility_target == state.my_ped then
        return record.is_enemy
    end

    record.hostility_target = state.my_ped
    if is_law(ped_type) then
        record.is_enemy = has_enemy_blip(ped)
    else
        record.is_enemy = Native.get_ped_target_from_combat_ped(ped, false) == state.my_ped
            or Native.call("get_relationship_between_peds", ped, state.my_ped) == REL_HATE
            or has_enemy_blip(ped)
    end
    if interval > 0 then
        local phase = ped % interval
        record.hostility_time = time - ((time - phase) % interval)
    else
        record.hostility_time = time
    end
    return record.is_enemy
end

local function classify_ped(record, ped, request, time)
    local ped_type = read_ped_type(record, ped)
    local enabled = request.enabled_categories
    if ped_type == PED_TYPE_ANIMAL then return enabled.animal and "animal" or nil end
    if request.needs_hostility and read_enemy(record, ped, ped_type, time, request.hostility_refresh_ms) then
        return enabled.hostile and "hostile" or nil
    end
    if is_law(ped_type) then return enabled.cop and "cop" or nil end
    return enabled.npc and "npc" or nil
end

local function build_entry(entity, data, is_vehicle)
    return {
        entity = entity,
        ped = is_vehicle and nil or entity,
        vehicle = is_vehicle and entity or nil,
        pos = data.pos,
        coords = data.pos,
        dist_sq = data.dist_sq,
        category = data.category,
        is_dead = data.is_dead,
        is_player = data.is_player,
        is_vehicle = is_vehicle,
        model_hash = data.model_hash,
    }
end

local function fill_entry(entry, entity, data, is_vehicle)
    entry.entity = entity
    entry.ped = is_vehicle and nil or entity
    entry.vehicle = is_vehicle and entity or nil
    entry.pos = data.pos
    entry.coords = data.pos
    entry.dist_sq = data.dist_sq
    entry.category = data.category
    entry.is_dead = data.is_dead
    entry.is_player = data.is_player
    entry.is_vehicle = is_vehicle
    entry.model_hash = data.model_hash
    entry.health = nil
    entry.max_health = nil
    entry.armour = nil
    entry.armor = nil
    return entry
end

local function can_be_damaged(entity)
    local value = Native.call("get_entity_can_be_damaged", entity)
    if value == nil then return true end
    if value == false then return false end
    return value ~= 0
end

local DEFAULT_DAMAGEABLE_REFRESH_MS <const> = 1000

local function read_damageable(record, ped, time)
    if expired(time, record.damageable_time, DEFAULT_DAMAGEABLE_REFRESH_MS) then
        record.damageable = can_be_damaged(ped)
        record.damageable_time = time
    end
    return record.damageable
end

local function record_for(cache, entity)
    local record = cache[entity]
    if record then return record end
    record = {}
    cache[entity] = record
    return record
end

local function prune_records(cache, frame)
    for entity, record in pairs(cache) do
        if record.frame ~= frame then cache[entity] = nil end
    end
end

local function scan_ped(ped, request, frame, time, max_dist_sq)
    if ped == state.my_ped then return end

    local record = record_for(state.ped_data, ped)
    record.entity = ped
    record.ped = ped
    record.frame = frame
    record.is_vehicle = false

    local category = classify_ped(record, ped, request, time)
    record.category = category
    if not category then
        record.pos = nil
        record.coords = nil
        record.dist_sq = nil
        return
    end

    local pos = Native.get_entity_coords(ped, false)
    local d_sq = dist_sq(pos, state.my_pos)
    record.pos = pos
    record.coords = pos
    record.dist_sq = d_sq
    if d_sq > max_dist_sq then
        record.category = nil
        return
    end

    if request.needs_dead then read_dead(record, ped, time, request.dead_refresh_ms) end
    if request.needs_model then read_model_hash(record, ped) end
    state.peds_by_category[category][#state.peds_by_category[category] + 1] = ped
end

local function scan_vehicle(vehicle, request, frame, time, max_dist_sq)
    local pos = Native.get_entity_coords(vehicle, false)
    local d_sq = dist_sq(pos, state.my_pos)
    if d_sq > max_dist_sq then return end

    local record = record_for(state.vehicle_data, vehicle)
    record.entity = vehicle
    record.vehicle = vehicle
    record.pos = pos
    record.coords = pos
    record.dist_sq = d_sq
    record.frame = frame
    record.is_vehicle = true

    if request.needs_dead and read_dead(record, vehicle, time, request.dead_refresh_ms) then return end
    if request.needs_model then read_model_hash(record, vehicle) end
end

local function refresh_known_peds(time)
    local request = state.request
    local needs_dead = request.needs_dead
    local dead_refresh = request.dead_refresh_ms
    for i = 1, #CATEGORY_ORDER do
        local list = state.peds_by_category[CATEGORY_ORDER[i]]
        local kept = 0
        for j = 1, #list do
            local ped = list[j]
            local record = state.ped_data[ped]
            if record and Game.entity_exists(ped) then
                local pos = Native.get_entity_coords(ped, false)
                record.pos = pos
                record.coords = pos
                record.dist_sq = dist_sq(pos, state.my_pos)
                if needs_dead then read_dead(record, ped, time, dead_refresh) end
                kept = kept + 1
                list[kept] = ped
            elseif record then
                state.ped_data[ped] = nil
            end
        end
        for j = kept + 1, #list do list[j] = nil end
    end
end

local function refresh_known_vehicles(time)
    local request = state.request
    if not request.include_vehicles then return end
    for vehicle, record in pairs(state.vehicle_data) do
        if Game.entity_exists(vehicle) then
            local pos = Native.get_entity_coords(vehicle, false)
            record.pos = pos
            record.coords = pos
            record.dist_sq = dist_sq(pos, state.my_pos)
            if request.needs_dead and read_dead(record, vehicle, time, request.dead_refresh_ms) then
                state.vehicle_data[vehicle] = nil
            end
        else
            state.vehicle_data[vehicle] = nil
        end
    end
end

function EntityPool.update(my_ped, my_pos, wanted_level, max_distance, options)
    local frame = current_frame()
    local request = normalize_request(options)
    local requested_pos = Util.required_vector3(my_pos)
    local requested_distance = tonumber(max_distance) or 800
    local requested_wanted_level = tonumber(wanted_level) or 0
    if requested_distance < 0 then requested_distance = 0 end

    local key = options or DEFAULT_CONSUMER
    local consumer = state.consumers[key]
    if not consumer then
        consumer = {}
        state.consumers[key] = consumer
    end
    consumer.request = request
    consumer.distance = requested_distance
    consumer.frame = frame

    local scan_request = request
    local scan_distance = requested_distance
    for other_key, other in pairs(state.consumers) do
        if frame - other.frame > CONSUMER_EXPIRE_FRAMES then
            state.consumers[other_key] = nil
        elseif other ~= consumer then
            if scan_request == request then
                scan_request = clone_request(request)
            end
            widen_request(scan_request, other.request)
            if other.distance > scan_distance then scan_distance = other.distance end
        end
    end

    if state.frame == frame
        and scan_distance <= state.max_distance
        and requested_wanted_level == state.wanted_level
        and state.my_ped == (my_ped or 0)
        and same_position(state.my_pos, requested_pos)
        and request_covers(state.request, scan_request)
    then
        return
    end

    local time = now_ms()

    if state.enum_frame
        and frame - state.enum_frame < ENUMERATE_INTERVAL_FRAMES
        and state.my_ped == (my_ped or 0)
        and requested_wanted_level == state.wanted_level
        and scan_distance <= state.max_distance
        and request_covers(state.request, scan_request)
        and dist_sq(requested_pos, state.enum_pos) <= REFRESH_CENTER_DRIFT_SQ
    then
        state.frame = frame
        state.my_pos = requested_pos
        refresh_known_peds(time)
        refresh_known_vehicles(time)
        return
    end

    state.frame = frame
    state.enum_frame = frame
    state.enum_pos = requested_pos
    state.my_ped = my_ped or 0
    state.my_pos = requested_pos
    state.wanted_level = requested_wanted_level
    state.max_distance = scan_distance
    state.request = scan_request

    state.ped_handles = {}
    state.vehicle_handles = {}
    clear_categories()

    if not state.my_pos then
        state.enum_frame = nil
        state.ped_data = {}
        state.vehicle_data = {}
        return
    end

    local max_dist_sq = scan_distance * scan_distance

    state.ped_handles = Pools.ped_handles(false)
    for i = 1, #state.ped_handles do
        scan_ped(state.ped_handles[i], scan_request, frame, time, max_dist_sq)
    end
    prune_records(state.ped_data, frame)

    if scan_request.include_vehicles then
        state.vehicle_handles = Pools.vehicle_handles(false)
        for i = 1, #state.vehicle_handles do
            scan_vehicle(state.vehicle_handles[i], scan_request, frame, time, max_dist_sq)
        end
    end
    prune_records(state.vehicle_data, frame)
end

function EntityPool.get_peds()
    return state.ped_handles
end

function EntityPool.get_vehicles()
    return state.vehicle_handles
end

function EntityPool.get_peds_by_category()
    return state.peds_by_category
end

function EntityPool.get_ped_data(ped)
    local data = state.ped_data[ped]
    if not data then return nil end
    return build_entry(ped, data, false)
end

function EntityPool.get_entity_coords_safe(entity)
    local data = state.ped_data[entity] or state.vehicle_data[entity]
    if data and data.pos then return data.pos end
    if not entity or entity == 0 or not Game.entity_exists(entity) then return nil end
    return Native.get_entity_coords(entity, false)
end

function EntityPool.is_ped_in_vehicle(ped)
    if not ped or ped == 0 then return false end
    local data = state.ped_data[ped]
    if data then return read_in_vehicle(data, ped, now_ms(), DEFAULT_IN_VEHICLE_REFRESH_MS) end
    return Native.call("is_ped_in_any_vehicle", ped, false) and true or false
end

function EntityPool.is_damageable(ped)
    if not ped or ped == 0 then return false end
    local data = state.ped_data[ped]
    if data then return read_damageable(data, ped, now_ms()) end
    return can_be_damaged(ped)
end

function EntityPool.is_entity_dead(entity)
    if not entity or entity == 0 then return true end
    local data = state.ped_data[entity] or state.vehicle_data[entity]
    if data then return read_dead(data, entity, now_ms(), 0) end
    if not Game.entity_exists(entity) then return true end
    return Native.call("is_entity_dead", entity, false) and true or false
end

local function entry_by_dist(a, b)
    return a.dist_sq < b.dist_sq
end

function EntityPool.get_enemies(options)
    options = options or {}
    local radius_sq = tonumber(options.radius_sq) or math.huge
    if radius_sq < 0 then radius_sq = 0 end
    local include_cops = options.kill_cops_when_wanted and state.wanted_level > 0
    local dead_refresh = refresh_ms(options.dead_refresh_ms, DEFAULT_DEAD_REFRESH_MS)
    local time = now_ms()
    local result = {}

    local function append(category)
        for _, ped in ipairs(state.peds_by_category[category]) do
            local data = state.ped_data[ped]
            if data and data.dist_sq <= radius_sq and not read_player(data, ped) and not read_dead(data, ped, time, dead_refresh) then
                if not options.check_invincible or read_damageable(data, ped, time) then
                    result[#result + 1] = build_entry(ped, data, false)
                end
            end
        end
    end

    append("hostile")
    if include_cops then append("cop") end
    table.sort(result, entry_by_dist)
    return result
end

local function lockable_enemy(category)
    if category == "hostile" then return true end
    if category == "cop" then return state.wanted_level > 0 end
    return false
end

function EntityPool.get_lockable_targets(options)
    options = options or {}
    local target_mode = tonumber(options.target_mode) or 3
    local enemy_mode = tonumber(options.enemy_mode) or 0
    local max_dist_sq = tonumber(options.max_distance_sq) or (500 * 500)
    if max_dist_sq < 0 then max_dist_sq = 0 end

    local dead_refresh = refresh_ms(options.dead_refresh_ms, DEFAULT_DEAD_REFRESH_MS)
    local time = now_ms()
    local enemies = {}
    local others = {}
    local function push(entry)
        if entry.is_enemy then
            enemies[#enemies + 1] = entry
        else
            others[#others + 1] = entry
        end
    end

    if target_mode == 1 or target_mode == 3 then
        for ped, data in pairs(state.ped_data) do
            if ped ~= state.my_ped and data.dist_sq and data.dist_sq <= max_dist_sq
                and read_in_vehicle(data, ped, time, DEFAULT_IN_VEHICLE_REFRESH_MS)
                and not read_dead(data, ped, time, dead_refresh)
            then
                local vehicle = Native.call("get_vehicle_ped_is_in", ped, false)
                if vehicle and vehicle ~= 0
                    and Native.call("get_ped_in_vehicle_seat", vehicle, -1, false) == ped
                    and not Native.call("is_entity_dead", vehicle, false)
                then
                    local driver_is_player = read_player(data, ped)
                    local is_enemy = lockable_enemy(data.category)
                    if enemy_mode ~= 2 or is_enemy or driver_is_player then
                        local entry = build_entry(vehicle, data, true)
                        entry.is_player = false
                        entry.model_hash = Native.get_entity_model(vehicle)
                        entry.driver = ped
                        entry.driver_is_player = driver_is_player
                        entry.is_enemy = is_enemy
                        push(entry)
                    end
                end
            end
        end
    end

    if target_mode == 2 or target_mode == 3 then
        for ped, data in pairs(state.ped_data) do
            if ped ~= state.my_ped and data.dist_sq and data.dist_sq <= max_dist_sq
                and not read_dead(data, ped, time, dead_refresh)
            then
                if not read_in_vehicle(data, ped, time, DEFAULT_IN_VEHICLE_REFRESH_MS) then
                    local is_player = read_player(data, ped)
                    local is_enemy = lockable_enemy(data.category)
                    if enemy_mode ~= 2 or is_enemy or is_player then
                        local entry = build_entry(ped, data, false)
                        entry.is_player = is_player
                        entry.is_enemy = is_enemy
                        push(entry)
                    end
                end
            end
        end
    end

    table.sort(enemies, entry_by_dist)
    table.sort(others, entry_by_dist)

    local result = {}
    if enemy_mode == 2 then
        for _, entry in ipairs(enemies) do result[#result + 1] = entry end
        for _, entry in ipairs(others) do
            if entry.is_player or entry.driver_is_player then result[#result + 1] = entry end
        end
    elseif enemy_mode == 1 then
        for _, entry in ipairs(enemies) do result[#result + 1] = entry end
        for _, entry in ipairs(others) do result[#result + 1] = entry end
    else
        for _, entry in ipairs(others) do result[#result + 1] = entry end
        for _, entry in ipairs(enemies) do result[#result + 1] = entry end
        table.sort(result, entry_by_dist)
    end
    return result
end

function EntityPool.get_esp_targets(options)
    options = options or {}
    local enabled = options.enabled_categories or all_categories()
    local max_dist_sq = tonumber(options.max_distance_sq) or math.huge
    if max_dist_sq < 0 then max_dist_sq = 0 end
    local exclude_players = options.exclude_players and true or false
    local wants_hostility = options.needs_hostility ~= false

    local result = options.out or {}
    for _, category in ipairs(CATEGORY_ORDER) do
        local peds = state.peds_by_category[category]
        if enabled[category] then
            local out = result[category]
            if not out then
                out = {}
                result[category] = out
            end
            local out_len = 0
            for _, ped in ipairs(peds) do
                local data = state.ped_data[ped]
                if data and data.dist_sq <= max_dist_sq
                    and not (exclude_players and read_player(data, ped))
                then
                    out_len = out_len + 1
                    local entry = out[out_len]
                    if not entry then
                        entry = {}
                        out[out_len] = entry
                    end
                    fill_entry(entry, ped, data, false)
                end
            end
            if category == "cop" and not wants_hostility and not enabled.hostile then
                for _, ped in ipairs(state.peds_by_category.hostile) do
                    local data = state.ped_data[ped]
                    if data and data.dist_sq <= max_dist_sq
                        and is_law(read_ped_type(data, ped))
                        and not (exclude_players and read_player(data, ped))
                    then
                        out_len = out_len + 1
                        local entry = out[out_len]
                        if not entry then
                            entry = {}
                            out[out_len] = entry
                        end
                        fill_entry(entry, ped, data, false)
                    end
                end
            end
            for i = out_len + 1, #out do out[i] = nil end
        elseif result[category] then
            clear_list(result[category])
        end
    end
    return result
end

function EntityPool.get_ped_model_hash(ped)
    if not ped or ped == 0 then return nil end
    local data = state.ped_data[ped]
    local hash = data and read_model_hash(data, ped) or Native.get_entity_model(ped)
    if not hash or hash == 0 then return nil end
    return hash
end

function EntityPool.get_ped_model_name(ped)
    local data = state.ped_data[ped]
    local hash = data and read_model_hash(data, ped) or Native.get_entity_model(ped)
    if not hash or hash == 0 then return nil end

    local cached = state.model_name_cache[hash]
    if cached ~= nil then
        if cached == false then return nil end
        return cached
    end

    if state.model_name_count >= MODEL_NAME_CACHE_MAX then
        state.model_name_cache = {}
        state.model_name_count = 0
    end

    local name = PedData.get_model_name(hash)
    state.model_name_cache[hash] = name or false
    state.model_name_count = state.model_name_count + 1
    return name
end

function EntityPool.player_wanted_level(player_id)
    return Native.call("get_player_wanted_level", player_id or 0) or 0
end

function EntityPool.clear()
    state.frame = nil
    state.enum_frame = nil
    state.enum_pos = nil
    state.my_ped = 0
    state.my_pos = nil
    state.wanted_level = 0
    state.max_distance = 0
    state.ped_handles = {}
    state.vehicle_handles = {}
    state.ped_data = {}
    state.vehicle_data = {}
    state.request = nil
    state.consumers = {}
    state.model_name_cache = {}
    state.model_name_count = 0
    clear_categories()
end

return EntityPool
