local Hotkeys = {}

local key_codes = require("ClickUl_Refactor.Core.KeyCodes")

local hotkey_settings = nil
local input_module = nil

local actions = {}
local action_order = {}
local actions_by_vk = {}
local binding_index_dirty = true
local capture_state = nil
local pending_capture_result = nil
local trigger_notifier = nil
local MAX_BINDING_SLOTS <const> = 2

local DEFAULT_BINDINGS = {
    ["system.toggle_menu"] = {
        slot1 = { vk = 0x77 },
    },
    ["favorites.toggle_hovered"] = {
        slot1 = { vk = 0x78 },
    },
    ["homing.fire"] = {
        slot1 = { vk = 0x02 },
    },
}

local function settings_module()
    return assert(hotkey_settings, "[Hotkeys] settings module is required")
end

local function input_ref()
    return assert(input_module, "[Hotkeys] input module is required")
end

local function slot_key(slot)
    return "slot" .. tostring(slot)
end

local function normalize_binding(binding)
    if type(binding) ~= "table" then return nil end
    local vk = math.tointeger(tonumber(binding.vk))
    if not vk or vk == 0 then return nil end
    return {
        vk = vk,
        ctrl = binding.ctrl == true and true or nil,
        shift = binding.shift == true and true or nil,
        alt = binding.alt == true and true or nil,
    }
end

local function clone_binding(binding)
    local normalized = normalize_binding(binding)
    if not normalized then return nil end
    return {
        vk = normalized.vk,
        ctrl = normalized.ctrl,
        shift = normalized.shift,
        alt = normalized.alt,
    }
end

local function clone_bindings(bindings)
    local result = {}
    if type(bindings) ~= "table" then return result end

    for i = 1, MAX_BINDING_SLOTS do
        result[i] = clone_binding(bindings[i] or bindings[slot_key(i)])
    end
    return result
end

local function serialize_bindings(bindings)
    local result = {}
    if type(bindings) ~= "table" then return result end

    for i = 1, MAX_BINDING_SLOTS do
        local binding = clone_binding(bindings[i] or bindings[slot_key(i)])
        if binding then
            result[slot_key(i)] = binding
        end
    end

    return result
end

local function clone_binding_table(source)
    local result = {}
    if type(source) ~= "table" then return result end

    for action_id, bindings in pairs(source) do
        result[action_id] = serialize_bindings(bindings)
    end

    return result
end

local function get_binding_table()
    return settings_module().get_bindings()
end

local binding_revision = 0

local function set_binding_table(bindings)
    settings_module().set_bindings(bindings)
    binding_index_dirty = true
    binding_revision = binding_revision + 1
end

function Hotkeys.get_revision()
    return binding_revision
end

local function is_modifier_down(vk_a, vk_b)
    local input_lib = input_ref()
    local key_a = input_lib.get_key_state(vk_a)
    local key_b = input_lib.get_key_state(vk_b)
    return (key_a and key_a.pressed) or (key_b and key_b.pressed) or false
end

local function current_modifiers()
    return {
        ctrl = is_modifier_down(0xA2, 0xA3),
        shift = is_modifier_down(0xA0, 0xA1),
        alt = is_modifier_down(0xA4, 0xA5),
    }
end

local function binding_matches(binding, pressed_key)
    local normalized = normalize_binding(binding)
    if not normalized then return false end
    if pressed_key ~= normalized.vk then return false end

    local mods = current_modifiers()
    return mods.ctrl == (normalized.ctrl == true)
        and mods.shift == (normalized.shift == true)
        and mods.alt == (normalized.alt == true)
end

local function action_allows_context(action, context)
    local when = action.when or "closed"
    local menu_open = context and context.menu_open or false

    if context and context.text_input_active and action.allow_text_input ~= true then
        return false
    end

    if when == "always" then return true end
    if when == "open" then return menu_open end
    return not menu_open
end

local tabbed_actions_cache = nil

local function register_ordered_action(spec)
    local id = spec.id
    if not actions[id] then
        action_order[#action_order + 1] = id
    end
    actions[id] = spec
    binding_index_dirty = true
    tabbed_actions_cache = nil
end

local function default_bindings_for(action_id)
    return serialize_bindings(DEFAULT_BINDINGS[action_id])
end

local function get_slot_binding(bindings, slot)
    if type(bindings) ~= "table" then return nil end
    return bindings[slot] or bindings[slot_key(slot)]
end

local function index_action_binding(action, binding)
    local normalized = normalize_binding(binding)
    if not normalized then return end

    local bucket = actions_by_vk[normalized.vk]
    if not bucket then
        bucket = {}
        actions_by_vk[normalized.vk] = bucket
    end
    bucket[#bucket + 1] = {
        action = action,
        binding = normalized,
    }
end

local function rebuild_binding_index()
    actions_by_vk = {}

    local bindings = get_binding_table()
    for i = 1, #action_order do
        local action = actions[action_order[i]]
        local action_bindings = action and bindings[action.id]
        if type(action_bindings) == "table" then
            for slot = 1, MAX_BINDING_SLOTS do
                index_action_binding(action, get_slot_binding(action_bindings, slot))
            end
        end
    end

    binding_index_dirty = false
end

local function get_key_candidates(vk)
    if binding_index_dirty then rebuild_binding_index() end
    return actions_by_vk[vk]
end

function Hotkeys.init(ctx)
    hotkey_settings = assert(ctx.settings, "[Hotkeys] settings module is required")
    input_module = assert(ctx.input, "[Hotkeys] input module is required")

    return true
end

function Hotkeys.register_action(spec)
    assert(type(spec) == "table", "[Hotkeys] action spec table is required")
    assert(type(spec.id) == "string" and spec.id ~= "", "[Hotkeys] action id is required")
    assert(type(spec.label) == "string" and spec.label ~= "", "[Hotkeys] action label is required")
    assert(type(spec.group) == "string" and spec.group ~= "", "[Hotkeys] action group is required")
    assert(type(spec.callback) == "function", "[Hotkeys] action callback is required")

    register_ordered_action({
        id = spec.id,
        label = spec.label,
        tab = spec.tab or spec.group,
        group = spec.group,
        column = math.tointeger(tonumber(spec.column)) or 1,
        path = spec.path,
        description = spec.description,
        callback = spec.callback,
        when = spec.when or "closed",
        allow_text_input = spec.allow_text_input == true,
        always_enabled = spec.always_enabled == true,
        notify_on_trigger = spec.notify_on_trigger == true,
    })

    local bindings = get_binding_table()
    if bindings[spec.id] == nil then
        local defaults = default_bindings_for(spec.id)
        if defaults.slot1 or defaults.slot2 then
            local updated = clone_binding_table(bindings)
            updated[spec.id] = defaults
            set_binding_table(updated)
        end
    end

    return true
end

function Hotkeys.get_action(action_id)
    return actions[action_id]
end

function Hotkeys.set_trigger_notifier(fn)
    assert(type(fn) == "function", "[Hotkeys] trigger notifier function is required")
    trigger_notifier = fn
end

function Hotkeys.get_tabbed_actions()
    if tabbed_actions_cache then
        return tabbed_actions_cache.tabs, tabbed_actions_cache.tab_order
    end

    local tabs = {}
    local tab_order = {}

    for i = 1, #action_order do
        local action = actions[action_order[i]]
        if action then
            local tab = action.tab or action.group
            local group = action.group
            local tab_entry = tabs[tab]
            if not tab_entry then
                tab_entry = {
                    groups = {},
                    group_columns = {},
                    group_order = {},
                    actions = {},
                }
                tabs[tab] = tab_entry
                tab_order[#tab_order + 1] = tab
            end

            if not tab_entry.groups[group] then
                tab_entry.groups[group] = {}
                tab_entry.group_columns[group] = action.column or 1
                tab_entry.group_order[#tab_entry.group_order + 1] = group
            end

            tab_entry.groups[group][#tab_entry.groups[group] + 1] = action
            tab_entry.actions[#tab_entry.actions + 1] = action
        end
    end

    tabbed_actions_cache = { tabs = tabs, tab_order = tab_order }
    return tabs, tab_order
end

function Hotkeys.get_bindings(action_id)
    return clone_bindings(get_binding_table()[action_id])
end

function Hotkeys.get_binding(action_id, slot)
    local bindings = get_binding_table()[action_id]
    if type(bindings) ~= "table" then return nil end
    return clone_binding(get_slot_binding(bindings, slot))
end

function Hotkeys.format_binding(binding)
    return key_codes.format_binding(binding)
end

function Hotkeys.find_conflict(binding, ignore_action_id, ignore_slot)
    local key = key_codes.binding_key(binding)
    if not key then return nil end

    local bindings = get_binding_table()
    for action_id, action_bindings in pairs(bindings) do
        if actions[action_id] and type(action_bindings) == "table" then
            for slot = 1, MAX_BINDING_SLOTS do
                if not (action_id == ignore_action_id and slot == ignore_slot) then
                    if key_codes.binding_key(get_slot_binding(action_bindings, slot)) == key then
                        return {
                            action_id = action_id,
                            slot = slot,
                            action = actions[action_id],
                        }
                    end
                end
            end
        end
    end

    return nil
end

function Hotkeys.set_binding(action_id, slot, binding)
    assert(actions[action_id], "[Hotkeys] unknown action: " .. tostring(action_id))
    slot = tonumber(slot) or 1
    assert(slot >= 1 and slot <= MAX_BINDING_SLOTS, "[Hotkeys] binding slot must be 1 or 2")

    local normalized = normalize_binding(binding)
    if not normalized then
        return false, "invalid"
    end

    local conflict = Hotkeys.find_conflict(normalized, action_id, slot)
    if conflict then
        return false, "conflict", conflict
    end

    local updated = clone_binding_table(get_binding_table())
    if type(updated[action_id]) ~= "table" then updated[action_id] = {} end
    updated[action_id][slot_key(slot)] = normalized
    set_binding_table(updated)
    return true
end

function Hotkeys.clear_binding(action_id, slot)
    local updated = clone_binding_table(get_binding_table())
    local action_bindings = updated[action_id]
    if type(action_bindings) ~= "table" then return false end

    slot = tonumber(slot) or 1
    local key = slot_key(slot)
    if action_bindings[key] == nil and action_bindings[slot] == nil then return false end

    action_bindings[key] = nil
    action_bindings[slot] = nil
    if not get_slot_binding(action_bindings, 1) and not get_slot_binding(action_bindings, 2) then
        updated[action_id] = {}
    end
    set_binding_table(updated)
    return true
end

function Hotkeys.clear_action(action_id)
    assert(actions[action_id], "[Hotkeys] unknown action: " .. tostring(action_id))

    if actions[action_id].always_enabled then
        return Hotkeys.reset_action(action_id)
    end

    local updated = clone_binding_table(get_binding_table())
    updated[action_id] = {}
    set_binding_table(updated)
    return true, "cleared"
end

function Hotkeys.reset_action(action_id)
    assert(actions[action_id], "[Hotkeys] unknown action: " .. tostring(action_id))

    local defaults = default_bindings_for(action_id)
    local updated = clone_binding_table(get_binding_table())
    if defaults.slot1 or defaults.slot2 then
        updated[action_id] = defaults
        set_binding_table(updated)
        return true, "defaults"
    end

    updated[action_id] = {}
    set_binding_table(updated)
    return true, "cleared"
end

function Hotkeys.reset_defaults()
    local bindings = {}
    for action_id in pairs(actions) do
        local defaults = default_bindings_for(action_id)
        if defaults.slot1 or defaults.slot2 then bindings[action_id] = defaults end
    end
    set_binding_table(bindings)
    return true
end

function Hotkeys.is_enabled()
    return settings_module().is_enabled()
end

function Hotkeys.set_enabled(enabled)
    settings_module().set_enabled(enabled)
end

function Hotkeys.is_trigger_notification_enabled()
    return settings_module().is_trigger_notification_enabled()
end

function Hotkeys.set_trigger_notification_enabled(enabled)
    settings_module().set_trigger_notification_enabled(enabled)
end

function Hotkeys.begin_capture(action_id, slot)
    assert(actions[action_id], "[Hotkeys] unknown action: " .. tostring(action_id))
    slot = tonumber(slot) or 1
    assert(slot >= 1 and slot <= MAX_BINDING_SLOTS, "[Hotkeys] binding slot must be 1 or 2")

    capture_state = {
        action_id = action_id,
        slot = slot,
        started = true,
        result = nil,
    }
end

function Hotkeys.cancel_capture()
    capture_state = nil
end

function Hotkeys.get_capture()
    return capture_state
end

function Hotkeys.update_capture()
    if not capture_state then return nil end

    local key = input_ref().get_key_pressed()
    if not key then return nil end

    if key == 0x1B then
        local result = { status = "cancelled" }
        capture_state.result = result
        capture_state = nil
        pending_capture_result = result
        return result
    end

    if key == 0x08 or key == 0x2E then
        local action = actions[capture_state.action_id]
        local other_slot = capture_state.slot == 1 and 2 or 1
        local result
        if action.always_enabled and not Hotkeys.get_binding(capture_state.action_id, other_slot) then
            result = { status = "protected" }
        else
            Hotkeys.clear_binding(capture_state.action_id, capture_state.slot)
            result = { status = "cleared" }
        end
        capture_state.result = result
        capture_state = nil
        pending_capture_result = result
        return result
    end

    if key_codes.is_modifier_key(key) then return nil end

    if key == 0x79 then
        local result = { status = "reserved" }
        capture_state.result = result
        capture_state = nil
        pending_capture_result = result
        return result
    end

    local mods = current_modifiers()
    local binding = { vk = key }
    if mods.ctrl then binding.ctrl = true end
    if mods.shift then binding.shift = true end
    if mods.alt then binding.alt = true end

    local ok, reason, conflict = Hotkeys.set_binding(capture_state.action_id, capture_state.slot, binding)
    local result = {
        status = ok and "saved" or reason,
        binding = binding,
        conflict = conflict,
    }
    capture_state.result = result
    capture_state = nil
    pending_capture_result = result
    return result
end

function Hotkeys.consume_capture_result()
    local result = pending_capture_result
    pending_capture_result = nil
    return result
end

function Hotkeys.dispatch(context)
    if capture_state then return false end
    local pressed_key = input_ref().get_key_pressed()
    if not pressed_key then return false end

    local candidates = get_key_candidates(pressed_key)
    if not candidates or #candidates == 0 then return false end

    local enabled = Hotkeys.is_enabled()
    for i = 1, #candidates do
        local candidate = candidates[i]
        local action = candidate.action
        if action and actions[action.id] == action and (enabled or action.always_enabled) and action_allows_context(action, context) then
            local binding = candidate.binding
            if binding_matches(binding, pressed_key) then
                local result = action.callback(action, binding)
                if trigger_notifier and action.notify_on_trigger and settings_module().is_trigger_notification_enabled() then
                    trigger_notifier(action, normalize_binding(binding), result)
                end
                return true
            end
        end
    end

    return false
end

return Hotkeys
