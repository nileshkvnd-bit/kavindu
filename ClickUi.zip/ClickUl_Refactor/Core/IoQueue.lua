local io_queue = {}

local pending_saves = {}
local pending_order = {}
local pending_logs = {}
local log_writer = nil

local MAX_LOGS_PER_PROCESS <const> = 16
local MAX_PENDING_LOGS <const> = 1000

local error_handler = nil

local function report_error(context, detail)
    if error_handler then
        pcall(error_handler, context, detail)
    else
        print("[IoQueue] " .. context .. ": " .. tostring(detail))
    end
end

function io_queue.set_error_handler(fn)
    error_handler = (type(fn) == "function") and fn or nil
end

function io_queue.queue_save(save_func, name)
    if type(save_func) ~= "function" then return false end
    local key = name or tostring(save_func)
    if not pending_saves[key] then pending_order[#pending_order + 1] = key end
    pending_saves[key] = save_func
    return true
end

function io_queue.process(max_count)
    max_count = max_count or 2
    local count = 0
    while count < max_count and #pending_order > 0 do
        local key = table.remove(pending_order, 1)
        local fn = pending_saves[key]
        pending_saves[key] = nil
        if fn then
            local ok, result = pcall(fn)
            if not ok then
                report_error("save failed: " .. tostring(key), result)
            elseif result == false then
                report_error("save failed: " .. tostring(key), "returned false")
            end
        end
        count = count + 1
    end
    io_queue.process_logs(MAX_LOGS_PER_PROCESS)
end

function io_queue.flush_saves()
    while #pending_order > 0 do io_queue.process(8) end
end

function io_queue.queue_log(message)
    if message == nil then return false end
    pending_logs[#pending_logs + 1] = tostring(message)
    if #pending_logs > MAX_PENDING_LOGS then
        table.remove(pending_logs, 1)
    end
    return true
end

function io_queue.set_log_handle(writer)
    log_writer = writer
end

function io_queue.get_log_handle()
    return log_writer
end

local function write_log_message(message)
    if not log_writer then return false end
    local ok, result = pcall(log_writer, message .. "\n")
    if ok and result ~= false then
        return true
    end
    return false
end

function io_queue.process_logs(max_count)
    if not log_writer then return false end
    max_count = max_count or MAX_LOGS_PER_PROCESS
    local count = 0
    while #pending_logs > 0 and count < max_count do
        write_log_message(table.remove(pending_logs, 1))
        count = count + 1
    end
    return count > 0
end

function io_queue.flush_logs()
    if not log_writer then return false end
    while #pending_logs > 0 do
        write_log_message(table.remove(pending_logs, 1))
    end
    return true
end

return io_queue
