local Projection = {}
local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local math_sin <const> = math.sin
local math_cos <const> = math.cos
local math_tan <const> = math.tan
local D2R <const> = math.pi / 180.0
local NEAR_DEPTH <const> = 0.05

local cache_frame = nil
local cache = {}

local active = { valid = false }
local pending = { valid = false }

local function promote(src)
    local rx, ry, rz = src.rx, src.ry, src.rz
    local sx, cx = math_sin(rx), math_cos(rx)
    local sy, cy = math_sin(ry), math_cos(ry)
    local sz, cz = math_sin(rz), math_cos(rz)
    active.right_x = cz * cy - sz * sx * sy
    active.right_y = sz * cy + cz * sx * sy
    active.right_z = -cx * sy
    active.fwd_x = -sz * cx
    active.fwd_y = cz * cx
    active.fwd_z = sx
    active.up_x = cz * sy + sz * sx * cy
    active.up_y = sz * sy - cz * sx * cy
    active.up_z = cx * cy
    active.cx, active.cy, active.cz = src.cx, src.cy, src.cz
    local tan_half = math_tan(src.fov * 0.5 * D2R)
    active.tan_half = tan_half
    active.aspect_tan = tan_half * (src.res_x / src.res_y)
    active.res_x, active.res_y = src.res_x, src.res_y
    active.valid = true
end

local function finite(v)
    return type(v) == "number" and v - v == 0
end

local function read_pending()
    local pos = Native.get_final_rendered_cam_coord()
    local rot = Native.get_final_rendered_cam_rot(2)
    local fov = Native.call("get_final_rendered_cam_fov")
    if not pos or not rot then
        pending.valid = false
        return
    end
    local px, py, pz = pos.x, pos.y, pos.z
    local rx, ry, rz = rot.x, rot.y, rot.z
    if not finite(fov) or fov <= 0.0 or fov >= 180.0
        or not finite(px) or not finite(py) or not finite(pz)
        or not finite(rx) or not finite(ry) or not finite(rz)
    then
        pending.valid = false
        return
    end
    local resolution = Runtime.resolution()
    pending.cx, pending.cy, pending.cz = px, py, pz
    pending.rx, pending.ry, pending.rz = rx * D2R, ry * D2R, rz * D2R
    pending.fov = fov
    pending.res_x, pending.res_y = resolution.x, resolution.y
    pending.valid = true
end

function Projection.refresh_camera()
    local frame = Native.call("get_frame_count")
    if frame == cache_frame then return end
    cache_frame = frame
    cache = {}
    if pending.valid then promote(pending) end
    read_pending()
    if not active.valid and pending.valid then promote(pending) end
end

local function project_xy(x, y, z)
    if not active.valid then
        Projection.refresh_camera()
        if not active.valid then return nil end
    end
    local dx = x - active.cx
    local dy = y - active.cy
    local dz = z - active.cz
    local depth = dx * active.fwd_x + dy * active.fwd_y + dz * active.fwd_z
    if depth < NEAR_DEPTH then return nil end
    local nx = 0.5 + 0.5 * ((dx * active.right_x + dy * active.right_y + dz * active.right_z)
        / (active.aspect_tan * depth))
    if nx < 0.0 or nx > 1.0 then return nil end
    local ny = 0.5 - 0.5 * ((dx * active.up_x + dy * active.up_y + dz * active.up_z)
        / (active.tan_half * depth))
    if ny < 0.0 or ny > 1.0 then return nil end
    return nx * active.res_x, ny * active.res_y, nx, ny
end

function Projection.world_to_screen(position)
    if not position then return nil end
    local x, y, z = position.x, position.y, position.z
    if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return nil end
    if x - x ~= 0 or y - y ~= 0 or z - z ~= 0 then return nil end

    local level_x = cache[x]
    local level_y = level_x and level_x[y]
    local cached = level_y and level_y[z]
    if cached ~= nil then return cached or nil end

    local sx, sy, normalized_x, normalized_y = project_xy(x, y, z)
    local result = false
    if sx then
        result = {
            x = sx,
            y = sy,
            normalized_x = normalized_x,
            normalized_y = normalized_y,
        }
    end
    if not level_x then
        level_x = {}
        cache[x] = level_x
    end
    if not level_y then
        level_y = {}
        level_x[y] = level_y
    end
    level_y[z] = result
    return result or nil
end

function Projection.world_to_screen_xy(position)
    if not position then return nil end
    local x, y, z = position.x, position.y, position.z
    if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then return nil end
    if x - x ~= 0 or y - y ~= 0 or z - z ~= 0 then return nil end
    return project_xy(x, y, z)
end

function Projection.is_behind(position)
    if not active.valid then return false end
    local dx = position.x - active.cx
    local dy = position.y - active.cy
    local dz = position.z - active.cz
    return dx * active.fwd_x + dy * active.fwd_y + dz * active.fwd_z <= 0
end

function Projection.maybe_on_screen(position, radius)
    if not active.valid then return true end
    local dx = position.x - active.cx
    local dy = position.y - active.cy
    local dz = position.z - active.cz
    local depth = dx * active.fwd_x + dy * active.fwd_y + dz * active.fwd_z
    if depth - radius <= NEAR_DEPTH then return true end
    local limit = depth + radius
    local rv = dx * active.right_x + dy * active.right_y + dz * active.right_z
    local half_w = active.aspect_tan * limit
    if rv - radius > half_w or rv + radius < -half_w then return false end
    local uv = dx * active.up_x + dy * active.up_y + dz * active.up_z
    local half_h = active.tan_half * limit
    return uv - radius <= half_h and uv + radius >= -half_h
end

function Projection.clear_cache()
    cache_frame = nil
    cache = {}
    active.valid = false
    pending.valid = false
end

function Projection.free()
    Projection.clear_cache()
end

return Projection
