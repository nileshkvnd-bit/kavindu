local JsonEncoder = {}

local string_format = string.format
local string_byte = string.byte
local string_rep = string.rep
local table_concat = table.concat
local math_type = math.type
local math_huge = math.huge

local ESCAPES <const> = {
    ['"'] = '\\"',
    ['\\'] = '\\\\',
    ['\b'] = '\\b',
    ['\f'] = '\\f',
    ['\n'] = '\\n',
    ['\r'] = '\\r',
    ['\t'] = '\\t',
}

local function escape_char(c)
    return ESCAPES[c] or string_format("\\u%04x", string_byte(c))
end

local function encode_string(value)
    return '"' .. value:gsub('[%c"\\]', escape_char) .. '"'
end

local function encode_number(value)
    if value ~= value or value == math_huge or value == -math_huge then
        error("[JsonEncoder] cannot encode non-finite number")
    end
    if math_type(value) == "integer" then
        return string_format("%d", value)
    end
    return string_format("%.14g", value)
end

local function sequence_length(tbl)
    local n = 0
    for key in pairs(tbl) do
        if math_type(key) ~= "integer" then return nil end
        if key > n then n = key end
    end
    if n == 0 then return nil end
    for i = 1, n do
        if tbl[i] == nil then return nil end
    end
    return n
end

local encode_value

local function encode_array(tbl, n, indent, level)
    local newline = indent and "\n" or ""
    local separator = indent and ",\n" or ","
    local inner_pad = indent and string_rep(" ", indent * (level + 1)) or ""
    local outer_pad = indent and string_rep(" ", indent * level) or ""

    local parts = {}
    for i = 1, n do
        parts[i] = inner_pad .. encode_value(tbl[i], indent, level + 1)
    end
    return "[" .. newline .. table_concat(parts, separator) .. newline .. outer_pad .. "]"
end

local function encode_object(tbl, indent, level)
    local keys = {}
    for key in pairs(tbl) do keys[#keys + 1] = key end
    if #keys == 0 then return "{}" end
    table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)

    local newline = indent and "\n" or ""
    local separator = indent and ",\n" or ","
    local colon = indent and ": " or ":"
    local inner_pad = indent and string_rep(" ", indent * (level + 1)) or ""
    local outer_pad = indent and string_rep(" ", indent * level) or ""

    local parts = {}
    for i = 1, #keys do
        local key = keys[i]
        parts[i] = inner_pad .. encode_string(tostring(key)) .. colon .. encode_value(tbl[key], indent, level + 1)
    end
    return "{" .. newline .. table_concat(parts, separator) .. newline .. outer_pad .. "}"
end

function encode_value(value, indent, level)
    local value_type = type(value)
    if value_type == "nil" then return "null" end
    if value_type == "boolean" then return value and "true" or "false" end
    if value_type == "number" then return encode_number(value) end
    if value_type == "string" then return encode_string(value) end
    if value_type == "table" then
        local n = sequence_length(value)
        if n then return encode_array(value, n, indent, level) end
        return encode_object(value, indent, level)
    end
    error("[JsonEncoder] cannot encode value of type " .. value_type)
end

function JsonEncoder.encode(value, indent)
    if indent ~= nil and (math_type(indent) ~= "integer" or indent < 0) then
        error("[JsonEncoder] indent must be a non-negative integer")
    end
    if indent == 0 then indent = nil end
    return encode_value(value, indent, 0)
end

return JsonEncoder
