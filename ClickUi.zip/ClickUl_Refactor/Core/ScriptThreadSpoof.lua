local ScriptThreadSpoof = {}
local Memory = require("ClickUl_Refactor.Adapters.Memory")
local Script = require("ClickUl_Refactor.Adapters.Script")

local THREADS_PATTERN <const> = "48 8B 05 ? ? ? ? 48 89 34 F8 48 FF C7 48 39 FB 75 97"
local FREEMODE_SCRIPT <const> = "freemode"
local FREEMODE_HASH <const> = 0xC875557D
local ORBITAL_HASH <const> = 0x6C25DCCB
local OFF_CTX <const> = 0x10
local OFF_H150 <const> = 0x150
local OFF_H1A8 <const> = 0x1A8
local OFF_HANDLER <const> = 0x198
local OFF_HANDLER_HASH <const> = 0x68
local ARRAY_COUNT_OFFSET <const> = 0x8
local ARRAY_DATA_OFFSET <const> = 0x0
local MAX_SCRIPT_THREADS <const> = 2048

local cached = nil

local function u32(value)
    return value & 0xFFFFFFFF
end

local function fail(message)
    error("ScriptThreadSpoof: " .. message, 3)
end

local function address_value(address)
    return address and Memory.value(address) or nil
end

local function in_module(value, base)
    return type(value) == "number" and value >= base and value <= base + 0x6000000
end

local function is_heap(value, base)
    return type(value) == "number" and value > 0x100000000 and value < base
end

local function read_at_array()
    local base = Memory.base()
    if type(base) ~= "number" then fail("memory base unavailable") end

    local match = Memory.scan(THREADS_PATTERN)
    if not match then fail("ScriptThreads signature not found") end

    local array = Memory.rip(match)
    if not in_module(address_value(array), base) then fail("ScriptThreads rip outside module") end

    local raw_data = Memory.uint64(Memory.add(array, ARRAY_DATA_OFFSET))
    local count = Memory.uint16(Memory.add(array, ARRAY_COUNT_OFFSET))
    if not is_heap(raw_data, base) or not count or count <= 0 or count > MAX_SCRIPT_THREADS then
        fail("ScriptThreads array invalid")
    end

    local data = Memory.ptr(Memory.add(array, ARRAY_DATA_OFFSET))
    if address_value(data) ~= raw_data then fail("ScriptThreads data pointer mismatch") end
    return data, count, base
end

local function find_freemode_thread()
    local data, count, base = read_at_array()
    for index = 0, math.min(count, 200) - 1 do
        local slot = Memory.add(data, index * 8)
        local thread = Memory.ptr(slot)
        if is_heap(address_value(thread), base) then
            local hash = Memory.uint32(Memory.add(thread, OFF_CTX))
            if u32(hash) == FREEMODE_HASH then return thread end
        end
    end
    fail("freemode thread not found")
end

local function resolve()
    if cached and cached.thread and cached.handler then return cached end

    local thread = find_freemode_thread()
    local handler = Memory.ptr(Memory.add(thread, OFF_HANDLER))
    local base = Memory.base()
    if not is_heap(address_value(handler), base) then fail("freemode handler not found") end

    cached = {
        thread = thread,
        handler = handler,
        ctx = Memory.add(thread, OFF_CTX),
        h150 = Memory.add(thread, OFF_H150),
        h1a8 = Memory.add(thread, OFF_H1A8),
        handler_hash = Memory.add(handler, OFF_HANDLER_HASH),
    }
    return cached
end

local function read_hashes(target)
    return {
        ctx64 = Memory.uint64(target.ctx),
        ctx32 = Memory.uint32(target.ctx),
        h150 = Memory.uint32(target.h150),
        h1a8 = Memory.uint32(target.h1a8),
        handler = Memory.uint32(target.handler_hash),
    }
end

local function assert_freemode_hashes(values)
    if u32(values.ctx32) ~= FREEMODE_HASH then fail("freemode ctx hash changed before spoof") end
    if u32(values.h150) ~= FREEMODE_HASH then fail("freemode +0x150 hash changed before spoof") end
    if u32(values.h1a8) ~= FREEMODE_HASH then fail("freemode +0x1A8 hash changed before spoof") end
    if u32(values.handler) ~= FREEMODE_HASH then fail("freemode handler hash changed before spoof") end
end

local function write_hashes(target, values)
    Memory.set_uint64(target.ctx, values.ctx64)
    Memory.set_uint32(target.h150, values.h150)
    Memory.set_uint32(target.h1a8, values.h1a8)
    Memory.set_uint32(target.handler_hash, values.handler)
end

local function write_orbital_hashes(target, original)
    local spoof_ctx = (original.ctx64 & 0xFFFFFFFF00000000) | ORBITAL_HASH
    Memory.set_uint64(target.ctx, spoof_ctx)
    Memory.set_uint32(target.h150, ORBITAL_HASH)
    Memory.set_uint32(target.h1a8, ORBITAL_HASH)
    Memory.set_uint32(target.handler_hash, ORBITAL_HASH)
end

local function assert_restored(target)
    local now = read_hashes(target)
    if u32(now.ctx32) ~= FREEMODE_HASH
        or u32(now.h150) ~= FREEMODE_HASH
        or u32(now.h1a8) ~= FREEMODE_HASH
        or u32(now.handler) ~= FREEMODE_HASH then
        fail("freemode hash restore verification failed")
    end
end

local function resolve_validated()
    local had_cache = cached ~= nil
    local target = resolve()
    local original = read_hashes(target)
    local ok = pcall(assert_freemode_hashes, original)
    if ok then return target, original end
    if not had_cache then assert_freemode_hashes(original) end

    ScriptThreadSpoof.reset_cache()
    target = resolve()
    original = read_hashes(target)
    assert_freemode_hashes(original)
    return target, original
end

function ScriptThreadSpoof.with_orbital_thread_hash(fn)
    if type(fn) ~= "function" then fail("with_orbital_thread_hash expects function") end
    local target, original = resolve_validated()

    local body_ok, body_err
    local restore_ok, restore_err
    local execute_ok, execute_err = xpcall(function()
        Script.execute_as(FREEMODE_SCRIPT, function()
            body_ok, body_err = xpcall(function()
                write_orbital_hashes(target, original)
                fn()
            end, debug.traceback)
            restore_ok, restore_err = xpcall(function()
                write_hashes(target, original)
                assert_restored(target)
            end, debug.traceback)
        end)
    end, debug.traceback)

    if not execute_ok then error(execute_err, 0) end
    if restore_ok == nil then fail("execute_as did not invoke callback") end
    if not restore_ok then
        error(restore_err or "ScriptThreadSpoof: restore failed", 0)
    end
    if not body_ok then error(body_err, 0) end
end

function ScriptThreadSpoof.reset_cache()
    cached = nil
end

return ScriptThreadSpoof
