local OrderedMapStore = require("ClickUl_Refactor.Core.OrderedMapStore")
local Util = require("ClickUl_Refactor.Core.Util")

local Favorites = {}

local action_registry = nil

local clone_list = Util.clone_list

local function normalize_favorite_kind(kind)
    if kind == "vehicle" then return "vehicle" end
    if kind == "outfit" then return "outfit" end
    if kind == "map" then return "map" end
    return "function"
end

local function normalize_item(value)
    if type(value) ~= "table" or type(value.id) ~= "string" or value.id == "" then return nil end

    return {
        id = value.id,
        label = type(value.label) == "string" and value.label or nil,
        group = type(value.group) == "string" and value.group or nil,
        feature = type(value.feature) == "string" and value.feature or nil,
        page = type(value.page) == "string" and value.page or nil,
        tabs = clone_list(value.tabs),
        section = type(value.section) == "string" and value.section or nil,
        column = type(value.column) == "number" and value.column or nil,
        layout = type(value.layout) == "string" and value.layout or nil,
        favorite_kind = normalize_favorite_kind(value.favorite_kind),
        path = type(value.path) == "string" and value.path or nil,
        description = type(value.description) == "string" and value.description or nil,
    }
end

local function action_for(id)
    return action_registry and action_registry.get(id) or nil
end

local function saved_item_for_id(id)
    local source = action_for(id)
    if type(source) ~= "table" then return nil end

    return normalize_item({
        id = id,
        label = source.label,
        group = source.group,
        feature = source.feature,
        page = source.page,
        tabs = clone_list(source.tabs),
        section = source.section,
        column = source.column,
        layout = source.layout,
        favorite_kind = source.favorite_kind,
        path = source.path,
        description = source.description,
    })
end

local function make_entry(item, index)
    local id = item.id
    local action = action_for(id)
    if action then
        return {
            id = id,
            index = index,
            label = action.label,
            group = action.group,
            feature = action.feature,
            page = action.page,
            tabs = clone_list(action.tabs),
            section = action.section,
            column = action.column,
            layout = action.layout,
            favorite_kind = action.favorite_kind or "function",
            path = action.path,
            description = action.description,
            action = action,
            available = not action_registry or action_registry.is_available(id),
        }
    end

    local saved = type(item) == "table" and item or {}
    local page = saved.page or "Unavailable"
    return {
        id = id,
        index = index,
        label = saved.label or id,
        group = saved.group or "Unavailable",
        feature = saved.feature or "Unavailable",
        page = page,
        tabs = clone_list(saved.tabs) or { page },
        section = saved.section or "Unavailable",
        column = saved.column or 1,
        layout = saved.layout or "SingleColumn",
        favorite_kind = normalize_favorite_kind(saved.favorite_kind),
        path = saved.path,
        description = saved.description,
        action = nil,
        available = false,
    }
end

local function serialize_item(item)
    return {
        label = item.label,
        group = item.group,
        feature = item.feature,
        page = item.page,
        section = item.section,
        column = item.column,
        layout = item.layout,
        favorite_kind = item.favorite_kind,
        path = item.path,
        description = item.description,
    }
end

local store = OrderedMapStore.new({
    filename = "favorites.json",
    version = 2,
    queue_key = "favorites",
    normalize = function(id, raw)
        raw.id = id
        return normalize_item(raw)
    end,
    serialize = serialize_item,
    log_name = "Core.Favorites",
})

function Favorites.init(ctx)
    ctx = ctx or {}
    action_registry = assert(ctx.action_registry, "[Favorites] action_registry is required")
    store.logger = ctx.logger
    return Favorites.load()
end

function Favorites.load()
    return store:load()
end

function Favorites.save_immediate()
    return store:save_immediate()
end

function Favorites.is_dirty()
    return store:is_dirty()
end

function Favorites.is_favorite(id)
    return store:has(id)
end

function Favorites.add(id)
    if type(id) ~= "string" or id == "" then return false end
    if store:has(id) then return false end
    local item = saved_item_for_id(id)
    if not item then return false end
    return store:insert(item)
end

function Favorites.remove(id)
    return store:remove(id)
end

function Favorites.toggle(id)
    if Favorites.is_favorite(id) then
        Favorites.remove(id)
        return false
    end
    if Favorites.add(id) then return true end
    return nil, "missing_action"
end

function Favorites.count()
    return store:count()
end

function Favorites.version()
    return store:version()
end

function Favorites.list()
    local result = {}
    local entries = store:entries()
    for index = 1, #entries do
        local entry = make_entry(entries[index], index)
        if entry then result[#result + 1] = entry end
    end
    return result
end

function Favorites.get_action(id)
    return action_for(id)
end

function Favorites.get_path()
    return store:config_path()
end

return Favorites
