local logger = require("ClickUl_Refactor.Core.Logger")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local input_adapter = require("ClickUl_Refactor.Adapters.Input")
local players_adapter = require("ClickUl_Refactor.Adapters.Players")
local entity_pool = require("ClickUl_Refactor.Core.EntityPool")
local projection = require("ClickUl_Refactor.Core.Projection")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")
local i18n = require("ClickUl_Refactor.Core.I18n")
local trace = require("ClickUl_Refactor.Core.Trace")
local hotkeys = require("ClickUl_Refactor.Core.Hotkeys")
local ui_loader = require("ClickUl_Refactor.UI.Loader")

local Bootstrap = {}

local app = nil

local function traceback_handler(err)
    return trace.capture(err, 3)
end

local function build_context()
    return {
        logger = logger,
        runtime = runtime,
        i18n = i18n,
    }
end

local function draw_ui(ui)
    if not ui.is_open() then
        input_adapter.disable_input(false)
        return
    end

    ui.draw_window("ClickUl", ui.draw_menu)
    ui.draw_hotkey_editor()
    ui.draw_loading_overlay()
end

local function tick()
    if not app then return false end

    local ui = app.ui
    local ok, err = xpcall(function()
        ui.clear_frame_events()
        local capture_result = hotkeys.update_capture()

        local hotkey_editor_handled = ui.handle_hotkey_editor(capture_result)

        if not capture_result and not hotkey_editor_handled then
            hotkeys.dispatch({
                menu_open = ui.is_open(),
                text_input_active = ui.is_text_input_active(),
            })
        end

        local is_open = ui.is_open()

        if is_open then
            ui.update_input()
        end

        if is_open then
            ui.block_game_controls()
        else
            input_adapter.disable_input(false)
        end

        draw_ui(ui)

        ui.draw_notifications()
        ui.auto_save_settings()
        io_queue.process()
    end, traceback_handler)

    if not ok then
        logger.error("Bootstrap", "tick failed: " .. tostring(err))
    end

    return true
end

function Bootstrap.init()
    if app then return app end

    collectgarbage("generational", 10, 100)

    logger.info("Bootstrap", "initializing refactor runtime")

    players_adapter.seed()

    local ctx = build_context()
    local ui = ui_loader.load(ctx)

    app = {
        ctx = ctx,
        ui = ui,
        thread_id = nil,
    }

    app.thread_id = runtime.create_thread(tick)

    logger.info("Bootstrap", "refactor runtime ready")
    return app
end

function Bootstrap.shutdown()
    if not app then
        input_adapter.disable_input(false)
        return true
    end

    local current = app
    app = nil

    if current.thread_id then
        runtime.remove_thread(current.thread_id)
    end

    local ui = current.ui
    if ui and ui.is_open and ui.is_open() and type(ui.on_menu_close) == "function" then
        local ok, err = xpcall(ui.on_menu_close, traceback_handler)
        if not ok then logger.error("Bootstrap", "menu close failed: " .. tostring(err)) end
    end

    if ui and type(ui.shutdown) == "function" then
        local ok, err = xpcall(ui.shutdown, traceback_handler)
        if not ok then logger.error("Bootstrap", "shutdown failed: " .. tostring(err)) end
    else
        input_adapter.disable_input(false)
    end

    io_queue.flush_saves()
    input_adapter.disable_input(false)
    entity_pool.clear()
    projection.free()
    logger.info("Bootstrap", "refactor runtime stopped")
    return true
end

return Bootstrap
