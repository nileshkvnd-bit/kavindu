local FileCatalog = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")

local ipairs <const> = ipairs
local pairs <const> = pairs
local tostring <const> = tostring
local table_sort <const> = table.sort
local string_lower <const> = string.lower
local EMPTY_LIST <const> = {}
local EMPTY_FOLDERS <const> = { by_folder = {}, folder_names = EMPTY_LIST }

local function natural_less(a, b)
    a, b = tostring(a), tostring(b)
    local la, lb = string_lower(a), string_lower(b)
    local ia, ib = 1, 1
    while ia <= #la and ib <= #lb do
        local da = la:match("^%d+", ia)
        local db = lb:match("^%d+", ib)
        if da and db then
            local na, nb = tonumber(da), tonumber(db)
            if na ~= nb then return na < nb end
            ia = ia + #da
            ib = ib + #db
        else
            local ca, cb = la:sub(ia, ia), lb:sub(ib, ib)
            if ca ~= cb then return ca < cb end
            ia = ia + 1
            ib = ib + 1
        end
    end
    if #la ~= #lb then return #la < #lb end
    return a < b
end

local function strip_extension(file_name)
    return tostring(file_name or ""):gsub("%.[^%.\\/]+$", "")
end

local function file_name(path)
    return tostring(path or ""):match("[\\/]([^\\/]+)$") or tostring(path or "Unknown")
end

local function normalize_search(value)
    return string_lower(tostring(value or ""))
end

local function normalize_path(path)
    return tostring(path or ""):gsub("/", "\\")
end

local function is_absolute_path(path)
    path = tostring(path or "")
    return path:match("^%a:[\\/]") ~= nil or path:match("^[\\/]") ~= nil
end

local function scan_path(base_path, entry)
    entry = tostring(entry or "")
    if is_absolute_path(entry) then return entry end
    return Fs.join(base_path, entry)
end

local function relative_path(base_path, path)
    local base = normalize_path(base_path)
    local value = normalize_path(path)
    if not base:match("[\\/]$") then base = base .. "\\" end
    if string_lower(value):sub(1, #base) == string_lower(base) then return value:sub(#base + 1) end
    return value
end

local function parent_folder(base_path, path, default_folder)
    local relative = relative_path(base_path, path)
    local folder = relative:match("^(.*)[\\/]") or ""
    folder = folder:gsub("[\\/]+$", "")
    if folder == "" then return default_folder end
    return folder
end

local function has_extension(path, extension)
    return string_lower(tostring(path or "")):match("%." .. string_lower(extension) .. "$") ~= nil
end

local function add_file_item(result, base_path, path, def)
    local name = file_name(path)
    local subfolder = parent_folder(base_path, path, def.default_folder)
    result[#result + 1] = {
        name = strip_extension(name),
        display_name = name,
        path = path,
        format = def.key,
        subfolder = subfolder,
        search_key = normalize_search(name .. " " .. subfolder .. " " .. def.key),
    }
end

local function scan_directory(result, base_path, current_path, def, visited)
    local key = string_lower(normalize_path(current_path))
    if visited[key] then return end
    visited[key] = true

    local files = Fs.list(current_path, def.extension)
    if type(files) == "table" then
        for _, entry in ipairs(files) do
            local entry_text = tostring(entry or "")
            if entry_text ~= "" and entry_text ~= "." and entry_text ~= ".." then
                local path = scan_path(current_path, entry_text)
                if has_extension(path, def.extension) then
                    add_file_item(result, base_path, path, def)
                end
            end
        end
    end

    local entries = Fs.scan(current_path)
    if type(entries) ~= "table" then return end

    for _, entry in ipairs(entries) do
        local entry_text = tostring(entry or "")
        if entry_text ~= "" and entry_text ~= "." and entry_text ~= ".." then
            local path = scan_path(current_path, entry_text)
            if not has_extension(path, def.extension) and Fs.exists(path) then
                scan_directory(result, base_path, path, def, visited)
            end
        end
    end
end

local function scan_definition(root, def)
    local result = {}
    local base_path = Fs.join(root, def.dir)
    if not Fs.exists(base_path) then return result end

    scan_directory(result, base_path, base_path, def, {})
    table_sort(result, function(a, b)
        if a.subfolder == b.subfolder then return natural_less(a.name, b.name) end
        return natural_less(a.subfolder, b.subfolder)
    end)
    for i = 1, #result do
        result[i].relative_path = relative_path(root, result[i].path)
    end
    return result
end

local function add_grouped(groups, item)
    local format = item.format
    groups.by_format[format] = groups.by_format[format] or {}
    groups.by_format[format][#groups.by_format[format] + 1] = item

    local folder_group = groups.folders[format]
    if not folder_group then
        folder_group = { by_folder = {}, folder_names = {} }
        groups.folders[format] = folder_group
    end

    local folder = item.subfolder or format
    if not folder_group.by_folder[folder] then
        folder_group.by_folder[folder] = {}
        folder_group.folder_names[#folder_group.folder_names + 1] = folder
    end
    folder_group.by_folder[folder][#folder_group.by_folder[folder] + 1] = item
end

local function split_folder_segments(folder)
    local segments = {}
    for segment in tostring(folder or ""):gmatch("[^\\/]+") do
        segments[#segments + 1] = segment
    end
    return segments
end

local function tree_child(node, name)
    local child = node.by_name[name]
    if child then return child end
    child = { name = name, by_name = {}, folders = {}, items = {}, total_count = 0 }
    node.by_name[name] = child
    node.folders[#node.folders + 1] = child
    return child
end

local function build_tree(items)
    local root = { name = "", by_name = {}, folders = {}, items = {}, total_count = 0 }
    for _, item in ipairs(items) do
        local node = root
        for _, segment in ipairs(split_folder_segments(item.subfolder)) do
            node = tree_child(node, segment)
        end
        node.items[#node.items + 1] = item
    end
    return root
end

local function finalize_tree(node)
    table_sort(node.folders, function(a, b) return natural_less(a.name, b.name) end)
    local count = #node.items
    for _, child in ipairs(node.folders) do
        count = count + finalize_tree(child)
    end
    node.total_count = count
    node.by_name = nil
    return count
end

function FileCatalog.new(opts)
    local root_fn = assert(opts and opts.root, "FileCatalog requires a root function")
    local formats = assert(opts and opts.formats, "FileCatalog requires a formats list")

    local cache = {
        loaded = false,
        version = 0,
        items = {},
        by_format = {},
        folders = {},
        snapshot = nil,
        root = nil,
    }

    local function cache_snapshot()
        if cache.snapshot then return cache.snapshot end
        cache.root = cache.root or root_fn()
        cache.snapshot = {
            loaded = cache.loaded,
            version = cache.version,
            items = cache.items,
            by_format = cache.by_format,
            folders = cache.folders,
            root = cache.root,
        }
        return cache.snapshot
    end

    local function rebuild()
        local root = root_fn()
        local items = {}
        local groups = { by_format = {}, folders = {} }

        for _, def in ipairs(formats) do
            local list = scan_definition(root, def)
            for _, item in ipairs(list) do
                items[#items + 1] = item
                add_grouped(groups, item)
            end
        end

        for _, group in pairs(groups.folders) do
            table_sort(group.folder_names, natural_less)
        end

        cache.items = items
        cache.by_format = groups.by_format
        cache.folders = groups.folders
        cache.loaded = true
        cache.version = cache.version + 1
        cache.root = root
        cache.snapshot = nil
        cache.trees = nil
        return cache_snapshot()
    end

    local function ensure_loaded()
        if cache.loaded then return cache_snapshot() end
        return rebuild()
    end

    local catalog = {}

    function catalog.refresh()
        return rebuild()
    end

    function catalog.ensure_loaded()
        return ensure_loaded()
    end

    function catalog.snapshot()
        return cache_snapshot()
    end

    function catalog.list(format)
        ensure_loaded()
        if not format then return cache.items end
        return cache.by_format[format] or EMPTY_LIST
    end

    function catalog.folders(format)
        ensure_loaded()
        return cache.folders[format] or EMPTY_FOLDERS
    end

    function catalog.tree(format)
        ensure_loaded()
        cache.trees = cache.trees or {}
        local existing = cache.trees[format]
        if existing then return existing end
        local items = format and (cache.by_format[format] or EMPTY_LIST) or cache.items
        local root = build_tree(items)
        finalize_tree(root)
        cache.trees[format] = root
        return root
    end

    function catalog.relative_path(path)
        return relative_path(root_fn(), path)
    end

    return catalog
end

return FileCatalog
