local utf8_utils = {}

local utf8_len = utf8.len
local utf8_offset = utf8.offset
local string_len <const> = string.len
local string_sub <const> = string.sub
local tostring <const> = tostring
local string_byte <const> = string.byte

function utf8_utils.len(str)
    str = tostring(str or "")
    return utf8_len(str) or string_len(str)
end

function utf8_utils.sub(str, first, last)
    str = tostring(str or "")
    first = first or 1
    last = last or utf8_utils.len(str)
    if first < 1 then first = 1 end
    if last < first then return "" end
    local start_byte = utf8_offset(str, first)
    if not start_byte then return "" end
    local end_byte = utf8_offset(str, last + 1)
    if end_byte then
        return string_sub(str, start_byte, end_byte - 1)
    end
    return string_sub(str, start_byte)
end

function utf8_utils.insert(str, pos, text)
    str = tostring(str or "")
    text = tostring(text or "")
    pos = pos or utf8_utils.len(str) + 1
    return utf8_utils.sub(str, 1, pos - 1) .. text .. utf8_utils.sub(str, pos)
end

function utf8_utils.remove(str, pos)
    str = tostring(str or "")
    return utf8_utils.sub(str, 1, pos - 1) .. utf8_utils.sub(str, pos + 1)
end

function utf8_utils.char_count(str)
    return utf8_utils.len(str)
end

function utf8_utils.clamp_cursor_pos(str, pos)
    str = tostring(str or "")
    local len = string_len(str)
    pos = tonumber(pos) or 0
    if pos <= 0 then return 0 end
    if pos >= len then return len end

    local byte = string_byte(str, pos + 1)
    if not byte or byte < 0x80 or byte > 0xBF then return pos end

    while pos > 0 do
        pos = pos - 1
        byte = string_byte(str, pos + 1)
        if not byte or byte < 0x80 or byte > 0xBF then return pos end
    end
    return pos
end

function utf8_utils.prev_char_pos(str, pos)
    str = tostring(str or "")
    pos = utf8_utils.clamp_cursor_pos(str, pos)
    if pos <= 0 then return 0 end

    local prev = pos - 1
    while prev > 0 do
        local byte = string_byte(str, prev + 1)
        if not byte or byte < 0x80 or byte > 0xBF then return prev end
        prev = prev - 1
    end
    return 0
end

function utf8_utils.next_char_pos(str, pos)
    str = tostring(str or "")
    local len = string_len(str)
    pos = utf8_utils.clamp_cursor_pos(str, pos)
    if pos >= len then return len end

    local next_byte = utf8_offset(str, 2, pos + 1)
    if not next_byte then return len end
    return next_byte - 1
end

return utf8_utils
