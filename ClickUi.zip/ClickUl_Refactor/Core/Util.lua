local Util = {}

function Util.clone_list(list)
    if type(list) ~= "table" then return nil end
    local result = {}
    for index = 1, #list do
        result[index] = list[index]
    end
    return result
end

function Util.copy_table(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do
        result[key] = Util.copy_table(item)
    end
    return result
end

function Util.trim(value)
    if value == nil then return nil end
    return (tostring(value):match("^%s*(.-)%s*$"))
end

function Util.dist2d(ax, ay, bx, by)
    local dx = ax - bx
    local dy = ay - by
    return math.sqrt(dx * dx + dy * dy)
end

local math_huge <const> = math.huge

function Util.is_finite(value)
    return type(value) == "number" and value == value and value ~= math_huge and value ~= -math_huge
end

function Util.valid_coord(coord)
    return coord ~= nil
        and Util.is_finite(coord.x)
        and Util.is_finite(coord.y)
        and Util.is_finite(coord.z)
end

function Util.is_screen_safe(value)
    if not Util.is_finite(value) then return false end
    return value >= -10000 and value <= 10000
end

function Util.to_number(value, default)
    if value == nil then return default end
    if type(value) == "number" then return value end

    local direct = tonumber(value)
    if direct ~= nil then return direct end

    local text = Util.trim(value)
    if text == nil or text == "" then return default end
    text = text:gsub("_", ""):gsub(",", ".")
    local hex = text:match("^0[xX]([%da-fA-F]+)$")
    if hex then return tonumber(hex, 16) or default end
    local num = tonumber(text)
    if num == nil then
        num = tonumber((text:gsub("%a+$", "")))
    end
    if num == nil then return default end
    return num
end

function Util.to_float(value, default)
    local n = Util.to_number(value, default)
    if n == nil then return nil end
    return n + 0.0
end

function Util.to_boolean(value)
    if value == nil then return false end
    if type(value) == "boolean" then return value end
    if type(value) == "number" then return value ~= 0 end
    if value == "true" or value == "1" or value == "yes" or value == "on" then return true end
    if value == "false" or value == "0" or value == "no" or value == "off" then return false end

    local text = Util.trim(value)
    if not text then return false end
    text = string.lower(text)
    return text == "true" or text == "1" or text == "yes" or text == "on"
end

function Util.merge_into(target, source)
    if type(source) ~= "table" then return target end
    for key, item in pairs(source) do
        if type(item) == "table" and type(target[key]) == "table" then
            Util.merge_into(target[key], item)
        else
            target[key] = Util.copy_table(item)
        end
    end
    return target
end

function Util.first_present(values, ...)
    if type(values) ~= "table" then return nil end
    for index = 1, select("#", ...) do
        local value = values[select(index, ...)]
        if value ~= nil then return value end
    end
    return nil
end

function Util.vector3(value, defaults)
    defaults = defaults or {}
    value = value or {}
    return {
        x = Util.to_float(value.x or value.X or value[1], defaults.x or 0.0),
        y = Util.to_float(value.y or value.Y or value[2], defaults.y or 0.0),
        z = Util.to_float(value.z or value.Z or value[3], defaults.z or 0.0),
    }
end

function Util.required_vector3(value)
    local value_type = type(value)
    if value_type ~= "table" and value_type ~= "userdata" then return nil end
    local px, py, pz
    if value_type == "table" then px, py, pz = value[1], value[2], value[3] end
    local x = Util.to_float(value.x or value.X or px, nil)
    local y = Util.to_float(value.y or value.Y or py, nil)
    local z = Util.to_float(value.z or value.Z or pz, nil)
    if x == nil or y == nil or z == nil then return nil end
    return { x = x, y = y, z = z }
end

function Util.rotation(value)
    value = value or {}
    return {
        x = Util.to_float(value.x or value.X or value.pitch or value.Pitch or value[1], 0.0),
        y = Util.to_float(value.y or value.Y or value.roll or value.Roll or value[2], 0.0),
        z = Util.to_float(value.z or value.Z or value.yaw or value.Yaw or value[3], 0.0),
    }
end

return Util
