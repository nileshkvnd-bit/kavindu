local HudDraw = {}
local Gui = require("ClickUl_Refactor.Adapters.Gui")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Util = require("ClickUl_Refactor.Core.Util")

local WHITE <const> = { r = 255, g = 255, b = 255, a = 255 }

local math_floor <const> = math.floor

local function channel(color_value, key, default)
    if type(color_value) ~= "table" then return default end
    local value = color_value[key]
    if value == nil then return default end
    return math_floor(value)
end

local function rgba(color_value, default)
    default = default or WHITE
    return
        channel(color_value, "r", default.r),
        channel(color_value, "g", default.g),
        channel(color_value, "b", default.b),
        channel(color_value, "a", default.a)
end

function HudDraw.draw_rect(x, y, width, height, color_value)
    return HudDraw.draw_native_rect_screen(x, y, width, height, color_value)
end


function HudDraw.draw_sprite_screen(texture_dict, texture_name, x, y, width, height, heading, color_value)
    local resolution = Runtime.resolution()
    local r, g, b, a = rgba(color_value)
    return Native.call(
        "draw_sprite",
        texture_dict,
        texture_name,
        x / resolution.x,
        y / resolution.y,
        width / resolution.x,
        height / resolution.y,
        heading or 0.0,
        r,
        g,
        b,
        a,
        0
    )
end

function HudDraw.draw_native_rect_screen(x, y, width, height, color_value)
    local resolution = Runtime.resolution()
    local r, g, b, a = rgba(color_value)
    return Native.call(
        "draw_rect",
        (x + width * 0.5) / resolution.x,
        (y + height * 0.5) / resolution.y,
        width / resolution.x,
        height / resolution.y,
        r,
        g,
        b,
        a,
        0
    )
end

function HudDraw.draw_marker_sphere(position, radius, color_value)
    position = Util.required_vector3(position)
    if not position then return nil end
    local r, g, b, a = rgba(color_value, { r = 255, g = 220, b = 40, a = 180 })
    return Native.draw_marker_sphere(position, radius or 1.0, r, g, b, a / 255.0)
end

function HudDraw.draw_scaleform_fullscreen(handle, color_value)
    if not handle or handle == 0 then return end
    local r, g, b, a = rgba(color_value)
    return Native.call("draw_scaleform_movie_fullscreen", handle, r, g, b, a, 0)
end


local function overlay_color(color_value, default)
    local r, g, b, a = rgba(color_value, default)
    return Gui.color(r, g, b, a)
end


function HudDraw.overlay_rect(x, y, width, height, color_value)
    Gui.rect(Gui.vec2_raw(x, y), Gui.vec2_raw(width, height)):color(overlay_color(color_value)):filled():draw()
end

function HudDraw.overlay_dot(center_x, center_y, size, color_value)
    size = size or 4
    HudDraw.overlay_rect(center_x - size * 0.5, center_y - size * 0.5, size, size, color_value)
end

function HudDraw.overlay_line(x1, y1, x2, y2, thickness, color_value)
    Gui.line(Gui.vec2_raw(x1, y1), Gui.vec2_raw(x2, y2), thickness or 1, overlay_color(color_value))
end

local WEIGHT_OFFSETS <const> = { { 1, 0 }, { 0, 1 } }

local function draw_text_pass(text, x, y, scale, color, align)
    local obj = Gui.text(text)
    obj:position(Gui.vec2_raw(x, y))
    obj:scale(scale)
    obj:color(color)
    if align == true or align == "center" then
        obj:justify(Gui.justify.center)
    elseif align == "right" then
        obj:justify(Gui.justify.right)
    end
    obj:draw()
end

function HudDraw.overlay_text(text, x, y, scale, color_value, align, weight)
    text = tostring(text or "")
    scale = scale or 16
    local color = overlay_color(color_value)
    draw_text_pass(text, x, y, scale, color, align)
    local extra = math.min((tonumber(weight) or 1) - 1, #WEIGHT_OFFSETS)
    for i = 1, extra do
        local off = WEIGHT_OFFSETS[i]
        draw_text_pass(text, x + off[1], y + off[2], scale, color, align)
    end
end

return HudDraw
