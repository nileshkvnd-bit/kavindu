local Teleport = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Redirects = require("ClickUl_Refactor.Core.TeleportRedirects")
local Util = require("ClickUl_Refactor.Core.Util")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")
local logger = require("ClickUl_Refactor.Core.Logger")

local dist2d = Util.dist2d

local WAYPOINT_SPRITE <const> = 8
local GROUND_POLL_FRAMES <const> = 80
local VEHICLE_GROUND_RADIUS <const> = 5.0
local HIGH_ALTITUDE_Z <const> = 2500.0
local GROUND_PROBE_Z <const> = 1000.0
local BLIP_COORD_LIFT <const> = 0.5
local FALLBACK_HALF_HEIGHT <const> = 0.5
local UNDO_STACK_LIMIT <const> = 20
local AUTO_WAYPOINT_THROTTLE_MS <const> = 1000
local AUTO_WAYPOINT_MIN_MOVE <const> = 1.0

local OBJECTIVE_SPRITES <const> = {
    { 535, -1 }, { 536, -1 }, { 537, -1 }, { 538, -1 }, { 539, -1 },
    { 540, -1 }, { 541, -1 }, { 542, -1 },
    { 1, -1 },
    { 432, -1 },
    { 568, -1 },
    { 64, 57 },
    { 501, 57 },
    { 556, 57 },
    { 225, 57 },
    { 280, 57 },
    { 631, 57 },
    { 760, 60 },
    { 765, 2 },
    { 459, 2 },
}

local undo_stack = {}
local last_tp = nil
local auto_waypoint = { enabled = false, thread = nil, busy = false, last_tick = 0, last_x = nil, last_y = nil }

local function is_valid_handle(handle)
    return handle ~= nil and handle ~= 0
end

local normalize_coords = Util.required_vector3

local function teleport_target()
    return Players.local_teleport_target(), Players.local_teleport_target_is_vehicle()
end

local function current_coords()
    return Players.local_coords()
end

local function push_undo()
    local coords = current_coords()
    if not coords then return end
    coords.heading = Players.local_heading()
    undo_stack[#undo_stack + 1] = coords
    if #undo_stack > UNDO_STACK_LIMIT then table.remove(undo_stack, 1) end
end

local function set_last_tp(x, y, z, heading)
    last_tp = { x = x, y = y, z = z, heading = heading }
end

local function half_model_height(target)
    local model = Native.call("get_entity_model", target)
    local dims = model and ModelDims.get(model) or nil
    if not dims then return FALLBACK_HALF_HEIGHT end
    return (dims.max.z - dims.min.z) * 0.5
end

local function place_exact(target, x, y, z, clear_area)
    if clear_area then
        Native.call("set_entity_coords", target, x + 0.0, y + 0.0, z + 0.0, false, false, false, true)
        return
    end
    Native.call("set_entity_coords_no_offset", target, x + 0.0, y + 0.0, z + 0.0, false, false, false)
end

local function apply_orientation(target, heading)
    local yaw = heading
    if yaw == nil then
        local rot = Native.get_entity_rotation(target, 2)
        yaw = rot and rot.z or 0.0
    end
    Native.call("set_entity_rotation", target, 0.0, 0.0, yaw + 0.0, 2, true)
end

local function place_on_ground(target, is_vehicle, x, y, heading, record, on_done)
    Runtime.create_job(function()
        local approx = Native.call("get_approx_height_for_point", x + 0.0, y + 0.0) or 0.0
        local ground = nil
        for _ = 1, GROUND_POLL_FRAMES do
            Native.call("request_collision_at_coord", x + 0.0, y + 0.0, approx + 0.0)
            local found, ground_z = Native.ground_z_shapetest(x, y, GROUND_PROBE_Z, target)
            if found and ground_z then
                ground = ground_z
                break
            end
            Runtime.yield(0)
        end

        local surface = ground or approx

        local water_found, water_z = Native.water_height(x, y, surface)
        if water_found and water_z and water_z > surface then surface = water_z end

        local placed_z = surface + half_model_height(target)
        place_exact(target, x, y, placed_z)
        apply_orientation(target, heading)
        if ground and is_vehicle then Native.call("set_vehicle_on_ground_properly", target, VEHICLE_GROUND_RADIUS) end
        if record then set_last_tp(x, y, placed_z, heading) end
        if not ground then logger.warn("Core.Teleport", "ground not found, placed at approx height", { x = x, y = y }) end
        if on_done then on_done(ground ~= nil) end
    end)
end

function Teleport.to_coords(coords, opts)
    local target_coords = normalize_coords(coords)
    if not target_coords then return false, "invalid_coords" end
    opts = opts or {}

    local target, is_vehicle = teleport_target()
    if not is_valid_handle(target) then return false, "no_target" end

    local record = opts.record_undo ~= false
    if record then push_undo() end

    if opts.redirect then
        local redirected = Redirects.resolve(target_coords.x, target_coords.y, is_vehicle, opts.resolve_ground and true or false)
        if redirected then
            place_exact(target, redirected.x, redirected.y, redirected.z, opts.clear_area)
            apply_orientation(target, opts.heading)
            if record then set_last_tp(redirected.x, redirected.y, redirected.z, opts.heading) end
            if opts.on_done then opts.on_done(true) end
            return true
        end
    end

    if opts.resolve_ground then
        place_on_ground(target, is_vehicle, target_coords.x, target_coords.y, opts.heading, record, opts.on_done)
        return true
    end

    place_exact(target, target_coords.x, target_coords.y, target_coords.z, opts.clear_area)
    apply_orientation(target, opts.heading)
    if record then set_last_tp(target_coords.x, target_coords.y, target_coords.z, opts.heading) end
    if opts.on_done then opts.on_done(true) end
    return true
end

function Teleport.waypoint_position()
    if not Native.call("is_waypoint_active") then return nil end
    local blip = Native.get_first_blip_info_id(WAYPOINT_SPRITE)
    if not is_valid_handle(blip) then return nil end
    local coords = Native.get_blip_coords(blip)
    if not coords then return nil end
    return { x = coords.x, y = coords.y, guessed = true }
end

function Teleport.to_waypoint()
    local position = Teleport.waypoint_position()
    if not position then return false, "no_waypoint" end
    return Teleport.to_coords({ x = position.x, y = position.y, z = 0.0 }, { resolve_ground = true })
end

function Teleport.to_entity(entity)
    if not is_valid_handle(entity) then return false, "no_entity" end
    local coords = Native.get_entity_coords(entity, true)
    if not coords then return false, "no_entity_coords" end
    return Teleport.to_coords(coords)
end

local function first_free_seat(vehicle)
    if Native.call("is_vehicle_seat_free", vehicle, -1, 0) then return -1 end
    local max_passengers = Native.call("get_vehicle_max_number_of_passengers", vehicle) or 0
    for seat = 0, max_passengers - 1 do
        if Native.call("is_vehicle_seat_free", vehicle, seat, 0) then return seat end
    end
    return nil
end

local function vehicle_has_player(vehicle)
    local max_passengers = Native.call("get_vehicle_max_number_of_passengers", vehicle) or 0
    for seat = -1, max_passengers - 1 do
        local ped = Native.call("get_ped_in_vehicle_seat", vehicle, seat, 0)
        if is_valid_handle(ped) and Native.call("is_ped_a_player", ped) then return true end
    end
    return false
end

function Teleport.to_veh(vehicle)
    if not is_valid_handle(vehicle) then return false, "no_vehicle" end
    local seat = first_free_seat(vehicle)
    if not seat then return Teleport.to_entity(vehicle) end
    local ped = Players.local_ped()
    if not is_valid_handle(ped) then return false, "no_ped" end
    push_undo()
    Native.call("set_ped_into_vehicle", ped, vehicle, seat)
    Native.call("set_vehicle_engine_on", vehicle, true, true, false)
    return true
end

function Teleport.to_blip(blip)
    if not is_valid_handle(blip) then return false, "no_blip" end
    local entity = Native.get_blip_info_id_entity_index(blip)
    if is_valid_handle(entity) then
        if Native.call("is_entity_a_vehicle", entity) and not vehicle_has_player(entity) then
            return Teleport.to_veh(entity)
        end
        return Teleport.to_entity(entity)
    end
    local coords = Native.get_blip_coords(blip)
    if not coords then return false, "no_blip_coords" end
    return Teleport.to_coords({ x = coords.x, y = coords.y, z = coords.z + BLIP_COORD_LIFT })
end

function Teleport.to_nearest(points, opts)
    if type(points) ~= "table" or #points == 0 then return false, "no_points" end
    local here = current_coords()
    if not here then return false, "no_coords" end
    opts = opts or {}

    local best, best_dist
    for _, point in ipairs(points) do
        local dist = dist2d(here.x, here.y, point.x, point.y)
        if not best_dist or dist < best_dist then
            best_dist = dist
            best = point
        end
    end
    if not best then return false, "no_points" end

    return Teleport.to_coords(
        { x = best.x, y = best.y, z = best.z or 0.0 },
        { redirect = true, resolve_ground = opts.guessed, on_done = opts.on_done }
    )
end

function Teleport.to_objective()
    local coord_blips, entity_blips = {}, {}
    for _, sprite in ipairs(OBJECTIVE_SPRITES) do
        local sprite_id, want_colour = sprite[1], sprite[2]
        local blip = Native.get_first_blip_info_id(sprite_id)
        while is_valid_handle(blip) do
            if want_colour == -1 or Native.get_blip_colour(blip) == want_colour then
                local entity = Native.get_blip_info_id_entity_index(blip)
                if is_valid_handle(entity) then
                    if not (Native.call("is_entity_a_ped", entity) and Native.call("is_ped_a_player", entity)) then
                        entity_blips[#entity_blips + 1] = blip
                    end
                else
                    coord_blips[#coord_blips + 1] = blip
                end
            end
            blip = Native.get_next_blip_info_id(sprite_id)
        end
    end

    local candidates = (#coord_blips > 0) and coord_blips or entity_blips
    if #candidates == 0 then return false, "no_objective" end

    local here = current_coords()
    local nearest, nearest_dist = candidates[1], nil
    if here then
        for _, blip in ipairs(candidates) do
            local coords = Native.get_blip_coords(blip)
            if coords then
                local dist = dist2d(here.x, here.y, coords.x, coords.y)
                if not nearest_dist or dist < nearest_dist then
                    nearest_dist = dist
                    nearest = blip
                end
            end
        end
    end

    return Teleport.to_blip(nearest)
end

local function enable_interior(x, y, z, entity_sets)
    local id = Native.call("get_interior_at_coords", x + 0.0, y + 0.0, z + 0.0)
    if not id or id == 0 then return end
    Native.call("pin_interior_in_memory", id)
    Native.call("cap_interior", id, false)
    if Native.call("is_interior_disabled", id) then
        Native.call("disable_interior", id, false)
    end
    if entity_sets then
        for _, set in ipairs(entity_sets) do
            local native = set.on and "activate_interior_entity_set" or "deactivate_interior_entity_set"
            Native.call(native, id, set.name)
        end
    end
    Native.call("refresh_interior", id)
end

function Teleport.to_interior(coords, opts)
    local target = normalize_coords(coords)
    if not target then return false, "invalid_coords" end
    opts = opts or {}
    enable_interior(target.x, target.y, target.z, opts.entity_sets)
    return Teleport.to_coords(target, opts)
end

function Teleport.to_high()
    local coords = current_coords()
    if not coords then return false, "no_coords" end
    return Teleport.to_coords({ x = coords.x, y = coords.y, z = HIGH_ALTITUDE_Z })
end

function Teleport.undo()
    local entry = undo_stack[#undo_stack]
    if not entry then return false, "empty" end
    undo_stack[#undo_stack] = nil
    return Teleport.to_coords(entry, { record_undo = false, heading = entry.heading })
end

function Teleport.repeat_last()
    if not last_tp then return false, "empty" end
    return Teleport.to_coords(last_tp, { heading = last_tp.heading })
end

function Teleport.current_position()
    local coords = current_coords()
    if not coords then return nil end
    coords.heading = Players.local_heading()
    return coords
end

function Teleport.has_waypoint()
    return Native.call("is_waypoint_active") and true or false
end

function Teleport.can_undo()
    return #undo_stack > 0
end

function Teleport.can_repeat()
    return last_tp ~= nil
end

function Teleport.clear_undo()
    for index = #undo_stack, 1, -1 do undo_stack[index] = nil end
end

function Teleport.clear_last_tp()
    last_tp = nil
end

local function auto_waypoint_tick()
    if not auto_waypoint.enabled then return false end
    if auto_waypoint.busy then return true end
    if not Native.call("is_waypoint_active") then return true end

    local blip = Native.get_first_blip_info_id(WAYPOINT_SPRITE)
    if not is_valid_handle(blip) then return true end
    local coords = Native.get_blip_coords(blip)
    if not coords then return true end

    if auto_waypoint.last_x and dist2d(coords.x, coords.y, auto_waypoint.last_x, auto_waypoint.last_y) < AUTO_WAYPOINT_MIN_MOVE then
        return true
    end

    local now = Runtime.get_tick_count()
    if now - auto_waypoint.last_tick < AUTO_WAYPOINT_THROTTLE_MS then return true end

    auto_waypoint.last_tick = now
    auto_waypoint.last_x, auto_waypoint.last_y = coords.x, coords.y
    auto_waypoint.busy = true
    Teleport.to_coords(coords, {
        resolve_ground = true,
        redirect = true,
        on_done = function() auto_waypoint.busy = false end,
    })
    return true
end

function Teleport.set_auto_waypoint(enabled)
    enabled = enabled and true or false
    if enabled == auto_waypoint.enabled then return end
    auto_waypoint.enabled = enabled
    if enabled then
        auto_waypoint.last_x, auto_waypoint.last_y = nil, nil
        auto_waypoint.busy = false
        auto_waypoint.thread = Runtime.create_thread(auto_waypoint_tick)
        return
    end
    if auto_waypoint.thread then
        Runtime.remove_thread(auto_waypoint.thread)
        auto_waypoint.thread = nil
    end
end

function Teleport.is_auto_waypoint()
    return auto_waypoint.enabled
end

return Teleport
