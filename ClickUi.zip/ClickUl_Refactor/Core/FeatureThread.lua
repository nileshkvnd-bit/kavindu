local FeatureThread = {}

local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

function FeatureThread.new(tick)
    local thread = {}
    local id = nil

    function thread.start()
        if id then return false end
        id = Runtime.create_thread(tick)
        return true
    end

    function thread.stop()
        if not id then return false end
        local current = id
        id = nil
        Runtime.remove_thread(current)
        return true
    end

    function thread.running()
        return id ~= nil
    end

    return thread
end

return FeatureThread
