local EntityBones = {}
local Native = require("ClickUl_Refactor.Adapters.Native")

local SKEL_HEAD <const> = 31086

local function read_ped_bone_world(ped, bone_id)
    if not ped or ped == 0 or not bone_id then return nil end
    return Native.get_ped_bone_coords(ped, bone_id, 0.0, 0.0, 0.0)
end

function EntityBones.ped_head_world(ped)
    return read_ped_bone_world(ped, SKEL_HEAD)
end

function EntityBones.ped_bone_world(ped, bone_id)
    return read_ped_bone_world(ped, bone_id)
end

return EntityBones
