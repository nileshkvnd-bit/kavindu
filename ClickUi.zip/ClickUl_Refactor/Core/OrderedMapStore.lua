local fs = require("ClickUl_Refactor.Adapters.Fs")
local json_adapter = require("ClickUl_Refactor.Adapters.Json")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")

local OrderedMapStore = {}
OrderedMapStore.__index = OrderedMapStore

function OrderedMapStore.new(opts)
    assert(type(opts) == "table", "[OrderedMapStore] opts table is required")
    assert(type(opts.filename) == "string" and opts.filename ~= "", "[OrderedMapStore] filename is required")
    assert(type(opts.queue_key) == "string" and opts.queue_key ~= "", "[OrderedMapStore] queue_key is required")
    assert(type(opts.normalize) == "function", "[OrderedMapStore] normalize callback is required")
    assert(type(opts.serialize) == "function", "[OrderedMapStore] serialize callback is required")

    return setmetatable({
        filename = opts.filename,
        version_tag = opts.version or 1,
        queue_key = opts.queue_key,
        normalize = opts.normalize,
        serialize = opts.serialize,
        logger = opts.logger,
        log_name = opts.log_name or "Core.OrderedMapStore",
        items = {},
        lookup = {},
        version_counter = 0,
        dirty = false,
        loaded = false,
    }, OrderedMapStore)
end

function OrderedMapStore:config_path()
    return fs.join(fs.config_dir(), self.filename)
end

function OrderedMapStore:rebuild_lookup()
    self.lookup = {}
    for index = 1, #self.items do
        local id = self.items[index].id
        if type(id) == "string" and id ~= "" then self.lookup[id] = index end
    end
end

function OrderedMapStore:mark_dirty()
    self.dirty = true
    self.version_counter = self.version_counter + 1
    io_queue.queue_save(function() return self:save_immediate() end, self.queue_key)
end

function OrderedMapStore:load()
    fs.ensure_dir(fs.config_dir())
    local decoded = fs.read_json_value(self:config_path())

    local collected = {}
    local missing_order = {}
    if type(decoded) == "table" and type(decoded.items) == "table" then
        for id, raw in pairs(decoded.items) do
            if type(id) == "string" and id ~= "" and type(raw) == "table" then
                local entry = self.normalize(id, raw)
                if entry then
                    local order = type(raw.order) == "number" and raw.order or nil
                    if order then
                        collected[#collected + 1] = { entry = entry, order = order, id = id }
                    else
                        missing_order[#missing_order + 1] = { entry = entry, id = id }
                    end
                end
            end
        end
    end
    table.sort(collected, function(a, b)
        if a.order ~= b.order then return a.order < b.order end
        return a.id < b.id
    end)
    table.sort(missing_order, function(a, b) return a.id < b.id end)

    self.items = {}
    for index = 1, #collected do self.items[index] = collected[index].entry end
    for index = 1, #missing_order do self.items[#self.items + 1] = missing_order[index].entry end
    self:rebuild_lookup()
    self.loaded = true
    self.dirty = false
    self.version_counter = self.version_counter + 1
    return true
end

function OrderedMapStore:save_immediate()
    if not self.loaded then return false end
    fs.ensure_dir(fs.config_dir())

    local payload = { version = self.version_tag }
    if #self.items > 0 then
        local map = {}
        for index = 1, #self.items do
            local entry = self.items[index]
            local fields = self.serialize(entry) or {}
            fields.order = index
            map[entry.id] = fields
        end
        payload.items = map
    end

    local saved = fs.write_text(self:config_path(), json_adapter.encode_document(payload, 2))
    if saved then
        self.dirty = false
    elseif self.logger and self.logger.warn then
        self.logger.warn(self.log_name, "failed to save " .. self.filename)
    end
    return saved
end

function OrderedMapStore:has(id)
    return self.lookup[id] ~= nil
end

function OrderedMapStore:find(id)
    local index = self.lookup[id]
    if not index then return nil end
    return self.items[index]
end

function OrderedMapStore:insert(entry)
    if type(entry) ~= "table" or type(entry.id) ~= "string" or entry.id == "" then return false end
    if self.lookup[entry.id] then return false end
    self.items[#self.items + 1] = entry
    self.lookup[entry.id] = #self.items
    self:mark_dirty()
    return true
end

function OrderedMapStore:remove(id)
    local index = self.lookup[id]
    if not index then return false end
    table.remove(self.items, index)
    self:rebuild_lookup()
    self:mark_dirty()
    return true
end

function OrderedMapStore:clear()
    if #self.items == 0 then return false end
    self.items = {}
    self.lookup = {}
    self:mark_dirty()
    return true
end

function OrderedMapStore:count()
    return #self.items
end

function OrderedMapStore:version()
    return self.version_counter
end

function OrderedMapStore:is_dirty()
    return self.dirty
end

function OrderedMapStore:entries()
    return self.items
end

return OrderedMapStore
