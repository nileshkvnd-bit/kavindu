local KeyCodes = {}

local tostring <const> = tostring
local table_concat <const> = table.concat
local table_insert <const> = table.insert

local VK_NAMES = {
    [0x01] = "LMB",
    [0x02] = "RMB",
    [0x04] = "MMB",
    [0x05] = "X1",
    [0x06] = "X2",

    [0x08] = "Backspace",
    [0x09] = "Tab",
    [0x0D] = "Enter",
    [0x10] = "Shift",
    [0x11] = "Ctrl",
    [0x12] = "Alt",
    [0x13] = "Pause",
    [0x14] = "CapsLock",
    [0x1B] = "Esc",
    [0x20] = "Space",
    [0x21] = "PageUp",
    [0x22] = "PageDown",
    [0x23] = "End",
    [0x24] = "Home",
    [0x25] = "Left",
    [0x26] = "Up",
    [0x27] = "Right",
    [0x28] = "Down",
    [0x2C] = "PrintScreen",
    [0x2D] = "Insert",
    [0x2E] = "Delete",

    [0x30] = "0", [0x31] = "1", [0x32] = "2", [0x33] = "3", [0x34] = "4",
    [0x35] = "5", [0x36] = "6", [0x37] = "7", [0x38] = "8", [0x39] = "9",

    [0x41] = "A", [0x42] = "B", [0x43] = "C", [0x44] = "D", [0x45] = "E",
    [0x46] = "F", [0x47] = "G", [0x48] = "H", [0x49] = "I", [0x4A] = "J",
    [0x4B] = "K", [0x4C] = "L", [0x4D] = "M", [0x4E] = "N", [0x4F] = "O",
    [0x50] = "P", [0x51] = "Q", [0x52] = "R", [0x53] = "S", [0x54] = "T",
    [0x55] = "U", [0x56] = "V", [0x57] = "W", [0x58] = "X", [0x59] = "Y",
    [0x5A] = "Z",

    [0x60] = "Num0", [0x61] = "Num1", [0x62] = "Num2", [0x63] = "Num3",
    [0x64] = "Num4", [0x65] = "Num5", [0x66] = "Num6", [0x67] = "Num7",
    [0x68] = "Num8", [0x69] = "Num9",
    [0x6A] = "Num*", [0x6B] = "Num+", [0x6C] = "NumEnter",
    [0x6D] = "Num-", [0x6E] = "Num.", [0x6F] = "Num/",

    [0x70] = "F1",  [0x71] = "F2",  [0x72] = "F3",  [0x73] = "F4",
    [0x74] = "F5",  [0x75] = "F6",  [0x76] = "F7",  [0x77] = "F8",
    [0x78] = "F9",  [0x79] = "F10", [0x7A] = "F11", [0x7B] = "F12",
    [0x7C] = "F13", [0x7D] = "F14", [0x7E] = "F15", [0x7F] = "F16",
    [0x80] = "F17", [0x81] = "F18", [0x82] = "F19", [0x83] = "F20",
    [0x84] = "F21", [0x85] = "F22", [0x86] = "F23", [0x87] = "F24",

    [0x90] = "NumLock",
    [0x91] = "ScrollLock",

    [0xA0] = "LShift", [0xA1] = "RShift",
    [0xA2] = "LCtrl",  [0xA3] = "RCtrl",
    [0xA4] = "LAlt",   [0xA5] = "RAlt",

    [0xA6] = "BrowserBack",
    [0xA7] = "BrowserForward",
    [0xA8] = "BrowserRefresh",
    [0xA9] = "BrowserStop",
    [0xAA] = "BrowserSearch",
    [0xAB] = "BrowserFavorites",
    [0xAC] = "BrowserHome",

    [0xAD] = "VolMute",
    [0xAE] = "VolDown",
    [0xAF] = "VolUp",
    [0xB0] = "MediaNext",
    [0xB1] = "MediaPrev",
    [0xB2] = "MediaStop",
    [0xB3] = "MediaPlay",

    [0xBA] = ";",
    [0xBB] = "=",
    [0xBC] = ",",
    [0xBD] = "-",
    [0xBE] = ".",
    [0xBF] = "/",
    [0xC0] = "`",
    [0xDB] = "[",
    [0xDC] = "\\",
    [0xDD] = "]",
    [0xDE] = "'",
}

local VK_LIST = {}
local KEY_LOOKUP = {}

local function register_key(code, char, shift)
    local data = { code = code, char = char, shift = shift }
    table_insert(VK_LIST, data)
    KEY_LOOKUP[code] = data
end

for i = 0x41, 0x5A do
    local char = string.char(i)
    register_key(i, char:lower(), char:upper())
end

local number_shift_map = {
    [0x30] = ')', [0x31] = '!', [0x32] = '@', [0x33] = '#', [0x34] = '$',
    [0x35] = '%', [0x36] = '^', [0x37] = '&', [0x38] = '*', [0x39] = '('
}
for i = 0x30, 0x39 do
    local num_char = string.char(i)
    register_key(i, num_char, number_shift_map[i])
end

local punctuation_map = {
    { code = 0x20, char = ' ', shift = ' ' },
    { code = 0xBA, char = ';', shift = ':' },
    { code = 0xBB, char = '=', shift = '+' },
    { code = 0xBC, char = ',', shift = '<' },
    { code = 0xBD, char = '-', shift = '_' },
    { code = 0xBE, char = '.', shift = '>' },
    { code = 0xBF, char = '/', shift = '?' },
    { code = 0xC0, char = '`', shift = '~' },
    { code = 0xDB, char = '[', shift = '{' },
    { code = 0xDC, char = '\\', shift = '|' },
    { code = 0xDD, char = ']', shift = '}' },
    { code = 0xDE, char = "'", shift = '"' },
}
for _, entry in ipairs(punctuation_map) do
    register_key(entry.code, entry.char, entry.shift)
end

for i = 0x60, 0x69 do
    local num_char = string.char(i - 0x60 + 0x30)
    register_key(i, num_char, num_char)
end

local numpad_operators = {
    { code = 0x6A, char = '*', shift = '*' },
    { code = 0x6B, char = '+', shift = '+' },
    { code = 0x6D, char = '-', shift = '-' },
    { code = 0x6E, char = '.', shift = '.' },
    { code = 0x6F, char = '/', shift = '/' },
}
for _, entry in ipairs(numpad_operators) do
    register_key(entry.code, entry.char, entry.shift)
end

function KeyCodes.get_key_name(vk_code)
    if not vk_code or vk_code == 0 then return "None" end
    return VK_NAMES[vk_code] or ("VK_" .. tostring(vk_code))
end

function KeyCodes.get_vk_names()
    return VK_NAMES
end

function KeyCodes.get_vk_list()
    return VK_LIST
end

function KeyCodes.get_key_lookup()
    return KEY_LOOKUP
end

function KeyCodes.is_modifier_key(vk_code)
    return vk_code == 0x10 or vk_code == 0x11 or vk_code == 0x12
        or vk_code == 0xA0 or vk_code == 0xA1
        or vk_code == 0xA2 or vk_code == 0xA3
        or vk_code == 0xA4 or vk_code == 0xA5
end

function KeyCodes.format_keybind(vk_code, ctrl, shift, alt)
    if not vk_code or vk_code == 0 then return "None" end

    local parts = {}
    if ctrl then parts[#parts + 1] = "Ctrl" end
    if shift then parts[#parts + 1] = "Shift" end
    if alt then parts[#parts + 1] = "Alt" end
    parts[#parts + 1] = KeyCodes.get_key_name(vk_code)

    return table_concat(parts, "+")
end

function KeyCodes.binding_key(binding)
    if type(binding) ~= "table" or not binding.vk or binding.vk == 0 then return nil end
    return tostring(binding.ctrl and 1 or 0)
        .. ":"
        .. tostring(binding.shift and 1 or 0)
        .. ":"
        .. tostring(binding.alt and 1 or 0)
        .. ":"
        .. tostring(binding.vk)
end

function KeyCodes.format_binding(binding)
    if type(binding) ~= "table" then return "None" end
    return KeyCodes.format_keybind(binding.vk, binding.ctrl, binding.shift, binding.alt)
end

return KeyCodes
