local EntityDelete = {}

local Game = require("ClickUl_Refactor.Adapters.Game")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local DELETE_YIELD_BATCH <const> = 25

local function exists(entity)
    return Game.entity_exists(entity)
end

function EntityDelete.delete(entity)
    if not exists(entity) then return false end
    Game.network_unregister_entity(entity, true)
    return true
end

function EntityDelete.delete_many(list, on_complete)
    if type(list) ~= "table" then
        if on_complete then on_complete({ api = 0, native = 0, total = 0 }) end
        return 0
    end

    local handles = {}
    for i = #list, 1, -1 do
        local value = list[i]
        local handle = type(value) == "table" and (value.handle or value.entity or value.vehicle or value.spawned_ped) or value
        if handle and handle ~= 0 and exists(handle) then
            handles[#handles + 1] = handle
        end
    end
    local count = #handles
    if count == 0 then
        if on_complete then on_complete({ api = 0, native = 0, total = 0 }) end
        return 0
    end

    Runtime.create_job(function()
        for i, handle in ipairs(handles) do
            Game.network_unregister_entity(handle, true)
            if i % DELETE_YIELD_BATCH == 0 then Runtime.yield(0) end
        end

        Runtime.yield(0)

        local native_used = 0
        for i, handle in ipairs(handles) do
            if exists(handle) then
                Native.delete_entity(handle)
                native_used = native_used + 1
            end
            if i % DELETE_YIELD_BATCH == 0 then Runtime.yield(0) end
        end

        if on_complete then on_complete({ api = count - native_used, native = native_used, total = count }) end
    end)

    return count
end

return EntityDelete
