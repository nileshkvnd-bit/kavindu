local CacheUtils = {}

local math_floor <const> = math.floor
local table_move <const> = table.move
local type <const> = type

local DEFAULT_EVICT_RATIO <const> = 0.3

local function get_evict_count(count, ratio)
    local evict_count = math_floor(count * (ratio or DEFAULT_EVICT_RATIO))
    if evict_count < 1 then evict_count = 1 end
    return evict_count
end

function CacheUtils.evict_ordered(cache, order, limit, ratio, remove_entry, current_count, evict_at_limit)
    local count = current_count or #order
    if evict_at_limit then
        if count < limit then return count end
    elseif count <= limit then
        return count
    end

    local evict_count = get_evict_count(limit, ratio)
    local order_len = #order
    if evict_count > order_len then evict_count = order_len end

    for i = 1, evict_count do
        local entry = order[i]
        if entry ~= nil then
            if remove_entry then
                remove_entry(cache, entry)
            else
                cache[entry] = nil
            end
        end
    end

    local remaining = order_len - evict_count
    if remaining > 0 then
        table_move(order, evict_count + 1, order_len, 1)
    end
    for i = remaining + 1, order_len do
        order[i] = nil
    end

    count = count - evict_count
    if count < 0 then return 0 end
    return count
end

function CacheUtils.evict_nested_pairs(buckets, remaining, ratio)
    local evicted = 0
    for _, bucket in pairs(buckets) do
        if type(bucket) == "table" then
            local bucket_count = 0
            for _ in pairs(bucket) do bucket_count = bucket_count + 1 end

            local to_evict = math_floor(bucket_count * (ratio or DEFAULT_EVICT_RATIO))
            if to_evict < 1 and bucket_count > 0 then to_evict = 1 end
            if to_evict > 0 then
                local removed = 0
                for key in pairs(bucket) do
                    if removed >= to_evict or evicted >= remaining then break end
                    bucket[key] = nil
                    removed = removed + 1
                    evicted = evicted + 1
                end
            end
        end
        if evicted >= remaining then break end
    end
    return evicted
end

function CacheUtils.prune_live_keys(cache, live_set)
    local count = 0
    for key in pairs(cache) do
        if live_set[key] then
            count = count + 1
        else
            cache[key] = nil
        end
    end
    return count
end

function CacheUtils.evict_pairs(cache, count, limit, ratio, remove_entry)
    if count < limit then return count end

    local evict_target = get_evict_count(count, ratio)
    local evicted = 0

    for key, value in pairs(cache) do
        if evicted >= evict_target then break end

        local removed
        if remove_entry then
            removed = remove_entry(cache, key, value, evict_target - evicted, ratio or DEFAULT_EVICT_RATIO)
        else
            cache[key] = nil
            removed = 1
        end

        if removed and removed > 0 then
            evicted = evicted + removed
        end
    end

    count = count - evicted
    if count < 0 then return 0 end
    return count
end

return CacheUtils
