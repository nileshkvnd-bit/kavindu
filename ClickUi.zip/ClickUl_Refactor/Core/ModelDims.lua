local ModelDims = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")

local math_abs <const> = math.abs

local cache = {}

local function vec_copy(value)
    if not value then return { x = 0.0, y = 0.0, z = 0.0 } end
    return { x = value.x or 0.0, y = value.y or 0.0, z = value.z or 0.0 }
end

function ModelDims.read(model)
    if not model then return nil end
    local minimum = Pointer.scr_vec3()
    local maximum = Pointer.scr_vec3()
    local ok, result = xpcall(function()
        Native.call("get_model_dimensions", model, minimum, maximum)
        return {
            min = vec_copy(Pointer.scr_vec3_value(minimum, nil)),
            max = vec_copy(Pointer.scr_vec3_value(maximum, nil)),
        }
    end, debug.traceback)
    Pointer.free(minimum)
    Pointer.free(maximum)
    if not ok then error(result, 0) end
    return result
end

function ModelDims.get(model_hash)
    if not model_hash or model_hash == 0 then return nil end
    local hit = cache[model_hash]
    if hit ~= nil then return hit or nil end

    local dims = ModelDims.read(model_hash)
    if math_abs(dims.min.x) <= 0.1 and math_abs(dims.max.x) <= 0.1 then
        cache[model_hash] = false
        return nil
    end
    cache[model_hash] = dims
    return dims
end

return ModelDims
