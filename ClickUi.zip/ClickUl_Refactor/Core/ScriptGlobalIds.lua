local Script = require("ClickUl_Refactor.Adapters.Script")

local MP_GLOBALS_AMBIENCE <const> = 2733138

local ScriptGlobalIds = {
    DOORS_INITED = MP_GLOBALS_AMBIENCE + 3697,

    DISABLE_DEATH_BARRIERS = MP_GLOBALS_AMBIENCE + 5830,
}

function ScriptGlobalIds.ambience_verified()
    return Script.read_global_int(ScriptGlobalIds.DOORS_INITED) == 1
end

return ScriptGlobalIds
