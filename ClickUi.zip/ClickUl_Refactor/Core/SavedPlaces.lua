local Fs = require("ClickUl_Refactor.Adapters.Fs")
local FileCatalog = require("ClickUl_Refactor.Core.FileCatalog")

local SavedPlaces = {}

local FORMAT_KEY <const> = "Places"

local logger = nil

local function root_dir()
    return Fs.join(Fs.root_dir(), "Places\\")
end

local catalog = FileCatalog.new({
    root = root_dir,
    formats = { { key = FORMAT_KEY, dir = "", extension = "txt", default_folder = FORMAT_KEY } },
})

local function sanitize_filename(value)
    value = tostring(value or ""):match("^%s*(.-)%s*$")
    return (value:gsub("[\\/:*?\"<>|]", "_"))
end

local function parse_numbers(line, limit)
    local nums = {}
    for token in tostring(line or ""):gmatch("%-?%d+%.?%d*") do
        local n = tonumber(token)
        if n then
            nums[#nums + 1] = n
            if #nums == limit then break end
        end
    end
    return nums
end

local function is_root_level(item)
    return not tostring(item.relative_path or ""):find("[\\/]")
end

function SavedPlaces.save(name, coords)
    name = sanitize_filename(name)
    if name == "" then return nil, "missing_filename" end
    if type(coords) ~= "table" then return nil, "invalid_position" end
    local x, y = tonumber(coords.x), tonumber(coords.y)
    if not x or not y then return nil, "invalid_position" end
    local z = tonumber(coords.z)

    Fs.ensure_dir(root_dir())
    local path = Fs.join(root_dir(), name .. ".txt")
    local body = z and string.format("%.4f, %.4f, %.4f", x, y, z) or string.format("%.4f, %.4f", x, y)
    local heading = tonumber(coords.heading)
    if heading then body = body .. "\n" .. string.format("%.4f", heading) end

    if not Fs.write_text(path, body) then return nil, "write_failed" end
    catalog.refresh()
    return path
end

function SavedPlaces.read_position(path)
    local text = Fs.read_text(path)
    if type(text) ~= "string" then return nil end

    local lines = {}
    for line in text:gmatch("[^\r\n]+") do lines[#lines + 1] = line end

    local coords = parse_numbers(lines[1], 3)
    if #coords < 2 then return nil end

    local position = { x = coords[1], y = coords[2], z = coords[3], guessed = coords[3] == nil }
    local heading = parse_numbers(lines[2], 1)
    if heading[1] then position.heading = heading[1] end
    return position
end

function SavedPlaces.remove(path)
    if not path or path == "" then return false end
    local ok = Fs.remove(path)
    catalog.refresh()
    return ok
end

function SavedPlaces.remove_all()
    local removed = 0
    for _, item in ipairs(catalog.list(FORMAT_KEY)) do
        if is_root_level(item) and Fs.remove(item.path) then removed = removed + 1 end
    end
    catalog.refresh()
    return removed
end

local function migrate()
    local legacy = Fs.join(Fs.config_dir(), "teleport_places.json")
    if not Fs.exists(legacy) then return end

    local data = Fs.read_json_value(legacy)
    if type(data) == "table" and type(data.items) == "table" then
        local migrated = 0
        for id, entry in pairs(data.items) do
            if type(entry) == "table" then
                local name = type(entry.name) == "string" and entry.name ~= "" and entry.name or tostring(id)
                if SavedPlaces.save(name, entry) then migrated = migrated + 1 end
            end
        end
        if logger then logger.info("Core.SavedPlaces", "migrated legacy places", { count = migrated }) end
    end

    Fs.remove(legacy)
end

function SavedPlaces.init(ctx)
    ctx = ctx or {}
    logger = ctx.logger
    migrate()
    catalog.refresh()
    return true
end

function SavedPlaces.refresh()
    return catalog.refresh()
end

function SavedPlaces.snapshot()
    return catalog.snapshot()
end

function SavedPlaces.list(format)
    return catalog.list(format or FORMAT_KEY)
end

function SavedPlaces.folders(format)
    return catalog.folders(format or FORMAT_KEY)
end

function SavedPlaces.relative_path(path)
    return catalog.relative_path(path)
end

function SavedPlaces.count()
    return #catalog.list(FORMAT_KEY)
end

return SavedPlaces
