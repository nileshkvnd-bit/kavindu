local JsonDecoder = {}

local byte = string.byte
local sub = string.sub
local find = string.find
local concat = table.concat
local s_char = string.char
local tointeger = math.tointeger

local ESCAPE_MAP <const> = {
    [34] = '"', [92] = "\\", [47] = "/",
    [98] = "\b", [102] = "\f", [110] = "\n", [114] = "\r", [116] = "\t",
}

local function utf8_encode(cp)
    if cp < 0x80 then return s_char(cp) end
    if cp < 0x800 then return s_char(0xC0 + (cp >> 6), 0x80 + (cp & 0x3F)) end
    if cp < 0x10000 then return s_char(0xE0 + (cp >> 12), 0x80 + ((cp >> 6) & 0x3F), 0x80 + (cp & 0x3F)) end
    return s_char(0xF0 + (cp >> 18), 0x80 + ((cp >> 12) & 0x3F), 0x80 + ((cp >> 6) & 0x3F), 0x80 + (cp & 0x3F))
end

local function parse(str)
    local pos = 1
    local len = #str
    local parse_value

    local function fail(message)
        error(string.format("JSON decode error at byte %d: %s", pos, message), 0)
    end

    local function skip_ws()
        while pos <= len do
            local c = byte(str, pos)
            if c == 32 or c == 9 or c == 10 or c == 13 then pos = pos + 1 else break end
        end
    end

    local function parse_string()
        pos = pos + 1
        local start = pos
        local q = find(str, '["\\]', pos)
        if not q then fail("unterminated string") end
        if byte(str, q) == 34 then
            pos = q + 1
            return sub(str, start, q - 1)
        end
        local parts = {}
        local i = start
        while true do
            local m = find(str, '["\\]', i)
            if not m then fail("unterminated string") end
            local c = byte(str, m)
            if c == 34 then
                parts[#parts + 1] = sub(str, i, m - 1)
                pos = m + 1
                return concat(parts)
            end
            parts[#parts + 1] = sub(str, i, m - 1)
            local nx = byte(str, m + 1)
            if nx == 117 then
                local cp = tonumber(sub(str, m + 2, m + 5), 16)
                if not cp then fail("bad unicode escape") end
                if cp >= 0xD800 and cp <= 0xDBFF and sub(str, m + 6, m + 7) == "\\u" then
                    local lo = tonumber(sub(str, m + 8, m + 11), 16) or 0
                    cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00)
                    parts[#parts + 1] = utf8_encode(cp)
                    i = m + 12
                else
                    parts[#parts + 1] = utf8_encode(cp)
                    i = m + 6
                end
            else
                local e = ESCAPE_MAP[nx]
                if not e then fail("bad escape") end
                parts[#parts + 1] = e
                i = m + 2
            end
        end
    end

    local function parse_number()
        local start = pos
        local is_float = false
        if byte(str, pos) == 45 then pos = pos + 1 end
        while pos <= len do
            local c = byte(str, pos)
            if c >= 48 and c <= 57 then
                pos = pos + 1
            elseif c == 46 then
                is_float = true; pos = pos + 1
            elseif c == 101 or c == 69 then
                is_float = true; pos = pos + 1
                local n = byte(str, pos)
                if n == 43 or n == 45 then pos = pos + 1 end
            else
                break
            end
        end
        local numstr = sub(str, start, pos - 1)
        local n = tonumber(numstr)
        if n == nil then fail("invalid number '" .. numstr .. "'") end
        if is_float then return n end
        return tointeger(n) or n
    end

    local function parse_object()
        pos = pos + 1
        local obj = {}
        skip_ws()
        if byte(str, pos) == 125 then pos = pos + 1; return obj end
        while true do
            skip_ws()
            if byte(str, pos) ~= 34 then fail("expected string key") end
            local key = parse_string()
            skip_ws()
            if byte(str, pos) ~= 58 then fail("expected ':'") end
            pos = pos + 1
            obj[key] = parse_value()
            skip_ws()
            local c = byte(str, pos)
            if c == 44 then pos = pos + 1
            elseif c == 125 then pos = pos + 1; return obj
            else fail("expected ',' or '}'") end
        end
    end

    local function parse_array()
        pos = pos + 1
        local arr = {}
        local n = 0
        skip_ws()
        if byte(str, pos) == 93 then pos = pos + 1; return arr end
        while true do
            n = n + 1
            arr[n] = parse_value()
            skip_ws()
            local c = byte(str, pos)
            if c == 44 then pos = pos + 1
            elseif c == 93 then pos = pos + 1; return arr
            else fail("expected ',' or ']'") end
        end
    end

    parse_value = function()
        skip_ws()
        if pos > len then fail("unexpected end of input") end
        local c = byte(str, pos)
        if c == 123 then return parse_object() end
        if c == 91 then return parse_array() end
        if c == 34 then return parse_string() end
        if c == 116 then
            if sub(str, pos, pos + 3) == "true" then pos = pos + 4; return true end
            fail("invalid literal")
        end
        if c == 102 then
            if sub(str, pos, pos + 4) == "false" then pos = pos + 5; return false end
            fail("invalid literal")
        end
        if c == 110 then
            if sub(str, pos, pos + 3) == "null" then pos = pos + 4; return nil end
            fail("invalid literal")
        end
        return parse_number()
    end

    skip_ws()
    local result = parse_value()
    skip_ws()
    if pos <= len then fail("trailing content after value") end
    return result
end

function JsonDecoder.decode(text)
    if type(text) ~= "string" then return nil, "expected string, got " .. type(text) end
    local ok, result = pcall(parse, text)
    if not ok then return nil, result end
    return result
end

return JsonDecoder
