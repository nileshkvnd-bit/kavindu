local logger = {}
local fs = require("ClickUl_Refactor.Adapters.Fs")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")
local trace = require("ClickUl_Refactor.Core.Trace")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")

local LEVELS = { VERBOSE = 1, INFO = 2, WARN = 3, ERROR = 4 }
local LEVEL_NAMES = { "VERBOSE", "INFO", "WARN", "ERROR" }

local config = {
    enabled = true,
    log_level = LEVELS.VERBOSE,
    show_timestamp = true,
    show_memory = false,
    show_performance = false,
    log_to_file = true,
    print_to_console = true,
    module_filter = "",
}

local history = {}
local history_order = {}
local marks = {}
local max_history = 500
local log_file_path = nil
local session_date = nil
local writer_path = nil
local get_time <const> = runtime.now
local table_concat <const> = table.concat

local function date_string(format)
    return os.date(format)
end

local function get_session_date()
    if not session_date then
        session_date = date_string("%Y-%m-%d")
    end
    return session_date
end

local function build_log_file_path()
    return fs.join(fs.logs_dir(), "runtime_" .. get_session_date() .. ".log")
end

local function ensure_log_writer()
    if not log_file_path then
        log_file_path = build_log_file_path()
    end
    if writer_path == log_file_path and io_queue.get_log_handle() then
        return true
    end
    fs.ensure_dir(fs.logs_dir())
    io_queue.set_log_handle(function(message)
        return fs.append_text(log_file_path, message)
    end)
    writer_path = log_file_path
    return true
end

local function normalize_level(level)
    if type(level) == "number" then
        if level < LEVELS.VERBOSE then return LEVELS.VERBOSE end
        if level > LEVELS.ERROR then return LEVELS.ERROR end
        return level
    end
    if type(level) == "string" then
        local normalized = string.upper(level)
        if normalized == "TRACE" then normalized = "VERBOSE" end
        return LEVELS[normalized] or config.log_level
    end
    return config.log_level
end

local function serialize_value(value, depth, seen)
    depth = depth or 0
    if depth > 3 then return "..." end
    if type(value) ~= "table" then return tostring(value) end
    if seen[value] then return "<cycle>" end
    seen[value] = true

    local parts = {}
    for k, v in pairs(value) do
        parts[#parts + 1] = tostring(k) .. "=" .. serialize_value(v, depth + 1, seen)
    end
    return "{" .. table.concat(parts, ", ") .. "}"
end

function logger.serialize(value)
    return serialize_value(value, 0, {})
end

local function split_args(module_name, message, data)
    if message == nil and data == nil then
        return "Log", tostring(module_name or ""), nil
    end
    return tostring(module_name or "Log"), tostring(message or ""), data
end

local function should_log(level, module_name)
    if not config.enabled then return false end
    if level < config.log_level then return false end
    if config.module_filter ~= "" and not tostring(module_name):find(config.module_filter, 1, true) then
        return false
    end
    return true
end

local function format_line(level, module_name, message, payload)
    local parts = {}
    if config.show_timestamp then
        parts[#parts + 1] = os.date("%H:%M:%S")
    end
    parts[#parts + 1] = LEVEL_NAMES[level] or "INFO"
    parts[#parts + 1] = tostring(module_name or "Log")

    local line = "[" .. table_concat(parts, "][") .. "] " .. tostring(message)
    if payload ~= nil then
        line = line .. " " .. logger.serialize(payload)
    end
    return line
end

local function push_history(level, line)
    history[#history + 1] = { level = level, line = line, time = get_time() }
    history_order[#history_order + 1] = line
    if #history > max_history then table.remove(history, 1) end
    if #history_order > max_history then table.remove(history_order, 1) end
end

local function emit(level, module_or_message, message_or_data, data)
    local module_name, message, payload = split_args(module_or_message, message_or_data, data)
    if not should_log(level, module_name) then return end

    local line = format_line(level, module_name, message, payload)
    push_history(level, line)
    if config.print_to_console then print(line) end
    if config.log_to_file then
        ensure_log_writer()
        io_queue.queue_log(line)
    end
end

function logger.init(options)
    if type(options) == "table" then
        for k, v in pairs(options) do
            if config[k] ~= nil then config[k] = v end
        end
        config.log_level = normalize_level(config.log_level)
    end
    io_queue.set_error_handler(function(context, detail)
        logger.warn("Core.IoQueue", context, detail)
    end)
    if config.log_to_file then
        logger.reopen_log_file()
    else
        io_queue.set_log_handle(nil)
    end
    return true
end

function logger.verbose(a, b, c) emit(LEVELS.VERBOSE, a, b, c) end
function logger.info(a, b, c) emit(LEVELS.INFO, a, b, c) end
function logger.warn(a, b, c) emit(LEVELS.WARN, a, b, c) end
function logger.error(a, b, c) emit(LEVELS.ERROR, a, b, c) end

function logger.set_level(level) config.log_level = normalize_level(level) end
function logger.enable() config.enabled = true end
function logger.disable() config.enabled = false end
function logger.toggle()
    config.enabled = not config.enabled
    return config.enabled
end
function logger.set_log_to_file(enabled)
    config.log_to_file = enabled and true or false
    if config.log_to_file then
        return logger.reopen_log_file()
    end
    io_queue.flush_logs()
    io_queue.set_log_handle(nil)
    writer_path = nil
    return true
end
function logger.set_module_filter(filter) config.module_filter = tostring(filter or "") end
function logger.set_print_to_console(enabled) config.print_to_console = enabled and true or false end
function logger.set_show_timestamp(enabled) config.show_timestamp = enabled and true or false end
function logger.set_show_memory(enabled) config.show_memory = enabled and true or false end
function logger.set_show_performance(enabled) config.show_performance = enabled and true or false end
function logger.reopen_log_file()
    if not config.log_to_file then return false end
    log_file_path = build_log_file_path()
    writer_path = nil
    return ensure_log_writer()
end
function logger.get_config() return config end

function logger.mark_start(name)
    marks[name] = get_time()
end

function logger.mark_end(name)
    local start = marks[name]
    if not start then return nil end
    marks[name] = nil
    local ms = (get_time() - start) * 1000
    if config.show_performance then
        logger.verbose("Perf", string.format("%s took %.2fms", tostring(name), ms))
    end
    return ms
end

function logger.get_memory()
    local kb = collectgarbage("count")
    return { kb = kb, mb = kb / 1024 }
end

function logger.force_gc()
    collectgarbage("collect")
end

function logger.clear_history()
    local count = #history
    history = {}
    history_order = {}
    return count
end

function logger.get_history_count() return #history end
function logger.dump_history()
    fs.ensure_dir(fs.logs_dir())
    local stamp = date_string("%Y-%m-%d_%H-%M-%S")
    local path = fs.join(fs.logs_dir(), "history_" .. stamp .. ".log")
    local lines = {}
    for i = 1, #history_order do
        lines[i] = history_order[i]
    end
    local saved = fs.write_text(path, table_concat(lines, "\n") .. "\n")
    if saved then
        return path
    end
    return false
end
function logger.trace()
    logger.verbose("Trace", trace.current("logger.trace", 3))
end

function logger.assert(condition, message)
    if condition then return true end
    logger.error("Assert", "Assertion failed: " .. tostring(message))
    return false
end

return logger
