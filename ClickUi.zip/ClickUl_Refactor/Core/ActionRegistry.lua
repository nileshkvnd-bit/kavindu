local ActionRegistry = {}

local Util = require("ClickUl_Refactor.Core.Util")

local actions = {}
local action_order = {}

local clone_list = Util.clone_list

local function clone_action(action)
    if not action then return nil end
    return {
        id = action.id,
        label = action.label,
        group = action.group,
        feature = action.feature,
        page = action.page,
        tabs = clone_list(action.tabs),
        section = action.section,
        column = action.column,
        layout = action.layout,
        favorite_kind = action.favorite_kind,
        path = action.path,
        description = action.description,
        execute = action.execute,
        render = action.render,
        is_available = action.is_available,
    }
end

local function normalize_tabs(tabs, page)
    local result = {}
    if type(tabs) == "table" then
        for i = 1, #tabs do
            local tab = tabs[i]
            if type(tab) == "string" and tab ~= "" then result[#result + 1] = tab end
        end
    end
    if #result == 0 then result[1] = page or "General" end
    return result
end

function ActionRegistry.clear()
    actions = {}
    action_order = {}
end

function ActionRegistry.register(spec)
    assert(type(spec) == "table", "[ActionRegistry] action spec table is required")
    assert(type(spec.id) == "string" and spec.id ~= "", "[ActionRegistry] action id is required")
    assert(type(spec.label) == "string" and spec.label ~= "", "[ActionRegistry] action label is required")
    assert(type(spec.group) == "string" and spec.group ~= "", "[ActionRegistry] action group is required")
    assert(type(spec.execute) == "function" or type(spec.render) == "function", "[ActionRegistry] action execute or render is required")

    local page = spec.page or "General"
    local action = {
        id = spec.id,
        label = spec.label,
        group = spec.group,
        feature = spec.feature or spec.group,
        page = page,
        tabs = normalize_tabs(spec.tabs, page),
        section = spec.section or spec.group,
        column = spec.column,
        layout = spec.layout,
        favorite_kind = spec.favorite_kind or "function",
        path = spec.path,
        description = spec.description,
        execute = spec.execute,
        render = spec.render,
        is_available = spec.is_available,
    }

    if actions[action.id] == nil then action_order[#action_order + 1] = action.id end
    actions[action.id] = action
    return true
end

function ActionRegistry.get(id)
    return clone_action(actions[id])
end

function ActionRegistry.exists(id)
    return actions[id] ~= nil
end

function ActionRegistry.is_available(id)
    local action = actions[id]
    if not action then return false end
    if type(action.is_available) == "function" then return action.is_available(action) ~= false end
    return true
end

function ActionRegistry.execute(id)
    local action = actions[id]
    if not action or type(action.execute) ~= "function" then return nil, "missing_action" end
    if not ActionRegistry.is_available(id) then return nil, "unavailable" end
    return action.execute(action)
end

function ActionRegistry.list()
    local result = {}
    for i = 1, #action_order do
        local action = actions[action_order[i]]
        if action then result[#result + 1] = clone_action(action) end
    end
    return result
end

return ActionRegistry
