local PedMemory = {}

local Game = require("ClickUl_Refactor.Adapters.Game")
local Memory = require("ClickUl_Refactor.Adapters.Memory")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local logger = require("ClickUl_Refactor.Core.Logger")

local OFF_HEALTH <const> = 0x280
local OFF_MAX <const> = 0x284
local OFF_ARMOUR <const> = 0x150C
local CHECK_TOLERANCE <const> = 1.5
local CHECK_RETRY_MS <const> = 500

local state = {
    checked = false,
    available = false,
    attempt_ms = nil,
}

local function ped_address(ped)
    if not ped or ped == 0 then return nil end
    local addr = Game.entity_from_guid(ped)
    if not addr or Memory.value(addr) == 0 then return nil end
    return addr
end

local function mem_field(addr, offset)
    return Memory.float(Memory.add(addr, offset))
end

local function ensure_checked()
    if state.checked then return end
    local now = Runtime.get_tick_count()
    if state.attempt_ms and now - state.attempt_ms < CHECK_RETRY_MS and now >= state.attempt_ms then
        return
    end
    state.attempt_ms = now
    local ped = Players.local_ped()
    local addr = ped_address(ped)
    if not addr then return end

    local mh = mem_field(addr, OFF_HEALTH)
    local mm = mem_field(addr, OFF_MAX)
    local ma = mem_field(addr, OFF_ARMOUR)
    if mh == nil or mm == nil or ma == nil then return end

    local nh = Native.call("get_entity_health", ped) or 0
    local nm = Native.call("get_entity_max_health", ped) or 0
    local na = Native.call("get_ped_armour", ped) or 0

    if nh <= 0 or nm <= 0 then return end

    local ok = math.abs(mh - nh) <= CHECK_TOLERANCE
        and math.abs(mm - nm) <= CHECK_TOLERANCE
        and math.abs(ma - na) <= CHECK_TOLERANCE

    state.available = ok
    state.checked = true
    if ok then
        logger.info("Core.PedMemory", "memory vitals offsets verified; using direct struct reads",
            { health = mh, max = mm, armour = ma })
    else
        logger.warn("Core.PedMemory", "memory offsets mismatch native -> native fallback",
            { mem = { mh, mm, ma }, native = { nh, nm, na } })
    end
end

function PedMemory.health(ped)
    ensure_checked()
    if state.available then
        local addr = ped_address(ped)
        if addr then return mem_field(addr, OFF_HEALTH) end
        return 0
    end
    return Native.call("get_entity_health", ped) or 0
end

function PedMemory.max_health(ped)
    ensure_checked()
    if state.available then
        local addr = ped_address(ped)
        if addr then return mem_field(addr, OFF_MAX) end
        return 100
    end
    return Native.call("get_entity_max_health", ped) or 100
end

function PedMemory.armour(ped)
    ensure_checked()
    if state.available then
        local addr = ped_address(ped)
        if addr then return mem_field(addr, OFF_ARMOUR) end
        return 0
    end
    return Native.call("get_ped_armour", ped) or 0
end

function PedMemory.vitals(ped, needs_health, needs_armour)
    ensure_checked()
    if state.available then
        local addr = ped_address(ped)
        if not addr then
            if needs_health then
                return 0, 100, needs_armour and 0 or nil
            end
            return nil, nil, needs_armour and 0 or nil
        end
        local health, max_health, armour
        if needs_health then
            health = mem_field(addr, OFF_HEALTH)
            max_health = mem_field(addr, OFF_MAX)
        end
        if needs_armour then armour = mem_field(addr, OFF_ARMOUR) end
        return health, max_health, armour
    end
    local health, max_health, armour
    if needs_health then
        health = Native.call("get_entity_health", ped) or 0
        max_health = Native.call("get_entity_max_health", ped) or 0
    end
    if needs_armour then armour = Native.call("get_ped_armour", ped) or 0 end
    return health, max_health, armour
end

function PedMemory.is_dead(ped)
    if not ped or ped == 0 then return true end
    ensure_checked()
    if state.available then
        local addr = ped_address(ped)
        if not addr then return true end
        local h = mem_field(addr, OFF_HEALTH)
        if h ~= nil then return h <= 0 end
    end
    if not Game.entity_exists(ped) then return true end
    return Native.call("is_entity_dead", ped, false) and true or false
end

return PedMemory
