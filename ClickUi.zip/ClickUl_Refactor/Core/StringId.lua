local StringId = {}

local tostring <const> = tostring
local select <const> = select

local pair_cache = {}
local pair_cache_count = 0
local PAIR_CACHE_LIMIT <const> = 4000

function StringId.concat(a, b, ...)
    if select("#", ...) == 0 then
        local by_a = pair_cache[a]
        if not by_a then
            by_a = {}
            pair_cache[a] = by_a
        end

        local cached = by_a[b]
        if cached then return cached end

        if pair_cache_count >= PAIR_CACHE_LIMIT then
            pair_cache = {}
            pair_cache_count = 0
            by_a = {}
            pair_cache[a] = by_a
        end

        cached = tostring(a) .. tostring(b)
        by_a[b] = cached
        pair_cache_count = pair_cache_count + 1
        return cached
    end

    local key = tostring(a) .. tostring(b)
    for i = 1, select("#", ...) do
        key = key .. tostring(select(i, ...))
    end
    return key
end

function StringId.clear()
    pair_cache = {}
    pair_cache_count = 0
end

return StringId
