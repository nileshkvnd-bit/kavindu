local fs = require("ClickUl_Refactor.Adapters.Fs")

local i18n = {}

local settings = nil
local translations = {}
local lang_list = {}
local current_lang = nil

local function refresh_available()
    local found = {}
    local files = fs.list(fs.languages_dir(), "json")
    for _, path in ipairs(files) do
        local name = tostring(path):match("([^\\/]+)%.json$")
        if name and name ~= "template" then found[#found + 1] = name end
    end
    lang_list = found
end

local function load_lang(lang_code)
    if not lang_code or lang_code == "" then
        translations = {}
        return false
    end

    local path = fs.join(fs.languages_dir(), tostring(lang_code) .. ".json")
    local decoded = fs.read_json_value(path)
    if type(decoded) == "table" then
        translations = decoded
        return true
    end
    translations = {}
    return false
end

function i18n.init(ctx)
    settings = assert(ctx.settings, "[I18n] settings module is required")
    fs.ensure_dir(fs.languages_dir())
    current_lang = settings.get_language()
    refresh_available()
    load_lang(current_lang or "")
    return true
end

function i18n.get(key)
    return translations[key] or key
end

local list_cache = setmetatable({}, { __mode = "k" })

function i18n.translate_list(keys)
    local entry = list_cache[keys]
    if entry and entry.language == current_lang then
        return entry.labels
    end

    if not entry then
        entry = { labels = {} }
        list_cache[keys] = entry
    end

    local labels = entry.labels
    for i = 1, #keys do
        labels[i] = i18n.get(keys[i])
    end
    for i = #keys + 1, #labels do labels[i] = nil end

    entry.language = current_lang
    return labels
end

function i18n.refresh_available() refresh_available() end
function i18n.reload() return load_lang(current_lang) end
function i18n.get_lang_list() return lang_list end

function i18n.get_lang_index()
    for i, lang in ipairs(lang_list) do
        if lang == current_lang then return i end
    end
    return 1
end

function i18n.set_lang_by_index(index)
    local lang = lang_list[index]
    if not lang then return false end
    current_lang = lang
    local settings_module = assert(settings, "[I18n] settings module is required")
    settings_module.set_language(lang)
    load_lang(lang)
    return true
end

function i18n.get_language() return current_lang end

return i18n
