local trace = {}

local traceback <const> = debug.traceback

function trace.capture(err, level)
    return traceback(tostring(err or ""), level or 2)
end

function trace.current(label, level)
    return trace.capture(label or "stack", level or 2)
end

return trace
