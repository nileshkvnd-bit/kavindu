local fs = require("ClickUl_Refactor.Adapters.Fs")
local json_adapter = require("ClickUl_Refactor.Adapters.Json")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")
local logger = require("ClickUl_Refactor.Core.Logger")
local runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Util = require("ClickUl_Refactor.Core.Util")

local settings = {}

local data = {}
local dirty = false
local initialized = false
local auto_save_enabled = true
local last_save_time = 0
local reset_handlers = {}
local SAVE_THROTTLE <const> = 1.0

local copy_table = Util.copy_table

local function tables_equal(a, b)
    if a == b then return true end
    if type(a) ~= "table" or type(b) ~= "table" then return false end
    for k, v in pairs(a) do
        if not tables_equal(v, b[k]) then return false end
    end
    for k in pairs(b) do
        if a[k] == nil then return false end
    end
    return true
end

local function default_data()
    return {
        System = {
            auto_save = true,
            language = "zh_cn",
            theme = "Default",
            loading_overlay_enabled = true,
        },
        Logging = {
            enabled = true,
            log_level = 1,
            show_timestamp = true,
            show_memory = false,
            show_performance = false,
            log_to_file = true,
            print_to_console = true,
            module_filter = "",
        },
    }
end

local function config_path()
    return fs.join(fs.config_dir(), "settings.json")
end

local function merge_defaults(target, defaults)
    for k, v in pairs(defaults) do
        if type(v) == "table" then
            if type(target[k]) ~= "table" then target[k] = {} end
            merge_defaults(target[k], v)
        elseif target[k] == nil then
            target[k] = v
        end
    end
end

function settings.init()
    if initialized then return true end
    settings.load()
    initialized = true
    return true
end

function settings.load()
    fs.ensure_dir(fs.config_dir())
    local decoded, read_error = fs.read_json_value(config_path())
    if type(decoded) == "table" then
        data = decoded
    else
        data = default_data()
        if read_error == "missing_file" then
            settings.save_immediate()
        end
    end
    merge_defaults(data, default_data())
    data.Hotkeys = nil
    auto_save_enabled = data.System.auto_save ~= false
    dirty = false
    logger.init(data.Logging)
    return true
end

function settings.save_immediate()
    fs.ensure_dir(fs.config_dir())
    local content = json_adapter.encode_document(data, 2)
    local saved = fs.write_text(config_path(), content)
    if saved then dirty = false end
    return saved
end

function settings.save()
    if not dirty then return true end
    io_queue.queue_save(function() return settings.save_immediate() end, "settings")
    return true
end

function settings.auto_save()
    if not auto_save_enabled or not dirty then return true end
    local now = runtime.now()
    if now - last_save_time < SAVE_THROTTLE then return true end
    last_save_time = now
    return settings.save()
end

function settings.force_save()
    if not dirty then return true end
    return settings.save_immediate()
end

function settings.reset()
    data = default_data()
    dirty = true
    for _, handler in pairs(reset_handlers) do handler() end
    return settings.force_save()
end

function settings.get(section, key, default)
    local sec = data[section]
    if type(sec) ~= "table" then return default end
    local value = sec[key]
    if value == nil then return default end
    return value
end

function settings.set(section, key, value)
    if type(data[section]) ~= "table" then data[section] = {} end
    if data[section][key] ~= value then
        data[section][key] = value
        dirty = true
    end
end

function settings.get_section(section)
    return copy_table(data[section] or {})
end

function settings.set_section(section, values)
    if type(values) ~= "table" then return end
    if tables_equal(data[section], values) then return end
    data[section] = copy_table(values)
    dirty = true
end

function settings.register_reset_handler(name, handler)
    assert(type(name) == "string" and name ~= "", "settings reset handler name is required")
    assert(type(handler) == "function", "settings reset handler must be a function")
    reset_handlers[name] = handler
end

function settings.is_dirty() return dirty end
function settings.is_enabled() return auto_save_enabled end
function settings.set_enabled(enabled)
    auto_save_enabled = enabled and true or false
    settings.set("System", "auto_save", auto_save_enabled)
end
function settings.get_language() return settings.get("System", "language", "zh_cn") end
function settings.set_language(lang_code) settings.set("System", "language", lang_code or "zh_cn") end
function settings.get_theme_name() return settings.get("System", "theme", "Default") end
function settings.set_theme_name(name) settings.set("System", "theme", name or "Default") end
function settings.get_logging_config() return settings.get_section("Logging") end
function settings.set_logging_config(logging_cfg)
    settings.set_section("Logging", logging_cfg)
    logger.init(settings.get_logging_config())
end
function settings.get_loading_overlay_enabled() return settings.get("System", "loading_overlay_enabled", true) end
function settings.set_loading_overlay_enabled(enabled) settings.set("System", "loading_overlay_enabled", enabled and true or false) end

return settings
