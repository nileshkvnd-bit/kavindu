local HotkeySettings = {}

local fs = require("ClickUl_Refactor.Adapters.Fs")
local json_adapter = require("ClickUl_Refactor.Adapters.Json")
local io_queue = require("ClickUl_Refactor.Core.IoQueue")

local data = {}
local dirty = false
local initialized = false

local function default_data()
    return {
        enabled = true,
        notify_on_trigger = true,
        bindings = {},
    }
end

local function config_path()
    return fs.join(fs.config_dir(), "hotkeys.json")
end

local function merge_defaults(target, defaults)
    for k, v in pairs(defaults) do
        if type(v) == "table" then
            if type(target[k]) ~= "table" then target[k] = {} end
            merge_defaults(target[k], v)
        elseif target[k] == nil then
            target[k] = v
        end
    end
end

local function normalize_binding(binding)
    if type(binding) ~= "table" then return nil, false end

    local vk = math.tointeger(tonumber(binding.vk))
    if not vk or vk == 0 then return nil, true end

    local normalized = { vk = vk }
    if binding.ctrl == true then normalized.ctrl = true end
    if binding.shift == true then normalized.shift = true end
    if binding.alt == true then normalized.alt = true end

    local changed = math.type(binding.vk) ~= "integer"
        or binding.vk ~= vk
        or binding.ctrl == false
        or binding.shift == false
        or binding.alt == false
        or normalized.ctrl ~= binding.ctrl
        or normalized.shift ~= binding.shift
        or normalized.alt ~= binding.alt

    return normalized, changed
end

local function normalize_bindings()
    local changed = false
    if type(data.bindings) ~= "table" then
        data.bindings = {}
        return true
    end

    for action_id, bindings in pairs(data.bindings) do
        if type(bindings) ~= "table" then
            data.bindings[action_id] = {}
            changed = true
        else
            local normalized_action = {}
            for slot = 1, 2 do
                local key = "slot" .. tostring(slot)
                local normalized, binding_changed = normalize_binding(bindings[key] or bindings[slot])
                if normalized then normalized_action[key] = normalized end
                if binding_changed or bindings[slot] ~= nil then changed = true end
            end
            data.bindings[action_id] = normalized_action
        end
    end

    return changed
end

local function queue_save()
    dirty = true
    io_queue.queue_save(function() HotkeySettings.save_immediate() end, "hotkeys")
end

function HotkeySettings.init()
    if initialized then return true end
    HotkeySettings.load()
    initialized = true
    return true
end

function HotkeySettings.load()
    fs.ensure_dir(fs.config_dir())
    local decoded = fs.read_json_value(config_path())
    data = type(decoded) == "table" and decoded or default_data()
    merge_defaults(data, default_data())
    local normalized = normalize_bindings()
    dirty = false
    if normalized and type(decoded) == "table" then queue_save() end
    return true
end

function HotkeySettings.save_immediate()
    fs.ensure_dir(fs.config_dir())
    local saved = fs.write_text(config_path(), json_adapter.encode_document(data, 2))
    if saved then dirty = false end
    return saved
end

function HotkeySettings.force_save()
    if not dirty then return true end
    return HotkeySettings.save_immediate()
end

function HotkeySettings.is_enabled()
    return data.enabled ~= false
end

function HotkeySettings.set_enabled(enabled)
    local value = enabled and true or false
    if data.enabled == value then return false end
    data.enabled = value
    queue_save()
    return true
end

function HotkeySettings.is_trigger_notification_enabled()
    return data.notify_on_trigger ~= false
end

function HotkeySettings.set_trigger_notification_enabled(enabled)
    local value = enabled and true or false
    if data.notify_on_trigger == value then return false end
    data.notify_on_trigger = value
    queue_save()
    return true
end

function HotkeySettings.get_bindings()
    if type(data.bindings) ~= "table" then data.bindings = {} end
    return data.bindings
end

function HotkeySettings.set_bindings(bindings)
    data.bindings = type(bindings) == "table" and bindings or {}
    queue_save()
    return true
end

function HotkeySettings.is_dirty()
    return dirty
end

function HotkeySettings.get_path()
    return config_path()
end

return HotkeySettings
