local KillRuntime = {}

local EntityPool = require("ClickUl_Refactor.Core.EntityPool")
local EntityBones = require("ClickUl_Refactor.Core.EntityBones")
local EntityDelete = require("ClickUl_Refactor.Core.EntityDelete")
local FeatureThread = require("ClickUl_Refactor.Core.FeatureThread")
local Util = require("ClickUl_Refactor.Core.Util")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Hash = require("ClickUl_Refactor.Adapters.Hash")

local DETECT_RADIUS <const> = 300.0
local KILL_INTERVAL_MS <const> = 100
local EXPLOSION_TYPE <const> = 1
local HEADSHOT_WEAPON <const> = "WEAPON_HEAVYSNIPER_MK2"
local BULLET_DAMAGE <const> = 500
local BULLET_SPEED <const> = 2000.0

local state = {
    enabled = false,
    mode = 1,
    headshot_distance = 0.1,
    check_invincible = true,
    delete_invincible = false,
    kill_cops_when_wanted = true,
    last_kill_ms = 0,
}

local logger = nil
local weapon_hash = nil

local SECTION <const> = "AutoKill"
local storage = nil

local pool_options = {
    include_vehicles = false,
    enabled_categories = { hostile = true, cop = true },
    needs_dead = true,
    needs_hostility = true,
}
local enemy_options = {
    kill_cops_when_wanted = false,
    radius_sq = DETECT_RADIUS * DETECT_RADIUS,
    check_invincible = false,
}

local function log_verbose(message)
    if logger then logger.verbose("Features.AutoKill", message) end
end

local valid_coord = Util.valid_coord

local function is_invincible(ped)
    return not EntityPool.is_damageable(ped)
end

local function explode(pos, my_ped)
    if not valid_coord(pos) then return false end
    Native.add_owned_explosion(my_ped, pos, EXPLOSION_TYPE, 1.0, false, true, 0.0)
    return true
end

local function headshot(ped, my_ped)
    local head = EntityBones.ped_head_world(ped)
    if not valid_coord(head) then return false end

    if not weapon_hash then weapon_hash = Hash.joaat(HEADSHOT_WEAPON) end

    local start_pos = { x = head.x, y = head.y, z = head.z + state.headshot_distance }
    Native.shoot_single_bullet_between_coords_ignore_entity_new(
        start_pos, head,
        BULLET_DAMAGE, true, weapon_hash, my_ped,
        false, false, BULLET_SPEED, my_ped,
        true, false, ped, false, false, false
    )
    return true
end

local function tick()
    if not state.enabled then
        KillRuntime.stop()
        return
    end

    local now = Runtime.get_tick_count()
    if now - state.last_kill_ms < KILL_INTERVAL_MS then return end

    local my_ped = Players.local_ped()
    local my_pos = Players.local_coords()
    if not my_ped or my_ped == 0 or not my_pos then return end

    local wanted = EntityPool.player_wanted_level(Players.local_id())
    EntityPool.update(my_ped, my_pos, wanted, DETECT_RADIUS, pool_options)

    enemy_options.kill_cops_when_wanted = state.kill_cops_when_wanted
    local enemies = EntityPool.get_enemies(enemy_options)

    local use_headshot = state.mode == 1
    for i = 1, #enemies do
        local enemy = enemies[i]
        local ped = enemy.ped
        if state.check_invincible and is_invincible(ped) then
            if state.delete_invincible then EntityDelete.delete(ped) end
        else
            local killed = use_headshot and headshot(ped, my_ped) or explode(enemy.pos, my_ped)
            if killed then
                state.last_kill_ms = now
                if use_headshot then return end
            end
        end
    end
end

local thread = FeatureThread.new(tick)

function KillRuntime.init(ctx)
    logger = ctx and ctx.logger or logger
end

function KillRuntime.bind_storage(settings)
    storage = settings
    state.check_invincible = storage.get(SECTION, "check_invincible", state.check_invincible) and true or false
    storage.register_reset_handler(SECTION, function()
        state.check_invincible = true
    end)
end

function KillRuntime.start()
    if not thread.start() then return end
    log_verbose("AutoKill thread started")
end

function KillRuntime.stop()
    if not thread.stop() then return end
    log_verbose("AutoKill thread stopped")
end

function KillRuntime.evaluate()
    if state.enabled then
        KillRuntime.start()
    else
        KillRuntime.stop()
    end
end

function KillRuntime.on_shutdown()
    KillRuntime.stop()
end

function KillRuntime.snapshot()
    return {
        enabled = state.enabled,
        mode = state.mode,
        headshot_distance = state.headshot_distance,
        check_invincible = state.check_invincible,
        delete_invincible = state.delete_invincible,
        kill_cops_when_wanted = state.kill_cops_when_wanted,
        running = thread.running(),
    }
end

function KillRuntime.set_enabled(value)
    state.enabled = value and true or false
    KillRuntime.evaluate()
end

function KillRuntime.set_mode(value)
    state.mode = (tonumber(value) == 2) and 2 or 1
end

function KillRuntime.set_headshot_distance(value)
    local number = tonumber(value) or 0.1
    if number < 0 then number = 0 end
    state.headshot_distance = number
end

function KillRuntime.set_check_invincible(value)
    state.check_invincible = value and true or false
    storage.set(SECTION, "check_invincible", state.check_invincible)
    storage.save()
end

function KillRuntime.set_delete_invincible(value)
    state.delete_invincible = value and true or false
end

function KillRuntime.set_kill_cops_when_wanted(value)
    state.kill_cops_when_wanted = value and true or false
end

return KillRuntime
