local GeneralPage = require("ClickUl_Refactor.Features.AutoKill.GeneralPage")
local KillRuntime = require("ClickUl_Refactor.Features.AutoKill.Core.KillRuntime")

local AutoKill = {}

function AutoKill.init(ctx)
    local ui = assert(ctx.ui, "[AutoKill] ui is required")
    local lang = assert(ctx.lang, "[AutoKill] lang is required")
    local logger = assert(ctx.logger, "[AutoKill] logger is required")
    local settings = assert(ctx.settings, "[AutoKill] settings is required")

    KillRuntime.init({ logger = logger })
    KillRuntime.bind_storage(settings)
    GeneralPage.init({ ui = ui, lang = lang })

    logger.info("Features.AutoKill", "AutoKill module initialized")
    return true
end

function AutoKill.draw()
    GeneralPage.draw()
end

function AutoKill.on_shutdown()
    KillRuntime.on_shutdown()
end

return AutoKill
