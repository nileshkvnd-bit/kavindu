local KillRuntime = require("ClickUl_Refactor.Features.AutoKill.Core.KillRuntime")

local GeneralPage = {}

local ui
local lang

local MODE_VALUES <const> = { 1, 2 }
local MODE_NAMES <const> = { "Headshot", "Explosion" }

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[AutoKill.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[AutoKill.GeneralPage] lang is required")
end

function GeneralPage.draw()
    local snap = KillRuntime.snapshot()

    ui.Group(_T("Auto Kill"), function()
        local enabled = ui.Checkbox(_T("Enable AutoKill"), snap.enabled, make_hint("Enable AutoKill", "Automatically kill nearby hostiles"))
        if enabled ~= snap.enabled then KillRuntime.set_enabled(enabled) end

        local index = snap.mode == 2 and 2 or 1
        local names = {}
        for i = 1, #MODE_NAMES do names[i] = _T(MODE_NAMES[i]) end
        local new_index = ui.Combo(_T("Mode"), index, names, make_hint("Mode", "Headshot: one bullet per frame. Explosion: blast all at once"))
        if new_index ~= index then KillRuntime.set_mode(MODE_VALUES[new_index]) end

        if snap.mode == 1 then
            local dist = snap.headshot_distance
            local new_dist = ui.Slider(_T("Headshot Distance"), dist, 0, 5, 0.1, make_hint("Headshot Distance", "Bullet spawn offset above the target head"))
            if new_dist ~= dist then KillRuntime.set_headshot_distance(new_dist) end
        end

        ui.Separator()

        local cops = ui.Checkbox(_T("Kill Cops When Wanted"), snap.kill_cops_when_wanted, make_hint("Kill Cops When Wanted", "Also kill police while you have a wanted level"))
        if cops ~= snap.kill_cops_when_wanted then KillRuntime.set_kill_cops_when_wanted(cops) end

        local check = ui.Checkbox(_T("Check Invincible"), snap.check_invincible, make_hint("Check Invincible", "A simple invincibility check, mainly for skipping the driverless taxi driver"))
        if check ~= snap.check_invincible then KillRuntime.set_check_invincible(check) end

        local del = ui.Checkbox(_T("Delete Invincible"), snap.delete_invincible, make_hint("Delete Invincible", "Remove invincible enemies that cannot be killed"))
        if del ~= snap.delete_invincible then KillRuntime.set_delete_invincible(del) end
    end)
end

return GeneralPage
