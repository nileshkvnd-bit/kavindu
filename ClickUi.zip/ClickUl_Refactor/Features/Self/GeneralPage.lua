local GeneralPage = {}

local definitions = require("ClickUl_Refactor.Features.Self.Definitions")
local option_renderer = require("ClickUl_Refactor.Features.Self.OptionRenderer")

local ui = nil
local lang = nil

local function _T(text)
    return lang.get(text)
end

local function render_column(column)
    for _, group in ipairs(definitions.groups) do
        if group.column == column then
            ui.Group(_T(group.title), function()
                for _, def in ipairs(group.options) do
                    option_renderer.render(def)
                end
            end)
        end
    end
end

local function render_column_1()
    render_column(1)
end

local function render_column_2()
    render_column(2)
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[Self.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[Self.GeneralPage] lang is required")
end

function GeneralPage.draw()
    ui.DualColumn(render_column_1, render_column_2)
end

return GeneralPage
