local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")
local OutfitOptions = require("ClickUl_Refactor.Features.Self.OutfitOptions")

local OutfitPage = {}

local ui
local lang
local action_registry
local favorites

local state = {
    format_tab = 1,
}

local format_state = {}

local FORMAT_TABS <const> = { "JSON", "XML" }

local PAGE_CONFIGS <const> = {
    {
        id = "json_outfits",
        format = "json",
        list_title = "JSON Outfits",
        options_title = "Outfit Options",
        settings_section = "json_outfit",
        action_prefix = "self.json_outfit",
        path_prefix = "Self / JSON Outfits",
        section = "JSON Outfits",
        page = "JSON Outfit",
        spawn = function(path) return Spawner.Json.Outfit.spawn_file(path) end,
        delete_label = "Delete All Outfits",
        delete_all = function() return Spawner.Json.Outfit.delete_all() end,
    },
    {
        id = "xml_outfits",
        format = "xml",
        list_title = "XML Outfits",
        options_title = "Outfit Options",
        settings_section = "menyoo_outfit",
        action_prefix = "self.xml_outfit",
        path_prefix = "Self / XML Outfits",
        section = "XML Outfits",
        page = "XML Outfit",
        spawn = function(path) return Spawner.Menyoo.Outfit.spawn_file(path) end,
        delete_label = "Delete All Outfits",
        delete_all = function() return Spawner.Menyoo.Outfit.delete_all() end,
    },
}

local function _T(text)
    return lang and lang.get(text) or text
end

local function search_matches(item, query)
    query = tostring(query or ""):lower()
    if query == "" then return true end
    return tostring(item.search_key or item.name or ""):lower():find(query, 1, true) ~= nil
end

local filter_cache = setmetatable({}, { __mode = "k" })

local function filtered(list, query)
    if query == "" then return list end
    local entry = filter_cache[list]
    if entry and entry.query == query then return entry.result end
    local result = {}
    for i = 1, #list do
        if search_matches(list[i], query) then result[#result + 1] = list[i] end
    end
    filter_cache[list] = { query = query, result = result }
    return result
end

local function outfit_key(config, item)
    return item.relative_path or Spawner.OutfitFiles.relative_path(item.path)
end

local function outfit_action_id(config, item)
    return config.action_prefix .. ":" .. outfit_key(config, item)
end

local function spawn_item(config, item)
    local ped, _, err = config.spawn(item.path)
    if ped and ped ~= 0 then
        ui.notify(_T("Outfit spawned") .. ": " .. item.name, "Success")
        return
    end
    ui.notify(_T("Outfit spawn failed") .. ": " .. tostring(err or "unknown"), "Error")
end

local hint_cache = setmetatable({}, { __mode = "k" })
local hint_cache_lang = nil

local function outfit_hint(config, item)
    local current_lang = lang.get_language()
    if hint_cache_lang ~= current_lang then
        hint_cache = setmetatable({}, { __mode = "k" })
        hint_cache_lang = current_lang
    end

    local hint = hint_cache[item]
    if not hint then
        local id = outfit_action_id(config, item)
        hint = {
            text = _T("Outfit"),
            description = outfit_key(config, item),
            favorite = {
                action_id = id,
                label = item.name,
                path = config.path_prefix,
                is_favorite = false,
            },
        }
        hint_cache[item] = hint
    end

    hint.favorite.is_favorite = favorites.is_favorite(hint.favorite.action_id)
    return hint
end

local function register_outfit_action(config, item)
    local id = outfit_action_id(config, item)
    if action_registry.exists(id) then return end
    local action_item = { path = item.path, name = item.name, relative_path = outfit_key(config, item) }
    action_registry.register({
        id = id,
        label = item.name,
        group = "Self",
        feature = "Self",
        page = config.page,
        tabs = { config.page },
        section = config.section,
        column = 1,
        layout = "DualColumn_FixedLeft",
        favorite_kind = "outfit",
        path = config.path_prefix,
        execute = function()
            return spawn_item(config, action_item)
        end,
        render = function()
            local label = action_item.name .. "##fav_" .. id
            if ui.Button(label, outfit_hint(config, action_item)) then
                spawn_item(config, action_item)
            end
        end,
    })
end

local register_version = {}

local function register_outfit_actions(config)
    local snap = Spawner.OutfitFiles.snapshot()
    local version = snap and snap.version
    if version ~= nil and register_version[config.id] == version then return end
    register_version[config.id] = version
    local list = Spawner.OutfitFiles.list(config.format)
    for i = 1, #list do
        register_outfit_action(config, list[i])
    end
end

local function draw_item(config, item, id)
    if ui.Button(item.name .. "##" .. id, outfit_hint(config, item)) then
        spawn_item(config, item)
    end
end

local count_cache = setmetatable({}, { __mode = "k" })

local function count_matches(node, query)
    local entry = count_cache[node]
    if entry and entry.query == query then return entry.count end
    local count = 0
    for i = 1, #node.items do
        if search_matches(node.items[i], query) then count = count + 1 end
    end
    for i = 1, #node.folders do
        count = count + count_matches(node.folders[i], query)
    end
    count_cache[node] = { query = query, count = count }
    return count
end

local function draw_node(config, node, id_prefix, query, btn_height)
    local items = (query == "") and node.items or filtered(node.items, query)
    if #items > 0 then
        ui.VirtualList(items, btn_height, function(index, item)
            draw_item(config, item, id_prefix .. "_i" .. tostring(index))
        end)
    end

    for _, child in ipairs(node.folders) do
        local count = (query == "") and child.total_count or count_matches(child, query)
        if count > 0 then
            local child_id = id_prefix .. "_" .. child.name
            ui.StickyCollapsible(child.name .. " (" .. tostring(count) .. ")###" .. child_id, function()
                draw_node(config, child, child_id, query, btn_height)
            end)
        end
    end
end

local function draw_outfit_list(config)
    local page = format_state[config.id]
    local query = page.query or ""
    local tree = Spawner.OutfitFiles.tree(config.format)
    local btn_height = ui.get_button_h()
    local total = #Spawner.OutfitFiles.list(config.format)

    if total == 0 then
        ui.Text(_T("No outfits found"))
        return
    end

    register_outfit_actions(config)

    local root_items = (query == "") and tree.items or filtered(tree.items, query)
    if #root_items > 0 then
        ui.VirtualList(root_items, btn_height, function(index, item)
            draw_item(config, item, config.id .. "_root_i" .. tostring(index))
        end)
    end

    for _, child in ipairs(tree.folders) do
        local count = (query == "") and child.total_count or count_matches(child, query)
        if count > 0 then
            local child_id = config.id .. "_" .. child.name
            ui.StickyCollapsible(child.name .. " (" .. tostring(count) .. ")###" .. child_id, function()
                draw_node(config, child, child_id, query, btn_height)
            end)
        end
    end
end

function OutfitPage.init(ctx)
    ui = assert(ctx.ui, "[Self.OutfitPage] ui is required")
    lang = assert(ctx.lang, "[Self.OutfitPage] lang is required")
    action_registry = assert(ctx.action_registry, "[Self.OutfitPage] action_registry is required")
    favorites = assert(ctx.favorites, "[Self.OutfitPage] favorites is required")
    OutfitOptions.init(ctx)
end

function OutfitPage.draw()
    Spawner.OutfitFiles.snapshot()
    local tabs = {}
    for i = 1, #FORMAT_TABS do tabs[i] = _T(FORMAT_TABS[i]) end
    state.format_tab = ui.SubTabBar2(tabs, state.format_tab)

    local config = PAGE_CONFIGS[state.format_tab]
    format_state[config.id] = format_state[config.id] or { query = "" }
    local page = format_state[config.id]
    local total = #Spawner.OutfitFiles.list(config.format)
    local title = _T(config.list_title) .. " (" .. tostring(total) .. ")###" .. config.id .. "_list"

    ui.DualColumn_FixedLeft(
        function()
            ui.ScrollGroupWithSearch(title, -1, function()
                draw_outfit_list(config)
            end, page, "query", _T("Search"))
        end,
        function()
            OutfitOptions.draw(config.settings_section, config.options_title)
            if ui.Button(_T(config.delete_label) .. "##" .. config.id .. "_delete_all") then
                local count = config.delete_all()
                ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
            end
        end
    )
end

return OutfitPage
