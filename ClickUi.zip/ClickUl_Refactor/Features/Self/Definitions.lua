local CommitPolicy = require("ClickUl_Refactor.Features.Self.CommitPolicy")

local Definitions = {}

Definitions.groups = {
    {
        column = 1,
        title = "Player",
        options = {
            { kind = "checkbox", key = "godmode", label = "Godmode", path = "Player > Godmode", hint = "Become completely invincible", toggle_commit = CommitPolicy.SET_THEN_INVOKE_ON_DISABLE },
            { kind = "checkbox", key = "never_wanted", label = "Never Wanted", path = "Player > Never Wanted", hint = "Police will never chase you" },
            { kind = "checkbox", key = "no_ragdoll", label = "No Ragdoll", path = "Player > No Ragdoll", hint = "Stay on your feet when hit" },
            { kind = "checkbox", key = "no_drag", label = "Don't Drag Out of Car", path = "Player > Don't Drag Out of Car", hint = "Can't be pulled from vehicles" },
            { kind = "checkbox", key = "no_sinking", label = "No Sinking", path = "Player > No Sinking", hint = "Won't sink in water" },
            { kind = "checkbox", key = "reduced_collision", label = "Reduced Collision", path = "Player > Reduced Collision", hint = "Reduce collision damage" },
            { kind = "checkbox", key = "invisibility", label = "Invisibility", path = "Player > Invisibility", hint = "Become invisible", toggle_commit = CommitPolicy.SET_THEN_INVOKE_ON_DISABLE },
            { kind = "checkbox", key = "peds_ignore", label = "Peds Ignore Player", path = "Player > Peds Ignore Player", hint = "NPCs won't react to you" },
            { kind = "separator" },
            { kind = "toggle_slider", key = "wanted_level", label = "Wanted Level", path = "Player > Wanted Level", hint = "Set wanted level (0-5)", min = 0, max = 5, step = 1 },
            { kind = "slider_value", key = "alpha", label = "Alpha", path = "Player > Alpha", hint = "Set transparency (0-255)", min = 0, max = 255, step = 1 },
            { kind = "toggle_slider", key = "forcefield", label = "Forcefield", path = "Player > Forcefield", hint = "Set forcefield radius", min = 0.0, max = 50.0, step = 0.5 },
        },
    },
    {
        column = 1,
        title = "Health",
        options = {
            { kind = "button", key = "refill_health", label = "Refill Health", path = "Player > Health > Refill Health", hint = "Restore full health" },
            { kind = "button", key = "refill_armor", label = "Refill Armor", path = "Player > Health > Refill Armor", hint = "Restore full armor" },
            { kind = "button", key = "refill_stamina", label = "Refill Stamina", path = "Player > Health > Refill Stamina", hint = "Restore full stamina" },
            { kind = "button", key = "refill_oxygen", label = "Refill Oxygen", path = "Player > Health > Refill Oxygen", hint = "Restore full oxygen" },
            { kind = "checkbox", key = "auto_health", label = "Auto Refill Health", path = "Player > Health > Auto Refill Health", hint = "Automatically restore health" },
            { kind = "checkbox", key = "auto_armor", label = "Auto Refill Armor", path = "Player > Health > Auto Refill Armor", hint = "Automatically restore armor" },
            { kind = "checkbox", key = "auto_stamina", label = "Auto Refill Stamina", path = "Player > Health > Auto Refill Stamina", hint = "Automatically restore stamina" },
            { kind = "checkbox", key = "auto_oxygen", label = "Auto Refill Oxygen", path = "Player > Health > Auto Refill Oxygen", hint = "Automatically restore oxygen" },
            { kind = "button", key = "clear_damage", label = "Clear Visible Damage", path = "Player > Health > Clear Visible Damage", hint = "Remove blood and dirt" },
            { kind = "button", key = "clear_wetness", label = "Clear Visible Wetness", path = "Player > Health > Clear Visible Wetness", hint = "Remove water from character" },
        },
    },
    {
        column = 2,
        title = "Movement",
        options = {
            { kind = "checkbox", key = "superman", label = "Superman", path = "Player > Superman", hint = "Fly like Superman" },
            { kind = "checkbox", key = "swim_anywhere", label = "Swim Anywhere", path = "Player > Swim Anywhere", hint = "Swim in the air" },
            { kind = "checkbox", key = "unlimited_roll", label = "Unlimited Combat Roll", path = "Player > Movement > Unlimited Combat Roll", hint = "No cooldown on combat roll" },
            { kind = "checkbox", key = "no_land_anim", label = "No Land Animation", path = "Player > Movement > No Land Animation", hint = "Skip landing animation" },
            { kind = "checkbox", key = "no_speed_cap", label = "Disable Speed Cap", path = "Player > Movement > Disable Speed Cap", hint = "Remove speed limit" },
            { kind = "toggle_slider", key = "climb_ladder_speed", label = "Climb Ladder Speed", path = "Player > Movement > Climb Ladder Speed", hint = "Adjust ladder climbing speed", min = 0.0, max = 5.0, step = 0.1 },
            { kind = "separator" },
            { kind = "toggle_slider", key = "noclip", label = "Noclip", path = "Player > Movement > Noclip", hint = "Fly through walls and terrain", min = 0.0, max = 10.0, step = 0.1, toggle_commit = CommitPolicy.SET_THEN_INVOKE_ON_DISABLE },
            { kind = "toggle_slider", key = "super_jump", label = "Super Jump", path = "Player > Movement > Super Jump", hint = "Jump much higher", min = 0.0, max = 10.0, step = 0.1 },
            { kind = "toggle_slider", key = "super_run", label = "Super Run", path = "Player > Movement > Super Run", hint = "Run much faster", min = 0.0, max = 10.0, step = 0.1 },
            { kind = "toggle_slider", key = "run_mult", label = "Run Multiplier", path = "Player > Movement > Run Multiplier", hint = "Custom run speed", min = 0.0, max = 10.0, step = 0.1 },
            { kind = "toggle_slider", key = "swim_mult", label = "Swim Multiplier", path = "Player > Movement > Swim Multiplier", hint = "Custom swim speed", min = 0.0, max = 10.0, step = 0.1 },
        },
    },
    {
        column = 2,
        title = "Actions",
        options = {
            { kind = "button", key = "clone", label = "Clone", path = "Player > Clone", hint = "Clone your character" },
            { kind = "button", key = "respawn", label = "Respawn", path = "Player > Respawn", hint = "Respawn at last location" },
            { kind = "button", key = "suicide", label = "Suicide", path = "Player > Suicide", hint = "Kill yourself" },
            { kind = "button", key = "skydive", label = "Skydive", path = "Player > Skydive", hint = "Start a skydive" },
            { kind = "separator" },
            { kind = "checkbox", key = "shrink", label = "Shrink", path = "Player > Shrink", hint = "Shrink your character" },
            { kind = "checkbox", key = "dragon", label = "Dragon", path = "Player > Dragon", hint = "Dragon mode" },
            { kind = "checkbox", key = "badsport", label = "Badsport", path = "Player > Badsport", hint = "Badsport dunce cap" },
            { kind = "checkbox", key = "karma", label = "Karma", path = "Player > Karma", hint = "Karma mode" },
        },
    },
}

return Definitions
