local CommitPolicy = {}

CommitPolicy.SET_THEN_INVOKE_ON_DISABLE = "set_then_invoke_on_disable"

return CommitPolicy
