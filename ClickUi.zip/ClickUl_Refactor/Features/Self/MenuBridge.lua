local MenuBridge = {}

local menu_adapter = require("ClickUl_Refactor.Adapters.Menu")
local definitions = require("ClickUl_Refactor.Features.Self.Definitions")
local CommitPolicy = require("ClickUl_Refactor.Features.Self.CommitPolicy")

local logger = nil
local options_by_key = {}
local missing_logged = {}

local function log_missing(def)
    if missing_logged[def.key] then return end
    missing_logged[def.key] = true
    if logger then
        logger.warn("Features.Self", "Menu option missing", { key = def.key, path = def.path })
    end
end

local function cache_definition(def)
    if not def.key or not def.path then return end

    local opt = menu_adapter.find(def.path)
    if opt then
        options_by_key[def.key] = opt
        missing_logged[def.key] = nil
    else
        options_by_key[def.key] = nil
        log_missing(def)
    end
end

function MenuBridge.init(ctx)
    logger = assert(ctx.logger, "[Self.MenuBridge] logger module is required")
    MenuBridge.refresh()
end

function MenuBridge.refresh()
    for _, group in ipairs(definitions.groups) do
        for _, def in ipairs(group.options) do
            cache_definition(def)
        end
    end
end

function MenuBridge.get(def)
    if not def or not def.key then return nil end
    return options_by_key[def.key]
end

function MenuBridge.value(opt)
    return menu_adapter.get_value(opt)
end

function MenuBridge.set_value(opt, value)
    menu_adapter.set_value(opt, value)
end

function MenuBridge.toggle(opt)
    return menu_adapter.get_toggle(opt)
end

local function commit_on_disable(def, opt, value)
    if value == false and def and def.toggle_commit == CommitPolicy.SET_THEN_INVOKE_ON_DISABLE then
        menu_adapter.invoke(opt)
    end
end

function MenuBridge.set_toggle(def, opt, value)
    menu_adapter.set_toggle(opt, value)
    commit_on_disable(def, opt, value)
end

function MenuBridge.set_checkbox(def, opt, value)
    menu_adapter.set_value(opt, value)
    commit_on_disable(def, opt, value)
end

function MenuBridge.invoke(opt)
    return menu_adapter.invoke(opt)
end

return MenuBridge
