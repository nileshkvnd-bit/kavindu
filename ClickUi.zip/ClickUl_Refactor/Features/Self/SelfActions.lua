local SelfActions = {}

local definitions = require("ClickUl_Refactor.Features.Self.Definitions")
local bridge = require("ClickUl_Refactor.Features.Self.MenuBridge")
local logger = require("ClickUl_Refactor.Core.Logger")

local function action_id(def)
    return "self." .. tostring(def.key)
end

local function can_register(def)
    return def
        and def.key
        and def.label
        and def.kind ~= "separator"
end

local function can_register_hotkey(def)
    return can_register(def)
        and def.kind ~= "slider_value"
end

local function run_action(def)
    local opt = bridge.get(def)
    if not opt then
        logger.warn("Features.Self.Actions", "run skipped: menu option unavailable", { key = def and def.key, path = def and def.path })
        return
    end

    if def.kind == "button" then
        bridge.invoke(opt)
        return nil
    elseif def.kind == "checkbox" then
        local next_value = not (bridge.value(opt) == true)
        bridge.set_checkbox(def, opt, next_value)
        return next_value
    elseif def.kind == "checkbox_toggle" then
        local next_value = not (bridge.toggle(opt) == true)
        bridge.set_toggle(def, opt, next_value)
        return next_value
    elseif def.kind == "toggle_slider" then
        local next_value = not (bridge.toggle(opt) == true)
        bridge.set_toggle(def, opt, next_value)
        return next_value
    end
end

function SelfActions.action_id(def)
    return action_id(def)
end

function SelfActions.can_register(def)
    return can_register(def)
end

function SelfActions.can_register_hotkey(def)
    return can_register_hotkey(def)
end

function SelfActions.run_action(def)
    return run_action(def)
end

function SelfActions.register_hotkeys(ctx)
    local hotkeys = assert(ctx.hotkeys, "[Self.Actions] hotkeys is required")

    for _, group in ipairs(definitions.groups) do
        for _, def in ipairs(group.options) do
            if can_register_hotkey(def) then
                local def_ref = def
                hotkeys.register_action({
                    id = action_id(def_ref),
                    label = def_ref.label,
                    tab = "Self",
                    group = group.title,
                    column = group.column,
                    path = def_ref.path,
                    description = def_ref.hint,
                    when = "always",
                    notify_on_trigger = true,
                    callback = function()
                        return run_action(def_ref)
                    end,
                })
            end
        end
    end

    return true
end

function SelfActions.register_favorites(ctx)
    local action_registry = assert(ctx.action_registry, "[Self.Actions] action_registry is required")
    local option_renderer = assert(ctx.option_renderer, "[Self.Actions] option_renderer is required")

    for _, group in ipairs(definitions.groups) do
        for _, def in ipairs(group.options) do
            if can_register(def) then
                local def_ref = def
                action_registry.register({
                    id = action_id(def_ref),
                    label = def_ref.label,
                    group = group.title,
                    feature = "Self",
                    page = "Self",
                    tabs = { "Self" },
                    section = group.title,
                    column = group.column,
                    layout = "DualColumn",
                    favorite_kind = "function",
                    path = def_ref.path,
                    description = def_ref.hint,
                    is_available = function()
                        return bridge.get(def_ref) ~= nil
                    end,
                    execute = function()
                        return run_action(def_ref)
                    end,
                    render = function()
                        option_renderer.render(def_ref)
                    end,
                })
            end
        end
    end

    return true
end

return SelfActions
