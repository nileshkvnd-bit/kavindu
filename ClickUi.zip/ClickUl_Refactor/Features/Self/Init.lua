local Self = {}

local bridge = require("ClickUl_Refactor.Features.Self.MenuBridge")
local option_renderer = require("ClickUl_Refactor.Features.Self.OptionRenderer")
local general_page = require("ClickUl_Refactor.Features.Self.GeneralPage")
local outfit_page = require("ClickUl_Refactor.Features.Self.OutfitPage")
local self_actions = require("ClickUl_Refactor.Features.Self.SelfActions")

local ui = nil
local lang = nil
local logger = nil

local state = {
    main_tab = 1,
}

local function _T(text)
    local lang_module = assert(lang, "[Self] language module is required")
    return lang_module.get(text)
end

function Self.init(ctx)
    ui = assert(ctx.ui, "[Self] ui is required")
    lang = assert(ctx.lang, "[Self] lang is required")
    logger = assert(ctx.logger, "[Self] logger is required")
    local action_registry = assert(ctx.action_registry, "[Self] action_registry is required")
    local favorites = assert(ctx.favorites, "[Self] favorites is required")

    bridge.init({ logger = logger })
    option_renderer.init({ ui = ui, lang = lang, favorites = favorites })
    general_page.init({ ui = ui, lang = lang })
    outfit_page.init({ ui = ui, lang = lang, action_registry = action_registry, favorites = favorites })
    self_actions.register_hotkeys({ hotkeys = assert(ctx.hotkeys, "[Self] hotkeys is required") })
    self_actions.register_favorites({ action_registry = action_registry, option_renderer = option_renderer })

    logger.info("Features.Self", "Self module initialized")
    return true
end

function Self.on_menu_open()
    bridge.refresh()
end

function Self.draw()
    local ui_lib = assert(ui, "[Self] UI library is required")
    state.main_tab = ui_lib.SubTabBar({ _T("Player"), _T("Outfits") }, state.main_tab)
    if state.main_tab == 2 then
        outfit_page.draw()
        return
    end
    general_page.draw()
end

return Self
