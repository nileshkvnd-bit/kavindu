local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")

local OutfitOptions = {}

local ui
local lang

local SPAWN_MODE_LABELS <const> = { "Spawn Ped", "Apply to Player", "Change Player Model" }

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

local function checkbox(section, settings, label, key, hint)
    local value = ui.Checkbox(_T(label), settings[key], make_hint(label, hint))
    if settings[key] == value then return settings end
    return Spawner.Settings.update(section, { [key] = value })
end

local function spawn_mode_combo(section, settings)
    local options = {}
    for i = 1, #SPAWN_MODE_LABELS do options[i] = _T(SPAWN_MODE_LABELS[i]) end
    local current = settings.spawn_mode or 2
    local value = ui.Combo(_T("Spawn Mode"), current, options, make_hint("Spawn Mode", "Spawn a ped, apply to your player, or change your player model"))
    if current == value then return settings end
    return Spawner.Settings.update(section, { spawn_mode = value })
end

function OutfitOptions.init(ctx)
    ui = assert(ctx.ui, "[Self.OutfitOptions] ui is required")
    lang = assert(ctx.lang, "[Self.OutfitOptions] lang is required")
end

function OutfitOptions.draw(section, title)
    ui.Group(_T(title or "Outfit Options"), function()
        local settings = Spawner.Settings.get(section)
        settings = spawn_mode_combo(section, settings)

        local is_menyoo = section == "menyoo_outfit"
        settings = checkbox(section, settings, "Delete Old Outfit", "delete_old_outfit", "Remove previous outfit when applying a new one")
        settings = checkbox(section, settings, "Disable Collision", "disable_collision", "Disable collision on outfit attachments")
        settings = checkbox(section, settings, "Apply Head Features", "apply_head_features", "Apply the saved face/hair when applying to your player (rebuilds the freemode head)")

        if not is_menyoo then return end
        settings = checkbox(section, settings, "Apply Components", "apply_components", "Apply clothing component variations")
        settings = checkbox(section, settings, "Apply Props", "apply_props", "Apply head/hand prop variations")
        settings = checkbox(section, settings, "Apply Decals", "apply_decals", "Apply tattoos and logo decals")
        settings = checkbox(section, settings, "Apply Damage Packs", "apply_damage_packs", "Apply blood and damage textures")
        checkbox(section, settings, "Apply Attachments", "apply_attachments", "Spawn the outfit's attached props")
    end)
end

return OutfitOptions
