local OptionRenderer = {}

local bridge = require("ClickUl_Refactor.Features.Self.MenuBridge")
local self_actions = require("ClickUl_Refactor.Features.Self.SelfActions")

local ui = nil
local lang = nil
local favorites = nil

local function _T(text)
    return lang.get(text)
end

local function translated(value)
    return value and _T(value) or nil
end

local hint_cache = {}
local hint_cache_lang = nil

local function option_hint(def)
    local current_lang = lang.get_language()
    if hint_cache_lang ~= current_lang then
        hint_cache = {}
        hint_cache_lang = current_lang
    end

    local hint = hint_cache[def]
    if not hint then
        local text = translated(def.hint) or _T(def.label)
        hint = { text = text, description = text }

        if self_actions.can_register_hotkey(def) then
            hint.hotkey = {
                action_id = self_actions.action_id(def),
                label = _T(def.label),
                path = def.path,
            }
        end

        if self_actions.can_register(def) then
            hint.favorite = {
                action_id = self_actions.action_id(def),
                label = _T(def.label),
                path = def.path,
                is_favorite = false,
            }
        end

        hint_cache[def] = hint
    end

    if hint.favorite then
        hint.favorite.is_favorite = favorites.is_favorite(hint.favorite.action_id)
    end

    return hint
end

local function render_checkbox(def, opt)
    local cur = bridge.value(opt) or false
    local new_val = ui.Checkbox(_T(def.label), cur, option_hint(def))
    if new_val ~= cur then bridge.set_checkbox(def, opt, new_val) end
end

local function render_checkbox_toggle(def, opt)
    local cur = bridge.toggle(opt) or false
    local new_val = ui.Checkbox(_T(def.label), cur, option_hint(def))
    if new_val ~= cur then bridge.set_toggle(def, opt, new_val) end
end

local function render_button(def, opt)
    if ui.Button(_T(def.label), option_hint(def)) then
        bridge.invoke(opt)
    end
end

local function render_slider_value(def, opt)
    local cur = bridge.value(opt) or def.min or 0
    local new_val = ui.Slider(_T(def.label), cur, def.min or 0, def.max or 100, def.step or 1, option_hint(def))
    if new_val ~= cur then bridge.set_value(opt, new_val) end
end

local function render_toggle_slider(def, opt)
    local cur_toggle = bridge.toggle(opt) or false
    local cur_val = bridge.value(opt) or def.min or 0
    local new_toggle, new_val = ui.ToggleSlider(
        _T(def.label),
        cur_toggle,
        cur_val,
        def.min or 0,
        def.max or 10,
        def.step or 0.1,
        option_hint(def)
    )

    if new_toggle ~= cur_toggle then
        bridge.set_toggle(def, opt, new_toggle)
    end
    if new_val ~= cur_val then bridge.set_value(opt, new_val) end
end

function OptionRenderer.init(ctx)
    ui = assert(ctx.ui, "[Self.OptionRenderer] ui is required")
    lang = assert(ctx.lang, "[Self.OptionRenderer] lang is required")
    favorites = assert(ctx.favorites, "[Self.OptionRenderer] favorites is required")
end

function OptionRenderer.render(def)
    if def.kind == "separator" then
        ui.Separator(def.label and _T(def.label) or nil)
        return
    end

    local opt = bridge.get(def)
    if not opt then return end

    if def.kind == "checkbox" then
        render_checkbox(def, opt)
    elseif def.kind == "checkbox_toggle" then
        render_checkbox_toggle(def, opt)
    elseif def.kind == "button" then
        render_button(def, opt)
    elseif def.kind == "slider_value" then
        render_slider_value(def, opt)
    elseif def.kind == "toggle_slider" then
        render_toggle_slider(def, opt)
    end
end

return OptionRenderer
