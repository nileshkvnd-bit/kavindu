local FileBrowserPage = {}

local ui
local lang
local action_registry
local favorites

local page_state = {}

local function _T(text)
    return lang and lang.get(text) or text
end

local function search_matches(item, query)
    query = tostring(query or ""):lower()
    if query == "" then return true end
    return tostring(item.search_key or item.name or ""):lower():find(query, 1, true) ~= nil
end

local filter_cache = setmetatable({}, { __mode = "k" })

local function filtered(list, query)
    if query == "" then return list end
    local entry = filter_cache[list]
    if entry and entry.query == query then return entry.result end
    local result = {}
    for i = 1, #list do
        if search_matches(list[i], query) then result[#result + 1] = list[i] end
    end
    filter_cache[list] = { query = query, result = result }
    return result
end

local function item_key(config, item)
    return item.relative_path or config.compute_key(item.path)
end

local function action_id(config, item)
    local id = item.__fav_id
    if id then return id end
    id = config.action_prefix .. ":" .. item_key(config, item)
    item.__fav_id = id
    return id
end

local function spawn_item(config, item)
    local ok, err, detail = config.spawn(item)
    if config.detail_is_message and ok and detail and detail ~= "" then
        ui.notify(detail, err and "Warning" or "Success")
        return
    end
    if ok and err then
        local message = _T(config.spawn_text.partial) .. ": " .. tostring(err)
        if detail and detail ~= "" then message = message .. " (" .. tostring(detail) .. ")" end
        ui.notify(message, "Warning")
        return
    end
    if ok then
        local message = _T(config.spawn_text.success) .. ": " .. item.name
        if detail and detail ~= "" then message = message .. " (" .. tostring(detail) .. ")" end
        ui.notify(message, "Success")
        return
    end
    ui.notify(_T(config.spawn_text.fail) .. ": " .. tostring(err or "unknown"), "Error")
end

local hint_cache = {}

local function item_hint(config, item)
    local id = action_id(config, item)
    local active_lang = lang and lang.get_language()
    local entry = hint_cache[id]
    if not entry then
        entry = {
            hint = {
                text = _T(config.hint_text or config.list_title),
                description = item_key(config, item),
                favorite = {
                    action_id = id,
                    label = item.name,
                    path = config.path_prefix,
                    is_favorite = false,
                },
            },
            language = active_lang,
        }
        hint_cache[id] = entry
    elseif entry.language ~= active_lang then
        entry.hint.text = _T(config.hint_text or config.list_title)
        entry.language = active_lang
    end
    entry.hint.favorite.is_favorite = favorites.is_favorite(id)
    return entry.hint
end

local function register_item_action(config, item, section)
    local id = action_id(config, item)
    if action_registry.exists(id) then return end
    local action_item = { path = item.path, name = item.name, relative_path = item_key(config, item), __fav_id = id }
    action_registry.register({
        id = id,
        label = item.name,
        group = config.group,
        feature = config.feature,
        page = config.page,
        tabs = { config.page },
        section = section,
        column = 1,
        layout = "DualColumn_FixedLeft",
        favorite_kind = config.favorite_kind,
        path = config.path_prefix,
        execute = function()
            return spawn_item(config, action_item)
        end,
        render = function()
            local label = action_item.name .. "##fav_" .. id
            if ui.Button(label, item_hint(config, action_item)) then
                spawn_item(config, action_item)
            end
        end,
    })
end

local function draw_list(config, state, register)
    local query = state.query or ""
    local groups = config.groups()
    local row_height = config.selectable and ui.get_item_h() or ui.get_button_h()

    if config.total() == 0 then
        ui.Text(_T(config.empty_text))
        if config.place_text then ui.Text(_T(config.place_text)) end
        if config.place_path then ui.Text(config.place_path) end
        return
    end

    for g = 1, #groups do
        local group = groups[g]
        local items = group.items or {}
        if register then
            for i = 1, #items do
                register_item_action(config, items[i], group.title)
            end
        end

        local shown = filtered(items, query)
        if #shown > 0 then
            ui.StickyCollapsible(group.title .. " (" .. tostring(#shown) .. ")###" .. config.id .. "_" .. group.title, function()
                ui.VirtualList(shown, row_height, function(index, item)
                    local label = item.name .. "##" .. config.id .. "_" .. group.title .. "_" .. tostring(index)
                    if not config.selectable then
                        if ui.Button(label, item_hint(config, item)) then spawn_item(config, item) end
                        return
                    end
                    local key = item_key(config, item)
                    local is_selected = state.selected ~= nil and state.selected.key == key
                    if ui.Selectable(label, is_selected, nil, item_hint(config, item)) then
                        if is_selected then
                            spawn_item(config, item)
                        else
                            state.selected = { key = key, path = item.path, name = item.name }
                        end
                    end
                end)
            end)
        end
    end
end

function FileBrowserPage.init(ctx)
    ui = assert(ctx.ui, "[Common.FileBrowserPage] ui is required")
    lang = assert(ctx.lang, "[Common.FileBrowserPage] lang is required")
    action_registry = assert(ctx.action_registry, "[Common.FileBrowserPage] action_registry is required")
    favorites = assert(ctx.favorites, "[Common.FileBrowserPage] favorites is required")
end

function FileBrowserPage.register_favorited(config)
    local groups = config.groups()
    for g = 1, #groups do
        local group = groups[g]
        local items = group.items or {}
        for i = 1, #items do
            local item = items[i]
            if favorites.is_favorite(action_id(config, item)) then
                register_item_action(config, item, group.title)
            end
        end
    end
end

function FileBrowserPage.selected(config)
    local state = page_state[config.id]
    return state and state.selected or nil
end

function FileBrowserPage.clear_selected(config)
    local state = page_state[config.id]
    if state then state.selected = nil end
end

function FileBrowserPage.draw(config)
    local snap = config.snapshot()
    page_state[config.id] = page_state[config.id] or { query = "" }
    local state = page_state[config.id]
    local version = snap and snap.version
    local need_register = version == nil or state.registered_version ~= version
    if need_register then state.registered_version = version end
    local title = _T(config.list_title) .. " (" .. tostring(config.total()) .. ")###" .. config.id .. "_list"

    ui.DualColumn_FixedLeft(
        function()
            ui.ScrollGroupWithSearch(title, -1, function()
                draw_list(config, state, need_register)
            end, state, "query", _T("Search"))
        end,
        config.draw_options
    )
end

return FileBrowserPage
