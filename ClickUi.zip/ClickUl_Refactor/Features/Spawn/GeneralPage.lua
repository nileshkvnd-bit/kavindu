local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")
local VehicleCatalog = require("ClickUl_Refactor.Features.Spawn.VehicleCatalog")
local StringId = require("ClickUl_Refactor.Core.StringId")

local GeneralPage = {}

local ui
local lang
local action_registry
local favorites

local state = {
    query = "",
}

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

local function update_vehicle_setting(settings, key, value)
    if value == settings[key] then return settings end
    return Spawner.Settings.update("vehicle", { [key] = value })
end

local function checkbox_setting(settings, label, key, hint)
    local value = ui.Checkbox(_T(label), settings[key], make_hint(label, hint))
    return update_vehicle_setting(settings, key, value)
end

local function combo_setting(settings, label, key, options, hint)
    local translated = {}
    for i = 1, #(options or {}) do translated[i] = _T(options[i]) end
    local value = ui.Combo(_T(label), settings[key] or 1, translated, make_hint(label, hint))
    return update_vehicle_setting(settings, key, value)
end

local function slider_setting(settings, label, key, min, max, step, hint)
    local value = ui.Slider(_T(label), settings[key] or min, min, max, step or 1, make_hint(label, hint))
    return update_vehicle_setting(settings, key, value)
end

local function text_setting(settings, label, key, max_len)
    local value = ui.TextInput(_T(label), settings[key] or "", max_len or 32)
    return update_vehicle_setting(settings, key, value)
end


local cat_labels_cache = nil
local cat_labels_cache_lang = nil

local function category_combo_labels(cat_keys, lang_code)
    if cat_labels_cache and cat_labels_cache_lang == lang_code then return cat_labels_cache end
    local labels = {}
    for i = 1, #cat_keys do labels[i] = _T(cat_keys[i]) end
    cat_labels_cache = labels
    cat_labels_cache_lang = lang_code
    return labels
end

local function standard_color_combo(settings, label, key, id)
    local lang_code = lang.get_language()
    local cat_keys = Spawner.VehiclePreset.color_category_keys()
    local cur = settings[key] or 0
    local cat = Spawner.VehiclePreset.color_category_of(lang_code, cur)
    local combo_label = StringId.concat(_T(label), StringId.concat(" ", _T("Category")))
    local new_cat = ui.Combo(StringId.concat(combo_label, StringId.concat("##scat_", id)), cat, category_combo_labels(cat_keys, lang_code))
    if new_cat ~= cat then
        local group = Spawner.VehiclePreset.color_category(lang_code, cat_keys[new_cat])
        return update_vehicle_setting(settings, key, group.indices[1] or 0)
    end
    local group = Spawner.VehiclePreset.color_category(lang_code, cat_keys[cat])
    local pos = 1
    for i = 1, #group.indices do
        if group.indices[i] == cur then pos = i break end
    end
    local new_pos = ui.Combo(StringId.concat(_T(label), StringId.concat("##scol_", id)), pos, group.labels)
    if new_pos ~= pos then
        return update_vehicle_setting(settings, key, group.indices[new_pos])
    end
    return settings
end

local function spawn_vehicle(item)
    if not item then
        ui.notify(_T("No vehicles found"), "Error")
        return
    end

    local vehicle, err = Spawner.Vehicle.spawn_model(item.hash, { label = item.label })
    if vehicle and vehicle ~= 0 then
        ui.notify(_T("Spawned") .. ": " .. item.label, "Success")
        return
    end

    ui.notify(_T("Vehicle spawn failed") .. ": " .. tostring(err or "unknown"), "Error")
end

local function vehicle_action_id(hash)
    return "spawn.vehicle:" .. tostring(hash)
end

local vehicle_hint_cache = {}

local function vehicle_hint(item)
    local active_lang = lang.get_language()
    local entry = vehicle_hint_cache[item.hash]
    if not entry or entry.language ~= active_lang then
        local action_id = vehicle_action_id(item.hash)
        local class_label = VehicleCatalog.class_label(item.class_key)
        entry = {
            language = active_lang,
            action_id = action_id,
            hint = {
                text = _T("Spawn Vehicle"),
                description = _T("Create selected vehicle"),
                favorite = {
                    action_id = action_id,
                    label = item.label,
                    path = "Spawn / Vehicles / " .. class_label,
                    is_favorite = false,
                },
            },
        }
        vehicle_hint_cache[item.hash] = entry
    end
    entry.hint.favorite.is_favorite = favorites.is_favorite(entry.action_id)
    return entry.hint
end

local function register_vehicle_actions()
    local classes = VehicleCatalog.classes()
    local registered = {}
    for i = 1, #classes do
        local class = classes[i]
        local items = VehicleCatalog.list(class.key)
        for j = 1, #items do
            local item = items[j]
            local id = vehicle_action_id(item.hash)
            if not registered[id] then
                registered[id] = true
                local action_item = { hash = item.hash, label = item.label, class_key = class.key }
                action_registry.register({
                    id = id,
                    label = item.label,
                    group = "Spawn",
                    feature = "Spawn",
                    page = "Vehicles",
                    tabs = { "Vehicles" },
                    section = class.label,
                    column = 1,
                    layout = "DualColumn_FixedLeft",
                    favorite_kind = "vehicle",
                    path = "Spawn / Vehicles / " .. class.label,
                    description = "Create selected vehicle",
                    execute = function()
                        return spawn_vehicle(action_item)
                    end,
                    render = function()
                        local label = action_item.label .. "##favorite_spawn_vehicle_" .. tostring(action_item.hash)
                        if ui.Button(label, vehicle_hint(action_item)) then
                            spawn_vehicle(action_item)
                        end
                    end,
                })
            end
        end
    end
end

local function draw_vehicle_list()
    local query = state.query or ""
    local classes = VehicleCatalog.classes()
    local btn_height = ui.get_button_h()
    local total_count = 0

    for i = 1, #classes do
        local class = classes[i]
        local items = VehicleCatalog.filtered(class.key, query)
        if #items > 0 then
            total_count = total_count + #items
            local header = _T(class.label) .. " (" .. tostring(#items) .. ")###spawn_vehicle_class_" .. class.key
            ui.StickyCollapsible(header, function()
                ui.VirtualList(items, btn_height, function(index, item)
                    local label = item.label .. "##spawn_vehicle_" .. class.key .. "_" .. tostring(item.hash) .. "_" .. tostring(index)
                    if ui.Button(label, vehicle_hint(item)) then
                        spawn_vehicle(item)
                    end
                end)
            end)
        end
    end

    if query ~= "" and total_count == 0 then
        ui.Text(_T("No matching vehicles found"))
    elseif #classes == 0 then
        ui.Text(_T("No vehicles found"))
    end
end

local function draw_settings()
    local settings = Spawner.Settings.get("vehicle")
    ui.Group(_T("Spawn Options"), function()
        ui.Row({
            function()
                settings = checkbox_setting(settings, "Teleport to Vehicle", "in_vehicle", "Warp into spawned vehicle automatically")
            end,
            function()
                settings = checkbox_setting(settings, "Delete Old Vehicle", "delete_old_vehicle", "Remove previous vehicle when spawning new one")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Spawn Aircraft in Air", "spawn_plane_in_air", "Spawn planes and helicopters airborne")
            end,
            function()
                settings = checkbox_setting(settings, "Engine On", "vehicle_engine_on", "Start engine after spawn")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Vehicle God Mode", "vehicle_god_mode", "Vehicle becomes invincible")
            end,
            function()
                settings = checkbox_setting(settings, "Max Upgrade", "upgraded_vehicle", "Apply maximum visual upgrades")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Clean Vehicle", "clean_vehicle", "Remove dirt and damage from spawned vehicle")
            end,
            function()
                settings = checkbox_setting(settings, "Bulletproof Tires", "bulletproof_tires", "Tires cannot be shot out")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Max Performance", "max_performance", "Apply max engine, brakes, transmission upgrades")
            end,
            function()
                settings = checkbox_setting(settings, "Keep Velocity", "keep_velocity", "Maintain speed when switching vehicles")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Random Color", "random_color", "Apply a random color")
            end,
            function()
                settings = checkbox_setting(settings, "Random Livery", "random_livery", "Apply a random livery")
            end,
        })

        ui.Row({
            function()
                settings = checkbox_setting(settings, "Radio Off", "radio_off", "Disable vehicle radio")
            end,
        })

        ui.Row({
            function()
                if ui.Button(_T("Delete Current Vehicle"), make_hint("Delete Current Vehicle", "Remove the vehicle you are in")) then
                    if Spawner.Vehicle.delete_current() then
                        ui.notify(_T("Vehicle deleted"), "Info")
                    else
                        ui.notify(_T("Please enter a vehicle first"), "Warning")
                    end
                end
            end,
            function()
                if ui.Button(_T("Delete Spawned Vehicles")) then
                    local count = Spawner.Vehicle.delete_all()
                    ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
                end
            end,
        })
    end)

    settings = checkbox_setting(settings, "Enable Presets", "use_preset", "Apply color and mod presets when spawning")

    ui.Group(_T("Primary Tone"), function()
        settings = standard_color_combo(settings, "Primary Color", "primary_color", "pricol")
        settings = standard_color_combo(settings, "Pearlescent", "pearlescent_id", "pearl")
    end)

    ui.Group(_T("Secondary Tone"), function()
        settings = standard_color_combo(settings, "Secondary Color", "secondary_color", "seccol")
    end)

    ui.Group(_T("Other Colors"), function()
        settings = standard_color_combo(settings, "Wheel Color", "wheel_color_id", "wclr")
    end)

    ui.Group(_T("Horn"), function()
        local horns = Spawner.VehicleEditor.horn_preset_names()
        local names = {}
        local cur_pos = 1
        for i = 1, #horns do
            names[i] = (horns[i].id == -1) and _T("Stock") or horns[i].name
            if horns[i].id == (settings.horn_id or -1) then cur_pos = i end
        end
        local new_pos = ui.Combo(_T("Horn"), cur_pos, names, make_hint("Horn"))
        if new_pos ~= cur_pos then
            settings = update_vehicle_setting(settings, "horn_id", horns[new_pos].id)
        end
    end)

    ui.Group(_T("Lights"), function()
        ui.Row({
            function()
                settings = combo_setting(settings, "Xenon Lights", "xenon_color", Spawner.VehiclePreset.xenon_names())
            end,
            function()
                settings = combo_setting(settings, "Neon Lights", "neon_color", Spawner.VehiclePreset.neon_names())
            end,
        })
    end)

    ui.Group(_T("Wheels"), function()
        local wheel_types = { _T("Stock") }
        for _, name in ipairs(Spawner.VehicleEditor.wheel_type_names()) do wheel_types[#wheel_types + 1] = name end
        settings = combo_setting(settings, "Wheel Type", "wheel_type", wheel_types)
        local wheel_style_max = -1
        if (settings.wheel_type or 1) >= 2 then
            wheel_style_max = Spawner.VehicleEditor.wheel_style_count((settings.wheel_type or 1) - 2) - 1
            if wheel_style_max < -1 then wheel_style_max = -1 end
        end
        settings = slider_setting(settings, "Wheel Style", "wheel_index", -1, wheel_style_max, 1)
        ui.Row({
            function()
                settings = checkbox_setting(settings, "Custom Tires", "custom_tires", "Apply custom tire variant")
            end,
            function()
                settings = combo_setting(settings, "Tire Smoke", "tire_smoke_color", Spawner.VehiclePreset.smoke_names())
            end,
        })
    end)

    ui.Group(_T("Windows"), function()
        settings = combo_setting(settings, "Window Tint", "window_tint", Spawner.VehiclePreset.window_tints())
    end)

    ui.Group(_T("License Plate"), function()
        settings = combo_setting(settings, "Plate Style", "plate_type", Spawner.VehiclePreset.plate_types())
        settings = text_setting(settings, "Plate Text", "plate_text", 8)
    end)
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[Spawn.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[Spawn.GeneralPage] lang is required")
    action_registry = assert(ctx.action_registry, "[Spawn.GeneralPage] action_registry is required")
    favorites = assert(ctx.favorites, "[Spawn.GeneralPage] favorites is required")
    VehicleCatalog.preload()
    register_vehicle_actions()
end

local function draw_vehicle_column()
    ui.ScrollGroupWithSearch(_T("Vehicles"), -1, draw_vehicle_list, state, "query", _T("Search"))
end

function GeneralPage.draw()
    ui.DualColumn_FixedLeft(draw_vehicle_column, draw_settings)
end

return GeneralPage
