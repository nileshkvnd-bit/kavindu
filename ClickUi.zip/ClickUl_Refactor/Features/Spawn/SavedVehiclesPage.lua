local FileBrowserPage = require("ClickUl_Refactor.Features.Common.FileBrowserPage")
local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")
local VehicleOptions = require("ClickUl_Refactor.Features.Spawn.VehicleOptions")
local StringId = require("ClickUl_Refactor.Core.StringId")

local SavedVehiclesPage = {}

local ui
local lang

local FORMATS <const> = { "Lexis", "Stand", "Cherax" }

local save_state = { name = "" }

local function _T(text)
    return lang and lang.get(text) or text
end

local function vehicle_label(record)
    local path = record.file_path
    if path then
        return path:match("([^/\\]+)%.[^.]+$") or path:match("([^/\\]+)$") or "Vehicle"
    end
    return "Vehicle"
end

local function draw_spawned_vehicles()
    local vehicles = Spawner.SavedVehicle.get_spawned() or {}
    if #vehicles == 0 then return end
    ui.Group(_T("Spawned Vehicles") .. ": " .. tostring(#vehicles), function()
        for index, record in ipairs(vehicles) do
            local name = vehicle_label(record)
            local count = (record.entities and #record.entities) or 0
            local label = name .. " (" .. tostring(count) .. " " .. _T("entities") .. ")"
            if ui.Button(StringId.concat(label, StringId.concat("##saved_vehicles_spawned_", index))) then
                Spawner.SavedVehicle.delete(index)
                ui.notify(_T("Vehicle deleted") .. ": " .. name, "Info")
            end
        end
        if ui.Button(StringId.concat(_T("Delete All Vehicles"), "##saved_vehicles_delete_all")) then
            local count = Spawner.SavedVehicle.delete_all()
            ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
        end
    end)
end

local function total_count()
    local n = 0
    for _, format in ipairs(FORMATS) do n = n + #Spawner.SavedVehicle.list(format) end
    return n
end

local function save_group_body()
    local new_name = ui.TextInput(StringId.concat(_T("Filename"), "##save"), save_state.name, 32)
    if new_name ~= save_state.name then save_state.name = new_name end

    if ui.Button(_T("Save as Lexis Format")) then
        local path, err = Spawner.SavedVehicle.save_current(save_state.name)
        if path then
            ui.notify(_T("Vehicle saved") .. ": " .. save_state.name, "Success")
            return
        end
        if err == "missing_filename" then
            ui.notify(_T("Please enter a filename"), "Warning")
            return
        end
        ui.notify(_T("Failed to save file") .. ": " .. tostring(err or "unknown"), "Error")
    end
end

local function draw_save_group()
    ui.Group(_T("Save Current Vehicle"), save_group_body)
end

local JSON_SAVED_OPTS <const> = { saved_vehicle = true }

local function options_group_body()
    if ui.Button(_T("Refresh Vehicle List")) then
        Spawner.SavedVehicle.refresh()
        ui.notify(_T("Vehicles loaded") .. ": " .. tostring(total_count()), "Success")
    end
    ui.Separator()
    VehicleOptions.draw_fields("json", JSON_SAVED_OPTS)
end

local CONFIG <const> = {
    id = "saved_vehicles",
    list_title = "Saved Vehicles",
    hint_text = "Spawn Vehicle",
    action_prefix = "spawn.saved_vehicle",
    favorite_kind = "vehicle",
    group = "Spawn",
    feature = "Spawn",
    page = "Saved Vehicles",
    path_prefix = "Spawn / Saved Vehicles",
    empty_text = "No vehicle files found",
    spawn_text = {
        success = "Spawned",
        partial = "Vehicle attachments failed",
        fail = "Vehicle spawn failed",
    },
    snapshot = function() return Spawner.SavedVehicle.snapshot() end,
    total = total_count,
    groups = function()
        local groups = {}
        for _, format in ipairs(FORMATS) do
            groups[#groups + 1] = { title = format, items = Spawner.SavedVehicle.list(format) }
        end
        return groups
    end,
    compute_key = function(path) return Spawner.SavedVehicle.relative_path(path) end,
    spawn = function(item)
        local root, _, err = Spawner.SavedVehicle.spawn_file(item)
        return (root ~= nil and root ~= 0), err
    end,
    draw_options = function()
        draw_save_group()
        ui.Group(_T("Options"), options_group_body)
        draw_spawned_vehicles()
    end,
}

function SavedVehiclesPage.init(ctx)
    ui = assert(ctx.ui, "[Spawn.SavedVehiclesPage] ui is required")
    lang = assert(ctx.lang, "[Spawn.SavedVehiclesPage] lang is required")
    FileBrowserPage.init(ctx)
    VehicleOptions.init(ctx)
    FileBrowserPage.register_favorited(CONFIG)
end

function SavedVehiclesPage.draw()
    FileBrowserPage.draw(CONFIG)
end

return SavedVehiclesPage
