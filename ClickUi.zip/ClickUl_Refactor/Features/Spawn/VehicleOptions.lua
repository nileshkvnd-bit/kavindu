local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")

local VehicleOptions = {}

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

local function update_setting(section, settings, key, value)
    if settings[key] == value then return settings end
    return Spawner.Settings.update(section, { [key] = value })
end

local function checkbox(section, settings, label, key, hint)
    local value = ui.Checkbox(_T(label), settings[key], make_hint(label, hint))
    return update_setting(section, settings, key, value)
end

function VehicleOptions.init(ctx)
    ui = assert(ctx.ui, "[Spawn.VehicleOptions] ui is required")
    lang = assert(ctx.lang, "[Spawn.VehicleOptions] lang is required")
end

function VehicleOptions.draw_fields(section, opts)
    opts = opts or {}
    local settings = Spawner.Settings.get(section)

    ui.Row({
        function()
            settings = checkbox(section, settings, "Delete Old Vehicle", "delete_old_vehicle", "Remove previous vehicle when spawning new one")
        end,
        function()
            settings = checkbox(section, settings, "Teleport to Vehicle", "in_vehicle", "Warp into spawned vehicle automatically")
        end,
    })

    ui.Row({
        function()
            settings = checkbox(section, settings, "Auto Start Engine", "vehicle_engine_on", "Start engine after spawn")
        end,
        function()
            settings = checkbox(section, settings, "Vehicle God Mode", "vehicle_god_mode", "Vehicle becomes invincible")
        end,
    })

    ui.Row({
        function()
            settings = checkbox(section, settings, "Radio Off", "radio_off", "Disable vehicle radio")
        end,
    })

    ui.Separator()

    ui.Row({
        function()
            settings = checkbox(section, settings, "Spawn Plane in Air", "spawn_plane_in_air", "Spawn planes and helicopters airborne")
        end,
        function()
            settings = checkbox(section, settings, "Max Upgrade", "upgraded_vehicle", "Apply maximum visual upgrades")
        end,
    })

    if opts.enable_ptfx then
        ui.Row({
            function()
                settings = checkbox(section, settings, "Enable Looped PTFX", "enable_ptfx", "Enable looped particle effects")
            end,
        })
    end

    ui.Row({
        function()
            local key = opts.saved_vehicle and "saved_vehicle_use_preset" or "use_preset"
            settings = checkbox(section, settings, "Apply Vehicle Preset", key, "Apply configured vehicle preset after spawning")
        end,
    })
end

function VehicleOptions.draw(section, title, opts)
    ui.Group(_T(title or "Spawn Options"), function()
        VehicleOptions.draw_fields(section, opts)
    end)
end

return VehicleOptions
