local general_page = require("ClickUl_Refactor.Features.Spawn.GeneralPage")
local saved_vehicles_page = require("ClickUl_Refactor.Features.Spawn.SavedVehiclesPage")
local file_vehicle_page = require("ClickUl_Refactor.Features.Spawn.FileVehiclePage")
local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")

local Spawn = {}

local ui
local lang
local logger

local function _T(text)
    return lang and lang.get(text) or text
end

local MAIN_TABS <const> = { "Vehicles", "Saved Vehicles", "Menyoo Vehicle", "INI Vehicle", "JSON Vehicle" }

local state = {
    main_tab = 1,
}

function Spawn.init(ctx)
    ui = assert(ctx.ui, "[Spawn] ui is required")
    lang = assert(ctx.lang, "[Spawn] lang is required")
    logger = assert(ctx.logger, "[Spawn] logger is required")
    local action_registry = assert(ctx.action_registry, "[Spawn] action_registry is required")
    local favorites = assert(ctx.favorites, "[Spawn] favorites is required")
    Spawner.Settings.bind_storage(assert(ctx.settings, "[Spawn] settings module is required"))

    local page_ctx = { ui = ui, lang = lang, action_registry = action_registry, favorites = favorites }
    general_page.init(page_ctx)
    saved_vehicles_page.init(page_ctx)
    file_vehicle_page.init(page_ctx)

    logger.info("Features.Spawn", "Spawn module initialized")
    return true
end

function Spawn.draw()
    local ui_lib = assert(ui, "[Spawn] UI library is required")
    local tabs = {}
    for i = 1, #MAIN_TABS do tabs[i] = _T(MAIN_TABS[i]) end
    state.main_tab = ui_lib.SubTabBar(tabs, state.main_tab)

    if state.main_tab == 1 then
        general_page.draw()
    elseif state.main_tab == 2 then
        saved_vehicles_page.draw()
    elseif state.main_tab == 3 then
        file_vehicle_page.draw("menyoo")
    elseif state.main_tab == 4 then
        file_vehicle_page.draw("ini")
    elseif state.main_tab == 5 then
        file_vehicle_page.draw("json")
    end
end

return Spawn
