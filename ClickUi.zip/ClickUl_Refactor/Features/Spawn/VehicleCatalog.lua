local VehicleCatalog = {}

local Models = require("ClickUl_Refactor.Adapters.Models")

local tostring <const> = tostring
local tonumber <const> = tonumber
local string_lower <const> = string.lower
local table_sort <const> = table.sort

local DEFAULT_CLASS_KEY <const> = "compacts"

local CLASS_LABELS <const> = {
    compacts = "Compacts",
    sedans = "Sedans",
    suvs = "SUVs",
    coupes = "Coupes",
    muscle = "Muscle",
    sports_classics = "Sports Classics",
    sports = "Sports",
    super = "Super",
    motorcycles = "Motorcycles",
    off_road = "Off-Road",
    industrial = "Industrial",
    utility = "Utility",
    vans = "Vans",
    cycles = "Cycles",
    boats = "Boats",
    helicopters = "Helicopters",
    planes = "Planes",
    service = "Service",
    emergency = "Emergency",
    military = "Military",
    commercial = "Commercial",
    trains = "Trains",
    open_wheel = "Open Wheel",
}

local cache = {
    classes = nil,
    lists = {},
    filtered = {},
    preloaded = false,
}

local function normalize_class_key(class_key)
    if class_key == nil or class_key == "" then return DEFAULT_CLASS_KEY end
    return tostring(class_key)
end

local function label_for_model(hash)
    return Models.vehicle_display_name(hash)
end

local function sort_items(a, b)
    if a.label == b.label then return tostring(a.hash) < tostring(b.hash) end
    return a.label < b.label
end

local function build_items(hashes, class_key)
    local items = {}
    local seen = {}

    if type(hashes) ~= "table" then return items end

    for i = 1, #hashes do
        local hash = tonumber(hashes[i])
        if hash and hash ~= 0 and not seen[hash] then
            seen[hash] = true
            local label = label_for_model(hash)
            items[#items + 1] = {
                hash = hash,
                label = label,
                class_key = class_key,
                search = string_lower(label .. " " .. tostring(hash)),
            }
        end
    end

    table_sort(items, sort_items)
    return items
end

function VehicleCatalog.class_label(class_key)
    return CLASS_LABELS[normalize_class_key(class_key)] or tostring(class_key or "")
end

function VehicleCatalog.classes()
    if cache.classes then return cache.classes end

    local classes = {}
    local api_classes = Models.vehicle_classes()
    for i = 1, #api_classes do
        local key = api_classes[i].key
        classes[#classes + 1] = {
            key = key,
            label = VehicleCatalog.class_label(key),
        }
    end

    cache.classes = classes
    return classes
end

function VehicleCatalog.refresh(class_key)
    class_key = normalize_class_key(class_key)
    local items = build_items(Models.vehicles_from_class(class_key), class_key)
    cache.lists[class_key] = items
    return items
end

function VehicleCatalog.preload()
    if cache.preloaded then return true end

    local classes = VehicleCatalog.classes()
    for i = 1, #classes do
        VehicleCatalog.refresh(classes[i].key)
    end

    if #classes == 0 then VehicleCatalog.refresh(DEFAULT_CLASS_KEY) end
    cache.preloaded = true
    return true
end

function VehicleCatalog.list(class_key)
    class_key = normalize_class_key(class_key)
    return cache.lists[class_key] or {}
end

function VehicleCatalog.filtered(class_key, query)
    class_key = normalize_class_key(class_key)
    local items = VehicleCatalog.list(class_key)
    query = string_lower(tostring(query or ""))
    if query == "" then return items end

    local entry = cache.filtered[class_key]
    if entry and entry.query == query and entry.source == items then return entry.result end

    local result = {}
    for i = 1, #items do
        local item = items[i]
        if item.search:find(query, 1, true) then result[#result + 1] = item end
    end
    cache.filtered[class_key] = { query = query, result = result, source = items }
    return result
end

return VehicleCatalog
