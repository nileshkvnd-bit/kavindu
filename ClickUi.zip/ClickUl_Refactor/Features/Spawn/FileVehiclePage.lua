local FileBrowserPage = require("ClickUl_Refactor.Features.Common.FileBrowserPage")
local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")
local VehicleOptions = require("ClickUl_Refactor.Features.Spawn.VehicleOptions")
local StringId = require("ClickUl_Refactor.Core.StringId")

local FileVehiclePage = {}

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

local function vehicle_label(record)
    local path = record.file_path
    if path then
        return path:match("([^/\\]+)%.[^.]+$") or path:match("([^/\\]+)$") or "Vehicle"
    end
    return "Vehicle"
end

local function draw_spawned_vehicles(scfg)
    local vehicles = scfg.get_spawned() or {}
    if #vehicles == 0 then return end
    ui.Group(_T("Spawned Vehicles") .. ": " .. tostring(#vehicles), function()
        for index, record in ipairs(vehicles) do
            local name = vehicle_label(record)
            local count = (record.entities and #record.entities) or 0
            local label = name .. " (" .. tostring(count) .. " " .. _T("entities") .. ")"
            if ui.Button(label .. "##" .. StringId.concat(StringId.concat(scfg.id, "_spawned_"), index)) then
                scfg.delete(index)
                ui.notify(_T("Vehicle deleted") .. ": " .. name, "Info")
            end
        end
        if ui.Button(_T("Delete All Vehicles") .. "##" .. StringId.concat(scfg.id, "_delete_all")) then
            local count = scfg.delete_all()
            ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
        end
    end)
end

local groups_cache = setmetatable({}, { __mode = "k" })

local function to_groups(folders)
    local cached = groups_cache[folders]
    if cached then return cached end
    local groups = {}
    local names = folders.folder_names or {}
    local by = folders.by_folder or {}
    for i = 1, #names do
        local name = names[i]
        groups[#groups + 1] = { title = name, items = by[name] or {} }
    end
    groups_cache[folders] = groups
    return groups
end

local SPAWN_TEXT <const> = {
    success = "Spawned",
    partial = "Vehicle attachments failed",
    fail = "Vehicle spawn failed",
}

local function options_with_spawned(settings_section, options_title, enable_ptfx, spawned_cfg)
    return function()
        VehicleOptions.draw(settings_section, options_title, { enable_ptfx = enable_ptfx })
        draw_spawned_vehicles(spawned_cfg)
    end
end

local CONFIGS <const> = {
    menyoo = {
        id = "menyoo_vehicles",
        list_title = "Menyoo Vehicles",
        hint_text = "Spawn Vehicle",
        action_prefix = "spawn.menyoo_vehicle",
        favorite_kind = "vehicle",
        group = "Spawn",
        feature = "Spawn",
        page = "Menyoo Vehicle",
        path_prefix = "Spawn / Menyoo Vehicles",
        empty_text = "No Menyoo vehicles found",
        place_text = "Place .xml files in:",
        place_path = "Vehicles/Menyoo/",
        spawn_text = SPAWN_TEXT,
        snapshot = function() return Spawner.VehicleFiles.snapshot() end,
        total = function() return #Spawner.VehicleFiles.list("Menyoo") end,
        groups = function() return to_groups(Spawner.VehicleFiles.folders("Menyoo")) end,
        compute_key = function(path) return Spawner.VehicleFiles.relative_path(path) end,
        spawn = function(item)
            local root, _, err = Spawner.Menyoo.Vehicle.spawn_file(item.path)
            return (root ~= nil and root ~= 0), err
        end,
        draw_options = options_with_spawned("menyoo", "Menyoo Options", true, {
            id = "menyoo_vehicles",
            get_spawned = function() return Spawner.Menyoo.Vehicle.get_spawned() end,
            delete = function(index) return Spawner.Menyoo.Vehicle.delete(index) end,
            delete_all = function() return Spawner.Menyoo.Vehicle.delete_all() end,
        }),
    },
    ini = {
        id = "ini_vehicles",
        list_title = "INI Vehicles",
        hint_text = "Spawn Vehicle",
        action_prefix = "spawn.ini_vehicle",
        favorite_kind = "vehicle",
        group = "Spawn",
        feature = "Spawn",
        page = "INI Vehicle",
        path_prefix = "Spawn / INI Vehicles",
        empty_text = "No INI vehicles found",
        place_text = "Place .ini files in:",
        place_path = "Vehicles/INI/",
        spawn_text = SPAWN_TEXT,
        snapshot = function() return Spawner.VehicleFiles.snapshot() end,
        total = function() return #Spawner.VehicleFiles.list("INI") end,
        groups = function() return to_groups(Spawner.VehicleFiles.folders("INI")) end,
        compute_key = function(path) return Spawner.VehicleFiles.relative_path(path) end,
        spawn = function(item)
            local root, _, err = Spawner.Ini.Vehicle.spawn_file(item.path)
            return (root ~= nil and root ~= 0), err
        end,
        draw_options = options_with_spawned("ini", "INI Options", false, {
            id = "ini_vehicles",
            get_spawned = function() return Spawner.Ini.Vehicle.get_spawned() end,
            delete = function(index) return Spawner.Ini.Vehicle.delete(index) end,
            delete_all = function() return Spawner.Ini.Vehicle.delete_all() end,
        }),
    },
    json = {
        id = "json_vehicles",
        list_title = "JSON Vehicles",
        hint_text = "Spawn Vehicle",
        action_prefix = "spawn.json_vehicle",
        favorite_kind = "vehicle",
        group = "Spawn",
        feature = "Spawn",
        page = "JSON Vehicle",
        path_prefix = "Spawn / JSON Vehicles",
        empty_text = "No JSON vehicles found",
        place_text = "Place .json files in:",
        place_path = "Vehicles/Json/",
        spawn_text = SPAWN_TEXT,
        snapshot = function() return Spawner.VehicleFiles.snapshot() end,
        total = function() return #Spawner.VehicleFiles.list("JSON") end,
        groups = function() return to_groups(Spawner.VehicleFiles.folders("JSON")) end,
        compute_key = function(path) return Spawner.VehicleFiles.relative_path(path) end,
        spawn = function(item)
            local root, _, err = Spawner.Json.Vehicle.spawn_file(item.path)
            return (root ~= nil and root ~= 0), err
        end,
        draw_options = options_with_spawned("json", "JSON Options", false, {
            id = "json_vehicles",
            get_spawned = function() return Spawner.Json.Vehicle.get_spawned() end,
            delete = function(index) return Spawner.Json.Vehicle.delete(index) end,
            delete_all = function() return Spawner.Json.Vehicle.delete_all() end,
        }),
    },
}

function FileVehiclePage.init(ctx)
    ui = assert(ctx.ui, "[Spawn.FileVehiclePage] ui is required")
    lang = assert(ctx.lang, "[Spawn.FileVehiclePage] lang is required")
    FileBrowserPage.init(ctx)
    VehicleOptions.init(ctx)
    for _, config in pairs(CONFIGS) do
        FileBrowserPage.register_favorited(config)
    end
end

function FileVehiclePage.draw(format_key)
    FileBrowserPage.draw(CONFIGS[format_key])
end

return FileVehiclePage
