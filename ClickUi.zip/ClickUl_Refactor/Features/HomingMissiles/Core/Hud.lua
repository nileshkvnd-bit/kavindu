local Hud = {}

local HudDraw = require("ClickUl_Refactor.Core.HudDraw")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Projection = require("ClickUl_Refactor.Core.Projection")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local math_abs <const> = math.abs
local math_max <const> = math.max
local math_min <const> = math.min
local math_sqrt <const> = math.sqrt
local string_format <const> = string.format

local LOCKON_TXD <const> = "mpsubmarine_periscope"
local LOCKON_TEXTURE <const> = "target_default"

local MARKER_MIN_PX <const> = 22
local MARKER_MAX_PX <const> = 500
local MARKER_BASE_PX <const> = 45
local MARKER_PADDING <const> = 1.15
local DEFAULT_EXTENT_M <const> = 2.4
local MARKER_FIXED_PX <const> = 80

local BAR_CENTER_X <const> = 0.90
local BAR_CENTER_Y <const> = 0.92
local BAR_WIDTH <const> = 0.12
local BAR_HEIGHT <const> = 0.02

local AMBER <const> = { r = 255, g = 165, b = 0, a = 200 }
local RED <const> = { r = 255, g = 0, b = 0, a = 255 }
local BAR_BG <const> = { r = 0, g = 0, b = 0, a = 150 }
local BAR_READY <const> = { r = 0, g = 255, b = 0, a = 200 }
local BAR_CHARGING <const> = { r = 255, g = 50, b = 50, a = 200 }
local BAR_BORDER <const> = { r = 255, g = 255, b = 255, a = 255 }
local TEXT_WHITE <const> = { r = 255, g = 255, b = 255, a = 200 }

local lang = nil

local function _T(text)
    if lang then return lang.get(text) end
    return text
end

local TXD_RETRY_FRAMES <const> = 30
local txd_retry = 0

local function ensure_texture()
    if Native.call("has_streamed_texture_dict_loaded", LOCKON_TXD) then return true end
    if txd_retry > 0 then
        txd_retry = txd_retry - 1
        return false
    end
    txd_retry = TXD_RETRY_FRAMES
    Request.dict(LOCKON_TXD)
    return false
end

local function target_extent(slot)
    local dims = ModelDims.get(slot.model_hash)
    if not dims then return DEFAULT_EXTENT_M end
    local extent = math_max(
        math_abs(dims.max.x - dims.min.x),
        math_abs(dims.max.y - dims.min.y),
        math_abs(dims.max.z - dims.min.z))
    if extent < 0.5 or extent > 30 then return DEFAULT_EXTENT_M end
    return extent
end

local function marker_size_px(state, slot, pos, screen, px_scale)
    if not state.cfg.use_auto_marker_size then return MARKER_FIXED_PX * px_scale end
    local fallback = MARKER_BASE_PX * px_scale
    local up = Projection.world_to_screen({ x = pos.x, y = pos.y, z = pos.z + 1.0 })
    if not up then return fallback end
    local dx, dy = up.x - screen.x, up.y - screen.y
    local px_per_m = math_sqrt(dx * dx + dy * dy)
    if px_per_m < 0.5 then return fallback end
    local size = target_extent(slot) * MARKER_PADDING * px_per_m
    return math_max(MARKER_MIN_PX * px_scale, math_min(MARKER_MAX_PX * px_scale, size))
end

local function draw_lock_markers(state)
    if #state.slots == 0 then return end
    if not ensure_texture() then return end
    local px_scale = Runtime.resolution().y / 1080
    for i = 1, #state.slots do
        local slot = state.slots[i]
        local pos = slot.pos
        local screen = pos and Projection.world_to_screen(pos)
        if screen then
            local size = marker_size_px(state, slot, pos, screen, px_scale)
            if not slot.confirmed then size = size * 0.85 end
            HudDraw.draw_sprite_screen(LOCKON_TXD, LOCKON_TEXTURE, screen.x, screen.y,
                size, size, 0.0, slot.confirmed and RED or AMBER)
        end
    end
end

local targets_text = { slots = -1, max = -1, language = nil, text = "" }

local function targets_text_for(state)
    local slots, max = #state.slots, state.cfg.max_targets
    local language = lang and lang.get_language() or nil
    if targets_text.slots ~= slots or targets_text.max ~= max or targets_text.language ~= language then
        targets_text.slots = slots
        targets_text.max = max
        targets_text.language = language
        targets_text.text = string_format("%s: %d/%d", _T("Targets"), slots, max)
    end
    return targets_text.text
end

local function draw_charge_bar(state)
    local resolution = Runtime.resolution()
    local width = BAR_WIDTH * resolution.x
    local height = BAR_HEIGHT * resolution.y
    local x = BAR_CENTER_X * resolution.x - width * 0.5
    local y = BAR_CENTER_Y * resolution.y - height * 0.5

    HudDraw.draw_rect(x, y, width, height, BAR_BG)

    local fill_color = state.is_recharging and BAR_CHARGING or BAR_READY
    local progress = math_max(0.0, math_min(1.0, (state.charge_level or 100) / 100.0))
    if progress > 0 then
        HudDraw.draw_rect(x, y, width * progress, height, fill_color)
    end

    HudDraw.draw_rect(x, y, width, 1, BAR_BORDER)
    HudDraw.draw_rect(x, y + height - 1, width, 1, BAR_BORDER)
    HudDraw.draw_rect(x, y, 1, height, BAR_BORDER)
    HudDraw.draw_rect(x + width - 1, y, 1, height, BAR_BORDER)

    local font = math_max(12, math_min(24, (15 * resolution.y) // 1080))
    local text_y = y - font - 4
    HudDraw.overlay_text(state.is_recharging and _T("Charging") or _T("Ready"), x, text_y, font, fill_color)
    HudDraw.overlay_text(targets_text_for(state), x + width, text_y, font, TEXT_WHITE, "right")
end

function Hud.init(ctx)
    lang = ctx and ctx.lang or lang
end

function Hud.tick(state)
    local cfg = state.cfg
    if cfg.enable_lock_markers then draw_lock_markers(state) end
    if cfg.enable_charge_bar then draw_charge_bar(state) end
end

return Hud
