local Launcher = {}

local Input = require("ClickUl_Refactor.Adapters.Input")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Hotkeys = require("ClickUl_Refactor.Core.Hotkeys")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")
local Targeting = require("ClickUl_Refactor.Features.HomingMissiles.Core.Targeting")

local CONTROL_GROUP <const> = 0
local SHOT_DELAY_MS <const> = 300
local RECHARGE_MS <const> = 2000
local DISABLE_CONTROLS <const> = { 25, 68, 69, 70, 92, 99, 100, 114, 115, 262, 331 }
local FIRE_ACTION_ID <const> = "homing.fire"
local MOUSE_VKS <const> = { [0x01] = true, [0x02] = true, [0x04] = true, [0x05] = true, [0x06] = true }
local BINDING_REFRESH_TICKS <const> = 30
local AUTO_MARGIN_X <const> = 0.3
local AUTO_MARGIN_Y <const> = 0.15

local math_sin <const> = math.sin
local math_cos <const> = math.cos
local math_rad <const> = math.rad

function Launcher.reset(state)
    state.shot_count = 0
    state.last_shot_ms = 0
    state.weapon_side = 0
    state.is_recharging = false
    state.recharge_start_ms = 0
    state.charge_level = 100
end

function Launcher.disable_controls()
    for i = 1, #DISABLE_CONTROLS do
        Input.disable_control(CONTROL_GROUP, DISABLE_CONTROLS[i], true)
    end
end

local fire_bindings = nil
local fire_bindings_age = BINDING_REFRESH_TICKS

local MOUSE_VK_CONTROLS <const> = { [0x01] = 24, [0x02] = 25 }

local function vk_held(vk)
    local key_state = MOUSE_VKS[vk] and Input.mouse(vk) or Input.key(vk)
    if key_state and key_state.pressed then return true end
    local control = MOUSE_VK_CONTROLS[vk]
    if control and Input.disabled_pressed(CONTROL_GROUP, control) then return true end
    return false
end

local function binding_held(binding)
    if not binding then return false end
    if not vk_held(binding.vk) then return false end
    if binding.ctrl and not (vk_held(0xA2) or vk_held(0xA3)) then return false end
    if binding.shift and not (vk_held(0xA0) or vk_held(0xA1)) then return false end
    if binding.alt and not (vk_held(0xA4) or vk_held(0xA5)) then return false end
    return true
end

local function fire_held(state)
    if state.menu_open then return false end
    if not Hotkeys.is_enabled() then return false end
    fire_bindings_age = fire_bindings_age + 1
    if not fire_bindings or fire_bindings_age >= BINDING_REFRESH_TICKS then
        fire_bindings = Hotkeys.get_bindings(FIRE_ACTION_ID)
        fire_bindings_age = 0
    end
    return binding_held(fire_bindings[1]) or binding_held(fire_bindings[2])
end

local function charge_ok(state, now)
    if not state.is_recharging then return true end
    if now < state.recharge_start_ms then state.recharge_start_ms = now end
    local actual = RECHARGE_MS / state.cfg.recharge_speed
    state.charge_level = 100 * (now - state.recharge_start_ms) / actual
    if state.charge_level >= 100 then
        state.is_recharging = false
        state.charge_level = 100
        state.shot_count = 0
        Targeting.clear_shot_flags(state)
    end
    return not state.is_recharging
end

local function launch_offset(state, side)
    local cfg = state.cfg
    if cfg.use_auto_dimensions then
        local dims = ModelDims.get(state.my_vehicle_model)
        if dims then
            local ox = (side == 0) and (dims.max.x - AUTO_MARGIN_X) or (dims.min.x + AUTO_MARGIN_X)
            return ox + 0.0, (dims.max.y - AUTO_MARGIN_Y) + 0.0
        end
    end
    local ox = (side == 0) and cfg.missile_offset_x or -cfg.missile_offset_x
    return ox + 0.0, cfg.missile_offset_y + 0.0
end

local function shoot_missile(state, target_entity, side)
    local cfg = state.cfg
    local veh = state.my_vehicle
    local ox, oy = launch_offset(state, side)
    local launch = Native.get_offset_from_entity_in_world_coords(veh, ox, oy, cfg.missile_offset_z + 0.0)
    if not (launch and launch.x) then return false end

    local rot = Native.get_entity_rotation(veh, 2)
    local z_rad = math_rad(rot and rot.z or 0.0)
    local dir_x, dir_y = -math_sin(z_rad), math_cos(z_rad)
    local right_x, right_y = math_cos(z_rad), math_sin(z_rad)
    local arc_x = (side == 0) and cfg.missile_arc_offset or -cfg.missile_arc_offset
    local dist = cfg.missile_initial_distance

    local target = {
        x = launch.x + dir_x * dist + right_x * arc_x + 0.0,
        y = launch.y + dir_y * dist + right_y * arc_x + 0.0,
        z = launch.z + cfg.missile_launch_z_offset + 0.0,
    }

    Native.shoot_single_bullet_between_coords_ignore_entity_new(
        launch, target,
        0, true, state.weapon_hash, state.my_ped,
        true, false, cfg.missile_speed + 0.0, veh,
        false, false, target_entity, false, false, false)

    if cfg.enable_sounds then
        Native.call("play_sound_from_coord", -1, "Fire", launch.x + 0.0, launch.y + 0.0, launch.z + 0.0,
            "DLC_BTL_Terrobyte_Turret_Sounds", true, 200, true)
    end
    return true
end

function Launcher.tick(state)
    local cfg = state.cfg
    local now = Runtime.get_tick_count()

    if not charge_ok(state, now) then return end

    local want = fire_held(state)
    if not want and cfg.auto_attack and Targeting.has_confirmed_unshot(state) then
        want = true
    end
    if not want then return end
    if now < state.last_shot_ms then state.last_shot_ms = now end
    if now - state.last_shot_ms < SHOT_DELAY_MS then return end

    if not Native.call("has_ped_got_weapon", state.my_ped, state.weapon_hash, false) then
        Native.call("give_delayed_weapon_to_ped", state.my_ped, state.weapon_hash, -1, false)
        if state.logger then
            state.logger.verbose("Features.HomingMissiles", "weapon stripped at fire; re-given")
        end
        return
    end

    local target = Targeting.next_shot_target(state)
    if cfg.require_lock_confirm and (not target or target == 0) then return end

    state.weapon_side = (state.weapon_side == 0) and 1 or 0
    if shoot_missile(state, target, state.weapon_side) then
        state.shot_count = state.shot_count + 1
        state.last_shot_ms = now
        if state.shot_count >= cfg.max_targets then
            state.is_recharging = true
            state.recharge_start_ms = now
            state.charge_level = 0
        end
    else
        Targeting.unmark_shot(state, target)
    end
end

return Launcher
