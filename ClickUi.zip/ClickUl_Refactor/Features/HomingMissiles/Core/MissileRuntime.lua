local MissileRuntime = {}

local FeatureThread = require("ClickUl_Refactor.Core.FeatureThread")
local Util = require("ClickUl_Refactor.Core.Util")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Script = require("ClickUl_Refactor.Adapters.Script")
local Targeting = require("ClickUl_Refactor.Features.HomingMissiles.Core.Targeting")
local Launcher = require("ClickUl_Refactor.Features.HomingMissiles.Core.Launcher")
local LockSound = require("ClickUl_Refactor.Features.HomingMissiles.Core.LockSound")
local Hud = require("ClickUl_Refactor.Features.HomingMissiles.Core.Hud")

local WEAPON_HASH <const> = 0xB4F96934
local RC_HASHES <const> = { [0x5D0AAC8F] = true, [0x65B4004C] = true }

local valid_coord = Util.valid_coord

local function defaults()
    return {
        max_targets = 6,
        target_mode = 3,
        lock_players = true,
        lock_peds = true,
        enemy_mode = 2,
        los_mode = 1,
        use_visual_check = false,
        use_screen_check = true,
        require_lock_confirm = true,
        instant_lock = false,
        auto_attack = false,
        recharge_speed = 1.0,
        exclude_animals = true,
        missile_speed = 800.0,
        lock_distance_min = 5.0,
        lock_distance_max = 500.0,
        missile_offset_x = 1.0,
        missile_offset_y = 3.0,
        missile_offset_z = 0.0,
        missile_launch_z_offset = 1.0,
        missile_initial_distance = 5.0,
        missile_arc_offset = 1.5,
        enable_sounds = true,
        enable_lock_markers = true,
        enable_charge_bar = true,
        lockon_notify = true,
        use_auto_dimensions = true,
        use_auto_marker_size = false,
        ignore_friends = true,
        ignore_org_members = true,
        ignore_team_members = false,
        ignore_mission_players = true,
        ignore_ghosted = true,
    }
end

local state = {
    enabled = false,
    logger = nil,
    menu_open = false,
    weapon_hash = WEAPON_HASH,
    cfg = defaults(),
    my_ped = 0,
    my_vehicle = 0,
    my_coords = nil,
    my_vehicle_model = 0,
    model_vehicle = 0,
    weapon_vehicle = 0,
    weapon_ped = 0,
    in_mission = false,
    slots = {},
    players_by_ped = {},
    shot_count = 0,
    last_shot_ms = 0,
    weapon_side = 0,
    is_recharging = false,
    recharge_start_ms = 0,
    charge_level = 100,
}

local function log_verbose(message)
    if state.logger then state.logger.verbose("Features.HomingMissiles", message) end
end

local function is_camera_app_open()
    return Script.running("appcamera")
end

local function vehicle_model(vehicle)
    if state.model_vehicle ~= vehicle then
        state.model_vehicle = vehicle
        state.my_vehicle_model = Native.get_entity_model(vehicle)
    end
    return state.my_vehicle_model
end

local function should_pause_lockon(vehicle)
    return is_camera_app_open() or RC_HASHES[vehicle_model(vehicle)] or false
end

function MissileRuntime.reset()
    Targeting.clear(state)
    Launcher.reset(state)
    LockSound.stop_all()
    state.my_vehicle = 0
    state.my_coords = nil
    state.my_vehicle_model = 0
    state.model_vehicle = 0
    state.weapon_vehicle = 0
    state.weapon_ped = 0
end

local function tick()
    LockSound.pump()

    if not state.enabled then
        MissileRuntime.stop()
        return
    end

    local my_ped = Players.local_ped()
    if not my_ped or my_ped == 0 then MissileRuntime.reset(); return end

    local vehicle = Players.local_driver_vehicle()
    if vehicle == 0 or not Game.entity_exists(vehicle) then
        MissileRuntime.reset()
        return
    end

    local coords = Players.local_coords()
    if not valid_coord(coords) then return end

    if should_pause_lockon(vehicle) then
        MissileRuntime.reset()
        return
    end

    state.my_ped = my_ped
    state.my_vehicle = vehicle
    state.my_coords = coords

    if state.weapon_vehicle ~= vehicle or state.weapon_ped ~= my_ped then
        Native.call("give_delayed_weapon_to_ped", my_ped, state.weapon_hash, -1, false)
        state.weapon_vehicle = vehicle
        state.weapon_ped = my_ped
        Launcher.reset(state)
    end

    state.in_mission = Game.in_mission()

    Targeting.tick(state)
    LockSound.tick(state)
    Launcher.tick(state)
    Launcher.disable_controls()
    Hud.tick(state)
end

local thread = FeatureThread.new(tick)

function MissileRuntime.init(ctx)
    state.logger = ctx and ctx.logger or state.logger
    Hud.init({ lang = ctx and ctx.lang })
    return true
end

function MissileRuntime.start()
    if not thread.start() then return end
    log_verbose("HomingMissiles thread started")
end

function MissileRuntime.stop()
    if not thread.stop() then return end
    MissileRuntime.reset()
    LockSound.shutdown()
    log_verbose("HomingMissiles thread stopped")
end

function MissileRuntime.evaluate()
    if state.enabled then MissileRuntime.start() else MissileRuntime.stop() end
end

function MissileRuntime.on_menu_open() state.menu_open = true end
function MissileRuntime.on_menu_close() state.menu_open = false end

function MissileRuntime.on_shutdown()
    MissileRuntime.stop()
    LockSound.shutdown()
end

function MissileRuntime.set_enabled(value)
    state.enabled = value and true or false
    MissileRuntime.evaluate()
end

MissileRuntime.defaults = defaults

local function clamp(value, lo, hi, fallback)
    local n = tonumber(value)
    if not n then return fallback end
    if n < lo then return lo end
    if n > hi then return hi end
    return n
end

function MissileRuntime.apply_config(config)
    if type(config) ~= "table" then return end
    local cfg = state.cfg
    local d = defaults()
    cfg.max_targets = math.floor(clamp(config.max_targets, 1, 8, d.max_targets))
    cfg.target_mode = math.floor(clamp(config.target_mode, 1, 3, d.target_mode))
    cfg.enemy_mode = math.floor(clamp(config.enemy_mode, 0, 2, d.enemy_mode))
    cfg.los_mode = math.floor(clamp(config.los_mode, 0, 2, d.los_mode))
    cfg.recharge_speed = clamp(config.recharge_speed, 0.1, 10.0, d.recharge_speed)
    cfg.missile_speed = clamp(config.missile_speed, 100, 10000, d.missile_speed)
    cfg.lock_distance_min = clamp(config.lock_distance_min, 1, 50, d.lock_distance_min)
    cfg.lock_distance_max = clamp(config.lock_distance_max, 100, 1000, d.lock_distance_max)
    cfg.missile_offset_x = clamp(config.missile_offset_x, 0.5, 3.0, d.missile_offset_x)
    cfg.missile_offset_y = clamp(config.missile_offset_y, 1.0, 8.0, d.missile_offset_y)
    cfg.missile_offset_z = clamp(config.missile_offset_z, 0.0, 2.0, d.missile_offset_z)
    cfg.missile_launch_z_offset = clamp(config.missile_launch_z_offset, 0.0, 20.0, d.missile_launch_z_offset)
    cfg.missile_initial_distance = clamp(config.missile_initial_distance, 1.0, 10.0, d.missile_initial_distance)
    cfg.missile_arc_offset = clamp(config.missile_arc_offset, 0.0, 20.0, d.missile_arc_offset)
    if config.lock_players ~= nil then cfg.lock_players = config.lock_players and true or false end
    if config.lock_peds ~= nil then cfg.lock_peds = config.lock_peds and true or false end
    if config.use_visual_check ~= nil then cfg.use_visual_check = config.use_visual_check and true or false end
    if config.use_screen_check ~= nil then cfg.use_screen_check = config.use_screen_check and true or false end
    if config.require_lock_confirm ~= nil then cfg.require_lock_confirm = config.require_lock_confirm and true or false end
    if config.instant_lock ~= nil then cfg.instant_lock = config.instant_lock and true or false end
    if config.auto_attack ~= nil then cfg.auto_attack = config.auto_attack and true or false end
    if config.exclude_animals ~= nil then cfg.exclude_animals = config.exclude_animals and true or false end
    if config.enable_sounds ~= nil then cfg.enable_sounds = config.enable_sounds and true or false end
    if config.enable_lock_markers ~= nil then cfg.enable_lock_markers = config.enable_lock_markers and true or false end
    if config.enable_charge_bar ~= nil then cfg.enable_charge_bar = config.enable_charge_bar and true or false end
    if config.lockon_notify ~= nil then cfg.lockon_notify = config.lockon_notify and true or false end
    if config.use_auto_dimensions ~= nil then cfg.use_auto_dimensions = config.use_auto_dimensions and true or false end
    if config.use_auto_marker_size ~= nil then cfg.use_auto_marker_size = config.use_auto_marker_size and true or false end
    if config.ignore_friends ~= nil then cfg.ignore_friends = config.ignore_friends and true or false end
    if config.ignore_org_members ~= nil then cfg.ignore_org_members = config.ignore_org_members and true or false end
    if config.ignore_team_members ~= nil then cfg.ignore_team_members = config.ignore_team_members and true or false end
    if config.ignore_mission_players ~= nil then cfg.ignore_mission_players = config.ignore_mission_players and true or false end
    if config.ignore_ghosted ~= nil then cfg.ignore_ghosted = config.ignore_ghosted and true or false end
end

return MissileRuntime
