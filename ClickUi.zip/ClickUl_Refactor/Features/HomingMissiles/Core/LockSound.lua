local LockSound = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local SOUND_AMBER <const> = "VULKAN_LOCK_ON_AMBER"
local SOUND_RED <const> = "VULKAN_LOCK_ON_RED"
local SOUND_REF <const> = 0
local RED_MS <const> = 700
local AMBER_MAX_MS <const> = 1500
local MIN_AGE_TICKS <const> = 2

local TONE_NONE <const> = 0
local TONE_AMBER <const> = 1
local TONE_RED <const> = 2

local tick_count = 0
local now_ms = 0
local entries = {}
local dying = {}
local pending_release = {}
local desired = {}

local function sound_finished(id)
    return Native.call("has_sound_finished", id) and true or false
end

local function any_tone_active()
    for _, entry in pairs(entries) do
        if entry.tone ~= TONE_NONE and
            (tick_count - entry.play_tick < MIN_AGE_TICKS or not sound_finished(entry.id)) then
            return true
        end
    end
    return false
end

local function play(entry, tone, name)
    local id = Native.call("get_sound_id")
    if id == nil or id == -1 then return end
    Native.call("play_sound_frontend", id, name, SOUND_REF, true)
    entry.id = id
    entry.tone = tone
    entry.play_tick = tick_count
    entry.play_ms = now_ms
end

local function stop_tone(entry)
    if entry.tone == TONE_NONE then return end
    if tick_count - entry.play_tick < MIN_AGE_TICKS then
        dying[#dying + 1] = { id = entry.id, play_tick = entry.play_tick }
    else
        Native.call("stop_sound", entry.id)
        pending_release[#pending_release + 1] = { id = entry.id, stop_tick = tick_count }
    end
    entry.id = -1
    entry.tone = TONE_NONE
end

local function drain_deferred()
    for i = #dying, 1, -1 do
        local d = dying[i]
        if tick_count - d.play_tick >= MIN_AGE_TICKS then
            Native.call("stop_sound", d.id)
            pending_release[#pending_release + 1] = { id = d.id, stop_tick = tick_count }
            table.remove(dying, i)
        end
    end
    for i = #pending_release, 1, -1 do
        local p = pending_release[i]
        if tick_count - p.stop_tick >= MIN_AGE_TICKS then
            Native.call("release_sound_id", p.id)
            table.remove(pending_release, i)
        end
    end
end

local function drop_entry(entity)
    local entry = entries[entity]
    if not entry then return end
    stop_tone(entry)
    entries[entity] = nil
end

function LockSound.stop_all()
    for entity in pairs(entries) do drop_entry(entity) end
end

function LockSound.shutdown()
    LockSound.stop_all()
    for i = #dying, 1, -1 do
        Native.call("stop_sound", dying[i].id)
        Native.call("release_sound_id", dying[i].id)
        dying[i] = nil
    end
    for i = #pending_release, 1, -1 do
        Native.call("release_sound_id", pending_release[i].id)
        pending_release[i] = nil
    end
end

function LockSound.pump()
    tick_count = tick_count + 1
    now_ms = Runtime.get_tick_count()
    drain_deferred()
end

function LockSound.tick(state)
    if not state.cfg.enable_sounds or state.is_recharging then
        LockSound.stop_all()
        return
    end

    for entity in pairs(desired) do desired[entity] = nil end
    for i = 1, #state.slots do
        local slot = state.slots[i]
        desired[slot.entity] = slot.confirmed and TONE_RED or TONE_AMBER
    end

    for entity in pairs(entries) do
        if not desired[entity] then drop_entry(entity) end
    end

    for entity, want in pairs(desired) do
        local entry = entries[entity]
        if not entry then
            entry = { id = -1, tone = TONE_NONE, play_tick = 0, play_ms = 0,
                      amber_done = false, red_done = false }
            entries[entity] = entry
        end
        if entry.tone ~= TONE_NONE and now_ms < entry.play_ms then entry.play_ms = now_ms end
        if entry.tone == TONE_AMBER then
            if want == TONE_RED or now_ms - entry.play_ms >= AMBER_MAX_MS then
                stop_tone(entry)
                entry.amber_done = true
            end
        elseif entry.tone == TONE_RED then
            if now_ms - entry.play_ms >= RED_MS then
                stop_tone(entry)
                entry.red_done = true
            end
        elseif want == TONE_AMBER then
            if not entry.amber_done and not any_tone_active() then
                play(entry, TONE_AMBER, SOUND_AMBER)
            end
        else
            if not entry.red_done then
                entry.amber_done = true
                if not any_tone_active() then
                    play(entry, TONE_RED, SOUND_RED)
                end
            end
        end
    end
end

return LockSound
