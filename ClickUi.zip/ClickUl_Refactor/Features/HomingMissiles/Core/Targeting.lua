local Targeting = {}

local EntityPool = require("ClickUl_Refactor.Core.EntityPool")
local Game = require("ClickUl_Refactor.Adapters.Game")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Projection = require("ClickUl_Refactor.Core.Projection")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local LOCK_CONFIRM_MS <const> = 700
local LOS_GRACE_MS <const> = 1000
local SCREEN_GRACE_MS <const> = 500
local SCREEN_MARGIN <const> = 0.15
local LOS_FLAGS <const> = { 17, 287 }
local ALL_CATEGORIES <const> = { animal = true, cop = true, hostile = true, npc = true }
local ENEMY_CATEGORIES <const> = { cop = true, hostile = true }

local function by_dist_sq(a, b)
    return a.dist_sq < b.dist_sq
end

local function release_vis_point(slot)
    if not slot.vis_point then return end
    Native.call("destroy_tracked_point", slot.vis_point)
    slot.vis_point = nil
end

function Targeting.clear(state)
    for i = 1, #state.slots do release_vis_point(state.slots[i]) end
    state.slots = {}
    local probes = state.vis_probes
    if probes then
        for entity, probe in pairs(probes.map) do
            Native.call("destroy_tracked_point", probe.point)
            probes.map[entity] = nil
        end
        probes.count = 0
    end
end

local function find_slot(state, entity)
    for i = 1, #state.slots do
        if state.slots[i].entity == entity then return i end
    end
    return nil
end

local function on_screen(pos)
    if not pos then return false end
    local screen = Projection.world_to_screen(pos)
    if not screen then return false end
    local nx, ny = screen.normalized_x, screen.normalized_y
    return nx >= -SCREEN_MARGIN and nx <= 1 + SCREEN_MARGIN
        and ny >= -SCREEN_MARGIN and ny <= 1 + SCREEN_MARGIN
end

local function has_los(state, entity)
    local mode = state.cfg.los_mode
    if mode == 0 then return true end
    local flags = LOS_FLAGS[mode] or LOS_FLAGS[1]
    return Native.call("has_entity_clear_los_to_entity", state.my_vehicle, entity, flags) and true or false
end

local VIS_PRIME_TICKS <const> = 2
local VIS_RADIUS <const> = 0.8
local VIS_TOP_MARGIN <const> = 0.4
local VIS_DEFAULT_HEIGHT <const> = 1.4

local function vis_point_height(slot)
    local dims = ModelDims.get(slot.model_hash)
    if dims then return dims.max.z + VIS_TOP_MARGIN end
    return VIS_DEFAULT_HEIGHT
end

local function visual_check(state, slot, pos)
    local cfg = state.cfg
    if cfg.los_mode == 0 or not cfg.use_visual_check then
        release_vis_point(slot)
        return
    end
    if not slot.vis_point then
        slot.vis_point = Native.call("create_tracked_point")
        slot.vis_ticks = 0
    end
    slot.vis_ticks = slot.vis_ticks + 1
    if slot.vis_ticks > VIS_PRIME_TICKS
        and Projection.world_to_screen(pos)
        and not Native.call("is_tracked_point_visible", slot.vis_point)
    then
        slot.los_clear = false
    end
    Native.call("set_tracked_point_info", slot.vis_point,
        pos.x + 0.0, pos.y + 0.0, pos.z + vis_point_height(slot), VIS_RADIUS)
end

local MAX_VIS_PROBES <const> = 8

local function probe_state(state)
    local probes = state.vis_probes
    if not probes then
        probes = { map = {}, count = 0, serial = 0 }
        state.vis_probes = probes
    end
    return probes
end

local function release_probe(probes, entity, destroy)
    local probe = probes.map[entity]
    if not probe then return end
    if destroy then Native.call("destroy_tracked_point", probe.point) end
    probes.map[entity] = nil
    probes.count = probes.count - 1
end

local function probe_allows(state, entry)
    local cfg = state.cfg
    if cfg.los_mode == 0 or not cfg.use_visual_check then return true, nil end

    local probes = probe_state(state)
    local probe = probes.map[entry.entity]
    if not probe then
        if probes.count >= MAX_VIS_PROBES then return false, nil end
        probe = { point = Native.call("create_tracked_point"), ticks = 0 }
        probes.map[entry.entity] = probe
        probes.count = probes.count + 1
    end
    probe.serial = probes.serial
    probe.ticks = probe.ticks + 1

    local pos = entry.pos
    if probe.ticks > VIS_PRIME_TICKS then
        if not Projection.world_to_screen(pos) then
            release_probe(probes, entry.entity, true)
            return true, nil
        end
        if Native.call("is_tracked_point_visible", probe.point) then
            local primed = { point = probe.point, ticks = probe.ticks }
            release_probe(probes, entry.entity, false)
            return true, primed
        end
    end

    Native.call("set_tracked_point_info", probe.point,
        pos.x + 0.0, pos.y + 0.0, pos.z + vis_point_height(entry), VIS_RADIUS)
    return false, nil
end

local function prune_probes(state)
    local probes = state.vis_probes
    if not probes then return end
    for entity, probe in pairs(probes.map) do
        if probe.serial ~= probes.serial then
            release_probe(probes, entity, true)
        end
    end
end

local WHITELIST_REFRESH_MS <const> = 1000

local function refresh_players(state)
    local map = state.players_by_ped
    for ped in pairs(map) do map[ped] = nil end
    local list = Players.session_snapshot(state.my_coords, state.cfg.lock_distance_max)
    for i = 1, #list do
        local info = list[i]
        if info.ped and info.ped ~= 0 then map[info.ped] = info end
    end

    local now = state.tick_now
    local last = state.whitelist_refresh_ms
    if not last or now - last >= WHITELIST_REFRESH_MS or now < last then
        local cfg = state.cfg
        state.my_org = cfg.ignore_org_members and Players.local_org_info() or nil
        state.my_team = cfg.ignore_team_members and Native.call("get_player_team", Players.local_id()) or nil
        state.whitelist_refresh_ms = now
    end
end

local function player_candidates(state, out)
    local cfg = state.cfg
    if not cfg.lock_players then return out end
    if cfg.ignore_mission_players and state.in_mission then return out end
    local my = state.my_coords
    for ped, info in pairs(state.players_by_ped) do
        if ped ~= state.my_ped and info.detailed then
            local c = info.coords
            local dx, dy, dz = c.x - my.x, c.y - my.y, c.z - my.z
            local d_sq = dx * dx + dy * dy + dz * dz
            local entry = nil
            if info.in_vehicle and info.vehicle ~= 0 then
                if cfg.target_mode ~= 2 and info.vehicle ~= state.my_vehicle and info.driver then
                    entry = {
                        entity = info.vehicle,
                        is_vehicle = true,
                        driver = ped,
                        driver_is_player = true,
                        is_player = false,
                        model_hash = info.vehicle_model,
                    }
                end
            elseif cfg.target_mode ~= 1 then
                entry = {
                    entity = ped,
                    is_vehicle = false,
                    is_player = true,
                    model_hash = info.model,
                }
            end
            if entry then
                entry.pos = c
                entry.coords = c
                entry.dist_sq = d_sq
                out[#out + 1] = entry
            end
        end
    end
    table.sort(out, by_dist_sq)
    return out
end

local WHITELIST_NATIVE_TTL_MS <const> = 1000

local function cached_ghost(state, ped)
    local cache = state.ghost_cache
    if not cache then
        cache = {}
        state.ghost_cache = cache
    end
    local now = state.tick_now
    local rec = cache[ped]
    if not rec then
        rec = { value = false, ms = nil }
        cache[ped] = rec
    end
    if not rec.ms or now - rec.ms >= WHITELIST_NATIVE_TTL_MS or now < rec.ms then
        rec.value = Native.call("is_entity_a_ghost", ped) and true or false
        rec.ms = now
    end
    return rec.value
end

local function cached_team(state, player_id)
    local cache = state.team_cache
    if not cache then
        cache = {}
        state.team_cache = cache
    end
    local now = state.tick_now
    local rec = cache[player_id]
    if not rec then
        rec = { value = -1, ms = nil }
        cache[player_id] = rec
    end
    if not rec.ms or now - rec.ms >= WHITELIST_NATIVE_TTL_MS or now < rec.ms then
        rec.value = Native.call("get_player_team", player_id) or -1
        rec.ms = now
    end
    return rec.value
end

local function should_ignore_player(state, info)
    local cfg = state.cfg
    if cfg.ignore_mission_players and state.in_mission then return true end
    if cfg.ignore_friends and info.friend then return true end
    local org = state.my_org
    if org and org.in_ceo and info.in_ceo and org.gang_id ~= 0 and org.gang_id == info.gang_id then
        return true
    end
    if cfg.ignore_ghosted and cached_ghost(state, info.ped) then return true end
    if state.my_team and state.my_team ~= -1 then
        local team = cached_team(state, info.id)
        if team ~= -1 and team == state.my_team then return true end
    end
    return false
end

local function passes_target_filters(state, entry)
    local cfg = state.cfg
    if entry.is_vehicle then
        if cfg.target_mode == 2 then return false end
        if entry.entity == state.my_vehicle then return false end
        local driver = entry.driver or 0
        if driver == 0 then return false end
        if driver == state.my_ped then return false end
        local info = state.players_by_ped[driver]
        if info then
            if not cfg.lock_players then return false end
            if not info.detailed or should_ignore_player(state, info) then return false end
        elseif not cfg.lock_peds then
            return false
        end
        return true
    end
    if cfg.target_mode == 1 then return false end
    if entry.entity == state.my_ped then return false end
    if cfg.exclude_animals and entry.category == "animal" then return false end
    local info = state.players_by_ped[entry.entity]
    if info then
        if not cfg.lock_players then return false end
        if not info.detailed or should_ignore_player(state, info) then return false end
    elseif not cfg.lock_peds then
        return false
    end
    return true
end

local function add_slot(state, entry, now)
    state.slots[#state.slots + 1] = {
        entity = entry.entity,
        is_vehicle = entry.is_vehicle and true or false,
        is_player = state.players_by_ped[entry.entity] ~= nil,
        driver = entry.driver or 0,
        driver_is_player = state.players_by_ped[entry.driver or 0] ~= nil,
        is_enemy = entry.is_enemy and true or false,
        category = entry.category,
        model_hash = entry.model_hash,
        dist_sq = entry.dist_sq,
        pos = entry.pos,
        lock_ms = now,
        confirmed = false,
        los_clear = true,
        los_lost_ms = nil,
        screen_lost_ms = nil,
        shot = false,
    }
end

local function still_targetable(state, slot)
    if slot.is_vehicle then
        slot.driver = Native.call("get_ped_in_vehicle_seat", slot.entity, -1, false) or 0
        slot.driver_is_player = state.players_by_ped[slot.driver] ~= nil
        return passes_target_filters(state, slot)
    end
    if EntityPool.is_ped_in_vehicle(slot.entity) then return false end
    return passes_target_filters(state, slot)
end

local function slot_tier(cfg, entry)
    if cfg.enemy_mode ~= 1 then return 0 end
    if entry.is_player or entry.driver_is_player then return 2 end
    if entry.is_enemy then return 1 end
    return 0
end

local function lowest_priority_slot(state)
    local cfg = state.cfg
    local idx, worst_tier, worst_dist = nil, math.huge, -1
    for i = 1, #state.slots do
        local slot = state.slots[i]
        local tier = slot_tier(cfg, slot)
        if tier < worst_tier or (tier == worst_tier and slot.dist_sq > worst_dist) then
            idx, worst_tier, worst_dist = i, tier, slot.dist_sq
        end
    end
    return idx, worst_tier, worst_dist
end

local LOS_CHECK_STRIDE <const> = 3

local function validate_slots(state, now)
    local cfg = state.cfg
    local max_sq = cfg.lock_distance_max * cfg.lock_distance_max
    local min_sq = cfg.lock_distance_min * cfg.lock_distance_min
    state.los_rotor = ((state.los_rotor or 0) + 1) % LOS_CHECK_STRIDE
    for i = #state.slots, 1, -1 do
        local slot = state.slots[i]
        local entity = slot.entity
        local drop = false
        local pos = nil
        if now < slot.lock_ms then slot.lock_ms = now end
        if slot.los_lost_ms and now < slot.los_lost_ms then slot.los_lost_ms = now end
        if slot.screen_lost_ms and now < slot.screen_lost_ms then slot.screen_lost_ms = now end
        if not Game.entity_exists(entity) or EntityPool.is_entity_dead(entity)
            or not still_targetable(state, slot)
        then
            drop = true
        else
            pos = Native.get_entity_coords(entity, false)
            slot.pos = pos
            if not pos or not state.my_coords then
                drop = true
            else
                local dx, dy, dz = pos.x - state.my_coords.x, pos.y - state.my_coords.y, pos.z - state.my_coords.z
                slot.dist_sq = dx * dx + dy * dy + dz * dz
                if slot.dist_sq > max_sq or slot.dist_sq < min_sq then
                    drop = true
                elseif cfg.use_screen_check and not on_screen(pos) then
                    slot.screen_lost_ms = slot.screen_lost_ms or now
                    if now - slot.screen_lost_ms > SCREEN_GRACE_MS then drop = true end
                else
                    slot.screen_lost_ms = nil
                end
            end
        end
        if not drop then
            if (i + state.los_rotor) % LOS_CHECK_STRIDE == 0 then
                slot.los_clear = has_los(state, entity)
            end
            if slot.los_clear then visual_check(state, slot, pos) end
            if not slot.los_clear then
                slot.los_lost_ms = slot.los_lost_ms or now
                if now - slot.los_lost_ms > LOS_GRACE_MS then drop = true end
            else
                slot.los_lost_ms = nil
            end
        end
        if drop then
            release_vis_point(slot)
            table.remove(state.slots, i)
        end
    end
    while #state.slots > cfg.max_targets do
        local idx = lowest_priority_slot(state)
        if not idx then break end
        release_vis_point(state.slots[idx])
        table.remove(state.slots, idx)
    end
end

local function acquire(state, candidates, now)
    local cfg = state.cfg
    local min_sq = cfg.lock_distance_min * cfg.lock_distance_min
    local max_sq = cfg.lock_distance_max * cfg.lock_distance_max
    for _, entry in ipairs(candidates) do
        local entity = entry.entity
        if entity ~= 0 and entity ~= state.my_vehicle and entity ~= state.my_ped
            and entry.dist_sq >= min_sq and entry.dist_sq <= max_sq
            and passes_target_filters(state, entry)
            and not find_slot(state, entity)
        then
            local replace_idx = nil
            local have_room = #state.slots < cfg.max_targets
            if not have_room then
                local idx, worst_tier, worst_dist = lowest_priority_slot(state)
                if idx then
                    local tier = slot_tier(cfg, entry)
                    if tier > worst_tier or (tier == worst_tier and entry.dist_sq < worst_dist) then
                        replace_idx = idx
                    end
                end
            end
            if (have_room or replace_idx)
                and (not cfg.use_screen_check or on_screen(entry.pos))
                and has_los(state, entity)
            then
                local allowed, primed = probe_allows(state, entry)
                if allowed then
                    if replace_idx then
                        release_vis_point(state.slots[replace_idx])
                        table.remove(state.slots, replace_idx)
                    end
                    add_slot(state, entry, now)
                    if primed then
                        local slot = state.slots[#state.slots]
                        slot.vis_point = primed.point
                        slot.vis_ticks = primed.ticks
                    end
                end
            end
        end
    end
end

local function confirm(state, now)
    local cfg = state.cfg
    for i = 1, #state.slots do
        local slot = state.slots[i]
        if not slot.confirmed and slot.los_clear
            and (cfg.los_mode == 0 or not cfg.use_visual_check or (slot.vis_ticks or 0) > VIS_PRIME_TICKS)
            and (cfg.instant_lock or now - slot.lock_ms >= LOCK_CONFIRM_MS)
        then
            slot.confirmed = true
            if cfg.lockon_notify and slot.is_vehicle and slot.driver_is_player then
                Native.set_vehicle_homing_lockedonto_state(slot.entity, 2)
            end
        end
    end
end

local pool_options = {
    include_vehicles = false,
    enabled_categories = ALL_CATEGORIES,
    needs_hostility = true,
    needs_model = true,
}
local lockable_options = {
    target_mode = 3,
    enemy_mode = 0,
    max_distance_sq = 0,
}

local DISCOVER_INTERVAL <const> = 3

local WHITELIST_CACHE_WIPE_TICKS <const> = 2048

function Targeting.tick(state)
    local cfg = state.cfg
    local now = Runtime.get_tick_count()
    state.tick_now = now

    Projection.refresh_camera()

    state.cache_wipe_rotor = ((state.cache_wipe_rotor or 0) + 1) % WHITELIST_CACHE_WIPE_TICKS
    if state.cache_wipe_rotor == 0 then
        state.ghost_cache = nil
        state.team_cache = nil
    end

    refresh_players(state)

    validate_slots(state, now)

    state.discover_rotor = ((state.discover_rotor or 0) + 1) % DISCOVER_INTERVAL
    if cfg.use_visual_check or state.discover_rotor == 0 then
        local wanted = EntityPool.player_wanted_level(Players.local_id())
        pool_options.enabled_categories = (cfg.enemy_mode == 2) and ENEMY_CATEGORIES or ALL_CATEGORIES
        EntityPool.update(state.my_ped, state.my_coords, wanted, cfg.lock_distance_max, pool_options)

        local candidates = player_candidates(state, {})
        local seen = {}
        for i = 1, #candidates do seen[candidates[i].entity] = true end
        lockable_options.target_mode = cfg.target_mode
        lockable_options.enemy_mode = cfg.enemy_mode
        lockable_options.max_distance_sq = cfg.lock_distance_max * cfg.lock_distance_max
        local pool = EntityPool.get_lockable_targets(lockable_options)
        for i = 1, #pool do
            local entry = pool[i]
            if not seen[entry.entity] then candidates[#candidates + 1] = entry end
        end

        local probes = probe_state(state)
        probes.serial = probes.serial + 1
        acquire(state, candidates, now)
        prune_probes(state)
    end

    confirm(state, now)
end

function Targeting.next_shot_target(state)
    for i = 1, #state.slots do
        local slot = state.slots[i]
        if slot.confirmed and not slot.shot then
            slot.shot = true
            return slot.entity
        end
    end
    local first = nil
    for i = 1, #state.slots do
        state.slots[i].shot = false
        if not first and state.slots[i].confirmed then first = i end
    end
    if first then
        state.slots[first].shot = true
        return state.slots[first].entity
    end
    return 0
end

function Targeting.has_confirmed_unshot(state)
    for i = 1, #state.slots do
        if state.slots[i].confirmed and not state.slots[i].shot then return true end
    end
    return false
end

function Targeting.clear_shot_flags(state)
    for i = 1, #state.slots do state.slots[i].shot = false end
end

function Targeting.unmark_shot(state, entity)
    if not entity or entity == 0 then return end
    for i = 1, #state.slots do
        local slot = state.slots[i]
        if slot.entity == entity then
            slot.shot = false
            return
        end
    end
end

return Targeting
