local GeneralPage = require("ClickUl_Refactor.Features.HomingMissiles.GeneralPage")
local Settings = require("ClickUl_Refactor.Features.HomingMissiles.Settings")
local MissileRuntime = require("ClickUl_Refactor.Features.HomingMissiles.Core.MissileRuntime")

local HomingMissiles = {}

function HomingMissiles.init(ctx)
    local ui = assert(ctx.ui, "[HomingMissiles] ui is required")
    local lang = assert(ctx.lang, "[HomingMissiles] lang is required")
    local logger = assert(ctx.logger, "[HomingMissiles] logger is required")
    local settings = assert(ctx.settings, "[HomingMissiles] settings is required")
    local hotkeys = assert(ctx.hotkeys, "[HomingMissiles] hotkeys is required")
    local action_registry = assert(ctx.action_registry, "[HomingMissiles] action_registry is required")
    local favorites = assert(ctx.favorites, "[HomingMissiles] favorites is required")

    MissileRuntime.init({ logger = logger, lang = lang })
    Settings.bind_storage(settings)
    GeneralPage.init({ ui = ui, lang = lang, favorites = favorites })
    GeneralPage.register_actions({ hotkeys = hotkeys, action_registry = action_registry })

    hotkeys.register_action({
        id = "homing.fire",
        label = "Fire Homing Missiles",
        group = "Homing Missiles",
        tab = "Vehicle",
        when = "closed",
        callback = function() end,
    })

    logger.info("Features.HomingMissiles", "HomingMissiles module initialized")
    return true
end

function HomingMissiles.draw()
    GeneralPage.draw()
end

function HomingMissiles.on_menu_open()
    MissileRuntime.on_menu_open()
end

function HomingMissiles.on_menu_close()
    MissileRuntime.on_menu_close()
end

function HomingMissiles.on_shutdown()
    MissileRuntime.on_shutdown()
end

return HomingMissiles
