local Settings = {}

local MissileRuntime = require("ClickUl_Refactor.Features.HomingMissiles.Core.MissileRuntime")

local SECTION_NAME <const> = "HomingMissiles"

local storage = nil
local current = nil

local function defaults()
    local d = MissileRuntime.defaults()
    d.enabled = false
    return d
end

local function copy_table(source)
    local out = {}
    for key, value in pairs(source) do out[key] = value end
    return out
end

local function normalize_snapshot(input)
    local d = defaults()
    if type(input) ~= "table" then return d end
    local out = {}
    for key, default_value in pairs(d) do
        local value = input[key]
        if type(value) == type(default_value) then
            out[key] = value
        else
            out[key] = default_value
        end
    end
    return out
end

local function apply_to_runtime()
    MissileRuntime.apply_config(current)
    MissileRuntime.set_enabled(current.enabled)
end

local function queue_save()
    if not storage then return end
    storage.set_section(SECTION_NAME, copy_table(current))
    storage.save()
end

local function reset_current()
    current = defaults()
    apply_to_runtime()
end

function Settings.bind_storage(settings_module)
    storage = settings_module
    current = normalize_snapshot(storage.get_section(SECTION_NAME))
    storage.register_reset_handler(SECTION_NAME, function()
        reset_current()
        queue_save()
    end)
    apply_to_runtime()
    queue_save()
end

function Settings.snapshot()
    return copy_table(current or defaults())
end

function Settings.set_option(key, value)
    if not current then current = defaults() end
    current[key] = value
    current = normalize_snapshot(current)
    apply_to_runtime()
    queue_save()
end

return Settings
