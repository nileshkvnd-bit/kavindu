local GeneralPage = {}

local Settings = require("ClickUl_Refactor.Features.HomingMissiles.Settings")

local ui, lang, favorites

local TARGET_MODES <const> = { "Vehicles", "Peds", "All" }
local ENEMY_MODES <const> = { "Off", "Priority", "Only" }
local LOS_MODES <const> = { "Off", "Loose", "Strict" }

local OPTIONS <const> = {
    { key = "enabled", id = "homing.toggle", label = "Enable Homing Missiles", hotkey_label = "Toggle Homing Missiles",
      desc = "Hold the fire hotkey while driving to launch (default: right mouse button, rebindable in hotkey settings)." },
    { key = "target_mode", label = "Target Type", list = TARGET_MODES, base = 1 },
    { key = "enemy_mode", label = "Enemy Priority", list = ENEMY_MODES, base = 0,
      desc = "Priority = enemies first; Only = enemies exclusively." },
    { key = "los_mode", label = "Line of Sight", list = LOS_MODES, base = 0,
      desc = "Require clear line of sight before locking." },
    { key = "enable_lock_markers", label = "Lock Markers",
      desc = "Draw a reticle over each locked target (amber = locking, red = confirmed)." },
    { key = "enable_charge_bar", label = "Charge Bar",
      desc = "Show the missile charge bar at the bottom right." },
    { key = "use_auto_marker_size", label = "Auto Marker Size",
      desc = "On: box hugs each target's real size. Off: constant screen size like the game's lock-on box." },
    { key = "enable_sounds", label = "Lock-on Sounds",
      desc = "Play lock-on tones and the launch sound." },
    { key = "lock_players", label = "Lock Players" },
    { key = "lock_peds", label = "Lock NPCs" },
    { key = "exclude_animals", label = "Ignore Animals" },
    { key = "use_screen_check", label = "On-Screen Only",
      desc = "Only lock targets currently on screen." },
    { key = "use_visual_check", label = "Visual Occlusion Check",
      desc = "Extra sight check against rendered geometry: distant buildings block locks even when their collision isn't loaded — the ray check alone sees through far buildings from the air, and the missile itself also flies through unloaded buildings (engine collision streaming limit), so blocking the lock is the only defense. On-screen targets only; lock confirm starts a few frames later. No effect when Line of Sight is Off." },
    { key = "require_lock_confirm", label = "Require Lock Confirm",
      desc = "Only fire at fully-confirmed (red) locks." },
    { key = "instant_lock", label = "Instant Lock",
      desc = "Skip the lock-on hold time." },
    { key = "auto_attack", label = "Auto Attack",
      desc = "Fire automatically at confirmed targets without holding the fire key." },
    { key = "lockon_notify", label = "Lock-on Warning",
      desc = "Show the homing warning to locked player vehicles." },
    { key = "ignore_friends", label = "Ignore Friends" },
    { key = "ignore_org_members", label = "Ignore Organization",
      desc = "Skip players in your CEO/MC organization." },
    { key = "ignore_team_members", label = "Ignore Team",
      desc = "Skip players on your team (versus modes)." },
    { key = "ignore_mission_players", label = "Ignore Mission Players",
      desc = "Session-level check: only instanced mission/job sessions count (contact missions, heists, adversary modes) — freemode work inside a free-roam session (sell/VIP missions) does not. Held player locks drop when the mission session starts." },
    { key = "ignore_ghosted", label = "Ignore Ghosted",
      desc = "Skip ghosted players (the Ghosted session flag): the game blocks all interaction with them, so locks only waste ammo." },
    { key = "use_auto_dimensions", label = "Auto Muzzle Offset",
      desc = "Compute launch points from the vehicle's dimensions." },
}

local OPTION_BY_KEY = {}
for _, opt in ipairs(OPTIONS) do OPTION_BY_KEY[opt.key] = opt end

local function _T(text) return lang and lang.get(text) or text end

local function option_id(opt)
    return opt.id or ("homing." .. opt.key)
end

local function execute_option(opt)
    local snap = Settings.snapshot()
    if opt.list then
        local idx = (snap[opt.key] - opt.base + 1) % #opt.list + 1
        Settings.set_option(opt.key, opt.base + idx - 1)
        return nil
    end
    local next_value = not snap[opt.key]
    Settings.set_option(opt.key, next_value)
    return next_value
end

local slider_hint_cache = {}

local function make_hint(text, desc)
    local key = text .. "\0" .. (desc or "")
    local active_lang = lang.get_language()
    local entry = slider_hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        slider_hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = desc and _T(desc) or hint_text
    entry.language = active_lang
    return hint
end

local hint_cache = {}

local function option_hint(key)
    local opt = OPTION_BY_KEY[key]
    local current_lang = lang.get_language()
    local entry = hint_cache[key]
    if not entry or entry.language ~= current_lang then
        local id = option_id(opt)
        local label = _T(opt.label)
        entry = {
            language = current_lang,
            id = id,
            hint = {
                text = label,
                description = opt.desc and _T(opt.desc) or label,
                hotkey = { action_id = id, label = _T(opt.hotkey_label or opt.label) },
                favorite = { action_id = id, label = label, is_favorite = false },
            },
        }
        hint_cache[key] = entry
    end
    entry.hint.favorite.is_favorite = favorites.is_favorite(entry.id)
    return entry.hint
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[HomingMissiles.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[HomingMissiles.GeneralPage] lang is required")
    favorites = assert(ctx.favorites, "[HomingMissiles.GeneralPage] favorites is required")
end

function GeneralPage.register_actions(ctx)
    local hotkeys = assert(ctx.hotkeys, "[HomingMissiles.GeneralPage] hotkeys is required")
    local action_registry = assert(ctx.action_registry, "[HomingMissiles.GeneralPage] action_registry is required")

    for _, opt in ipairs(OPTIONS) do
        local opt_ref = opt
        local id = option_id(opt_ref)
        hotkeys.register_action({
            id = id,
            label = opt_ref.hotkey_label or opt_ref.label,
            group = "Homing Missiles",
            tab = "Vehicle",
            when = "always",
            notify_on_trigger = not opt_ref.list,
            callback = function() return execute_option(opt_ref) end,
        })
        action_registry.register({
            id = id,
            label = opt_ref.label,
            group = "Homing Missiles",
            feature = "Vehicle",
            page = "Homing Missiles",
            tabs = { "Vehicle" },
            section = "Homing Missiles",
            column = 1,
            layout = "DualColumn",
            favorite_kind = "function",
            description = opt_ref.desc,
            execute = function() return execute_option(opt_ref) end,
        })
    end
end

local SLIDERS <const> = {
    missile_speed = { label = "Missile Speed", min = 100, max = 10000, step = 50,
        desc = "Lower = tighter orbit but slower to catch fast movers." },
    max_targets = { label = "Max Targets", min = 1, max = 8, step = 1, integer = true },
    recharge_speed = { label = "Recharge Speed", min = 0.1, max = 10.0, step = 0.1 },
    lock_distance_min = { label = "Lock Distance Min", min = 1, max = 50, step = 1 },
    lock_distance_max = { label = "Lock Distance Max", min = 100, max = 1000, step = 50 },
    missile_arc_offset = { label = "Launch Arc", min = 0.0, max = 20.0, step = 0.5,
        desc = "How far missiles swing outward before homing (0 = straight)." },
    missile_launch_z_offset = { label = "Launch Climb", min = 0.0, max = 20.0, step = 0.5,
        desc = "How far missiles pitch upward before homing (0 = flat)." },
}

local LEFT_GROUPS <const> = {
    { title = "Homing Missiles", items = {
        { kind = "toggle", key = "enabled" },
        { kind = "slider", key = "missile_speed" },
        { kind = "slider", key = "max_targets" },
        { kind = "slider", key = "recharge_speed" },
        { kind = "combo", key = "target_mode" },
        { kind = "combo", key = "enemy_mode" },
        { kind = "combo", key = "los_mode" },
    } },
    { title = "Range", items = {
        { kind = "slider", key = "lock_distance_min" },
        { kind = "slider", key = "lock_distance_max" },
        { kind = "slider", key = "missile_arc_offset" },
        { kind = "slider", key = "missile_launch_z_offset" },
        { kind = "checkbox", key = "use_auto_dimensions" },
    } },
    { title = "HUD", items = {
        { kind = "checkbox", key = "enable_lock_markers" },
        { kind = "checkbox", key = "enable_charge_bar" },
        { kind = "checkbox", key = "use_auto_marker_size" },
        { kind = "checkbox", key = "enable_sounds" },
    } },
}

local RIGHT_GROUPS <const> = {
    { title = "Targeting", items = {
        { kind = "checkbox", key = "lock_players" },
        { kind = "checkbox", key = "lock_peds" },
        { kind = "checkbox", key = "use_screen_check" },
        { kind = "checkbox", key = "use_visual_check" },
        { kind = "checkbox", key = "require_lock_confirm" },
        { kind = "checkbox", key = "instant_lock" },
        { kind = "checkbox", key = "auto_attack" },
        { kind = "checkbox", key = "lockon_notify" },
    } },
    { title = "Exclusions", items = {
        { kind = "checkbox", key = "exclude_animals" },
        { kind = "checkbox", key = "ignore_friends" },
        { kind = "checkbox", key = "ignore_org_members" },
        { kind = "checkbox", key = "ignore_team_members" },
        { kind = "checkbox", key = "ignore_mission_players" },
        { kind = "checkbox", key = "ignore_ghosted" },
    } },
}

local function draw_item(snap, item)
    local key = item.key
    if item.kind == "slider" then
        local def = SLIDERS[key]
        local current = snap[key]
        local value = ui.Slider(_T(def.label), current, def.min, def.max, def.step,
            make_hint(def.label, def.desc))
        if value ~= current then
            Settings.set_option(key, def.integer and math.floor(value) or value)
        end
        return
    end

    local opt = OPTION_BY_KEY[key]
    if item.kind == "combo" then
        local shown = snap[key] - opt.base + 1
        local value = ui.Combo(_T(opt.label), shown, lang.translate_list(opt.list), option_hint(key))
        if value ~= shown then Settings.set_option(key, opt.base + value - 1) end
        return
    end

    local widget = item.kind == "toggle" and ui.Toggle or ui.Checkbox
    local current = snap[key]
    local value = widget(_T(opt.label), current, option_hint(key))
    if value ~= current then Settings.set_option(key, value) end
end

local function draw_groups(groups, snap)
    for gi = 1, #groups do
        local group = groups[gi]
        ui.Group(_T(group.title), function()
            local items = group.items
            for i = 1, #items do draw_item(snap, items[i]) end
        end)
    end
end

local current_snap = nil

local function draw_left()
    draw_groups(LEFT_GROUPS, current_snap)
end

local function draw_right()
    draw_groups(RIGHT_GROUPS, current_snap)
end

function GeneralPage.draw()
    current_snap = Settings.snapshot()
    ui.DualColumn(draw_left, draw_right)
end

return GeneralPage
