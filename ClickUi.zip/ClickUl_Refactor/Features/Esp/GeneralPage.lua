local Settings = require("ClickUl_Refactor.Features.Esp.Settings")
local StringId = require("ClickUl_Refactor.Core.StringId")

local GeneralPage = {}

local ui
local lang

local TABS <const> = { "NPC", "Cop", "Hostile", "Animal", "Settings" }
local TYPE_KEYS <const> = { "npc", "cop", "hostile", "animal" }

local TYPE_DESC <const> = {
    npc = "Show ESP for normal NPCs",
    cop = "Show ESP for police/SWAT/army",
    hostile = "Show ESP for hostile NPCs",
    animal = "Show ESP for animals",
}

local GENERAL_TOGGLES <const> = {
    { key = "box", label = "Draw Box", hint = "Draw bounding box" },
    { key = "skeleton", label = "Draw Bones",
      hint = "Skeleton lines. The most expensive ESP element: 15 bone reads (native calls) + projections per target every frame — leave off unless you need it. Auto-skipped beyond 100m." },
    { key = "health", label = "Show Health", hint = "Display health bar" },
    { key = "armor", label = "Armor Bar", hint = "Display armor bar" },
}

local INFO_TOGGLES <const> = {
    { key = "name", label = "Name", hint = "Display type name above box" },
    { key = "distance", label = "Distance", hint = "Display distance below ESP" },
}

local TRACELINE_TOGGLE <const> = { key = "traceline", label = "Draw Tracers", hint = "Draw line from screen to target" }
local TRACELINE_ORIGINS <const> = { "Screen Top", "Screen Center", "Screen Bottom" }

local COLOR_ITEMS <const> = {
    { key = "color", label = "Color" },
    { key = "health_color", label = "Health Bar" },
    { key = "armor_color", label = "Armor Bar" },
}

local STYLE_SLIDERS <const> = {
    { key = "box_thickness", label = "Box Thickness", min = 1, max = 5, step = 1 },
    { key = "skeleton_thickness", label = "Skeleton Thickness", min = 1, max = 5, step = 1 },
    { key = "traceline_thickness", label = "Traceline Thickness", min = 1, max = 5, step = 1 },
    { key = "bar_width", label = "Bar Width", min = 1, max = 20, step = 1 },
    { key = "name_size", label = "Name Size", min = 8, max = 50, step = 1 },
    { key = "distance_size", label = "Distance Size", min = 8, max = 50, step = 1 },
    { key = "text_weight", label = "Text Weight", min = 1, max = 3, step = 1,
      hint = "Name / distance text thickness: 1 normal, 2 bold, 3 heavy" },
}

local OPTION_TOGGLES <const> = {
    { key = "health_bg", label = "Health Bar Background", hint = "Show background for health bar" },
    { key = "armor_bg", label = "Armor Bar Background", hint = "Show background for armor bar" },
}

local BOX_STYLES <const> = { "corner", "filled" }
local BOX_STYLE_NAMES <const> = { "Corner", "Filled" }

local state = { tab = 1 }

local page_colors = {}

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[Esp.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[Esp.GeneralPage] lang is required")
end

local function sync_page_colors()
    local live = Settings.current()
    for _, category in ipairs(TYPE_KEYS) do
        local bucket = page_colors[category]
        if not bucket then
            bucket = {}
            page_colors[category] = bucket
        end
        local cfg = live[category]
        for _, item in ipairs(COLOR_ITEMS) do
            local source = cfg[item.key]
            local target = bucket[item.key]
            if not target then
                target = {}
                bucket[item.key] = target
            end
            target.r, target.g, target.b, target.a = source.r, source.g, source.b, source.a
        end
    end
end

local function draw_toggle(category, item)
    local current = Settings.get_option(category, item.key)
    local value = ui.Checkbox(_T(item.label), current, make_hint(item.label, item.hint))
    if value ~= current then
        Settings.set_option(category, item.key, value)
    end
end

local function draw_type_left(category)
    ui.Group(_T("General"), function()
        local enabled = Settings.get_option(category, "enabled")
        local new_enabled = ui.Checkbox(_T("Enable ESP"), enabled, make_hint("Enable ESP", TYPE_DESC[category]))
        if new_enabled ~= enabled then
            Settings.set_option(category, "enabled", new_enabled)
        end
        for _, item in ipairs(GENERAL_TOGGLES) do draw_toggle(category, item) end
    end)

    ui.Group(_T("Info"), function()
        for _, item in ipairs(INFO_TOGGLES) do draw_toggle(category, item) end
    end)
end

local function draw_type_right(category)
    ui.Group(_T("Tracers"), function()
        draw_toggle(category, TRACELINE_TOGGLE)

        local origin = Settings.get_option(category, "traceline_origin") or 1
        local new_origin = ui.Combo(_T("Traceline Origin"), origin, lang.translate_list(TRACELINE_ORIGINS), make_hint("Traceline Origin", "Starting position of tracelines"))
        if new_origin ~= origin then
            Settings.set_option(category, "traceline_origin", new_origin)
        end
    end)

    ui.Group(_T("Distance"), function()
        local max_dist = Settings.get_option(category, "max_distance") or 200
        local new_max = ui.Slider(_T("Max Distance"), max_dist, 50, 500, 10, make_hint("Max Distance", "Maximum display distance (meters)"))
        if new_max ~= max_dist then
            Settings.set_option(category, "max_distance", new_max)
        end
    end)

    ui.Group(_T("Colors"), function()
        for _, item in ipairs(COLOR_ITEMS) do
            local id = StringId.concat(_T(item.label), StringId.concat("##esp_", StringId.concat(category, StringId.concat("_", item.key))))
            if ui.ColorPicker(id, page_colors[category], item.key) then
                Settings.set_color(category, item.key, page_colors[category][item.key])
            end
        end
    end)
end

local function draw_type_settings(category)
    ui.DualColumn(function() draw_type_left(category) end, function() draw_type_right(category) end)
end

local function draw_style_group()
    local box_style = Settings.get_style("box_style")
    local index = 1
    for i = 1, #BOX_STYLES do
        if BOX_STYLES[i] == box_style then index = i break end
    end
    local new_index = ui.Combo(_T("Box Style"), index, lang.translate_list(BOX_STYLE_NAMES), make_hint("Box Style", "Corner: 8 draw calls, Filled: 1 draw call (best performance)"))
    if new_index ~= index then
        Settings.set_style("box_style", BOX_STYLES[new_index])
    end

    if Settings.get_style("box_style") == "filled" then
        local alpha = Settings.get_style("box_fill_alpha")
        local new_alpha = ui.Slider(_T("Fill Alpha"), alpha, 20, 200, 10, make_hint("Fill Alpha", "Filled box transparency"))
        if new_alpha ~= alpha then
            Settings.set_style("box_fill_alpha", new_alpha)
        end
    end

    for _, item in ipairs(STYLE_SLIDERS) do
        local current = Settings.get_style(item.key)
        local value = ui.Slider(_T(item.label), current, item.min, item.max, item.step,
            make_hint(item.label, item.hint))
        if value ~= current then
            Settings.set_style(item.key, value)
        end
    end
end

local function draw_settings_left()
    ui.Group(_T("Style"), draw_style_group)
end

local function draw_options_group()
    for _, item in ipairs(OPTION_TOGGLES) do
        local current = Settings.get_style(item.key)
        local value = ui.Checkbox(_T(item.label), current, make_hint(item.label, item.hint))
        if value ~= current then
            Settings.set_style(item.key, value)
        end
    end
end

local function draw_settings_right()
    ui.Group(_T("Options"), draw_options_group)
end

local function draw_settings()
    ui.DualColumn(draw_settings_left, draw_settings_right)
end

function GeneralPage.draw()
    sync_page_colors()

    state.tab = ui.SubTabBar2(lang.translate_list(TABS), state.tab)

    if state.tab >= 1 and state.tab <= #TYPE_KEYS then
        draw_type_settings(TYPE_KEYS[state.tab])
    else
        draw_settings()
    end
end

return GeneralPage
