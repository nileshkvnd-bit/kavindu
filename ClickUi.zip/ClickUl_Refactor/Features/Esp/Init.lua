local GeneralPage = require("ClickUl_Refactor.Features.Esp.GeneralPage")
local EspRuntime = require("ClickUl_Refactor.Features.Esp.Core.EspRuntime")
local Settings = require("ClickUl_Refactor.Features.Esp.Settings")

local Esp = {}

function Esp.init(ctx)
    local ui = assert(ctx.ui, "[Esp] ui is required")
    local lang = assert(ctx.lang, "[Esp] lang is required")
    local logger = assert(ctx.logger, "[Esp] logger is required")
    local settings = assert(ctx.settings, "[Esp] settings is required")

    Settings.bind_storage(settings)
    EspRuntime.init({ logger = logger, lang = lang })
    GeneralPage.init({ ui = ui, lang = lang })

    logger.info("Features.Esp", "ESP module initialized")
    return true
end

function Esp.draw()
    GeneralPage.draw()
end

function Esp.on_shutdown()
    EspRuntime.on_shutdown()
end

return Esp
