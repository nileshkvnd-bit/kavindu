local Renderer = {}

local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")
local EntityPool = require("ClickUl_Refactor.Core.EntityPool")
local Projection = require("ClickUl_Refactor.Core.Projection")
local HudDraw = require("ClickUl_Refactor.Core.HudDraw")
local Util = require("ClickUl_Refactor.Core.Util")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Bones = require("ClickUl_Refactor.Features.Esp.Core.Bones")
local Vitals = require("ClickUl_Refactor.Features.Esp.Core.Vitals")
local EntityBones = require("ClickUl_Refactor.Core.EntityBones")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")

local math_floor = math.floor
local math_min = math.min
local math_max = math.max
local math_abs = math.abs
local string_format = string.format

local PED_HEIGHT <const> = 2.1
local PED_WIDTH_RATIO <const> = 1.1 / 2.1
local ANIMAL_HALF_HEIGHT <const> = 0.5
local SAFE_BONE_DIST <const> = 150.0
local VEH_HEAD_TOP <const> = 0.25
local VEH_HEAD_BOTTOM <const> = 0.75
local VEH_SEAT_TOP <const> = 0.4
local VEH_SEAT_BOTTOM <const> = 0.5
local MIN_BOX_HEIGHT <const> = 5.0
local DOT_SIZE <const> = 4.0
local BAR_SPACING <const> = 2.0
local BAR_REF_HEIGHT <const> = 95.0
local BAR_MIN_WIDTH <const> = 1.0
local BAR_MAX_SCALE <const> = 3.0
local SMOOTH_CACHE_LIMIT <const> = 400
local DIST_STRING_LIMIT <const> = 600

local LOD_SIMPLIFIED <const> = 150.0
local LOD_MINIMAL <const> = 500.0

local SMOOTH_STILL <const> = 0.3
local SMOOTH_SLOW <const> = 0.5
local SMOOTH_FAST <const> = 0.85

local CATEGORY_LABELS <const> = {
    npc = "NPC",
    cop = "Cop",
    hostile = "Hostile",
    animal = "Animal",
}

local HEALTH_BG <const> = { r = 40, g = 40, b = 40, a = 180 }
local ARMOR_BG <const> = { r = 40, g = 40, b = 40, a = 180 }

local state = {
    smooth = {},
    dist_strings = {},
    fill_colors = {},
    temp_head = { x = 0, y = 0, z = 0 },
    temp_foot = { x = 0, y = 0, z = 0 },
}

local lang = nil

local function _T(text)
    if lang then return lang.get(text) end
    return text
end

local is_safe = Util.is_screen_safe

local function count_table(tbl)
    local n = 0
    for _ in pairs(tbl) do n = n + 1 end
    return n
end

local function live_ped_set(live)
    local set = {}
    if type(live) ~= "table" then return set end
    for _, list in pairs(live) do
        for i = 1, #list do
            local ped = list[i].ped
            if ped then set[ped] = true end
        end
    end
    return set
end

local function dist_string(dist)
    local rounded = math_floor(dist + 0.5)
    local cached = state.dist_strings[rounded]
    if cached then return cached end
    local text = string_format("%dm", rounded)
    state.dist_strings[rounded] = text
    return text
end

local function fill_color(category, cfg, style)
    local color = state.fill_colors[category]
    local source = cfg.color
    if not color then
        color = { r = source.r, g = source.g, b = source.b, a = style.box_fill_alpha }
        state.fill_colors[category] = color
        return color
    end
    color.r = source.r
    color.g = source.g
    color.b = source.b
    color.a = style.box_fill_alpha
    return color
end

local function draw_dot(center_x, center_y, color)
    if not (is_safe(center_x) and is_safe(center_y)) then return false end
    HudDraw.overlay_dot(center_x, center_y, DOT_SIZE, color)
    return true
end

local function draw_box(category, x1, y1, x2, y2, cfg, style)
    if not (is_safe(x1) and is_safe(y1) and is_safe(x2) and is_safe(y2)) then return false end
    local width = x2 - x1
    local height = y2 - y1

    if style.box_style == "filled" then
        HudDraw.overlay_rect(x1, y1, width, height, fill_color(category, cfg, style))
        return true
    end

    local color = cfg.color
    local thickness = style.box_thickness
    local corner = math_floor(math_min(width, height) * 0.25)
    if corner < 1 then return false end
    HudDraw.overlay_rect(x1, y1, corner, thickness, color)
    HudDraw.overlay_rect(x1, y1, thickness, corner, color)
    HudDraw.overlay_rect(x2 - corner, y1, corner, thickness, color)
    HudDraw.overlay_rect(x2 - thickness, y1, thickness, corner, color)
    HudDraw.overlay_rect(x1, y2 - thickness, corner, thickness, color)
    HudDraw.overlay_rect(x1, y2 - corner, thickness, corner, color)
    HudDraw.overlay_rect(x2 - corner, y2 - thickness, corner, thickness, color)
    HudDraw.overlay_rect(x2 - thickness, y2 - corner, thickness, corner, color)
    return true
end

local function scaled_bar_width(box_height, style)
    local scale = box_height / BAR_REF_HEIGHT
    if scale > BAR_MAX_SCALE then scale = BAR_MAX_SCALE end
    local width = style.bar_width * scale
    if width < BAR_MIN_WIDTH then width = BAR_MIN_WIDTH end
    return width
end

local function draw_health_bar(x1, y1, box_height, cfg, style, target)
    if not (is_safe(x1) and is_safe(y1)) then return false end
    local health = target.health or 0
    local max_health = target.max_health or 100
    local pct = math_min(1.0, health / math_max(1, max_health))

    local bar_width = scaled_bar_width(box_height, style)
    local bar_x = x1 - bar_width - BAR_SPACING
    local drew = false
    if style.health_bg then
        HudDraw.overlay_rect(bar_x, y1, bar_width, box_height, HEALTH_BG)
        drew = true
    end

    local bar_height = math_floor(box_height * pct)
    if bar_height <= 0 then return drew end
    HudDraw.overlay_rect(bar_x, y1 + box_height - bar_height, bar_width, bar_height, cfg.health_color)
    return true
end

local function draw_armor_bar(x2, y1, box_height, cfg, style, target)
    local armor = target.armour or 0
    if armor <= 0 then return false end
    if not (is_safe(x2) and is_safe(y1)) then return false end
    local pct = math_min(1.0, armor / 100.0)

    local bar_width = scaled_bar_width(box_height, style)
    local bar_x = x2 + BAR_SPACING
    local drew = false
    if style.armor_bg then
        HudDraw.overlay_rect(bar_x, y1, bar_width, box_height, ARMOR_BG)
        drew = true
    end

    local bar_height = math_floor(box_height * pct)
    if bar_height <= 0 then return drew end
    HudDraw.overlay_rect(bar_x, y1 + box_height - bar_height, bar_width, bar_height, cfg.armor_color)
    return true
end

local function draw_traceline(target_x, target_y, origin_type, cfg, style)
    if not (is_safe(target_x) and is_safe(target_y)) then return false end
    local resolution = Runtime.resolution()
    local origin_x = resolution.x * 0.5
    local origin_y = resolution.y
    if origin_type == 1 then
        origin_y = 0
    elseif origin_type == 2 then
        origin_y = resolution.y * 0.5
    end
    HudDraw.overlay_line(origin_x, origin_y, target_x, target_y, style.traceline_thickness, cfg.color)
    return true
end

local function draw_name(ped, category, cfg, style, center_x, top_y)
    if not (is_safe(center_x) and is_safe(top_y)) then return false end
    local name = EntityPool.get_ped_model_name(ped) or _T(CATEGORY_LABELS[category] or category)
    HudDraw.overlay_text(name, center_x, top_y - style.name_size - 2, style.name_size, cfg.color, true, style.text_weight)
    return true
end

local function draw_distance(cfg, style, center_x, bottom_y, dist)
    if not (is_safe(center_x) and is_safe(bottom_y)) then return false end
    HudDraw.overlay_text(dist_string(dist), center_x, bottom_y + 2, style.distance_size, cfg.color, true, style.text_weight)
    return true
end

local function needs_body_geometry(cfg)
    return cfg.box or cfg.health or cfg.armor or cfg.name or cfg.distance
end

local function traceline_anchor(ped, pos, dist)
    if dist < SAFE_BONE_DIST and EntityPool.is_ped_in_vehicle(ped) then
        local h = EntityBones.ped_head_world(ped)
        if h and is_safe(h.x) and is_safe(h.y) and is_safe(h.z) then return h end
    end
    return pos
end

local function draw_lightweight_target(pos, ped, category, dist, lod_mult, cfg, style)
    local drew = false
    if cfg.traceline then
        local x, y = Projection.world_to_screen_xy(traceline_anchor(ped, pos, dist))
        if x and draw_traceline(x, y, cfg.traceline_origin, cfg, style) then
            drew = true
        end
    end
    if Bones.should_draw(category, dist, lod_mult, cfg) and Bones.draw(ped, cfg, style) then
        drew = true
    end
    return drew
end

local function smooth_box(ped, x1, top_y, x2, bottom_y)
    local cached = state.smooth[ped]
    if not cached then
        state.smooth[ped] = { x1, top_y, x2, bottom_y }
        return x1, top_y, x2, bottom_y
    end

    local delta = math_abs(x1 - cached[1]) + math_abs(top_y - cached[2])
        + math_abs(x2 - cached[3]) + math_abs(bottom_y - cached[4])
    local factor = SMOOTH_FAST
    if delta < 2 then
        factor = SMOOTH_STILL
    elseif delta < 10 then
        factor = SMOOTH_SLOW
    end

    x1 = cached[1] + (x1 - cached[1]) * factor
    top_y = cached[2] + (top_y - cached[2]) * factor
    x2 = cached[3] + (x2 - cached[3]) * factor
    bottom_y = cached[4] + (bottom_y - cached[4]) * factor
    cached[1], cached[2], cached[3], cached[4] = x1, top_y, x2, bottom_y
    return x1, top_y, x2, bottom_y
end

local function resolve_body_span(ped, category, pos, dist, head, foot)
    if category == "animal" then
        local dims = ModelDims.get(EntityPool.get_ped_model_hash(ped))
        if dims then
            head.x, head.y, head.z = pos.x, pos.y, pos.z + dims.max.z
            foot.x, foot.y, foot.z = pos.x, pos.y, pos.z + dims.min.z
            local z_ext = dims.max.z - dims.min.z
            if z_ext > 0.01 then
                local x_ext = dims.max.x - dims.min.x
                local y_ext = dims.max.y - dims.min.y
                return (x_ext > y_ext and x_ext or y_ext) / z_ext
            end
            return
        end
        head.x, head.y, head.z = pos.x, pos.y, pos.z + ANIMAL_HALF_HEIGHT
        foot.x, foot.y, foot.z = pos.x, pos.y, pos.z - ANIMAL_HALF_HEIGHT
        return
    end

    if EntityPool.is_ped_in_vehicle(ped) then
        if dist < SAFE_BONE_DIST then
            local h = EntityBones.ped_head_world(ped)
            if h and is_safe(h.x) and is_safe(h.y) and is_safe(h.z) then
                head.x, head.y, head.z = h.x, h.y, h.z + VEH_HEAD_TOP
                foot.x, foot.y, foot.z = h.x, h.y, h.z - VEH_HEAD_BOTTOM
                return
            end
        end
        head.x, head.y, head.z = pos.x, pos.y, pos.z + VEH_SEAT_TOP
        foot.x, foot.y, foot.z = pos.x, pos.y, pos.z - VEH_SEAT_BOTTOM
        return
    end

    head.x, head.y, head.z = pos.x, pos.y, pos.z + PED_HEIGHT * 0.4
    foot.x, foot.y, foot.z = pos.x, pos.y, pos.z - PED_HEIGHT * 0.5
end

function Renderer.init(ctx)
    lang = ctx and ctx.lang or lang
end

function Renderer.draw_target(entry, category, dist, lod_mult, snapshot)
    local pos = entry.pos
    if not pos or not (is_safe(pos.x) and is_safe(pos.y) and is_safe(pos.z)) then return false end

    local cfg = snapshot[category]
    if not cfg then return false end
    local style = snapshot.style
    local ped = entry.ped
    local color = cfg.color
    local body_geometry = needs_body_geometry(cfg)
    local has_lightweight = cfg.traceline or Bones.should_draw(category, dist, lod_mult, cfg)

    if not body_geometry and not has_lightweight then return false end

    if dist >= LOD_MINIMAL * lod_mult then
        local x, y = Projection.world_to_screen_xy(pos)
        if not x then return false end
        local drew = false
        if cfg.traceline and draw_traceline(x, y, cfg.traceline_origin, cfg, style) then
            drew = true
        end
        if body_geometry and draw_dot(x, y, color) then
            drew = true
        end
        return drew
    end

    if not body_geometry then
        return draw_lightweight_target(pos, ped, category, dist, lod_mult, cfg, style)
    end

    local head = state.temp_head
    local foot = state.temp_foot
    local width_ratio = resolve_body_span(ped, category, pos, dist, head, foot) or PED_WIDTH_RATIO

    local head_x, head_y = Projection.world_to_screen_xy(head)
    if not head_x then return false end
    local foot_x, foot_y = Projection.world_to_screen_xy(foot)
    if not foot_x then return false end

    local top_y = math_min(head_y, foot_y)
    local bottom_y = math_max(head_y, foot_y)
    local box_height = bottom_y - top_y
    if box_height <= MIN_BOX_HEIGHT then return false end

    local width = box_height * width_ratio
    local center_x = (head_x + foot_x) * 0.5
    local x1 = center_x - width * 0.5
    local x2 = center_x + width * 0.5

    x1, top_y, x2, bottom_y = smooth_box(ped, x1, top_y, x2, bottom_y)
    box_height = bottom_y - top_y
    center_x = (x1 + x2) * 0.5
    local center_y = (top_y + bottom_y) * 0.5

    local drew = false
    if dist >= LOD_SIMPLIFIED * lod_mult then
        if cfg.traceline and draw_traceline(center_x, center_y, cfg.traceline_origin, cfg, style) then drew = true end
        if cfg.name and draw_name(ped, category, cfg, style, center_x, center_y) then drew = true end
        if cfg.distance and draw_distance(cfg, style, center_x, center_y, dist) then drew = true end
        return drew
    end

    if cfg.health or cfg.armor then Vitals.apply(entry, cfg) end
    if cfg.box and draw_box(category, x1, top_y, x2, bottom_y, cfg, style) then drew = true end
    if cfg.health and draw_health_bar(x1, top_y, box_height, cfg, style, entry) then drew = true end
    if cfg.armor and draw_armor_bar(x2, top_y, box_height, cfg, style, entry) then drew = true end
    if Bones.should_draw(category, dist, lod_mult, cfg) and Bones.draw(ped, cfg, style) then drew = true end
    if cfg.traceline and draw_traceline(center_x, center_y, cfg.traceline_origin, cfg, style) then drew = true end
    local name_y = cfg.box and top_y or center_y
    local dist_y = cfg.box and bottom_y or center_y
    if cfg.name and draw_name(ped, category, cfg, style, center_x, name_y) then drew = true end
    if cfg.distance and draw_distance(cfg, style, center_x, dist_y, dist) then drew = true end
    return drew
end

function Renderer.prune_caches(live)
    local live_set = live_ped_set(live)
    if CacheUtils.prune_live_keys(state.smooth, live_set) > SMOOTH_CACHE_LIMIT then state.smooth = {} end
    Bones.prune(live_set)
    if count_table(state.dist_strings) > DIST_STRING_LIMIT then state.dist_strings = {} end
end

function Renderer.clear()
    state.smooth = {}
    state.dist_strings = {}
    state.fill_colors = {}
    Bones.clear()
end

return Renderer
