local Bones = {}
local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")
local EntityBones = require("ClickUl_Refactor.Core.EntityBones")
local Projection = require("ClickUl_Refactor.Core.Projection")
local HudDraw = require("ClickUl_Refactor.Core.HudDraw")
local Util = require("ClickUl_Refactor.Core.Util")

local SKELETON_MAX_DIST <const> = 100.0
local BONE_SMOOTH <const> = 0.4
local SMOOTH_CACHE_LIMIT <const> = 400

local GATE_BODY_RADIUS <const> = 1.5

local BONE_IDS <const> = {
    HEAD = 31086, NECK = 39317, PELVIS = 11816,
    L_UPPERARM = 45509, L_FOREARM = 61163, L_HAND = 18905,
    R_UPPERARM = 40269, R_FOREARM = 28252, R_HAND = 57005,
    L_THIGH = 58271, L_CALF = 63931, L_FOOT = 14201,
    R_THIGH = 51826, R_CALF = 36864, R_FOOT = 52301,
}

local SKELETON_LINES <const> = {
    { BONE_IDS.HEAD, BONE_IDS.NECK }, { BONE_IDS.NECK, BONE_IDS.PELVIS },
    { BONE_IDS.NECK, BONE_IDS.L_UPPERARM }, { BONE_IDS.L_UPPERARM, BONE_IDS.L_FOREARM }, { BONE_IDS.L_FOREARM, BONE_IDS.L_HAND },
    { BONE_IDS.NECK, BONE_IDS.R_UPPERARM }, { BONE_IDS.R_UPPERARM, BONE_IDS.R_FOREARM }, { BONE_IDS.R_FOREARM, BONE_IDS.R_HAND },
    { BONE_IDS.PELVIS, BONE_IDS.L_THIGH }, { BONE_IDS.L_THIGH, BONE_IDS.L_CALF }, { BONE_IDS.L_CALF, BONE_IDS.L_FOOT },
    { BONE_IDS.PELVIS, BONE_IDS.R_THIGH }, { BONE_IDS.R_THIGH, BONE_IDS.R_CALF }, { BONE_IDS.R_CALF, BONE_IDS.R_FOOT },
}

local state = {
    smooth = {},
    points = {},
    draw_id = 0,
}

local is_safe = Util.is_screen_safe

local function skeleton_bone_world(ped, bone_id)
    return EntityBones.ped_bone_world(ped, bone_id)
end

local function bone_screen(ped, bone_id, smooth, world)
    world = world or skeleton_bone_world(ped, bone_id)
    if not world then return nil end
    local sx, sy = Projection.world_to_screen_xy(world)
    if not sx then return nil end
    if not (is_safe(sx) and is_safe(sy)) then return nil end

    local prev = smooth[bone_id]
    if prev then
        sx = prev[1] * (1 - BONE_SMOOTH) + sx * BONE_SMOOTH
        sy = prev[2] * (1 - BONE_SMOOTH) + sy * BONE_SMOOTH
        prev[1], prev[2] = sx, sy
    else
        smooth[bone_id] = { sx, sy }
    end
    return sx, sy
end

function Bones.should_draw(category, dist, lod_mult, cfg)
    if not cfg or not cfg.skeleton then return false end
    if category == "animal" then return false end
    return dist <= SKELETON_MAX_DIST * (lod_mult or 1.0)
end

local function point(points, draw_id, ped, smooth, bone_id, world)
    local cached = points[bone_id]
    if not cached then
        cached = { x = 0, y = 0, valid = false, draw_id = 0 }
        points[bone_id] = cached
    elseif cached.draw_id == draw_id then
        return cached.valid and cached or nil
    end

    local sx, sy = bone_screen(ped, bone_id, smooth, world)
    cached.draw_id = draw_id
    cached.valid = sx and true or false
    if not sx then return nil end
    cached.x = sx
    cached.y = sy
    return cached
end

function Bones.draw(ped, cfg, style)
    local smooth = state.smooth[ped]
    if not smooth then
        smooth = {}
        state.smooth[ped] = smooth
    end

    local points = state.points
    state.draw_id = state.draw_id + 1
    local draw_id = state.draw_id

    local pelvis_world = skeleton_bone_world(ped, BONE_IDS.PELVIS)
    if pelvis_world then
        if not Projection.maybe_on_screen(pelvis_world, GATE_BODY_RADIUS) then
            return false
        end
        point(points, draw_id, ped, smooth, BONE_IDS.PELVIS, pelvis_world)
    end

    local color = cfg.color
    local thickness = style.skeleton_thickness
    local drew = false
    for i = 1, #SKELETON_LINES do
        local link = SKELETON_LINES[i]
        local p1 = point(points, draw_id, ped, smooth, link[1])
        local p2 = point(points, draw_id, ped, smooth, link[2])
        if p1 and p2 then
            HudDraw.overlay_line(p1.x, p1.y, p2.x, p2.y, thickness, color)
            drew = true
        end
    end
    return drew
end

function Bones.prune(live_set)
    if type(live_set) ~= "table" then
        state.smooth = {}
        return
    end
    if CacheUtils.prune_live_keys(state.smooth, live_set) > SMOOTH_CACHE_LIMIT then state.smooth = {} end
end

function Bones.clear()
    state.smooth = {}
    state.points = {}
    state.draw_id = 0
end

return Bones
