local Vitals = {}
local PedMemory = require("ClickUl_Refactor.Core.PedMemory")

local os_clock <const> = os.clock
local TTL_S <const> = 0.15
local CACHE_WIPE_COUNT <const> = 256

local cache = {}
local cache_count = 0

local function cache_rec(ped)
    local rec = cache[ped]
    if rec then return rec end
    if cache_count >= CACHE_WIPE_COUNT then
        cache = {}
        cache_count = 0
    end
    rec = {}
    cache[ped] = rec
    cache_count = cache_count + 1
    return rec
end

function Vitals.apply(entry, needs)
    if not entry then return end
    entry.health = nil
    entry.max_health = nil
    entry.armour = nil
    entry.armor = nil

    needs = needs or {}
    local needs_health = needs.health and true or false
    local needs_armor = needs.armor and true or false
    if not needs_health and not needs_armor then return end

    local ped = entry.ped
    if not ped or ped == 0 then return end

    local rec = cache_rec(ped)
    local now = os_clock()
    local refresh_health = needs_health
        and (not rec.h_t or now - rec.h_t >= TTL_S or now < rec.h_t)
    local refresh_armor = needs_armor
        and (not rec.a_t or now - rec.a_t >= TTL_S or now < rec.a_t)
    if refresh_health or refresh_armor then
        local health, max_health, armour = PedMemory.vitals(ped, refresh_health, refresh_armor)
        if refresh_health then
            rec.health = health
            rec.max_health = max_health
            rec.h_t = health ~= nil and now or nil
        end
        if refresh_armor then
            rec.armour = armour
            rec.a_t = armour ~= nil and now or nil
        end
    end

    if needs_health then
        entry.health = rec.health
        entry.max_health = rec.max_health
    end
    if needs_armor then
        entry.armour = rec.armour
        entry.armor = rec.armour
    end
end

return Vitals
