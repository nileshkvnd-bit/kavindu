local EspRuntime = {}

local EntityPool = require("ClickUl_Refactor.Core.EntityPool")
local FeatureThread = require("ClickUl_Refactor.Core.FeatureThread")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Projection = require("ClickUl_Refactor.Core.Projection")
local Settings = require("ClickUl_Refactor.Features.Esp.Settings")
local Renderer = require("ClickUl_Refactor.Features.Esp.Core.Renderer")

local math_sqrt = math.sqrt

local LOD_DYNAMIC_THRESHOLD <const> = 30
local LOD_DYNAMIC_MIN_MULT <const> = 0.3
local CHUNK_THRESHOLD <const> = 60
local CHUNK_SIZE <const> = 40

local state = {
    frame = 0,
    targets = {},
    live = {},
}

local logger = nil

local pool_options = {
    include_vehicles = false,
    enabled_categories = nil,
    needs_dead = true,
    needs_hostility = false,
    dead_refresh_ms = 300,
    hostility_refresh_ms = 300,
}
local target_options = {
    enabled_categories = nil,
    max_distance_sq = 0,
    exclude_players = true,
    needs_hostility = false,
    out = nil,
}

local function clear_list(list)
    for i = 1, #list do list[i] = nil end
end


local function cull_behind(entry)
    if not entry.pos or not Projection.is_behind(entry.pos) then return false end
    return not EntityPool.is_ped_in_vehicle(entry.ped)
end

local function collect(snapshot, targets, live)
    local total = 0
    for _, category in ipairs(Settings.category_keys()) do
        local cfg = snapshot[category]
        local list = targets[category]
        local out = live[category]
        if not out then
            out = {}
            live[category] = out
        else
            clear_list(out)
        end
        local has_output = cfg and (cfg.box or cfg.health or cfg.armor or cfg.name
            or cfg.distance or cfg.traceline or cfg.skeleton)
        if cfg and cfg.enabled and has_output and list then
            local type_max_sq = cfg.max_distance * cfg.max_distance
            for i = 1, #list do
                local entry = list[i]
                if not entry.is_dead and (entry.dist_sq or 0) <= type_max_sq
                    and not cull_behind(entry)
                then
                    out[#out + 1] = entry
                    total = total + 1
                end
            end
        end
    end
    return total
end

local function dynamic_lod_mult(total)
    if total <= LOD_DYNAMIC_THRESHOLD then return 1.0 end
    local mult = LOD_DYNAMIC_THRESHOLD / total
    if mult < LOD_DYNAMIC_MIN_MULT then mult = LOD_DYNAMIC_MIN_MULT end
    return mult
end

local function by_dist(a, b)
    return (a.dist_sq or 0) < (b.dist_sq or 0)
end

local function tick()
    if not Settings.any_enabled() then
        EspRuntime.stop()
        return
    end

    local my_pos = Players.local_coords()
    if not my_pos then return end

    Projection.refresh_camera()

    state.frame = state.frame + 1

    local snapshot = Settings.current()
    local enabled = Settings.enabled_map()
    local max_distance = Settings.max_enabled_distance()
    local wanted = EntityPool.player_wanted_level(Players.local_id())
    local wants_hostility = enabled.hostile or enabled.npc

    pool_options.enabled_categories = enabled
    pool_options.needs_hostility = wants_hostility
    EntityPool.update(Players.local_ped(), my_pos, wanted, max_distance, pool_options)

    target_options.enabled_categories = enabled
    target_options.max_distance_sq = max_distance * max_distance
    target_options.needs_hostility = wants_hostility
    target_options.out = state.targets
    local targets = EntityPool.get_esp_targets(target_options)

    local live = state.live
    local total = collect(snapshot, targets, live)
    local lod_mult = dynamic_lod_mult(total)

    if total > CHUNK_THRESHOLD then
        for _, category in ipairs(Settings.category_keys()) do
            local list = live[category]
            if list and #list > 1 then table.sort(list, by_dist) end
        end
    end

    local drawn = 0
    for _, category in ipairs(Settings.category_keys()) do
        local list = live[category]
        if list then
            local priority = category == "hostile" or category == "cop"
            for i = 1, #list do
                if total > CHUNK_THRESHOLD and drawn >= CHUNK_SIZE and not priority then
                    break
                end
                local entry = list[i]
                if Renderer.draw_target(entry, category, math_sqrt(entry.dist_sq or 0), lod_mult, snapshot) then
                    drawn = drawn + 1
                end
            end
        end
    end

    if state.frame % 60 == 0 then Renderer.prune_caches(live) end
end

local thread = FeatureThread.new(tick)

function EspRuntime.init(ctx)
    logger = ctx and ctx.logger or logger
    Renderer.init({ lang = ctx and ctx.lang })
    Settings.set_change_callback(function() EspRuntime.evaluate() end)
    EspRuntime.evaluate()
end

function EspRuntime.start()
    if not thread.start() then return end
    if logger then logger.verbose("Features.Esp", "ESP render thread started") end
end

function EspRuntime.stop()
    if not thread.stop() then return end
    Renderer.clear()
    if logger then logger.verbose("Features.Esp", "ESP render thread stopped") end
end

function EspRuntime.evaluate()
    if Settings.any_enabled() then
        EspRuntime.start()
    else
        EspRuntime.stop()
    end
end

function EspRuntime.on_shutdown()
    EspRuntime.stop()
end

return EspRuntime
