local Settings = {}

local CATEGORY_ORDER <const> = { "hostile", "cop", "animal", "npc" }
local SECTION_NAME <const> = "Esp"

local DEFAULT_COLORS <const> = {
    npc = { r = 255, g = 255, b = 255, a = 200 },
    cop = { r = 66, g = 135, b = 245, a = 200 },
    hostile = { r = 255, g = 60, b = 60, a = 200 },
    animal = { r = 100, g = 255, b = 100, a = 200 },
}

local DEFAULT_HEALTH_COLOR <const> = { r = 0, g = 255, b = 0, a = 220 }
local DEFAULT_ARMOR_COLOR <const> = { r = 50, g = 150, b = 255, a = 220 }

local OPTION_TYPES <const> = {
    enabled = "boolean",
    box = "boolean",
    skeleton = "boolean",
    health = "boolean",
    armor = "boolean",
    name = "boolean",
    distance = "boolean",
    traceline = "boolean",
    traceline_origin = "origin",
    max_distance = "distance",
    color = "color",
    health_color = "color",
    armor_color = "color",
}

local STYLE_NUMERIC <const> = {
    box_fill_alpha = { min = 0, max = 255 },
    box_thickness = { min = 1, max = 5 },
    skeleton_thickness = { min = 1, max = 5 },
    traceline_thickness = { min = 1, max = 5 },
    bar_width = { min = 1, max = 20 },
    name_size = { min = 8, max = 50 },
    distance_size = { min = 8, max = 50 },
    text_weight = { min = 1, max = 3 },
}

local current = nil
local storage = nil
local loaded = false
local on_change = nil
local enabled_cache = {}

local math_floor = math.floor

local function copy_table(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for k, v in pairs(value) do
        result[k] = copy_table(v)
    end
    return result
end

local function clamp_number(value, min_value, max_value, fallback)
    local number = tonumber(value)
    if not number then number = fallback end
    if number < min_value then return min_value end
    if number > max_value then return max_value end
    return number
end

local function clamp_channel(value, fallback)
    return math_floor(clamp_number(value, 0, 255, fallback or 0))
end

local function color_copy(color, default)
    color = type(color) == "table" and color or {}
    default = default or {}
    return {
        r = clamp_channel(color.r, default.r),
        g = clamp_channel(color.g, default.g),
        b = clamp_channel(color.b, default.b),
        a = clamp_channel(color.a, default.a or 200),
    }
end

local function default_type_config(category)
    return {
        enabled = false,
        box = true,
        skeleton = false,
        health = false,
        armor = false,
        name = false,
        distance = false,
        traceline = false,
        traceline_origin = 1,
        max_distance = 200.0,
        color = color_copy(DEFAULT_COLORS[category], DEFAULT_COLORS[category]),
        health_color = color_copy(DEFAULT_HEALTH_COLOR, DEFAULT_HEALTH_COLOR),
        armor_color = color_copy(DEFAULT_ARMOR_COLOR, DEFAULT_ARMOR_COLOR),
    }
end

local function defaults()
    local result = {
        style = {
            box_style = "filled",
            box_fill_alpha = 80,
            box_thickness = 2,
            skeleton_thickness = 1,
            traceline_thickness = 2,
            bar_width = 3,
            name_size = 30,
            distance_size = 30,
            text_weight = 1,
            health_bg = true,
            armor_bg = true,
        },
    }

    for _, category in ipairs(CATEGORY_ORDER) do
        result[category] = default_type_config(category)
    end
    return result
end

local function normalize_option(category, key, value, fallback)
    local kind = OPTION_TYPES[key]
    if kind == "boolean" then
        if value == nil then return fallback and true or false end
        return value and true or false
    end
    if kind == "distance" then return clamp_number(value, 0, 500, fallback or 200.0) end
    if kind == "origin" then return math_floor(clamp_number(value, 1, 3, fallback or 1)) end
    if kind == "color" then return color_copy(value, fallback) end
    return fallback
end

local function normalize_style(key, value, fallback)
    if key == "box_style" then
        if value == "corner" or value == "filled" then return value end
        return fallback
    end
    if key == "health_bg" or key == "armor_bg" then
        if value == nil then return fallback and true or false end
        return value and true or false
    end

    local bounds = STYLE_NUMERIC[key]
    if bounds then
        return clamp_number(value, bounds.min, bounds.max, fallback)
    end
    return fallback
end

local function normalize_snapshot(input)
    local result = defaults()
    input = type(input) == "table" and input or {}

    for _, category in ipairs(CATEGORY_ORDER) do
        local source = type(input[category]) == "table" and input[category] or {}
        local target = result[category]
        for key, fallback in pairs(target) do
            target[key] = normalize_option(category, key, source[key], fallback)
        end
    end

    local style_source = type(input.style) == "table" and input.style or {}
    for key, fallback in pairs(result.style) do
        result.style[key] = normalize_style(key, style_source[key], fallback)
    end
    return result
end

local function ensure_loaded()
    if loaded then return end
    local saved = storage and storage.get_section(SECTION_NAME) or nil
    current = normalize_snapshot(saved)
    loaded = true
end

local function notify_change()
    if on_change then on_change() end
end

local function queue_save()
    if not storage then return end
    storage.set_section(SECTION_NAME, copy_table(current))
    storage.save()
end

local function set_current(next_value, save)
    current = normalize_snapshot(next_value)
    loaded = true
    notify_change()
    if save then queue_save() end
end

local function reset_current()
    set_current(defaults(), true)
end

function Settings.bind_storage(settings_module)
    storage = settings_module
    loaded = false
    ensure_loaded()
    assert(type(storage.register_reset_handler) == "function", "settings storage reset handler API is required")
    storage.register_reset_handler(SECTION_NAME, reset_current)
    queue_save()
    return true
end

function Settings.set_change_callback(callback)
    assert(callback == nil or type(callback) == "function", "ESP settings change callback must be function")
    on_change = callback
end

function Settings.category_keys()
    return CATEGORY_ORDER
end

function Settings.snapshot()
    ensure_loaded()
    return copy_table(current)
end

function Settings.current()
    ensure_loaded()
    return current
end

function Settings.get_option(category, key)
    ensure_loaded()
    local cfg = current[category]
    if not cfg then return nil end
    local value = cfg[key]
    if type(value) == "table" then return copy_table(value) end
    return value
end

function Settings.set_option(category, key, value)
    ensure_loaded()
    local cfg = current[category]
    if not cfg or cfg[key] == nil then return false end
    local next_value = normalize_option(category, key, value, cfg[key])
    cfg[key] = next_value
    notify_change()
    queue_save()
    return true
end

function Settings.get_color(category, key)
    ensure_loaded()
    local cfg = current[category]
    local c = cfg and cfg[key]
    if type(c) ~= "table" then return nil end
    return color_copy(c, c)
end

function Settings.set_color(category, key, color)
    ensure_loaded()
    local cfg = current[category]
    if not cfg or type(cfg[key]) ~= "table" then return false end
    cfg[key] = normalize_option(category, key, color, cfg[key])
    notify_change()
    queue_save()
    return true
end

function Settings.get_style(key)
    ensure_loaded()
    return current.style[key]
end

function Settings.set_style(key, value)
    ensure_loaded()
    if current.style[key] == nil then return false end
    current.style[key] = normalize_style(key, value, current.style[key])
    notify_change()
    queue_save()
    return true
end

local function category_renderable(category, cfg)
    if not cfg.enabled then return false end
    if cfg.box or cfg.health or cfg.armor or cfg.name or cfg.distance or cfg.traceline then
        return true
    end
    return (cfg.skeleton and category ~= "animal") and true or false
end

function Settings.any_enabled()
    ensure_loaded()
    for _, category in ipairs(CATEGORY_ORDER) do
        if category_renderable(category, current[category]) then return true end
    end
    return false
end

function Settings.max_enabled_distance()
    ensure_loaded()
    local distance = 0.0
    for _, category in ipairs(CATEGORY_ORDER) do
        local cfg = current[category]
        if category_renderable(category, cfg) and cfg.max_distance > distance then
            distance = cfg.max_distance
        end
    end
    if distance <= 0 then return 200.0 end
    return distance
end

function Settings.enabled_map()
    ensure_loaded()
    for _, category in ipairs(CATEGORY_ORDER) do
        enabled_cache[category] = category_renderable(category, current[category])
    end
    return enabled_cache
end

function Settings.reset(save)
    set_current(defaults(), save ~= false)
    return Settings.snapshot()
end

function Settings.defaults()
    return defaults()
end

return Settings
