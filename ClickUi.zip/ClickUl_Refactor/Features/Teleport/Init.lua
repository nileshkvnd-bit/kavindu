local general_page = require("ClickUl_Refactor.Features.Teleport.GeneralPage")
local saved_places_page = require("ClickUl_Refactor.Features.Teleport.SavedPlacesPage")
local interiors_page = require("ClickUl_Refactor.Features.Teleport.InteriorsPage")

local Teleport = {}

local ui
local lang
local logger

local MAIN_TABS <const> = { "Teleport", "Saved Places" }

local state = {
    main_tab = 1,
}

local function _T(text)
    return lang and lang.get(text) or text
end

function Teleport.init(ctx)
    ui = assert(ctx.ui, "[Teleport] ui is required")
    lang = assert(ctx.lang, "[Teleport] lang is required")
    logger = assert(ctx.logger, "[Teleport] logger is required")
    local hotkeys = assert(ctx.hotkeys, "[Teleport] hotkeys is required")
    local action_registry = assert(ctx.action_registry, "[Teleport] action_registry is required")
    local favorites = assert(ctx.favorites, "[Teleport] favorites is required")

    general_page.init({
        ui = ui,
        lang = lang,
        logger = logger,
        hotkeys = hotkeys,
        action_registry = action_registry,
        favorites = favorites,
    })
    saved_places_page.init({
        ui = ui,
        lang = lang,
        logger = logger,
        action_registry = action_registry,
        favorites = favorites,
    })
    interiors_page.init({
        ui = ui,
        lang = lang,
        logger = logger,
        hotkeys = hotkeys,
        action_registry = action_registry,
        favorites = favorites,
    })

    logger.info("Features.Teleport", "Teleport module initialized")
    return true
end

function Teleport.draw()
    local tabs = {}
    for i = 1, #MAIN_TABS do tabs[i] = _T(MAIN_TABS[i]) end
    state.main_tab = ui.SubTabBar(tabs, state.main_tab)

    if state.main_tab == 1 then
        general_page.draw()
    else
        saved_places_page.draw()
    end
end

return Teleport
