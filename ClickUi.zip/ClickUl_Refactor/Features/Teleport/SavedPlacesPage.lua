local FileBrowserPage = require("ClickUl_Refactor.Features.Common.FileBrowserPage")
local SavedPlaces = require("ClickUl_Refactor.Core.SavedPlaces")
local Teleport = require("ClickUl_Refactor.Core.Teleport")
local StringId = require("ClickUl_Refactor.Core.StringId")

local SavedPlacesPage = {}

local ui
local lang

local save_state = { name = "" }

local function _T(text)
    return lang and lang.get(text) or text
end

local groups_cache = setmetatable({}, { __mode = "k" })

local SAVE_FOLDER <const> = "Places"

local function to_groups(folders)
    local cached = groups_cache[folders]
    if cached then return cached end
    local names = folders.folder_names or {}
    local by = folders.by_folder or {}
    local groups = {}
    if by[SAVE_FOLDER] then
        groups[#groups + 1] = { title = SAVE_FOLDER, items = by[SAVE_FOLDER] }
    end
    for i = 1, #names do
        local name = names[i]
        if name ~= SAVE_FOLDER then
            groups[#groups + 1] = { title = name, items = by[name] or {} }
        end
    end
    groups_cache[folders] = groups
    return groups
end

local function teleport_to(item)
    local position = SavedPlaces.read_position(item.path)
    if not position then return false, "unreadable" end
    Teleport.to_coords(
        { x = position.x, y = position.y, z = position.z or 0.0 },
        { resolve_ground = position.guessed, heading = position.heading }
    )
    return true
end

local function do_save(position, no_pos_warning)
    if not position then
        ui.notify(_T(no_pos_warning or "Could not read position"), "Warning")
        return
    end
    local path, err = SavedPlaces.save(save_state.name, position)
    if path then
        save_state.name = ""
        ui.notify(_T("Location saved"), "Success")
        return
    end
    if err == "missing_filename" then
        ui.notify(_T("Please enter a filename"), "Warning")
        return
    end
    ui.notify(_T("Failed to save file") .. ": " .. tostring(err or "unknown"), "Error")
end

local function save_group_body()
    save_state.name = ui.TextInput(StringId.concat(_T("Place Name"), "##saved_places_name"), save_state.name, 32)
    if ui.Button(StringId.concat(_T("Save Current Location"), "##saved_places_save")) then
        do_save(Teleport.current_position())
    end
    if ui.Button(StringId.concat(_T("Save Waypoint Location"), "##saved_places_save_wp")) then
        do_save(Teleport.waypoint_position(), "No waypoint set")
    end
end

local function draw_save_group()
    ui.Group(_T("Save Current Location"), save_group_body)
end

local function options_group_body()
    if ui.Button(StringId.concat(_T("Refresh"), "##saved_places_refresh")) then
        SavedPlaces.refresh()
        ui.notify(_T("Places loaded") .. ": " .. tostring(SavedPlaces.count()), "Success")
    end
    if ui.Button(StringId.concat(_T("Clear Saved Positions"), "##saved_places_delete_all")) then
        local count = SavedPlaces.remove_all()
        ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
    end
end

local CONFIG
CONFIG = {
    id = "saved_places",
    list_title = "Saved Places",
    hint_text = "Teleport",
    action_prefix = "teleport.saved_place",
    favorite_kind = "place",
    group = "Teleport",
    feature = "Teleport",
    page = "Saved Places",
    path_prefix = "Teleport / Saved Places",
    empty_text = "No saved places",
    place_text = "Place .txt files in:",
    place_path = "Places\\",
    selectable = true,
    spawn_text = {
        success = "Teleporting to",
        partial = "Teleport failed",
        fail = "Teleport failed",
    },
    snapshot = function() return SavedPlaces.snapshot() end,
    total = function() return SavedPlaces.count() end,
    groups = function() return to_groups(SavedPlaces.folders("Places")) end,
    compute_key = function(path) return SavedPlaces.relative_path(path) end,
    spawn = teleport_to,
    draw_options = function()
        draw_save_group()

        local selected = FileBrowserPage.selected(CONFIG)
        if selected then
            ui.Group(_T("Selected") .. ": " .. selected.name, function()
                if ui.Button(StringId.concat(_T("Teleport"), "##saved_places_tp_selected")) then
                    local ok, err = teleport_to(selected)
                    if ok then
                        ui.notify(_T("Teleporting to") .. " " .. selected.name, "Info")
                    else
                        ui.notify(_T("Teleport failed") .. ": " .. tostring(err or "unknown"), "Error")
                    end
                end
                if ui.Button(StringId.concat(_T("Delete"), "##saved_places_del_selected")) then
                    SavedPlaces.remove(selected.path)
                    FileBrowserPage.clear_selected(CONFIG)
                    ui.notify(_T("Deleted") .. ": " .. selected.name, "Info")
                end
            end)
        end

        ui.Group(_T("Options"), options_group_body)
    end,
}

function SavedPlacesPage.init(ctx)
    ui = assert(ctx.ui, "[Teleport.SavedPlacesPage] ui is required")
    lang = assert(ctx.lang, "[Teleport.SavedPlacesPage] lang is required")
    SavedPlaces.init({ logger = ctx.logger })
    FileBrowserPage.init(ctx)
    FileBrowserPage.register_favorited(CONFIG)
end

function SavedPlacesPage.draw()
    FileBrowserPage.draw(CONFIG)
end

return SavedPlacesPage
