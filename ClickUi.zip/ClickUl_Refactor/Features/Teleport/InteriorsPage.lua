local Teleport = require("ClickUl_Refactor.Core.Teleport")
local Places = require("ClickUl_Refactor.Features.Teleport.TeleportPlaces")

local InteriorsPage = {}

local ui
local lang
local favorites

local function _T(text)
    return lang and lang.get(text) or text
end

local function run_interior(interior)
    Teleport.to_interior({ x = interior.x, y = interior.y, z = interior.z }, { entity_sets = interior.entity_sets })
    ui.notify(_T("Teleporting to") .. " " .. _T(interior.label), "Info")
end

local function interior_action_id(interior)
    return "teleport.interior." .. interior.key
end

local list_cache
local collapsible_title
local cached_lang_index

local function build_cache()
    collapsible_title = _T("Interiors") .. "###teleport_interiors"
    list_cache = {}
    for i = 1, #Places.interiors do
        local interior = Places.interiors[i]
        local id = interior_action_id(interior)
        local text = _T(interior.label)
        list_cache[i] = {
            interior = interior,
            id = id,
            button_label = text .. "##tp_interior_" .. interior.key,
            hint = {
                text = text,
                description = text,
                hotkey = { action_id = id, label = text },
                favorite = { action_id = id, label = text, is_favorite = false },
            },
        }
    end
end

local function ensure_cache()
    local lang_index = lang.get_lang_index()
    if lang_index ~= cached_lang_index then
        build_cache()
        cached_lang_index = lang_index
    end
end

local function register_actions(ctx)
    local action_registry = ctx.action_registry
    if not action_registry then return end
    local hotkeys = ctx.hotkeys

    for _, interior in ipairs(Places.interiors) do
        local it = interior
        local id = interior_action_id(it)
        local run = function() run_interior(it) end
        if hotkeys then
            hotkeys.register_action({
                id = id,
                label = it.label,
                group = "Teleport",
                tab = "Teleport",
                when = "always",
                notify_on_trigger = false,
                callback = run,
            })
        end
        action_registry.register({
            id = id,
            label = it.label,
            group = "Teleport",
            feature = "Teleport",
            page = "Interiors",
            tabs = { "Teleport" },
            section = "Interiors",
            column = 1,
            layout = "ScrollGroup",
            execute = run,
        })
    end
end

local function draw_list()
    for i = 1, #list_cache do
        local entry = list_cache[i]
        entry.hint.favorite.is_favorite = favorites.is_favorite(entry.id)
        if ui.Button(entry.button_label, entry.hint) then
            run_interior(entry.interior)
        end
    end
end

function InteriorsPage.init(ctx)
    ui = assert(ctx.ui, "[Teleport.InteriorsPage] ui is required")
    lang = assert(ctx.lang, "[Teleport.InteriorsPage] lang is required")
    favorites = assert(ctx.favorites, "[Teleport.InteriorsPage] favorites is required")
    register_actions(ctx)
end

function InteriorsPage.draw()
    ensure_cache()
    ui.Collapsible(collapsible_title, draw_list)
end

return InteriorsPage
