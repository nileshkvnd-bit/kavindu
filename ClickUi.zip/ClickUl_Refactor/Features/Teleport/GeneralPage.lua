local Teleport = require("ClickUl_Refactor.Core.Teleport")
local Places = require("ClickUl_Refactor.Features.Teleport.TeleportPlaces")
local InteriorsPage = require("ClickUl_Refactor.Features.Teleport.InteriorsPage")
local StringId = require("ClickUl_Refactor.Core.StringId")

local GeneralPage = {}

local ui
local lang
local favorites

local function _T(text)
    return lang and lang.get(text) or text
end

local function parse_coords(text)
    if type(text) ~= "string" then return nil end
    local nums = {}
    for token in text:gmatch("%-?%d+%.?%d*") do
        nums[#nums + 1] = tonumber(token)
        if #nums == 3 then break end
    end
    if #nums < 3 then return nil end
    return { x = nums[1], y = nums[2], z = nums[3] }
end

local function run_waypoint()
    if Teleport.to_waypoint() then
        ui.notify(_T("Teleporting to Waypoint"), "Info")
    else
        ui.notify(_T("No waypoint set"), "Warning")
    end
end

local function run_objective()
    if Teleport.to_objective() then
        ui.notify(_T("Teleporting to Objective"), "Info")
    else
        ui.notify(_T("No objective found"), "Warning")
    end
end

local function run_high()
    Teleport.to_high()
    ui.notify(_T("Teleporting High"), "Info")
end

local function run_undo()
    if Teleport.undo() then
        ui.notify(_T("Teleport undone"), "Info")
    else
        ui.notify(_T("Nothing to undo"), "Info")
    end
end

local function run_repeat()
    if Teleport.repeat_last() then
        ui.notify(_T("Repeating teleport"), "Info")
    else
        ui.notify(_T("Nothing to repeat"), "Info")
    end
end

local function run_paste()
    local coords = parse_coords(ui.get_clipboard())
    if not coords then
        ui.notify(_T("Invalid clipboard coordinates"), "Warning")
        return
    end
    Teleport.to_coords(coords)
    ui.notify(_T("Teleporting to") .. " " .. string.format("%.0f, %.0f, %.0f", coords.x, coords.y, coords.z), "Info")
end

local function set_auto_waypoint(enabled)
    Teleport.set_auto_waypoint(enabled)
    ui.notify(_T(enabled and "Auto teleport enabled" or "Auto teleport disabled"), "Info")
end

local function run_auto_toggle()
    local enabled = not Teleport.is_auto_waypoint()
    set_auto_waypoint(enabled)
    return enabled
end

local function run_landmark(landmark)
    Teleport.to_coords({ x = landmark.x, y = landmark.y, z = landmark.z }, { redirect = true })
    ui.notify(_T("Teleporting to") .. " " .. _T(landmark.label), "Info")
end

local function run_store(store)
    Teleport.to_nearest(store.points, { guessed = store.guessed })
    ui.notify(_T("Teleporting to") .. " " .. _T(store.label), "Info")
end

local function landmark_id(landmark) return StringId.concat("teleport.landmark.", landmark.key) end
local function store_id(store) return StringId.concat("teleport.store.", store.key) end

local hint_cache = {}
local hint_cache_lang = nil

local function action_hint(id, label)
    local current_lang = lang.get_language()
    if current_lang ~= hint_cache_lang then
        hint_cache_lang = current_lang
        hint_cache = {}
    end

    local hint = hint_cache[id]
    if not hint then
        local text = _T(label)
        hint = {
            text = text,
            description = text,
            hotkey = { action_id = id, label = text },
            favorite = { action_id = id, label = text, is_favorite = false },
        }
        hint_cache[id] = hint
    end

    hint.favorite.is_favorite = favorites.is_favorite(id)
    return hint
end

local function register_actions(ctx)
    local action_registry = ctx.action_registry
    if not action_registry then return end
    local hotkeys = ctx.hotkeys

    local function register(id, label, run)
        if hotkeys then
            hotkeys.register_action({
                id = id,
                label = label,
                group = "Teleport",
                tab = "Teleport",
                when = "always",
                notify_on_trigger = false,
                callback = function() return run() end,
            })
        end
        action_registry.register({
            id = id,
            label = label,
            group = "Teleport",
            feature = "Teleport",
            page = "Teleport",
            tabs = { "Teleport" },
            section = "Teleport",
            column = 1,
            layout = "DualColumn",
            execute = function() return run() end,
        })
    end

    register("teleport.waypoint", "Teleport to Waypoint", run_waypoint)
    register("teleport.objective", "Teleport to Objective", run_objective)
    register("teleport.high", "Teleport High", run_high)
    register("teleport.undo", "Undo Teleport", run_undo)
    register("teleport.repeat", "Repeat Teleport", run_repeat)
    register("teleport.auto_waypoint", "Auto Teleport to Waypoint", run_auto_toggle)

    for _, landmark in ipairs(Places.landmarks) do
        local l = landmark
        register(landmark_id(l), l.label, function() run_landmark(l) end)
    end
    for _, store in ipairs(Places.stores) do
        local s = store
        register(store_id(s), s.label, function() run_store(s) end)
    end
end

local function draw_quick_group()
    if ui.Button(StringId.concat(_T("Teleport to Waypoint"), "##tp_waypoint"), action_hint("teleport.waypoint", "Teleport to Waypoint")) then
        run_waypoint()
    end
    if ui.Button(StringId.concat(_T("Teleport to Objective"), "##tp_objective"), action_hint("teleport.objective", "Teleport to Objective")) then
        run_objective()
    end
    if ui.Button(StringId.concat(_T("Teleport High"), "##tp_high"), action_hint("teleport.high", "Teleport High")) then
        run_high()
    end
    if ui.Button(StringId.concat(_T("Paste Coordinates"), "##tp_paste")) then
        run_paste()
    end
    if ui.Button(StringId.concat(_T("Undo Teleport"), "##tp_undo"), action_hint("teleport.undo", "Undo Teleport")) then
        run_undo()
    end
    if ui.Button(StringId.concat(_T("Repeat Teleport"), "##tp_repeat"), action_hint("teleport.repeat", "Repeat Teleport")) then
        run_repeat()
    end
end

local function draw_landmarks_group()
    for _, landmark in ipairs(Places.landmarks) do
        if ui.Button(StringId.concat(_T(landmark.label), StringId.concat("##tp_landmark_", landmark.key)), action_hint(landmark_id(landmark), landmark.label)) then
            run_landmark(landmark)
        end
    end
end

local function draw_quick()
    ui.Group(_T("Quick Teleport"), draw_quick_group)
    ui.Group(_T("Landmarks"), draw_landmarks_group)
end

local function draw_stores_group()
    for _, store in ipairs(Places.stores) do
        if ui.Button(StringId.concat(_T(store.label), StringId.concat("##tp_store_", store.key)), action_hint(store_id(store), store.label)) then
            run_store(store)
        end
    end
end

local function draw_auto_group()
    local enabled = Teleport.is_auto_waypoint()
    local new_enabled = ui.Checkbox(_T("Auto Teleport to Waypoint"), enabled, action_hint("teleport.auto_waypoint", "Auto Teleport to Waypoint"))
    if new_enabled ~= enabled then set_auto_waypoint(new_enabled) end
end

local function draw_places()
    ui.Group(_T("Stores"), draw_stores_group)
    ui.Group(_T("Auto"), draw_auto_group)

    InteriorsPage.draw()
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[Teleport.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[Teleport.GeneralPage] lang is required")
    favorites = assert(ctx.favorites, "[Teleport.GeneralPage] favorites is required")
    register_actions(ctx)
end

function GeneralPage.draw()
    ui.DualColumn(draw_quick, draw_places)
end

return GeneralPage
