local TeleportPlaces = {}

TeleportPlaces.landmarks = {
    { key = "lsia", label = "Los Santos Intl. Airport", x = -1087.7434, y = -3015.614, z = 13.825307 },
    { key = "maze_helipad", label = "Maze Bank Helipad", x = -75.2188, y = -818.582, z = 326.175 },
    { key = "fort_zancudo", label = "Fort Zancudo", x = -2285.9294, y = 3124.115, z = 32.81487 },
    { key = "mount_chiliad", label = "Mount Chiliad", x = 501.77032, y = 5595.622, z = 795.77277 },
    { key = "cayo_perico", label = "Cayo Perico", x = 4906.2554, y = -4912.7646, z = 3.3630776 },
    { key = "diamond_casino", label = "Diamond Casino", x = 922.816223, y = 47.206078, z = 81.106331 },
}

TeleportPlaces.stores = {
    {
        key = "ammunation", label = "Ammu-Nation", guessed = true, points = {
            { x = 1697.979126, y = 3753.200439 }, { x = 245.271103, y = -45.812595 },
            { x = 844.124817, y = -1025.570679 }, { x = -325.886658, y = 6077.020020 },
            { x = -664.217773, y = -943.364624 }, { x = -1313.927856, y = -390.968933 },
            { x = -3165.230713, y = 1082.855103 }, { x = 2569.611572, y = 302.575989 },
            { x = -1111.251831, y = 2688.476318 }, { x = 811.869873, y = -2149.101563 },
            { x = 17.680408, y = -1114.287964 },
        },
    },
    {
        key = "shooting_range", label = "Shooting Range", guessed = true, points = {
            { x = 811.869873, y = -2149.101563 }, { x = 17.680408, y = -1114.287964 },
        },
    },
    {
        key = "barber", label = "Barber Shop", guessed = true, points = {
            { x = -821.9946, y = -187.1776 }, { x = 133.5702, y = -1710.918 },
            { x = -1287.0822, y = -1116.5576 }, { x = 1933.1191, y = 3726.079 },
            { x = 1208.3335, y = -470.917 }, { x = -30.7448, y = -148.4921 },
            { x = -280.8165, y = 6231.7705 },
        },
    },
    {
        key = "clothes", label = "Clothes Store", guessed = true, points = {
            { x = 419.531, y = -807.5787 }, { x = -818.6218, y = -1077.533 },
            { x = 80.665, y = -1391.6694 }, { x = 1687.8812, y = 4820.55 },
            { x = -1094.0487, y = 2704.1707 }, { x = 1197.9722, y = 2704.2205 },
            { x = -0.2361, y = 6516.0454 }, { x = -715.3598, y = -155.7742 },
            { x = -158.2199, y = -304.9663 }, { x = -1455.0045, y = -233.1862 },
            { x = -1199.8092, y = -776.6886 }, { x = 618.1857, y = 2752.5667 },
            { x = 126.6853, y = -212.5027 }, { x = -3168.9663, y = 1055.2869 },
        },
    },
    {
        key = "lsc", label = "Los Santos Customs", guessed = false, points = {
            { x = -1147.202759, y = -1992.451782, z = 12.653099 },
            { x = 724.479248, y = -1089.010254, z = 21.648642 },
            { x = -354.587860, y = -135.499176, z = 38.479984 },
            { x = 1174.730347, y = 2644.499023, z = 37.240135 },
        },
    },
    {
        key = "tattoo", label = "Tattoo Parlor", guessed = true, points = {
            { x = 321.6098, y = 179.4165 }, { x = 1861.6853, y = 3750.0798 },
            { x = -290.1603, y = 6199.0947 }, { x = -1153.9481, y = -1425.0186 },
            { x = 1322.4547, y = -1651.1252 }, { x = -3169.4204, y = 1074.7272 },
        },
    },
}

TeleportPlaces.interiors = {
    { key = "bunker", label = "Bunker", x = 900.686, y = -3224.6824, z = -98.27065, needs_mp = true, entity_sets = {
        { name = "bunker_style_a", on = false }, { name = "bunker_style_b", on = true }, { name = "bunker_style_c", on = false },
        { name = "standard_security_set", on = false }, { name = "security_upgrade", on = true },
        { name = "standard_bunker_set", on = false }, { name = "upgrade_bunker_set", on = true },
        { name = "gun_locker_upgrade", on = true },
        { name = "Office_blocker_set", on = false }, { name = "Office_Upgrade_set", on = true },
        { name = "gun_range_blocker_set", on = false }, { name = "gun_wall_blocker", on = false }, { name = "gun_range_lights", on = true },
    } },
    { key = "vehware", label = "Vehicle Warehouse", x = 975.0267, y = -3000.2334, z = -39.648537, needs_mp = true, entity_sets = {
        { name = "Basic_style_set", on = false }, { name = "Urban_style_set", on = true }, { name = "Branded_style_set", on = false },
    } },
    { key = "lscm", label = "LS Car Meet", x = -2000.0, y = 1113.4, z = 25.7, needs_mp = true },
    { key = "facility", label = "IAA Facility", x = 2047.0, y = 2942.0, z = -61.9, needs_mp = true },
    { key = "server_room", label = "Server Room", x = 2168.0, y = 2920.0, z = -84.0, needs_mp = true },
    { key = "submarine", label = "Bogdan's Submarine", x = 514.19403, y = 4838.989, z = -62.587917, needs_mp = true },
    { key = "humane_labs", label = "Humane Labs", x = 3616.85, y = 3738.5544, z = 28.69009 },
    { key = "burnt_fib", label = "FIB (Bureau Raid)", x = 115.09295, y = -747.57446, z = 234.15239 },
    { key = "fib", label = "FIB", x = 129.75044, y = -763.3821, z = 242.1519 },
    { key = "iaa", label = "IAA", x = 114.059616, y = -619.2508, z = 206.04666 },
    { key = "la_fuente_blanca", label = "La Fuente Blanca", x = 1399.973, y = 1148.756, z = 113.3336 },
    { key = "comedy_club", label = "Split Sides West Comedy Club", x = 377.253662, y = -998.272339, z = -98.999947 },
    { key = "bahama_mamas", label = "Bahama Mamas", x = -1388.0013, y = -618.41967, z = 30.819599 },
    { key = "torture_room", label = "Torture Room", x = 144.77847, y = -2201.925, z = 4.68802 },
    { key = "motel_room", label = "Motel Room", x = 152.2604, y = -1004.47107, z = -99.00476 },
    { key = "cinema", label = "Cinema", x = -1425.5645, y = -244.3, z = 16.8053 },
    { key = "recycling", label = "Recycling Plant", x = -598.6379, y = -1608.399, z = 26.0108 },
    { key = "omega_garage", label = "Omega's Garage", x = 2330.9282, y = 2574.3071, z = 46.680347 },
    { key = "lester_house", label = "Lester's House", x = 1273.9, y = -1719.305, z = 54.77141 },
    { key = "friedlander", label = "Friedlander's Office", x = -1908.024, y = -573.4244, z = 19.09722 },
    { key = "solomon", label = "Solomon's Office", x = -1005.663, y = -478.3461, z = 49.0265 },
    { key = "floyd_house", label = "Floyd's House", x = -1152.3326, y = -1518.9675, z = 10.632729 },
    { key = "janitor_house", label = "Janitor's House", x = -111.7116, y = -11.912, z = 69.5196 },
    { key = "benny", label = "Benny's Original Motor Works", x = -210.29391, y = -1324.2723, z = 30.890385, needs_mp = true },
    { key = "hayes", label = "Hayes Autos", x = 479.0568, y = -1316.825, z = 28.2038 },
    { key = "tequilala", label = "Tequi-La-La", x = -556.5089, y = 286.3181, z = 81.1763 },
    { key = "foundry", label = "Foundry", x = 1100.1342, y = -2002.1356, z = 30.063913 },
    { key = "udg", label = "Union Depository Garage", x = -16.29585, y = -684.0385, z = 33.50832 },
    { key = "epsilon_storage", label = "Epsilon Storage Room", x = 245.1564, y = 370.211, z = 104.7382 },
    { key = "character_creation", label = "Character Creation Room", x = 402.5164, y = -1002.847, z = -99.2587 },
    { key = "mission_end_carpark", label = "Mission End Carpark", x = 405.9228, y = -954.1149, z = -99.6627 },
    { key = "nightclub_garage", label = "Nightclub Garage", x = -1505.783, y = -3012.587, z = -79.9999, needs_mp = true },
    { key = "weed_farm", label = "Weed Farm", x = 1042.3301, y = -3199.142, z = -38.161537, needs_mp = true },
    { key = "stilt_house", label = "Stilt House", x = 372.6707, y = 405.5235, z = 144.5326, needs_mp = true },
    { key = "apartment_high", label = "High-End Apartment", x = -282.0588, y = -955.17, z = 85.3036 },
    { key = "apartment_mid", label = "Mid-End Apartment", x = 342.7946, y = -997.4225, z = -99.7444 },
    { key = "apartment_low", label = "Low-End Apartment", x = 260.3268, y = -997.4298, z = -100.0086 },
    { key = "garage_high", label = "High-End Garage", x = 228.6161, y = -992.053, z = -99.9999 },
    { key = "garage_mid", label = "Mid-End Garage", x = 199.9716, y = -999.6678, z = -100.0 },
    { key = "garage_low", label = "Low-End Garage", x = 173.1165, y = -1003.28, z = -99.9999 },
    { key = "warehouse_large", label = "Large Warehouse", x = 1010.008, y = -3100.0, z = -39.9999, needs_mp = true },
    { key = "warehouse_medium", label = "Medium Warehouse", x = 1059.995, y = -3100.0, z = -39.9999, needs_mp = true },
    { key = "warehouse_small", label = "Small Warehouse", x = 1094.997, y = -3100.012, z = -39.9999, needs_mp = true },
}

return TeleportPlaces
