local FileBrowserPage = require("ClickUl_Refactor.Features.Common.FileBrowserPage")
local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")
local MapOptions = require("ClickUl_Refactor.Features.World.MapOptions")
local StringId = require("ClickUl_Refactor.Core.StringId")

local MapPage = {}

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

local function map_spawn_detail(spawned, failed, coords)
    local lines = {
        _T("Created") .. ": " .. tostring(spawned or 0) .. _T("entities"),
    }
    if (failed or 0) > 0 then
        lines[#lines + 1] = _T("Failed") .. ": " .. tostring(failed) .. _T("entities")
    end
    if type(coords) == "table" and coords.x then
        lines[#lines + 1] = _T("Location") .. ": " .. string.format("%.0f,%.0f,%.0f", coords.x, coords.y, coords.z)
    end
    return table.concat(lines, "\n")
end

local groups_cache = setmetatable({}, { __mode = "k" })

local function to_groups(folders)
    local cached = groups_cache[folders]
    if cached then return cached end
    local groups = {}
    local names = folders.folder_names or {}
    local by = folders.by_folder or {}
    for i = 1, #names do
        local name = names[i]
        groups[#groups + 1] = { title = name, items = by[name] or {} }
    end
    groups_cache[folders] = groups
    return groups
end

local function map_name(record, ext)
    local path = record.file_path
    if path then
        return path:match("([^/\\]+)%." .. ext .. "$") or path:match("([^/\\]+)$") or "Map"
    end
    return "Map"
end

local function draw_spawned(scfg)
    local maps = scfg.get_spawned() or {}
    if #maps == 0 then return end
    ui.Group(_T("Spawned Maps") .. ": " .. tostring(#maps), function()
        for index, record in ipairs(maps) do
            local name = map_name(record, scfg.ext)
            local count = (record.entities and #record.entities) or 0
            local label = name .. " (" .. tostring(count) .. " " .. _T("entities") .. ")"
            if ui.Button(label .. "##" .. scfg.id .. "_spawned_" .. tostring(index)) then
                scfg.delete(index)
                ui.notify(_T("Map deleted") .. ": " .. name, "Info")
            end
        end
        if ui.Button(StringId.concat(_T("Delete All Maps"), scfg.delete_all_id)) then
            local count = scfg.delete_all()
            ui.notify(_T("Deleted") .. ": " .. tostring(count), "Info")
        end
    end)
end

local JSON_SPAWNED_CFG <const> = {
    id = "json_maps",
    ext = "json",
    delete_all_id = "##json_maps_delete_all",
    get_spawned = function() return Spawner.Json.Map.get_spawned() end,
    delete = function(index) return Spawner.Json.Map.delete(index) end,
    delete_all = function() return Spawner.Json.Map.delete_all() end,
}

local MENYOO_SPAWNED_CFG <const> = {
    id = "menyoo_maps",
    ext = "xml",
    delete_all_id = "##menyoo_maps_delete_all",
    get_spawned = function() return Spawner.Menyoo.Map.get_spawned() end,
    delete = function(index) return Spawner.Menyoo.Map.delete(index) end,
    delete_all = function() return Spawner.Menyoo.Map.delete_all() end,
}

local SPAWN_TEXT <const> = {
    success = "Spawned",
    partial = "Map spawned with errors",
    fail = "Map spawn failed",
}

local CONFIGS <const> = {
    json = {
        id = "json_maps",
        list_title = "JSON Maps",
        hint_text = "Spawn Map",
        action_prefix = "world.json_map",
        favorite_kind = "map",
        group = "World",
        feature = "World",
        page = "JSON Map",
        path_prefix = "World / JSON Maps",
        empty_text = "No map files found",
        place_text = "Place .json files in:",
        place_path = "Maps/Json/",
        spawn_text = SPAWN_TEXT,
        snapshot = function() return Spawner.MapFiles.snapshot() end,
        total = function() return #Spawner.MapFiles.list("json") end,
        groups = function() return to_groups(Spawner.MapFiles.folders("json")) end,
        compute_key = function(path) return Spawner.MapFiles.relative_path(path) end,
        detail_is_message = true,
        spawn = function(item)
            local map_data, count, err = Spawner.Json.Map.spawn_file(item.path)
            if map_data == nil then return false, err end
            local failed = map_data.failed or math.max(0, (map_data.attempted or count) - count)
            return true, err, map_spawn_detail(count, failed, map_data.refCoords)
        end,
        draw_options = function()
            MapOptions.draw("json_map", "Map Options")
            draw_spawned(JSON_SPAWNED_CFG)
        end,
    },
    menyoo = {
        id = "menyoo_maps",
        list_title = "Menyoo Maps",
        hint_text = "Spawn Map",
        action_prefix = "world.menyoo_map",
        favorite_kind = "map",
        group = "World",
        feature = "World",
        page = "Menyoo Map",
        path_prefix = "World / Menyoo Maps",
        empty_text = "No map files found",
        place_text = "Place .xml files in:",
        place_path = "Maps/Menyoo/",
        spawn_text = SPAWN_TEXT,
        snapshot = function() return Spawner.MapFiles.snapshot() end,
        total = function() return #Spawner.MapFiles.list("menyoo") end,
        groups = function() return to_groups(Spawner.MapFiles.folders("menyoo")) end,
        compute_key = function(path) return Spawner.MapFiles.relative_path(path) end,
        detail_is_message = true,
        spawn = function(item)
            local map_data, count, err = Spawner.Menyoo.Map.spawn_file(item.path)
            if map_data == nil then return false, err end
            local failed = map_data.failed or math.max(0, (map_data.attempted or count) - count)
            return true, err, map_spawn_detail(count, failed, map_data.refCoords)
        end,
        draw_options = function()
            MapOptions.draw("menyoo_map", "Map Options")
            draw_spawned(MENYOO_SPAWNED_CFG)
        end,
    },
}

function MapPage.init(ctx)
    ui = assert(ctx.ui, "[World.MapPage] ui is required")
    lang = assert(ctx.lang, "[World.MapPage] lang is required")
    FileBrowserPage.init(ctx)
    MapOptions.init(ctx)
    for _, config in pairs(CONFIGS) do
        FileBrowserPage.register_favorited(config)
    end
end

function MapPage.draw(format_key)
    FileBrowserPage.draw(CONFIGS[format_key])
end

return MapPage
