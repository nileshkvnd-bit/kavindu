local map_page = require("ClickUl_Refactor.Features.World.MapPage")
local esp = require("ClickUl_Refactor.Features.Esp.Init")

local World = {}

local ui
local lang
local logger
local settings

local function _T(text)
    return lang and lang.get(text) or text
end

local MAIN_TABS <const> = { "ESP", "JSON Map", "Menyoo Map" }

local state = {
    main_tab = 1,
}

function World.init(ctx)
    ui = assert(ctx.ui, "[World] ui is required")
    lang = assert(ctx.lang, "[World] lang is required")
    logger = assert(ctx.logger, "[World] logger is required")
    settings = assert(ctx.settings, "[World] settings is required")
    local action_registry = assert(ctx.action_registry, "[World] action_registry is required")
    local favorites = assert(ctx.favorites, "[World] favorites is required")

    map_page.init({ ui = ui, lang = lang, action_registry = action_registry, favorites = favorites })
    esp.init({ ui = ui, lang = lang, logger = logger, settings = settings })

    logger.info("Features.World", "World module initialized")
    return true
end

function World.draw()
    local ui_lib = assert(ui, "[World] UI library is required")
    local tabs = {}
    for i = 1, #MAIN_TABS do tabs[i] = _T(MAIN_TABS[i]) end
    state.main_tab = ui_lib.SubTabBar(tabs, state.main_tab)

    if state.main_tab == 1 then
        esp.draw()
    elseif state.main_tab == 2 then
        map_page.draw("json")
    elseif state.main_tab == 3 then
        map_page.draw("menyoo")
    end
end

function World.on_shutdown()
    esp.on_shutdown()
end

return World
