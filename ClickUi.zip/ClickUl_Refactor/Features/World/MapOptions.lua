local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")

local MapOptions = {}

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

local hint_cache = {}

local function make_hint(text, description)
    local key = text .. "\0" .. (description or "")
    local active_lang = lang.get_language()
    local entry = hint_cache[key]
    if entry and entry.language == active_lang then
        return entry.hint
    end
    if not entry then
        entry = { hint = {} }
        hint_cache[key] = entry
    end
    local hint = entry.hint
    local hint_text = _T(text)
    hint.text = hint_text
    hint.description = description and _T(description) or hint_text
    entry.language = active_lang
    return hint
end

local function checkbox(section, settings, label, key, hint)
    local value = ui.Checkbox(_T(label), settings[key], make_hint(label, hint))
    if settings[key] == value then return settings end
    return Spawner.Settings.update(section, { [key] = value })
end

function MapOptions.init(ctx)
    ui = assert(ctx.ui, "[World.MapOptions] ui is required")
    lang = assert(ctx.lang, "[World.MapOptions] lang is required")
end

function MapOptions.draw(section, title)
    ui.Group(_T(title or "Map Options"), function()
        local settings = Spawner.Settings.get(section)
        settings = checkbox(section, settings, "Teleport to Map", "teleport_to_map", "Warp to map center after spawn")
        settings = checkbox(section, settings, "Delete Old Map", "delete_old_map", "Remove previous map when loading new one")
        settings = checkbox(section, settings, "Entity God Mode", "entity_god_mode", "Make spawned entities invincible")
        settings = checkbox(section, settings, "Spawn Frozen", "spawn_frozen", "Entities stay in place, no physics")
        settings = checkbox(section, settings, "Apply Proofs", "apply_proofs", "Apply damage resistance settings")
    end)
end

return MapOptions
