local StringId = require("ClickUl_Refactor.Core.StringId")

local FavoritesPage = {}

local ui = nil
local lang = nil
local favorites = nil
local action_registry = nil

local state = {
    category_idx = 1,
}

local CATEGORY_FUNCTIONS <const> = "functions"
local CATEGORY_VEHICLES <const> = "vehicles"
local CATEGORY_ASSETS <const> = "assets"
local CATEGORY_LABELS <const> = {
    [CATEGORY_FUNCTIONS] = "Function Favorites",
    [CATEGORY_VEHICLES] = "Vehicle List",
    [CATEGORY_ASSETS] = "Outfit / Map List",
}
local CATEGORY_ORDER <const> = { CATEGORY_FUNCTIONS, CATEGORY_VEHICLES, CATEGORY_ASSETS }

local CATEGORY_LABEL_KEYS = {}
for i = 1, #CATEGORY_ORDER do
    CATEGORY_LABEL_KEYS[i] = CATEGORY_LABELS[CATEGORY_ORDER[i]]
end

local function _T(text)
    return lang.get(text)
end

local hint_cache = {}

local function action_hint(entry)
    local id = entry.id
    local active_lang = lang.get_language()
    local record = hint_cache[id]
    if not record then
        record = { hint = { favorite = {} } }
        hint_cache[id] = record
    end

    local hint = record.hint
    if record.language ~= active_lang then
        local label = _T(entry.label)
        hint.text = label
        hint.description = entry.description and _T(entry.description) or entry.path or entry.id
        local favorite = hint.favorite
        favorite.action_id = id
        favorite.label = label
        favorite.path = entry.path
        record.language = active_lang
    end

    hint.favorite.is_favorite = favorites.is_favorite(id)
    return hint
end

local function ensure_section(bucket, section_name)
    local section = bucket.sections[section_name]
    if section then return section end

    section = {
        name = section_name,
        column = 1,
        items = {},
    }
    bucket.sections[section_name] = section
    bucket.section_order[#bucket.section_order + 1] = section
    return section
end

local function create_catalog()
    return {
        [CATEGORY_FUNCTIONS] = {
            sections = {},
            section_order = {},
        },
        [CATEGORY_VEHICLES] = {
            types = {},
            type_order = {},
        },
        [CATEGORY_ASSETS] = {
            types = {},
            type_order = {},
        },
    }
end

local function ensure_type(bucket, type_name)
    local type_bucket = bucket.types[type_name]
    if type_bucket then return type_bucket end

    type_bucket = {
        name = type_name,
        column = 1,
        sections = {},
        section_order = {},
    }
    bucket.types[type_name] = type_bucket
    bucket.type_order[#bucket.type_order + 1] = type_bucket
    return type_bucket
end

local function add_type_favorite(bucket, entry, default_name)
    local type_name = entry.page or entry.group or default_name
    local type_bucket = ensure_type(bucket, type_name)
    local section_name = entry.section or default_name
    local section = ensure_section(type_bucket, section_name)
    section.items[#section.items + 1] = entry
end

local function assign_section_columns(bucket)
    local load = { 0, 0 }
    for i = 1, #bucket.section_order do
        local section = bucket.section_order[i]
        local column = load[1] <= load[2] and 1 or 2
        section.column = column
        load[column] = load[column] + #section.items
    end
end

local function type_weight(type_bucket)
    local weight = 1
    for i = 1, #type_bucket.section_order do
        weight = weight + 1 + #type_bucket.section_order[i].items
    end
    return weight
end

local function assign_type_columns(bucket)
    local load = { 0, 0 }
    for i = 1, #bucket.type_order do
        local type_bucket = bucket.type_order[i]
        local column = load[1] <= load[2] and 1 or 2
        type_bucket.column = column
        load[column] = load[column] + type_weight(type_bucket)
    end
end

function FavoritesPage.build_catalog(entries)
    local catalog = create_catalog()
    entries = entries or {}

    for i = 1, #entries do
        local entry = entries[i]
        local kind = entry.favorite_kind
        if kind == "vehicle" then
            add_type_favorite(catalog[CATEGORY_VEHICLES], entry, "Vehicles")
        elseif kind == "outfit" or kind == "map" then
            add_type_favorite(catalog[CATEGORY_ASSETS], entry, "Favorites")
        else
            local section_name = entry.section or entry.page or entry.group or "Favorites"
            local section = ensure_section(catalog[CATEGORY_FUNCTIONS], section_name)
            section.items[#section.items + 1] = entry
        end
    end

    assign_section_columns(catalog[CATEGORY_FUNCTIONS])
    assign_type_columns(catalog[CATEGORY_VEHICLES])
    assign_type_columns(catalog[CATEGORY_ASSETS])
    return catalog
end

local catalog_cache = { version = nil, catalog = nil }

local function build_catalog()
    local v = favorites.version()
    if catalog_cache.version ~= v then
        catalog_cache.catalog = FavoritesPage.build_catalog(favorites.list())
        catalog_cache.version = v
    end
    return catalog_cache.catalog
end

local function clamp_index(index, count)
    if count <= 0 then return 1 end
    if index < 1 then return 1 end
    if index > count then return count end
    return index
end

local function render_entry(entry)
    local action = action_registry.get(entry.id)
    local available = action ~= nil and action_registry.is_available(entry.id)
    if available and type(action.render) == "function" then
        action.render(action)
        return
    end

    local label = StringId.concat(_T(entry.label), StringId.concat("##favorite_", entry.id))
    if not ui.Button(label, action_hint(entry)) then return end

    if not available then
        ui.notify(_T("Favorite unavailable"), "Warning")
        return
    end

    local _, reason = action_registry.execute(entry.id)
    if reason == "unavailable" or reason == "missing_action" then
        ui.notify(_T("Favorite unavailable"), "Warning")
    end
end

local current_section = nil

local function draw_section_items()
    for i = 1, #current_section.items do
        render_entry(current_section.items[i])
    end
end

local function render_function_section(section)
    current_section = section
    ui.Group(_T(section.name), draw_section_items)
end

local function render_function_column(bucket, column)
    for i = 1, #bucket.section_order do
        local section = bucket.section_order[i]
        if section.column == column then render_function_section(section) end
    end
end

local function render_type_section(ns, type_name, section)
    local ns_id = StringId.concat(StringId.concat(ns, "_"), StringId.concat(type_name, StringId.concat("::", section.name)))
    local label = StringId.concat(_T(section.name), StringId.concat("###", ns_id))
    current_section = section
    ui.Collapsible(label, draw_section_items)
end

local current_type_ns = nil
local current_type_bucket = nil

local function draw_type_group_body()
    local type_bucket = current_type_bucket
    for i = 1, #type_bucket.section_order do
        render_type_section(current_type_ns, type_bucket.name, type_bucket.section_order[i])
    end
end

local function render_type_group(ns, type_bucket)
    current_type_ns = ns
    current_type_bucket = type_bucket
    ui.Group(_T(type_bucket.name), draw_type_group_body)
end

local function render_type_column(ns, bucket, column)
    for i = 1, #bucket.type_order do
        local type_bucket = bucket.type_order[i]
        if type_bucket.column == column then render_type_group(ns, type_bucket) end
    end
end

local current_bucket = nil
local current_ns = nil

local function function_col_1() render_function_column(current_bucket, 1) end
local function function_col_2() render_function_column(current_bucket, 2) end

local function render_function_favorites(bucket)
    if #bucket.section_order == 0 then
        ui.Text(_T("No favorites yet"))
        return
    end

    current_bucket = bucket
    ui.DualColumn(function_col_1, function_col_2)
end

local function type_col_1() render_type_column(current_ns, current_bucket, 1) end
local function type_col_2() render_type_column(current_ns, current_bucket, 2) end

local function render_type_favorites(ns, bucket)
    if #bucket.type_order == 0 then
        ui.Text(_T("No favorites yet"))
        return
    end

    current_ns = ns
    current_bucket = bucket
    ui.DualColumn(type_col_1, type_col_2)
end

function FavoritesPage.init(ctx)
    ui = assert(ctx.ui, "[Favorites] ui is required")
    lang = assert(ctx.lang, "[Favorites] lang is required")
    favorites = assert(ctx.favorites, "[Favorites] favorites is required")
    action_registry = assert(ctx.action_registry, "[Favorites] action_registry is required")
    return true
end

function FavoritesPage.draw()
    local catalog = build_catalog()
    if #catalog[CATEGORY_FUNCTIONS].section_order == 0
        and #catalog[CATEGORY_VEHICLES].type_order == 0
        and #catalog[CATEGORY_ASSETS].type_order == 0 then
        ui.Text(_T("No favorites yet"))
        return
    end

    state.category_idx = clamp_index(state.category_idx, #CATEGORY_ORDER)
    state.category_idx = ui.SubTabBar(lang.translate_list(CATEGORY_LABEL_KEYS), state.category_idx)

    local category = CATEGORY_ORDER[state.category_idx]
    if category == CATEGORY_VEHICLES then
        render_type_favorites("fav_veh", catalog[CATEGORY_VEHICLES])
        return
    end
    if category == CATEGORY_ASSETS then
        render_type_favorites("fav_asset", catalog[CATEGORY_ASSETS])
        return
    end

    render_function_favorites(catalog[CATEGORY_FUNCTIONS])
end

return FavoritesPage
