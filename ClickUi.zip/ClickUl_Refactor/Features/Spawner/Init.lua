local Spawner = {}

local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local TaskSequence = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Runner")
local JsonVehicle = require("ClickUl_Refactor.Features.Spawner.Json.VehicleSpawner")
local JsonMap = require("ClickUl_Refactor.Features.Spawner.Json.MapSpawner")
local JsonOutfit = require("ClickUl_Refactor.Features.Spawner.Json.OutfitSpawner")
local IniVehicle = require("ClickUl_Refactor.Features.Spawner.Ini.VehicleSpawner")
local MenyooVehicle = require("ClickUl_Refactor.Features.Spawner.Menyoo.VehicleSpawner")
local MenyooMap = require("ClickUl_Refactor.Features.Spawner.Menyoo.MapSpawner")
local MenyooOutfit = require("ClickUl_Refactor.Features.Spawner.Menyoo.OutfitSpawner")
local MenyooParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.Parser")
local MenyooXml = require("ClickUl_Refactor.Features.Spawner.Menyoo.Xml")
local JsonNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.Normalizer")
local VehiclePreset = require("ClickUl_Refactor.Features.Spawner.Core.VehiclePreset")
local MapFiles = require("ClickUl_Refactor.Features.Spawner.Core.MapFiles")
local OutfitFiles = require("ClickUl_Refactor.Features.Spawner.Core.OutfitFiles")
local ModelVehicleSpawner = require("ClickUl_Refactor.Features.Spawner.Core.ModelVehicleSpawner")
local VehicleFiles = require("ClickUl_Refactor.Features.Spawner.Core.VehicleFiles")
local VehicleModEditor = require("ClickUl_Refactor.Features.Spawner.Core.VehicleModEditor")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local SavedVehicle = require("ClickUl_Refactor.Features.Spawner.Json.SavedVehicle")

Spawner.OUTFIT_SPAWN_MODE = Settings.OUTFIT_SPAWN_MODE

Spawner.Settings = {
    bind_storage = function(settings_module)
        return Settings.bind_storage(settings_module)
    end,
    get = function(section)
        return Settings.get(section)
    end,
    defaults = function()
        return Settings.get_defaults()
    end,
    update = function(section, values)
        return Settings.update(section, values)
    end,
    reset = function(section)
        return Settings.reset(section)
    end,
}

Spawner.Runtime = {
    snapshot = function()
        return SpawnRegistry.snapshot()
    end,
    list = function(name)
        return SpawnRegistry.list(name)
    end,
    stop_all_ptfx_loops = function()
        return Ptfx.stop_all()
    end,
    task_sequences = function()
        return TaskSequence.registered()
    end,
    start_task_sequence = function(index)
        return TaskSequence.start_registered(index)
    end,
    start_all_task_sequences = function()
        return TaskSequence.start_all_registered()
    end,
    stop_task_sequence = function(index)
        return TaskSequence.stop_registered(index)
    end,
    stop_all_task_sequences = function()
        return TaskSequence.stop_all_registered()
    end,
}

Spawner.VehicleFiles = {
    refresh = function(...) return VehicleFiles.refresh(...) end,
    snapshot = function(...) return VehicleFiles.ensure_loaded(...) end,
    list = function(...) return VehicleFiles.list(...) end,
    folders = function(...) return VehicleFiles.folders(...) end,
    relative_path = function(...) return VehicleFiles.relative_path(...) end,
}

Spawner.MapFiles = {
    refresh = function(...) return MapFiles.refresh(...) end,
    snapshot = function(...) return MapFiles.ensure_loaded(...) end,
    list = function(...) return MapFiles.list(...) end,
    folders = function(...) return MapFiles.folders(...) end,
    relative_path = function(...) return MapFiles.relative_path(...) end,
}

Spawner.OutfitFiles = {
    refresh = function(...) return OutfitFiles.refresh(...) end,
    snapshot = function(...) return OutfitFiles.ensure_loaded(...) end,
    list = function(...) return OutfitFiles.list(...) end,
    folders = function(...) return OutfitFiles.folders(...) end,
    tree = function(...) return OutfitFiles.tree(...) end,
    relative_path = function(...) return OutfitFiles.relative_path(...) end,
}

Spawner.Vehicle = {
    spawn_model = function(...) return ModelVehicleSpawner.spawn_model(...) end,
    delete_all = function() return ModelVehicleSpawner.delete_all() end,
    delete_current = function() return ModelVehicleSpawner.delete_current() end,
    get_spawned = function() return ModelVehicleSpawner.get_spawned() end,
}

Spawner.VehicleEditor = {
    current_vehicle = function(...) return VehicleModEditor.current_vehicle(...) end,
    prepare = function(...) return VehicleModEditor.prepare(...) end,
    indexed_slots = function(...) return VehicleModEditor.indexed_slots(...) end,
    slot_state = function(...) return VehicleModEditor.slot_state(...) end,
    mod_name = function(...) return VehicleModEditor.mod_name(...) end,
    slot_category_name = function(...) return VehicleModEditor.slot_category_name(...) end,
    slot_name_dynamic = function(...) return VehicleModEditor.slot_name_dynamic(...) end,
    gxt_text = function(...) return VehicleModEditor.gxt_text(...) end,
    color_finishes = function(...) return VehicleModEditor.color_finishes(...) end,
    finish_name = function(...) return VehicleModEditor.finish_name(...) end,
    get_mod_color = function(...) return VehicleModEditor.get_mod_color(...) end,
    scan_color_names = function(...) return VehicleModEditor.scan_color_names(...) end,
    standard_color_category = function(...) return VehicleModEditor.standard_color_category(...) end,
    set_mod_color = function(...) return VehicleModEditor.set_mod_color(...) end,
    wheel_type_names = function(...) return VehicleModEditor.wheel_type_names(...) end,
    wheel_style_count = function(...) return VehicleModEditor.wheel_style_count(...) end,
    horn_categories = function(...) return VehicleModEditor.horn_categories(...) end,
    horn_slot = function(...) return VehicleModEditor.horn_slot(...) end,
    horn_preset_names = function(...) return VehicleModEditor.horn_preset_names(...) end,
    horn_state = function(...) return VehicleModEditor.horn_state(...) end,
    wheel_state = function(...) return VehicleModEditor.wheel_state(...) end,
    toggle_on = function(...) return VehicleModEditor.toggle_on(...) end,
    read_paint = function(...) return VehicleModEditor.read_paint(...) end,
    read_wheels = function(...) return VehicleModEditor.read_wheels(...) end,
    read_liveries = function(...) return VehicleModEditor.read_liveries(...) end,
    read_lights = function(...) return VehicleModEditor.read_lights(...) end,
    read_tyres = function(...) return VehicleModEditor.read_tyres(...) end,
    read_plate = function(...) return VehicleModEditor.read_plate(...) end,
    read_extras = function(...) return VehicleModEditor.read_extras(...) end,
    extra_slots = function(...) return VehicleModEditor.extra_slots(...) end,
    set_mod = function(...) return VehicleModEditor.set_mod(...) end,
    toggle_mod = function(...) return VehicleModEditor.toggle_mod(...) end,
    set_wheel = function(...) return VehicleModEditor.set_wheel(...) end,
    set_roof_livery = function(...) return VehicleModEditor.set_roof_livery(...) end,
    set_drift = function(...) return VehicleModEditor.set_drift(...) end,
    set_extra = function(...) return VehicleModEditor.set_extra(...) end,
    repair = function(...) return VehicleModEditor.repair(...) end,
    set_custom_primary = function(...) return VehicleCustomizer.set_custom_primary_color(...) end,
    set_custom_secondary = function(...) return VehicleCustomizer.set_custom_secondary_color(...) end,
    set_pearlescent = function(...) return VehicleCustomizer.set_pearlescent_color(...) end,
    set_wheel_color = function(...) return VehicleCustomizer.set_wheel_color(...) end,
    set_interior = function(...) return VehicleCustomizer.set_interior_color(...) end,
    set_dashboard = function(...) return VehicleCustomizer.set_dashboard_color(...) end,
    set_wheel_type = function(...) return VehicleCustomizer.set_wheel_type(...) end,
    set_window_tint = function(...) return VehicleCustomizer.set_window_tint(...) end,
    set_plate_type = function(...) return VehicleCustomizer.set_plate_type(...) end,
    set_plate_text = function(...) return VehicleCustomizer.set_plate_text(...) end,
    set_livery = function(...) return VehicleCustomizer.set_livery(...) end,
    set_neon_enabled = function(...) return VehicleCustomizer.set_all_neons_enabled(...) end,
    set_xenon_enabled = function(...) return VehicleCustomizer.set_xenon_enabled(...) end,
    set_xenon_color = function(...) return VehicleCustomizer.set_xenon_color(...) end,
    set_bulletproof = function(...) return VehicleCustomizer.set_bulletproof_tires(...) end,
    set_tire_smoke_enabled = function(...) return VehicleCustomizer.set_tire_smoke_enabled(...) end,
    set_tire_smoke_color = function(...) return VehicleCustomizer.set_tire_smoke_color(...) end,
    max_performance = function(...) return VehicleCustomizer.apply_max_performance(...) end,
    max_visual = function(...) return VehicleCustomizer.apply_max_visual_upgrades(...) end,
    clean = function(...) return VehicleCustomizer.clean_vehicle(...) end,
}

Spawner.VehiclePreset = {
    neon_names = function() return VehiclePreset.option_names(VehiclePreset.NEON_PRESETS) end,
    smoke_names = function() return VehiclePreset.option_names(VehiclePreset.SMOKE_PRESETS) end,
    xenon_names = function() return VehiclePreset.option_names(VehiclePreset.XENON_PRESETS) end,
    window_tints = function() return VehiclePreset.WINDOW_TINTS end,
    plate_types = function() return VehiclePreset.PLATE_TYPES end,
    apply_smoke_preset = function(...) return VehiclePreset.apply_smoke_preset(...) end,
    apply_neon_preset = function(...) return VehiclePreset.apply_neon_preset(...) end,
    neon_preset_index = function(...) return VehiclePreset.neon_preset_index(...) end,
    smoke_preset_index = function(...) return VehiclePreset.smoke_preset_index(...) end,
    color_category_keys = function() return VehiclePreset.color_category_keys() end,
    color_category = function(language, key) return VehiclePreset.color_category(language, key) end,
    color_category_of = function(language, index) return VehiclePreset.color_category_of(language, index) end,
}

Spawner.SavedVehicle = {
    save_current = function(...) return SavedVehicle.save_current(...) end,
    spawn_file = function(...) return SavedVehicle.spawn_file(...) end,
    delete = function(...) return SavedVehicle.delete(...) end,
    delete_all = function(...) return SavedVehicle.delete_all(...) end,
    get_spawned = function(...) return SavedVehicle.get_spawned(...) end,
    refresh = function(...) return SavedVehicle.refresh(...) end,
    snapshot = function(...) return SavedVehicle.snapshot(...) end,
    list = function(...) return SavedVehicle.list(...) end,
    folders = function(...) return SavedVehicle.folders(...) end,
    relative_path = function(...) return SavedVehicle.relative_path(...) end,
}

Spawner.Json = {
    Vehicle = {
        spawn_data = JsonVehicle.spawn_data,
        spawn_file = JsonVehicle.spawn_file,
        delete = JsonVehicle.delete,
        delete_all = JsonVehicle.delete_all,
        get_spawned = JsonVehicle.get_spawned,
    },
    Map = {
        spawn_data = JsonMap.spawn_data,
        spawn_file = JsonMap.spawn_file,
        delete = JsonMap.delete,
        delete_all = JsonMap.delete_all,
        get_spawned = JsonMap.get_spawned,
    },
    Outfit = {
        spawn_data = JsonOutfit.spawn_data,
        spawn_file = JsonOutfit.spawn_file,
        delete = JsonOutfit.delete,
        delete_all = JsonOutfit.delete_all,
        get_spawned = JsonOutfit.get_spawned,
    },
    Normalizer = {
        detect = JsonNormalizer.detect,
        normalize = JsonNormalizer.normalize,
    },
}

Spawner.Ini = {
    Vehicle = {
        spawn_string = IniVehicle.spawn_string,
        spawn_file = IniVehicle.spawn_file,
        delete = IniVehicle.delete,
        delete_all = IniVehicle.delete_all,
        get_spawned = IniVehicle.get_spawned,
        get_type = IniVehicle.get_type,
    },
}

Spawner.Menyoo = {
    Vehicle = {
        spawn_xml = MenyooVehicle.spawn_xml,
        spawn_file = MenyooVehicle.spawn_file,
        delete = MenyooVehicle.delete,
        delete_all = MenyooVehicle.delete_all,
        get_spawned = MenyooVehicle.get_spawned,
    },
    Outfit = {
        spawn_xml = MenyooOutfit.spawn_xml,
        spawn_file = MenyooOutfit.spawn_file,
        delete = MenyooOutfit.delete,
        delete_all = MenyooOutfit.delete_all,
        get_spawned = MenyooOutfit.get_spawned,
    },
    Map = {
        spawn_xml = MenyooMap.spawn_xml,
        spawn_file = MenyooMap.spawn_file,
        teleport_to_reference_xml = MenyooMap.teleport_to_reference_xml,
        teleport_to_reference_file = MenyooMap.teleport_to_reference_file,
        delete = MenyooMap.delete,
        delete_all = MenyooMap.delete_all,
        clear_database = MenyooMap.clear_database,
        clear_markers = MenyooMap.clear_markers,
        get_spawned = MenyooMap.get_spawned,
    },
    Parser = {
        vehicle = MenyooParser.vehicle,
        vehicle_properties = MenyooParser.vehicle_properties,
        outfit = MenyooParser.outfit,
        attachments = MenyooParser.attachments,
        map_placements = MenyooParser.map_placements,
        map_environment = MenyooParser.map_environment,
        map_root_name = MenyooParser.map_root_name,
        map_reference_coords = MenyooParser.map_reference_coords,
    },
    Xml = {
        parse = MenyooXml.parse,
        root = MenyooXml.root,
        node = MenyooXml.node,
        children = MenyooXml.children,
        find = MenyooXml.find,
        descendants = MenyooXml.descendants,
        text = MenyooXml.text,
        attr = MenyooXml.attr,
        number = MenyooXml.number,
        bool = MenyooXml.bool,
        vector = MenyooXml.vector,
        rotation = MenyooXml.rotation,
    },
}

return Spawner
