local VehicleSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Normalizer = require("ClickUl_Refactor.Features.Spawner.Json.Normalizer")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local VehiclePreset = require("ClickUl_Refactor.Features.Spawner.Core.VehiclePreset")
local VehicleSpawnSettings = require("ClickUl_Refactor.Features.Spawner.Core.VehicleSpawnSettings")
local VehicleAttributes = require("ClickUl_Refactor.Features.Spawner.Core.VehicleAttributes")
local PedAppearance = require("ClickUl_Refactor.Features.Spawner.Core.PedAppearance")
local ObjectCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.ObjectCustomizer")
local EntityTreeSpawner = require("ClickUl_Refactor.Features.Spawner.Core.EntityTreeSpawner")

local REGISTRY_KEY <const> = "json_spawned_entities"

local function apply_vehicle_settings(vehicle, settings)
    VehicleSpawnSettings.apply_flags(vehicle, settings)
    VehicleSpawnSettings.apply_randomization(vehicle, settings)
    if settings.spawn_plane_in_air then EntityFactory.raise_aircraft_if_needed(vehicle, 50.0) end
end

function VehicleSpawner.spawn_data(json_data, coords, heading, opts)
    opts = opts or {}
    local registry_key = opts.registry_key or REGISTRY_KEY
    local data = Normalizer.normalize(json_data)
    if not data then return nil, nil, "unsupported_json_format" end

    local settings = Settings.get("json")
    local root_type = tostring(data.type or "VEHICLE"):upper()
    local root_hash = data.hash or data.model
    if not root_hash then return nil, nil, "missing_model" end

    coords = coords or EntityFactory.forward_spawn_coords(5.0)
    heading = heading or EntityFactory.player_heading()

    local saved_speed = 0
    if root_type == "VEHICLE" then saved_speed = VehicleSpawnSettings.captured_speed(settings) end

    if root_type == "VEHICLE" and settings.delete_old_vehicle then
        SpawnRegistry.delete_entity_records(registry_key)
    end

    local root, err = EntityFactory.spawn_by_type(root_type, root_hash, coords, heading)
    if not root or root == 0 then return nil, nil, err end

    local entities = { root }
    local options = Util.copy_table(data.options or {})
    if options.has_collision == nil then options.has_collision = true end
    if settings.disable_collision then options.has_collision = false end
    if options.is_visible == nil then options.is_visible = true end
    if root_type == "VEHICLE" and settings.vehicle_god_mode then options.is_invincible = true end
    EntityOptions.apply(root, options)

    if root_type == "VEHICLE" then
        local vehicle_settings = settings
        if data.vehicle_attributes then
            VehicleAttributes.apply(root, data.vehicle_attributes, settings)
            if VehicleAttributes.specifies_engine(data.vehicle_attributes) then
                vehicle_settings = Util.copy_table(settings)
                vehicle_settings.vehicle_engine_on = nil
            end
        end
        apply_vehicle_settings(root, vehicle_settings)
        VehiclePreset.apply(root, vehicle_settings, opts.use_saved_preset)
    elseif root_type == "PED" and data.ped_attributes then
        PedAppearance.apply_attributes(root, data.ped_attributes)
    elseif root_type == "OBJECT" then
        ObjectCustomizer.apply(root, data.object_attributes or options)
    end

    if type(data.children) == "table" then
        local models_used = {}
        for _, child in ipairs(data.children) do
            local _, child_error = EntityTreeSpawner.spawn(child, {
                parent = root,
                records = entities,
                disable_collision = settings.disable_collision,
                settings = settings,
                models_used = models_used,
            })
            if child_error then
                EntityTreeSpawner.release_models(models_used)
                SpawnRegistry.delete_entities(entities)
                return nil, entities, child_error
            end
        end
        EntityTreeSpawner.release_models(models_used)
    end
    EntityFactory.clear_internal_collisions(entities)
    if data.particle_attributes then Ptfx.start_looped(root, data.particle_attributes) end
    if root_type == "VEHICLE" and settings.in_vehicle then
        if EntityFactory.put_player_in_vehicle(root) and data.vehicle_attributes then
            VehicleAttributes.apply_radio_station(root, data.vehicle_attributes)
        end
        if saved_speed > 0 then VehicleCustomizer.set_forward_speed(root, saved_speed) end
    end

    SpawnRegistry.add(registry_key, { entities = entities })
    return root, entities, nil
end

function VehicleSpawner.spawn_file(path, coords, heading, opts)
    local data, err = Fs.read_json_value(path)
    if not data then return nil, nil, err end
    local root, entities, spawn_err = VehicleSpawner.spawn_data(data, coords, heading, opts)
    if root and root ~= 0 then
        local registry_key = (opts and opts.registry_key) or REGISTRY_KEY
        SpawnRegistry.update_last(registry_key, function(record)
            record.file_path = path
        end)
    end
    return root, entities, spawn_err
end

function VehicleSpawner.delete(index)
    return SpawnRegistry.delete_entity_record_at(REGISTRY_KEY, index)
end

function VehicleSpawner.delete_all()
    return SpawnRegistry.delete_entity_records(REGISTRY_KEY)
end

function VehicleSpawner.get_spawned()
    return SpawnRegistry.list(REGISTRY_KEY)
end

return VehicleSpawner
