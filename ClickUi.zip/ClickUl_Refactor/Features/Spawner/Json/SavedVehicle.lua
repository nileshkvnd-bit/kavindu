local SavedVehicle = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Json = require("ClickUl_Refactor.Adapters.Json")
local VehicleFiles = require("ClickUl_Refactor.Features.Spawner.Core.VehicleFiles")
local VehicleSnapshot = require("ClickUl_Refactor.Features.Spawner.Core.VehicleSnapshot")
local JsonVehicle = require("ClickUl_Refactor.Features.Spawner.Json.VehicleSpawner")
local StandNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.StandNormalizer")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")

local SAVED_REGISTRY_KEY <const> = "saved_spawned_entities"

local function sanitize_filename(value)
    value = tostring(value or ""):match("^%s*(.-)%s*$")
    value = value:gsub("[\\/:*?\"<>|]", "_")
    return value
end

local function lexis_dir()
    return Fs.join(Fs.root_dir(), "Vehicles\\Lexis\\")
end

local function save_path(filename)
    return Fs.join(lexis_dir(), sanitize_filename(filename) .. ".json")
end

function SavedVehicle.export_current()
    return VehicleSnapshot.current()
end

function SavedVehicle.save_current(filename)
    filename = sanitize_filename(filename)
    if filename == "" then return nil, "missing_filename" end

    local data, err = SavedVehicle.export_current()
    if not data then return nil, err end

    Fs.ensure_dir(lexis_dir())
    local path = save_path(filename)
    if not Fs.write_text(path, Json.encode_document(data, 2)) then return nil, "write_failed" end
    VehicleFiles.refresh()
    return path, nil
end

function SavedVehicle.spawn_file(item_or_path)
    local path = type(item_or_path) == "table" and item_or_path.path or item_or_path
    local format = type(item_or_path) == "table" and item_or_path.format or nil
    if not path or path == "" then return nil, nil, "missing_path" end

    local opts = { use_saved_preset = true, registry_key = SAVED_REGISTRY_KEY }

    if format == "Stand" or tostring(path):lower():match("%.txt$") then
        local content, err = Fs.read_text(path)
        if not content then return nil, nil, err end
        return JsonVehicle.spawn_data(StandNormalizer.parse_text(content), nil, nil, opts)
    end

    return JsonVehicle.spawn_file(path, nil, nil, opts)
end

function SavedVehicle.delete(index)
    return SpawnRegistry.delete_entity_record_at(SAVED_REGISTRY_KEY, index)
end

function SavedVehicle.delete_all()
    return SpawnRegistry.delete_entity_records(SAVED_REGISTRY_KEY)
end

function SavedVehicle.get_spawned()
    return SpawnRegistry.list(SAVED_REGISTRY_KEY)
end

function SavedVehicle.refresh()
    return VehicleFiles.refresh()
end

function SavedVehicle.snapshot()
    return VehicleFiles.ensure_loaded()
end

function SavedVehicle.list(format)
    return VehicleFiles.list(format)
end

function SavedVehicle.folders(format)
    return VehicleFiles.folders(format)
end

function SavedVehicle.relative_path(path)
    return VehicleFiles.relative_path(path)
end

return SavedVehicle
