local Normalizer = {}

local Detector = require("ClickUl_Refactor.Features.Spawner.Json.Detector")
local JStandNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.JStandNormalizer")
local CraftLabNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.CraftLabNormalizer")
local LexisNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.LexisNormalizer")
local CheraxNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.CheraxNormalizer")
local StandNormalizer = require("ClickUl_Refactor.Features.Spawner.Json.StandNormalizer")

local VARIATION_FIELDS <const> = { "components", "props", "facial_features" }

local function numeric_slot(key)
    if type(key) == "number" then return math.tointeger(key) or math.floor(key) end
    local digits = tostring(key):match("^_?(%d+)$")
    if digits then return tonumber(digits) end
    return nil
end

local function rekey_slots(tbl)
    if type(tbl) ~= "table" then return tbl end
    local out = {}
    for key, val in pairs(tbl) do
        local id = numeric_slot(key)
        if id ~= nil then out[id] = val else out[key] = val end
    end
    return out
end

local function canonicalize_head_overlays(overlays)
    if type(overlays) ~= "table" then return overlays end
    local out = {}
    for key, val in pairs(overlays) do
        local id = numeric_slot(key)
        local out_key = id ~= nil and id or key
        if type(val) == "number" then
            out[out_key] = { index = val < 0 and 255 or val }
        else
            out[out_key] = val
        end
    end
    return out
end

local function canonicalize_animation(anim)
    if type(anim) ~= "table" then return end
    if anim.duration == nil and anim.emote_duration ~= nil then anim.duration = anim.emote_duration end
    if anim.flag == nil and anim.flags == nil then
        local flags = 0
        if anim.loop then flags = flags | 1 end
        if anim.controllable then flags = flags | 16 | 32 end
        anim.flags = flags
    end
end

local function canonicalize_ped_attributes(pa)
    if type(pa) ~= "table" then return end
    for _, field in ipairs(VARIATION_FIELDS) do
        pa[field] = rekey_slots(pa[field])
    end
    pa.head_overlays = canonicalize_head_overlays(pa.head_overlays)
    canonicalize_animation(pa.animation)
end

local function canonicalize_vehicle_attributes(va)
    if type(va) ~= "table" or type(va.paint) ~= "table" then return end
    local paint = va.paint
    if type(paint.primary) == "table" and paint.primary.paint_type ~= nil and paint.mod_1 == nil then
        paint.mod_1 = { color_type = paint.primary.paint_type, color = paint.primary.color, pearlescent = paint.primary.pearlescent_color }
    end
    if type(paint.secondary) == "table" and paint.secondary.paint_type ~= nil and paint.mod_2 == nil then
        paint.mod_2 = { color_type = paint.secondary.paint_type, color = paint.secondary.color }
    end
    if paint.livery2 == nil and paint.livery2_legacy ~= nil then paint.livery2 = paint.livery2_legacy end
    local primary_table = type(paint.primary) == "table" and paint.primary or nil
    local secondary_table = type(paint.secondary) == "table" and paint.secondary or nil
    if (primary_table and primary_table.vehicle_standard_color ~= nil)
            or (secondary_table and secondary_table.vehicle_standard_color ~= nil) then
        paint.vehicle_custom_color = nil
    end
end

local function canonicalize_node(node)
    if type(node) ~= "table" then return end
    canonicalize_ped_attributes(node.ped_attributes)
    canonicalize_vehicle_attributes(node.vehicle_attributes)
    if type(node.children) == "table" then
        for _, child in ipairs(node.children) do
            canonicalize_node(child)
        end
    end
end

function Normalizer.detect(data)
    return Detector.detect(data)
end

function Normalizer.normalize(data)
    local format = Detector.detect(data)
    local result
    if format == "constructor" then result = data
    elseif format == "jstand" then result = JStandNormalizer.normalize(data)
    elseif format == "craftlab" then result = CraftLabNormalizer.normalize(data)
    elseif format == "lexis" then result = LexisNormalizer.normalize(data)
    elseif format == "cherax" then result = CheraxNormalizer.normalize(data)
    elseif format == "stand" then result = StandNormalizer.normalize(data)
    else return nil end
    canonicalize_node(result)
    return result
end

return Normalizer
