local CraftLabNormalizer = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local CRAFTLAB_TYPE_MAP <const> = {
    [3] = "VEHICLE",
    [4] = "PED",
    [5] = "OBJECT",
}

local function craftlab_entity_type(ent)
    if type(ent.vehicle_data) == "table" then return "VEHICLE" end
    if type(ent.ped_data) == "table" or type(ent.ped_attributes) == "table" then return "PED" end
    if type(ent.object_data) == "table" or type(ent.object_attributes) == "table" then return "OBJECT" end
    return CRAFTLAB_TYPE_MAP[ent.type] or "OBJECT"
end

local CRAFTLAB_DOOR_BROKEN <const> = {
    is_broken_0 = "frontleft", is_broken_1 = "frontright", is_broken_2 = "backleft",
    is_broken_3 = "backright", is_broken_4 = "hood", is_broken_5 = "trunk", is_broken_6 = "trunk2",
}
local CRAFTLAB_WINDOW_BROKEN <const> = {
    is_deleted_left_front = "frontleft", is_deleted_left_rear = "rearleft",
    is_deleted_right_front = "frontright", is_deleted_right_rear = "rearright",
}

local function broken_map(source, key_map)
    if type(source) ~= "table" then return nil end
    local broken = {}
    for src_key, name in pairs(key_map) do
        local value = source[src_key]
        if value ~= nil then broken[name] = value and true or false end
    end
    if next(broken) == nil then return nil end
    return { broken = broken }
end

local function craftlab_extras(source)
    if type(source) ~= "table" then return nil end
    local extras = {}
    for index = 0, 60 do
        local value = source["exist_" .. index]
        if value ~= nil then extras["_" .. index] = value and true or false end
    end
    if next(extras) == nil then return nil end
    return extras
end

local function convert_entity(ent)
    local entity_type = craftlab_entity_type(ent)
    local result = {
        type = entity_type,
        hash = ent.model,
        children = {},
        options = {
            is_visible = ent.visible ~= false,
            has_collision = ent.collision ~= false,
            is_invincible = ent.invincible == true,
            is_frozen = ent.freeze == true,
            has_gravity = ent.gravity ~= false,
            alpha = ent.alpha_level or 255,
        },
    }

    if ent.attach_data then
        result.offset = {
            x = ent.attach_data.x or 0,
            y = ent.attach_data.y or 0,
            z = ent.attach_data.z or 0,
        }
        result.rotation = {
            x = ent.attach_data.pitch or 0,
            y = ent.attach_data.roll or 0,
            z = ent.attach_data.yaw or 0,
        }
        result.options.bone_index = ent.attach_data.attached_to_bone or 0
    end

    if entity_type == "VEHICLE" and ent.vehicle_data then
        local vd = ent.vehicle_data
        result.vehicle_attributes = {
            mods = {},
            paint = {
                primary = vd.primary_colour,
                secondary = vd.secondary_colour,
                extra_colors = {
                    pearlescent = vd.pearl_color,
                    wheel = vd.wheel_color,
                },
            },
            wheels = { wheel_type = vd.wheel_type },
            options = {
                license_plate_text = vd.number_plate_text,
                license_plate_type = vd.number_plate_text_index,
                window_tint = vd.window_tint,
                bulletproof_tires = not vd.tyres_can_burst,
            },
            neon = {},
        }
        if vd.rgb_colors then
            result.vehicle_attributes.paint.vehicle_custom_color = {}
            if vd.is_custom_primary_color then
                result.vehicle_attributes.paint.vehicle_custom_color.r = vd.rgb_colors.custom_primary_colour_r
                result.vehicle_attributes.paint.vehicle_custom_color.g = vd.rgb_colors.custom_primary_colour_g
                result.vehicle_attributes.paint.vehicle_custom_color.b = vd.rgb_colors.custom_primary_colour_b
            end
            if vd.is_custom_secondary_color then
                result.vehicle_attributes.paint.vehicle_custom_color.r2 = vd.rgb_colors.custom_secondary_colour_r
                result.vehicle_attributes.paint.vehicle_custom_color.g2 = vd.rgb_colors.custom_secondary_colour_g
                result.vehicle_attributes.paint.vehicle_custom_color.b2 = vd.rgb_colors.custom_secondary_colour_b
            end
            result.vehicle_attributes.neon.color = {
                r = vd.rgb_colors.neon_lights_colour_r,
                g = vd.rgb_colors.neon_lights_colour_g,
                b = vd.rgb_colors.neon_lights_colour_b,
            }
            result.vehicle_attributes.wheels.tire_smoke_color = {
                r = vd.rgb_colors.tyre_smoke_colour_r,
                g = vd.rgb_colors.tyre_smoke_colour_g,
                b = vd.rgb_colors.tyre_smoke_colour_b,
            }
        end
        if vd.neon then
            result.vehicle_attributes.neon.lights = {
                left = vd.neon.is_enabled_0,
                right = vd.neon.is_enabled_1,
                front = vd.neon.is_enabled_2,
                back = vd.neon.is_enabled_3,
            }
        end
        if vd.mod_slot then
            for key, value in pairs(vd.mod_slot) do
                local mod_id = tostring(key):match("mod_index_(%d+)") or tostring(key):match("mod_toggle_(%d+)")
                if mod_id then result.vehicle_attributes.mods["_" .. mod_id] = value end
            end
        end

        result.vehicle_attributes.paint.interior_color = vd.interior_color
        result.vehicle_attributes.paint.dashboard_color = vd.dashboard_color
        result.vehicle_attributes.paint.dirt_level = vd.dirt_level
        result.vehicle_attributes.paint.fade = vd.enveff_scale
        result.vehicle_attributes.options.headlights_color = vd.headlight_color
        result.vehicle_attributes.options.engine_on = vd.is_engine_running
        if type(vd.livery) == "number" and vd.livery >= 0 then
            result.vehicle_attributes.livery = vd.livery
        end
        result.vehicle_attributes.doors = broken_map(vd.doors, CRAFTLAB_DOOR_BROKEN)
        result.vehicle_attributes.windows = broken_map(vd.windows, CRAFTLAB_WINDOW_BROKEN)
        result.vehicle_attributes.extras = craftlab_extras(vd.extras)
    end

    if entity_type == "PED" then
        result.ped_attributes = ent.ped_attributes or ent.ped_data or ent.ped
        result.vehicle_seat = Util.first_present(ent, "vehicle_seat", "vehicle-seat", "seat")
        if result.vehicle_seat == nil and type(result.ped_attributes) == "table" then result.vehicle_seat = result.ped_attributes.seat end
    elseif entity_type == "OBJECT" then
        result.object_attributes = ent.object_attributes or ent.object_properties or ent.object_data
        local object_tint = Util.first_present(ent, "object_tint", "objectTint", "tint_index", "tintIndex")
        if object_tint == nil and type(result.object_attributes) == "table" then
            object_tint = Util.first_present(result.object_attributes, "object_tint", "TextureVariation", "texture_variation")
        end
        if object_tint ~= nil then
            result.object_attributes = result.object_attributes or {}
            result.object_attributes.object_tint = object_tint
        end
    end

    return result
end

function CraftLabNormalizer.normalize(data)
    if type(data.craftlab) ~= "table" or #data.craftlab == 0 then return nil end

    local entity_map = {}
    for _, item in ipairs(data.craftlab) do
        local ent = item.entity
        if ent and ent.unique_number then entity_map[ent.unique_number] = ent end
    end

    local root_entity
    for _, item in ipairs(data.craftlab) do
        local ent = item.entity
        if ent and not ent.is_attached then
            root_entity = ent
            break
        end
        if ent and ent.attach_data and not entity_map[ent.attach_data.attached_to_number] then
            root_entity = ent
            break
        end
    end
    root_entity = root_entity or (data.craftlab[1] and data.craftlab[1].entity)
    if not root_entity then return nil end

    local function find_children(parent_number)
        local children = {}
        for _, item in ipairs(data.craftlab) do
            local ent = item.entity
            if ent and ent.is_attached and ent.attach_data and ent.attach_data.attached_to_number == parent_number then
                local child = convert_entity(ent)
                child.children = find_children(ent.unique_number)
                children[#children + 1] = child
            end
        end
        return children
    end

    local result = convert_entity(root_entity)
    result.children = find_children(root_entity.unique_number)
    return result
end

return CraftLabNormalizer
