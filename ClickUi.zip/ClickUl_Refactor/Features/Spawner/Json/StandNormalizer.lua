local StandNormalizer = {}

local function trim(value)
    return (tostring(value):match("^%s*(.-)%s*$"))
end

local function to_int(value)
    if type(value) == "number" then return math.floor(value) end
    return tonumber(tostring(value))
end

local function is_yes(value)
    if type(value) == "boolean" then return value end
    return tostring(value):lower() == "yes"
end

local function yes_or_nil(value)
    if value == nil then return nil end
    return is_yes(value)
end

local function parse_hex_color(value)
    if type(value) ~= "string" then return nil end
    local hex = value:gsub("^#", "")
    if #hex < 6 then return nil end
    return {
        r = tonumber(hex:sub(1, 2), 16) or 0,
        g = tonumber(hex:sub(3, 4), 16) or 0,
        b = tonumber(hex:sub(5, 6), 16) or 0,
    }
end

local MOD_KEYS <const> = {
    ["Spoiler"] = 0, ["Front Bumper"] = 1, ["Rear Bumper"] = 2, ["Sideskirt"] = 3,
    ["Exhaust"] = 4, ["Chassis"] = 5, ["Grille"] = 6, ["Hood"] = 7, ["Fender"] = 8,
    ["Right Fender"] = 9, ["Roof"] = 10, ["Engine"] = 11, ["Brakes"] = 12,
    ["Transmission"] = 13, ["Horns"] = 14, ["Suspension"] = 15, ["Armor"] = 16,
    ["Plate Holder"] = 25, ["Vanity Plates"] = 26, ["Trim"] = 27, ["Ornaments"] = 28,
    ["Dashboard"] = 29, ["Dial"] = 30, ["Seats"] = 31, ["Door Speaker"] = 32,
    ["Steering Wheel"] = 33, ["Shifter Leavers"] = 34, ["Plaques"] = 35, ["Speakers"] = 36,
    ["Trunk"] = 37, ["Hydraulics"] = 38, ["Engine Block"] = 39, ["Air Filter"] = 40,
    ["Struts"] = 41, ["Arch Cover"] = 42, ["Aerials"] = 43, ["Trim2"] = 44, ["Tank"] = 45,
    ["Left Door"] = 46, ["Right Door"] = 47, ["Lightbar"] = 49,
}

local BOOL_MOD_KEYS <const> = {
    ["Nitrous"] = 17, ["Turbo"] = 18, ["Subwoofer"] = 19, ["Tiresmoke"] = 20, ["Unk21"] = 21,
}

local function wheel_mod(value)
    if value == nil then return nil end
    local str = tostring(value)
    local index = to_int(str:match("^(%d+)"))
    if not index or index <= 0 then return nil end
    return { mod = index - 1, variation = str:lower():find("custom") ~= nil }
end

function StandNormalizer.parse_text(content)
    local data = {}
    if type(content) ~= "string" then return data end
    for line in content:gmatch("[^\r\n]+") do
        local key, value = line:match("^(.-):%s*(.*)$")
        if key and key ~= "" then data[trim(key)] = trim(value or "") end
    end
    return data
end

function StandNormalizer.normalize(data)
    if type(data) ~= "table" then return nil end
    local model = data["Model Name"] or data.Model or data.model or data.Vehicle
    if not model then return nil end

    local mods = {}
    for key, slot in pairs(MOD_KEYS) do
        local value = to_int(data[key])
        if value and value > 0 then mods["_" .. slot] = value - 1 end
    end
    for key, slot in pairs(BOOL_MOD_KEYS) do
        if data[key] ~= nil then mods["_" .. slot] = is_yes(data[key]) end
    end

    local front_wheels = wheel_mod(data["Front Wheels"])
    local back_wheels = wheel_mod(data["Back Wheels"])
    if front_wheels then mods["_23"] = front_wheels end
    if back_wheels then mods["_24"] = back_wheels end

    local headlights = to_int(data["Headlights"])
    local headlights_color
    if headlights ~= nil then
        if headlights <= 0 then
            mods["_22"] = false
        elseif headlights == 1 then
            mods["_22"] = true
        else
            headlights_color = headlights - 2
        end
    end

    local paint = {
        primary = to_int(data["Primary Colour"]),
        secondary = to_int(data["Secondary Colour"]),
        interior = to_int(data["Interior Colour"]),
        dashboard = to_int(data["Dashboard Colour"]),
    }
    local pearl = to_int(data["Pearl Colour"])
    local wheel_color = to_int(data["Wheel Colour"])
    if pearl ~= nil or wheel_color ~= nil then
        paint.extra_colors = { pearlescent = pearl, wheel = wheel_color }
    end

    local primary_custom = parse_hex_color(data["Custom Primary Colour"])
    local secondary_custom = parse_hex_color(data["Custom Secondary Colour"])
    if primary_custom or secondary_custom then
        paint.vehicle_custom_color = {
            r = primary_custom and primary_custom.r,
            g = primary_custom and primary_custom.g,
            b = primary_custom and primary_custom.b,
            r2 = secondary_custom and secondary_custom.r,
            g2 = secondary_custom and secondary_custom.g,
            b2 = secondary_custom and secondary_custom.b,
        }
    end

    local options = {
        license_plate_text = data["Plate Text"],
        license_plate_type = to_int(data["Plate Style"] or data["Plate Type"]),
        window_tint = to_int(data["Window Tint"]),
        headlights_color = headlights_color,
    }

    local tyres_mode = to_int(data["Tyres Mode"])
    if tyres_mode == 1 or tyres_mode == 4 then options.bulletproof_tires = true end
    if tyres_mode == 3 or tyres_mode == 4 then options.drift_tyres = true end

    local wheels = { wheel_type = to_int(data["Wheel Type"]) }
    if is_yes(data["Tiresmoke"]) then
        local tyre_smoke = parse_hex_color(data["Tyre Smoke Colour"])
        if tyre_smoke then wheels.tire_smoke_color = tyre_smoke end
    end

    local attrs = {
        mods = mods,
        paint = paint,
        options = options,
        wheels = wheels,
    }

    local livery = to_int(data["Livery"])
    if livery and livery > 0 then attrs.livery = livery - 1 end

    local roof_livery = to_int(data["Roof Livery"])
    if roof_livery and roof_livery >= 0 then attrs.livery2 = roof_livery end

    local neon_color = parse_hex_color(data["Neon Colour"])
    local neon_lights = {
        left = yes_or_nil(data["Neon Left"]),
        right = yes_or_nil(data["Neon Right"]),
        front = yes_or_nil(data["Neon Front"]),
        back = yes_or_nil(data["Neon Back"]),
    }
    if neon_color or next(neon_lights) then
        attrs.neon = { lights = neon_lights, color = neon_color }
    end

    local extras = {}
    for n = 1, 15 do
        local value = data["Extra " .. n]
        if value ~= nil then extras["_" .. n] = is_yes(value) end
    end
    if next(extras) then attrs.extras = extras end

    return {
        type = "VEHICLE",
        hash = model,
        children = {},
        vehicle_attributes = attrs,
    }
end

return StandNormalizer
