local NormalizerShared = {}

function NormalizerShared.custom_color_pair(primary, secondary)
    return {
        r = primary and primary.r,
        g = primary and primary.g,
        b = primary and primary.b,
        r2 = secondary and secondary.r,
        g2 = secondary and secondary.g,
        b2 = secondary and secondary.b,
    }
end

function NormalizerShared.vehicle_attributes(spec)
    return {
        mods = spec.mods or {},
        paint = {
            primary = spec.primary,
            secondary = spec.secondary,
            interior = spec.interior,
            dashboard = spec.dashboard,
            extra_colors = { pearlescent = spec.pearlescent, wheel = spec.wheel_color },
            vehicle_custom_color = spec.custom_color,
        },
        options = {
            license_plate_text = spec.plate_text,
            license_plate_type = spec.plate_type,
            window_tint = spec.window_tint,
            bulletproof_tires = spec.bulletproof_tires,
        },
        neon = spec.neon,
        wheels = { wheel_type = spec.wheel_type, tire_smoke_color = spec.tire_smoke_color },
    }
end

return NormalizerShared
