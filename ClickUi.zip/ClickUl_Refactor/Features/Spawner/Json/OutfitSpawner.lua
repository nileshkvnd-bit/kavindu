local OutfitSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Normalizer = require("ClickUl_Refactor.Features.Spawner.Json.Normalizer")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local PedAppearance = require("ClickUl_Refactor.Features.Spawner.Core.PedAppearance")
local OutfitAttachmentSpawner = require("ClickUl_Refactor.Features.Spawner.Json.OutfitAttachmentSpawner")

local SWAP_SETTLE_MS <const> = 0

local function resolve_spawn_mode(data, settings, opts)
    if data.is_player == false then return Settings.OUTFIT_SPAWN_MODE.APPLY_TO_PLAYER end
    if opts.spawn_mode then return opts.spawn_mode end
    return settings.spawn_mode or Settings.OUTFIT_SPAWN_MODE.APPLY_TO_PLAYER
end

local function add_unique_entity(list, entity)
    if not entity or entity == 0 then return end
    for _, existing in ipairs(list) do
        if existing == entity then return end
    end
    list[#list + 1] = entity
end

function OutfitSpawner.spawn_data(json_data, opts)
    local data = Normalizer.normalize(json_data)
    if not data or tostring(data.type or ""):upper() ~= "PED" then return nil, nil, "not_ped_outfit" end
    opts = opts or {}

    local settings = Settings.get("json_outfit")
    if settings.delete_old_outfit and not opts.is_preview then OutfitSpawner.delete_all() end

    local mode = resolve_spawn_mode(data, settings, opts)
    local player_ped = EntityFactory.player_ped()
    if not player_ped or player_ped == 0 then return nil, nil, "missing_player_ped" end

    local builds_standalone_ped = mode == Settings.OUTFIT_SPAWN_MODE.SPAWN_PED
        or mode == Settings.OUTFIT_SPAWN_MODE.CHANGE_PLAYER_MODEL
    local target_ped = player_ped
    local spawned_ped = nil
    local attachments = {}
    local ptfx_entities = {}

    if builds_standalone_ped then
        local spawn_error
        spawned_ped, spawn_error = EntityFactory.spawn_ped(data.hash or data.model, EntityFactory.player_coords(), EntityFactory.player_heading(), 26)
        if not spawned_ped or spawned_ped == 0 then return nil, nil, spawn_error or "spawn_failed" end
        target_ped = spawned_ped
        PedAppearance.apply_default_components(target_ped)
        EntityOptions.apply(target_ped, data.options or {})
    end

    local attachment_error = nil
    if type(data.children) == "table" then
        local attachment_ptfx_entities
        attachments, attachment_error, attachment_ptfx_entities = OutfitAttachmentSpawner.spawn_many(data.children, target_ped, settings)
        if type(attachment_ptfx_entities) == "table" then ptfx_entities = attachment_ptfx_entities end
    end
    if attachment_error then
        if spawned_ped then EntityFactory.delete(spawned_ped) end
        return nil, attachments, attachment_error
    end

    if data.ped_attributes then
        PedAppearance.apply_attributes(target_ped, data.ped_attributes, {
            apply_head_features = builds_standalone_ped or settings.apply_head_features == true,
            apply_behavior = builds_standalone_ped,
        })
    end
    if data.particle_attributes then
        local handle = Ptfx.start_looped(target_ped, data.particle_attributes)
        if handle and handle > 0 then add_unique_entity(ptfx_entities, target_ped) end
    end

    if mode == Settings.OUTFIT_SPAWN_MODE.CHANGE_PLAYER_MODEL then
        EntityFactory.yield(SWAP_SETTLE_MS)
        EntityFactory.swap_player_to_ped(spawned_ped)
        EntityFactory.yield(0)
        local new_player_ped = EntityFactory.player_ped()
        if new_player_ped == spawned_ped and player_ped ~= spawned_ped and EntityFactory.exists(player_ped) then
            EntityFactory.delete(player_ped)
        end
        target_ped = new_player_ped
        spawned_ped = nil
    end

    SpawnRegistry.add("json_spawned_outfits", {
        spawned_ped = spawned_ped,
        attachments = attachments,
        ptfx_entities = ptfx_entities,
        attached_to_player = mode ~= Settings.OUTFIT_SPAWN_MODE.SPAWN_PED,
        file_path = opts.file_path,
    })

    return target_ped, attachments, attachment_error
end

function OutfitSpawner.spawn_file(path, opts)
    local data, err = Fs.read_json_value(path)
    if not data then return nil, nil, err end
    opts = opts or {}
    opts.file_path = path
    return OutfitSpawner.spawn_data(data, opts)
end

function OutfitSpawner.delete(index)
    return SpawnRegistry.delete_outfit_at("json_spawned_outfits", index)
end

function OutfitSpawner.delete_all()
    return SpawnRegistry.delete_outfits("json_spawned_outfits")
end

function OutfitSpawner.get_spawned()
    return SpawnRegistry.list("json_spawned_outfits")
end

return OutfitSpawner
