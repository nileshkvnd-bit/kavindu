local LexisNormalizer = {}

local NormalizerShared = require("ClickUl_Refactor.Features.Spawner.Json.NormalizerShared")

local function array_color(value)
    if type(value) ~= "table" then return nil end
    return { r = value[1] or 0, g = value[2] or 0, b = value[3] or 0 }
end

local function custom_rgb(flag, rgb)
    if type(rgb) ~= "table" then return nil end
    if flag ~= nil then
        if not flag then return nil end
        return rgb
    end
    if (rgb[1] or 0) == 0 and (rgb[2] or 0) == 0 and (rgb[3] or 0) == 0 then return nil end
    return rgb
end

function LexisNormalizer.normalize(data)
    if type(data) ~= "table" or not data.model then return nil end

    local mods = {}
    if type(data.mods) == "table" then
        for index, value in ipairs(data.mods) do
            mods["_" .. tostring(index - 1)] = value
        end
    end

    local colors = data.colors or {}
    local extra_colors = data["extra colors"] or {}
    local neon_enabled = data["neon enabled"] or {}

    local primary_rgb = custom_rgb(data["is custom primary"], data["custom primary"])
    local secondary_rgb = custom_rgb(data["is custom secondary"], data["custom secondary"])
    local custom_color
    if primary_rgb or secondary_rgb then
        custom_color = {
            r = primary_rgb and primary_rgb[1],
            g = primary_rgb and primary_rgb[2],
            b = primary_rgb and primary_rgb[3],
            r2 = secondary_rgb and secondary_rgb[1],
            g2 = secondary_rgb and secondary_rgb[2],
            b2 = secondary_rgb and secondary_rgb[3],
        }
    end

    return {
        type = "VEHICLE",
        hash = data.model,
        children = {},
        vehicle_attributes = NormalizerShared.vehicle_attributes({
            mods = mods,
            primary = colors[1] or 0,
            secondary = colors[2] or 0,
            pearlescent = extra_colors[1] or 0,
            wheel_color = extra_colors[2] or 0,
            interior = data["extra color 5"],
            dashboard = data["dashboard colour"] or data["dashboard color"],
            custom_color = custom_color,
            plate_text = data["plate text"],
            plate_type = data["plate index"],
            window_tint = data["window tint"],
            bulletproof_tires = data.bulletproof,
            neon = {
                lights = { left = neon_enabled[1], right = neon_enabled[2], front = neon_enabled[3], back = neon_enabled[4] },
                color = array_color(data["neon color"]),
            },
            wheel_type = data["wheel type"],
            tire_smoke_color = array_color(data["tire color"]),
        }),
    }
end

return LexisNormalizer
