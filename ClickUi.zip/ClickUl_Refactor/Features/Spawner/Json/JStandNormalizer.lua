local JStandNormalizer = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local NormalizerShared = require("ClickUl_Refactor.Features.Spawner.Json.NormalizerShared")

local MOD_SLOTS <const> = {
    ["Spoilers"] = 0, ["Front Bumper"] = 1, ["Rear Bumper"] = 2, ["Side Skirt"] = 3, ["Exhaust"] = 4,
    ["Frame"] = 5, ["Grille"] = 6, ["Hood"] = 7, ["Fender"] = 8, ["Right Fender"] = 9, ["Roof"] = 10,
    ["Engine"] = 11, ["Brakes"] = 12, ["Transmission"] = 13, ["Horns"] = 14, ["Suspension"] = 15, ["Armor"] = 16,
    ["Wheels Design"] = 23, ["Motorcycle Back Wheel Design"] = 24, ["Plate Holders"] = 25, ["Vanity Plates"] = 26,
    ["Trim Design"] = 27, ["Ornaments"] = 28, ["Dashboard"] = 29, ["Dial Design"] = 30, ["Door Speakers"] = 31,
    ["Seats"] = 32, ["Steering Wheel"] = 33, ["Shifter Leavers"] = 34, ["Plaques"] = 35, ["Speakers"] = 36,
    ["Trunk"] = 37, ["Hydraulics"] = 38, ["Engine Block"] = 39, ["Air Filter"] = 40, ["Struts"] = 41,
    ["Arch Cover"] = 42, ["Aerials"] = 43, ["Trim"] = 44, ["Tank"] = 45, ["Doors"] = 46, ["Livery"] = 48,
}

local TOGGLE_SLOTS <const> = {
    ["UNK17"] = 17, ["Turbo Turning"] = 18, ["UNK19"] = 19, ["Tire Smoke"] = 20, ["UNK21"] = 21, ["Xenon Headlights"] = 22,
}

local function root_model(data)
    if data.hash ~= nil then return data.hash end
    if data.model ~= nil then return data.model end
    local base = data.base
    if type(base) ~= "table" then return nil end
    if base.model ~= nil then return base.model end
    if base.hash ~= nil then return base.hash end
    if type(base.data) == "table" then return base.data.model or base.data.hash end
    return nil
end

local function build_mods(mods_block)
    local mods = {}
    if type(mods_block) ~= "table" then return mods end
    for name, value in pairs(mods_block) do
        if name == "Toggles" then
            if type(value) == "table" then
                for toggle_name, toggle_on in pairs(value) do
                    local slot = TOGGLE_SLOTS[toggle_name]
                    if slot ~= nil then mods["_" .. slot] = toggle_on and true or false end
                end
            end
        else
            local toggle_slot = TOGGLE_SLOTS[name]
            if toggle_slot ~= nil then
                mods["_" .. toggle_slot] = value and true or false
            else
                local slot = MOD_SLOTS[name]
                if slot ~= nil and type(value) == "number" then mods["_" .. slot] = value end
            end
        end
    end
    return mods
end

local function build_custom_color(colors)
    local out = {}
    local primary = colors.Primary
    if type(primary) == "table" and primary.Custom and type(primary["Custom Color"]) == "table" then
        out.r, out.g, out.b = primary["Custom Color"].r, primary["Custom Color"].g, primary["Custom Color"].b
    end
    local secondary = colors.Secondary
    if type(secondary) == "table" and secondary.Custom and type(secondary["Custom Color"]) == "table" then
        out.r2, out.g2, out.b2 = secondary["Custom Color"].r, secondary["Custom Color"].g, secondary["Custom Color"].b
    end
    return out
end

local function build_extras(extras_block)
    if type(extras_block) ~= "table" then return nil end
    local extras = {}
    for _, value in ipairs(extras_block) do
        if type(value) == "number" then extras["_" .. value] = true end
    end
    if next(extras) == nil then return nil end
    return extras
end

local function vehicle_attributes_from(sd)
    local colors = type(sd.Colors) == "table" and sd.Colors or {}
    local vehicle_colors = type(colors.Vehicle) == "table" and colors.Vehicle or {}
    local extra_colors = type(colors.Extras) == "table" and colors.Extras or {}
    local lights = type(sd.Lights) == "table" and sd.Lights or {}
    local neon = type(lights.Neon) == "table" and lights.Neon or {}
    local plate = type(sd["License Plate"]) == "table" and sd["License Plate"] or {}
    local livery = type(sd.Livery) == "table" and sd.Livery or {}
    local neon_enabled = neon.Left or neon.Right or neon.Front or neon.Back

    local attrs = NormalizerShared.vehicle_attributes({
        mods = build_mods(sd.Mods),
        primary = vehicle_colors.Primary,
        secondary = vehicle_colors.Secondary,
        pearlescent = extra_colors.Pearlescent,
        wheel_color = extra_colors.Wheel,
        interior = sd["Interior Color"],
        dashboard = sd["Dashboard Color"],
        custom_color = build_custom_color(colors),
        plate_text = plate.Text,
        plate_type = plate.Type,
        window_tint = sd["Window Tint"],
        bulletproof_tires = sd["Bulletproof Tires"],
        neon = neon_enabled and {
            lights = { left = neon.Left, right = neon.Right, front = neon.Front, back = neon.Back },
            color = neon.Color,
        } or nil,
        wheel_type = sd["Wheel Type"],
        tire_smoke_color = sd["Tire Smoke"],
    })

    attrs.dirt_level = sd["Dirt Level"]
    attrs.paint.color_combo = colors["Color Combo"]
    attrs.paint.fade = colors["Paint Fade"]
    attrs.options.engine_on = sd["Engine Running"]
    attrs.options.radio_loud = sd.RadioLoud
    attrs.options.siren = Util.first_present(lights, "SirenActive", "EmergencyLightsActive")
    attrs.options.headlights_color = lights["Xenon Color"]
    if type(livery.Style) == "number" and livery.Style >= 0 then attrs.livery = livery.Style end
    attrs.extras = build_extras(sd.Extras)
    return attrs
end

local function append_children(result, list, entity_type)
    if type(list) ~= "table" then return end
    for _, item in ipairs(list) do
        local node = {
            type = entity_type,
            hash = item.model or item.hash,
            offset = item.offset or { x = 0, y = 0, z = 0 },
            rotation = item.rotation or { x = 0, y = 0, z = 0 },
            options = {
                bone_index = item.boneIndex or -1,
                is_visible = item.visible ~= false,
                is_invincible = item.godmode,
                has_collision = item.collision ~= false,
            },
        }
        if entity_type == "VEHICLE" then
            node.vehicle_attributes = item.vehicle_attributes or item.vehicleAttributes
        elseif entity_type == "PED" then
            node.ped_attributes = item.ped_attributes or item.pedAttributes
            node.vehicle_seat = Util.first_present(item, "vehicle_seat", "vehicle-seat", "seat")
            if node.vehicle_seat == nil and type(node.ped_attributes) == "table" then node.vehicle_seat = node.ped_attributes.seat end
        elseif entity_type == "OBJECT" then
            node.object_attributes = item.object_attributes or item.objectAttributes or item.object_properties or item.objectProperties
            local object_tint = Util.first_present(item, "object_tint", "objectTint", "tint_index", "tintIndex")
            if object_tint == nil and type(item.options) == "table" then object_tint = item.options.object_tint end
            if object_tint ~= nil then
                node.object_attributes = node.object_attributes or {}
                node.object_attributes.object_tint = object_tint
            end
        end
        result.children[#result.children + 1] = node
    end
end

function JStandNormalizer.normalize(data)
    local result = {
        type = "VEHICLE",
        hash = root_model(data),
        position = (data.always_spawn_at_position and data.position) or data.reference,
        always_spawn_at_position = data.always_spawn_at_position,
        children = {},
        vehicle_attributes = {},
    }

    local base = type(data.base) == "table" and data.base or {}
    local sd = base.savedata
    if type(sd) == "table" then
        result.vehicle_attributes = vehicle_attributes_from(sd)
    end

    append_children(result, data.vehicles, "VEHICLE")
    append_children(result, data.objects, "OBJECT")
    append_children(result, data.peds, "PED")
    return result
end

return JStandNormalizer
