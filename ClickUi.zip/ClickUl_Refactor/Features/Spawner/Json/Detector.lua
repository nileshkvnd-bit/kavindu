local Detector = {}

function Detector.detect(data)
    if type(data) ~= "table" then return "unknown" end
    if data.format == "Cherax Entity" then return "cherax" end
    if data.mods and type(data.mods) == "table" and data["wheel type"] ~= nil then return "lexis" end
    if data["Model Name"] or (data["Wheel Type"] and data["Primary Colour"] ~= nil) then return "stand" end
    if data.type then return "constructor" end
    if data.base or tostring(data.version or ""):match("Jackz Builder") then return "jstand" end
    if type(data.craftlab) == "table" then return "craftlab" end
    return "unknown"
end

return Detector
