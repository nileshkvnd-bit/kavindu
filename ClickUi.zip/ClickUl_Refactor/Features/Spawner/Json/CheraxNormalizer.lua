local CheraxNormalizer = {}

local NormalizerShared = require("ClickUl_Refactor.Features.Spawner.Json.NormalizerShared")

local function convert_mods(source)
    local mods = {}
    if type(source) ~= "table" then return mods end
    for key, value in pairs(source) do
        local slot = tostring(key):match("^mod(%d+)$")
        if slot and type(value) == "table" then
            local index = tonumber(value.index)
            if index and index > 0 then
                mods["_" .. slot] = { mod = index - 1, variation = value.variation and true or false }
            end
        end
    end
    return mods
end

local function convert_extras(source)
    if type(source) ~= "table" then return nil end
    local extras = {}
    for key, value in pairs(source) do
        local id = tostring(key):match("^extra(%d+)$")
        if id then extras["_" .. id] = value and true or false end
    end
    if next(extras) == nil then return nil end
    return extras
end

function CheraxNormalizer.normalize(data)
    if type(data) ~= "table" or data.format ~= "Cherax Entity" then return nil end

    local neon = data.neonKits or {}
    local custom_color = nil
    if data.isPrimaryColorCustom or data.isSecondaryColorCustom then
        custom_color = NormalizerShared.custom_color_pair(
            data.isPrimaryColorCustom and data.customPrimaryColor or nil,
            data.isSecondaryColorCustom and data.customSecondaryColor or nil
        )
    end

    local attrs = NormalizerShared.vehicle_attributes({
        mods = convert_mods(data.mods),
        primary = data.primaryColor,
        secondary = data.secondaryColor,
        pearlescent = data.pearlescentColor,
        wheel_color = data.wheelColor,
        interior = data.interiorColor,
        dashboard = data.dashBoardColor,
        custom_color = custom_color,
        plate_text = data.plateText,
        plate_type = data.plateTextIndex,
        window_tint = data.windowTint,
        bulletproof_tires = data.bulletproofTyres,
        neon = {
            lights = { left = neon.left, right = neon.right, front = neon.front, back = neon.back },
            color = neon.color,
        },
        wheel_type = data.wheelType,
        tire_smoke_color = data.tyreSmokeColor,
    })
    if data.driftTyres ~= nil then attrs.options.drift_tyres = data.driftTyres end
    attrs.extras = convert_extras(data.extras)

    return {
        type = "VEHICLE",
        hash = data.model,
        children = {},
        vehicle_attributes = attrs,
    }
end

return CheraxNormalizer
