local EntityTreeSpawner = require("ClickUl_Refactor.Features.Spawner.Core.EntityTreeSpawner")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")

local OutfitAttachmentSpawner = {}

function OutfitAttachmentSpawner.spawn_many(children, target, settings)
    local attachments = {}
    local ptfx_entities = {}
    local first_error = nil
    for _, child in ipairs(children or {}) do
        local _, err = EntityTreeSpawner.spawn(child, {
            parent_target = target,
            records = attachments,
            ptfx_entities = ptfx_entities,
            settings = settings or {},
            disable_collision = settings and settings.disable_collision,
            spawn_at_player = true,
        })
        if err then
            first_error = err
            break
        end
    end

    if first_error then
        SpawnRegistry.delete_entities(attachments)
        attachments = {}
        ptfx_entities = {}
    end
    return attachments, first_error, ptfx_entities
end

return OutfitAttachmentSpawner
