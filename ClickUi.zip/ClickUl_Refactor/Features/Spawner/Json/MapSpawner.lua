local MapSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Normalizer = require("ClickUl_Refactor.Features.Spawner.Json.Normalizer")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityTreeSpawner = require("ClickUl_Refactor.Features.Spawner.Core.EntityTreeSpawner")

local function resolve_ref_coords(data, ref_coords)
    local explicit = ref_coords or data.position or data.reference
    if explicit then return Util.required_vector3(explicit), "missing_coords" end
    return EntityFactory.player_coords(), nil
end

function MapSpawner.spawn_data(json_data, ref_coords)
    local data = Normalizer.normalize(json_data)
    if not data then return nil, nil, "unsupported_json_format" end

    local settings = Settings.get("json_map")
    if settings.delete_old_map then MapSpawner.delete_all() end

    local ref_error
    ref_coords, ref_error = resolve_ref_coords(data, ref_coords)
    if not ref_coords then return nil, 0, ref_error or "missing_coords" end
    local entities = {}
    local stats = { attempted = 0, spawned = 0, failed = 0 }
    local json_settings = Settings.get("json")
    local root, spawn_error = EntityTreeSpawner.spawn(data, {
        base_coords = ref_coords,
        records = entities,
        record_type = "map",
        map_settings = settings,
        disable_collision = json_settings.disable_collision,
        settings = json_settings,
        continue_on_child_error = true,
        spawn_stats = stats,
    })
    if spawn_error then
        SpawnRegistry.delete_entities(entities)
        return nil, #entities, stats.first_error or spawn_error
    end
    if not root or root == 0 then return nil, #entities, "spawn_failed" end

    if settings.teleport_to_map then
        EntityFactory.teleport_player(ref_coords, true)
    end

    local map_data = {
        entities = entities,
        refCoords = ref_coords,
        attempted = stats.attempted,
        failed = stats.failed,
        first_error = stats.first_error,
    }
    SpawnRegistry.add("json_spawned_maps", map_data)
    return map_data, #entities, stats.first_error
end

function MapSpawner.spawn_file(path, ref_coords)
    local data, err = Fs.read_json_value(path)
    if not data then return nil, 0, err end
    local map_data, count, err = MapSpawner.spawn_data(data, ref_coords)
    if map_data then
        SpawnRegistry.update_last("json_spawned_maps", function(record)
            record.file_path = path
        end)
    end
    return map_data, count, err
end

function MapSpawner.delete(index)
    return SpawnRegistry.delete_entity_record_at("json_spawned_maps", index)
end

function MapSpawner.delete_all()
    return SpawnRegistry.delete_entity_records("json_spawned_maps")
end

function MapSpawner.get_spawned()
    return SpawnRegistry.list("json_spawned_maps")
end

return MapSpawner
