local FileCatalog = require("ClickUl_Refactor.Core.FileCatalog")
local Fs = require("ClickUl_Refactor.Adapters.Fs")

local OutfitFiles = {}

local FORMATS <const> = {
    { key = "json", dir = "JSON Outfits\\", extension = "json", default_folder = "JSON Outfits" },
    { key = "xml", dir = "XML Outfits\\", extension = "xml", default_folder = "XML Outfits" },
}

local catalog = FileCatalog.new({
    root = function() return Fs.join(Fs.root_dir(), "Outfits\\") end,
    formats = FORMATS,
})

function OutfitFiles.refresh()
    return catalog.refresh()
end

function OutfitFiles.ensure_loaded()
    return catalog.ensure_loaded()
end

function OutfitFiles.snapshot()
    return catalog.snapshot()
end

function OutfitFiles.list(format)
    return catalog.list(format)
end

function OutfitFiles.folders(format)
    return catalog.folders(format)
end

function OutfitFiles.tree(format)
    return catalog.tree(format)
end

function OutfitFiles.relative_path(path)
    return catalog.relative_path(path)
end

return OutfitFiles
