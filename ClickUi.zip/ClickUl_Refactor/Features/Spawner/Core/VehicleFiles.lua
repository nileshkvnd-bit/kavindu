local FileCatalog = require("ClickUl_Refactor.Core.FileCatalog")
local Fs = require("ClickUl_Refactor.Adapters.Fs")

local VehicleFiles = {}

local FORMATS <const> = {
    { key = "Lexis", dir = "Lexis\\", extension = "json", default_folder = "Lexis" },
    { key = "Stand", dir = "Stand\\", extension = "txt", default_folder = "Stand" },
    { key = "Cherax", dir = "Cherax\\", extension = "json", default_folder = "Cherax" },
    { key = "Menyoo", dir = "Menyoo\\", extension = "xml", default_folder = "Menyoo" },
    { key = "INI", dir = "INI\\", extension = "ini", default_folder = "INI" },
    { key = "JSON", dir = "Json\\", extension = "json", default_folder = "Json" },
}

local catalog = FileCatalog.new({
    root = function() return Fs.join(Fs.root_dir(), "Vehicles\\") end,
    formats = FORMATS,
})

function VehicleFiles.refresh()
    return catalog.refresh()
end

function VehicleFiles.ensure_loaded()
    return catalog.ensure_loaded()
end

function VehicleFiles.snapshot()
    return catalog.snapshot()
end

function VehicleFiles.list(format)
    return catalog.list(format)
end

function VehicleFiles.folders(format)
    return catalog.folders(format)
end

function VehicleFiles.relative_path(path)
    return catalog.relative_path(path)
end

return VehicleFiles
