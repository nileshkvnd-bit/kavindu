local VehicleRuntime = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")

local records = {}
local thread_id = nil

local function has_persistent_records()
    for _, record in pairs(records) do
        if record.torque_multiplier ~= nil or record.max_speed ~= nil then return true end
    end
    return false
end

local function apply_persistent(vehicle, record)
    if record.torque_multiplier ~= nil then
        Native.call("set_vehicle_cheat_power_increase", vehicle, record.torque_multiplier)
    end
    if record.max_speed ~= nil then Native.call("set_entity_max_speed", vehicle, record.max_speed) end
end

function VehicleRuntime.tick_once()
    local has_persistent = false
    for vehicle, record in pairs(records) do
        if EntityFactory.exists(vehicle) then
            apply_persistent(vehicle, record)
            if record.torque_multiplier ~= nil or record.max_speed ~= nil then has_persistent = true end
        else
            records[vehicle] = nil
        end
    end
    return has_persistent
end

local function ensure_thread()
    if thread_id or not has_persistent_records() then return end

    thread_id = Runtime.create_thread(function()
        if VehicleRuntime.tick_once() then return end

        local current_thread = thread_id
        thread_id = nil
        if current_thread then Runtime.remove_thread(current_thread) end
    end)
end

local function set_number_field(record, source, source_key, record_key, apply)
    local value = tonumber(source[source_key])
    if value == nil then return false end

    value = value + 0.0
    record[record_key] = value
    apply(value)
    return true
end

function VehicleRuntime.apply_modifiers(vehicle, modifiers)
    if not EntityFactory.exists(vehicle) or type(modifiers) ~= "table" then return false end

    local record = records[vehicle] or {}
    local changed = false
    changed = set_number_field(record, modifiers, "top_speed_multiplier", "top_speed_multiplier", function(value)
        Native.call("modify_vehicle_top_speed", vehicle, value)
    end) or changed
    changed = set_number_field(record, modifiers, "torque_multiplier", "torque_multiplier", function(value)
        Native.call("set_vehicle_cheat_power_increase", vehicle, value)
    end) or changed
    changed = set_number_field(record, modifiers, "max_speed", "max_speed", function(value)
        Native.call("set_entity_max_speed", vehicle, value)
    end) or changed
    changed = set_number_field(record, modifiers, "headlight_multiplier", "headlight_multiplier", function(value)
        Native.call("set_vehicle_light_multiplier", vehicle, value)
    end) or changed

    if not changed then return false end

    records[vehicle] = record
    ensure_thread()
    return true
end

function VehicleRuntime.restore_power_modifiers(vehicle)
    local record = records[vehicle]
    Native.call("modify_vehicle_top_speed", vehicle, record and record.top_speed_multiplier or 1.0)
    Native.call("set_vehicle_cheat_power_increase", vehicle, record and record.torque_multiplier or 1.0)
end

function VehicleRuntime.clear_for_entities(entities)
    if type(entities) ~= "table" then return 0 end

    local count = 0
    for _, entity in ipairs(entities) do
        if records[entity] then
            records[entity] = nil
            count = count + 1
        end
    end
    return count
end

function VehicleRuntime.reset()
    records = {}
    if thread_id then Runtime.remove_thread(thread_id) end
    thread_id = nil
end

return VehicleRuntime
