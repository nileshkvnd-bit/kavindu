local VehicleAttributes = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")

local function mod_kit(vehicle)
    Native.call("set_vehicle_mod_kit", vehicle, 0)
end

local function apply_roof_state(vehicle, state)
    local roof_state = tonumber(state)
    if roof_state == nil then return end

    if roof_state == 1 or roof_state == 2 then
        Native.call("raise_convertible_roof", vehicle, roof_state == 2)
        return
    end

    if roof_state == 0 or roof_state == 3 then
        Native.call("lower_convertible_roof", vehicle, roof_state == 0)
    end
end

local function color_channel(color_value, name, index)
    if type(color_value) ~= "table" then return nil end
    return color_value[name] or color_value[index]
end

local function apply_xenon_color(vehicle, value)
    local color_index = Util.to_number(value, nil)
    if color_index == nil or color_index < 0 or color_index > 12 then return end
    VehicleCustomizer.set_xenon_color(vehicle, color_index)
end

local DOOR_INDEX <const> = {
    frontleft = 0, frontright = 1, backleft = 2, backright = 3, hood = 4, trunk = 5, trunk2 = 6,
}
local WINDOW_INDEX <const> = {
    frontleft = 0, frontright = 1, rearleft = 2, rearright = 3, front = 4, rear = 5, midleft = 6, midright = 7,
}

local function apply_doors(vehicle, doors)
    if type(doors) ~= "table" then return end
    if type(doors.broken) == "table" then
        for name, broken in pairs(doors.broken) do
            local index = DOOR_INDEX[name]
            if index and Util.to_boolean(broken) then Native.call("set_vehicle_door_broken", vehicle, index, true) end
        end
    end
    if type(doors.open) == "table" then
        for name, open in pairs(doors.open) do
            local index = DOOR_INDEX[name]
            if index and Util.to_boolean(open) then Native.call("set_vehicle_door_open", vehicle, index, true, true) end
        end
    end
    if doors.lock_status ~= nil then Native.call("set_vehicle_doors_locked", vehicle, Util.to_number(doors.lock_status, 0)) end
end

local function apply_windows(vehicle, windows)
    if type(windows) ~= "table" then return end
    if type(windows.rolled_down) == "table" then
        for name, down in pairs(windows.rolled_down) do
            local index = WINDOW_INDEX[name]
            if index then Native.call(Util.to_boolean(down) and "roll_down_window" or "roll_up_window", vehicle, index) end
        end
    end
    if type(windows.broken) == "table" then
        for name, broken in pairs(windows.broken) do
            local index = WINDOW_INDEX[name]
            if index then Native.call(Util.to_boolean(broken) and "smash_vehicle_window" or "fix_vehicle_window", vehicle, index) end
        end
    end
end

local function apply_tires_burst(vehicle, wheels)
    if type(wheels) ~= "table" or type(wheels.tires_burst) ~= "table" then return end
    for key, burst in pairs(wheels.tires_burst) do
        local index = tonumber(tostring(key):match("_?(%d+)"))
        if index then
            if Util.to_boolean(burst) then
                Native.call("set_vehicle_tyre_burst", vehicle, index, true, 1000.0)
            else
                Native.call("set_vehicle_tyre_fixed", vehicle, index)
            end
        end
    end
end

function VehicleAttributes.apply(vehicle, attrs, settings)
    if not EntityFactory.exists(vehicle) or type(attrs) ~= "table" then return false end
    settings = settings or {}
    mod_kit(vehicle)
    local wheels = type(attrs.wheels) == "table" and attrs.wheels or nil

    if wheels and wheels.wheel_type ~= nil then
        Native.call("set_vehicle_wheel_type", vehicle, Util.to_number(wheels.wheel_type, 0))
    end

    if type(attrs.extras) == "table" then
        for key, value in pairs(attrs.extras) do
            local extra_id = tonumber(tostring(key):match("_(%d+)")) or tonumber(key)
            if extra_id then Native.call("set_vehicle_extra", vehicle, extra_id, not Util.to_boolean(value)) end
        end
    end
    if type(attrs.mods) == "table" then
        for key, mod_data in pairs(attrs.mods) do
            local mod_id = tonumber(tostring(key):match("_(%d+)")) or tonumber(key)
            if mod_id then
                local value = type(mod_data) == "table" and mod_data.mod or mod_data
                if type(value) == "boolean" then
                    Native.call("toggle_vehicle_mod", vehicle, mod_id, value)
                elseif tonumber(value) and tonumber(value) >= -1 then
                    local variation = type(mod_data) == "table" and mod_data.variation or nil
                    local custom_tires = (mod_id == 23 or mod_id == 24) and (Util.to_boolean(variation) or (wheels and Util.to_boolean(wheels.custom_tires)))
                    Native.call("set_vehicle_mod", vehicle, mod_id, tonumber(value), custom_tires and true or false)
                end
            end
        end
    end
    local paint = attrs.paint
    local dirt_level = attrs.dirt_level
    if dirt_level == nil and type(paint) == "table" then dirt_level = paint.dirt_level end
    if dirt_level ~= nil then Native.call("set_vehicle_dirt_level", vehicle, Util.to_number(dirt_level, 0.0) + 0.0) end

    local livery = attrs.livery
    if livery == nil and type(attrs.paint) == "table" then livery = attrs.paint.livery end
    livery = tonumber(livery)
    if livery and livery >= 0 then VehicleCustomizer.set_livery(vehicle, livery) end

    local livery2 = attrs.livery2
    if livery2 == nil and type(attrs.paint) == "table" then livery2 = attrs.paint.livery2 end
    livery2 = tonumber(livery2)
    if livery2 and livery2 >= 0 then Native.call("set_vehicle_livery2", vehicle, livery2) end

    if type(paint) == "table" then
        Native.call("clear_vehicle_custom_primary_colour", vehicle)
        Native.call("clear_vehicle_custom_secondary_colour", vehicle)
        if paint.color_combo ~= nil then
            local combo = Util.to_number(paint.color_combo, -1)
            if combo and combo >= 0 then Native.call("set_vehicle_colour_combination", vehicle, combo) end
        end
        local primary = type(paint.primary) == "number" and paint.primary or nil
        local secondary = type(paint.secondary) == "number" and paint.secondary or nil
        if type(paint.primary) == "table" then
            primary = paint.primary.vehicle_standard_color or primary
            local c = paint.primary.custom_color
            if paint.primary.is_custom and type(c) == "table" then
                local r = color_channel(c, "r", 1)
                local g = color_channel(c, "g", 2)
                local b = color_channel(c, "b", 3)
                if r or g or b then Native.call("set_vehicle_custom_primary_colour", vehicle, r or 0, g or 0, b or 0) end
            end
        end
        if type(paint.secondary) == "table" then
            secondary = paint.secondary.vehicle_standard_color or secondary
            local c = paint.secondary.custom_color
            if paint.secondary.is_custom and type(c) == "table" then
                local r = color_channel(c, "r", 1)
                local g = color_channel(c, "g", 2)
                local b = color_channel(c, "b", 3)
                if r or g or b then Native.call("set_vehicle_custom_secondary_colour", vehicle, r or 0, g or 0, b or 0) end
            end
        end
        if primary or secondary then Native.call("set_vehicle_colours", vehicle, primary or 0, secondary or 0) end
        if type(paint.mod_1) == "table" and paint.mod_1.color_type ~= nil then
            Native.call("set_vehicle_mod_color_1", vehicle, paint.mod_1.color_type, paint.mod_1.color or 0, paint.mod_1.pearlescent or 0)
        end
        if type(paint.mod_2) == "table" and paint.mod_2.color_type ~= nil then
            Native.call("set_vehicle_mod_color_2", vehicle, paint.mod_2.color_type, paint.mod_2.color or 0)
        end
        if type(paint.extra_colors) == "table" then
            Native.call("set_vehicle_extra_colours", vehicle, paint.extra_colors.pearlescent or 0, paint.extra_colors.wheel or 0)
        end
        local interior = Util.first_present(paint, "interior", "interior_color")
        if interior ~= nil then VehicleCustomizer.set_interior_color(vehicle, Util.to_number(interior, 0)) end
        local dashboard = Util.first_present(paint, "dashboard", "dashboard_color")
        if dashboard ~= nil then VehicleCustomizer.set_dashboard_color(vehicle, Util.to_number(dashboard, 0)) end
        if type(paint.vehicle_custom_color) == "table" then
            local c = paint.vehicle_custom_color
            if c.r or c.g or c.b then Native.call("set_vehicle_custom_primary_colour", vehicle, c.r or 0, c.g or 0, c.b or 0) end
            if c.r2 or c.g2 or c.b2 then Native.call("set_vehicle_custom_secondary_colour", vehicle, c.r2 or 0, c.g2 or 0, c.b2 or 0) end
        end
        if settings.apply_paint_fade ~= false and paint.fade ~= nil then Native.call("set_vehicle_enveff_scale", vehicle, (tonumber(paint.fade) or 0) + 0.0) end
    end

    local options = attrs.options
    if type(options) == "table" then
        if options.license_plate_text then Native.call("set_vehicle_number_plate_text", vehicle, tostring(options.license_plate_text)) end
        if options.license_plate_type ~= nil then Native.call("set_vehicle_number_plate_text_index", vehicle, Util.to_number(options.license_plate_type, 0)) end
        if options.window_tint ~= nil then Native.call("set_vehicle_window_tint", vehicle, Util.to_number(options.window_tint, 0)) end
        if options.bulletproof_tires ~= nil then Native.call("set_vehicle_tyres_can_burst", vehicle, not Util.to_boolean(options.bulletproof_tires)) end
        local engine_on = Util.first_present(options, "engine_on", "engine_running")
        if engine_on ~= nil then VehicleCustomizer.set_engine_on(vehicle, Util.to_boolean(engine_on)) end
        if options.radio_loud ~= nil then
            local radio_loud = Util.to_boolean(options.radio_loud)
            Native.call("set_vehicle_radio_loud", vehicle, radio_loud)
            if radio_loud then Native.call("set_vehicle_radio_enabled", vehicle, true) end
        end
        if options.lights_on ~= nil then Native.call("set_vehicle_lights", vehicle, Util.to_boolean(options.lights_on) and 3 or 4) end
        if options.siren ~= nil then Native.call("set_vehicle_siren", vehicle, Util.to_boolean(options.siren)) end
        if options.engine_health ~= nil then
            Native.call("set_vehicle_engine_health", vehicle, Util.to_number(options.engine_health, 1000.0) + 0.0)
        end
        if options.lock_status ~= nil then Native.call("set_vehicle_doors_locked", vehicle, Util.to_number(options.lock_status, 0)) end
        if options.roof_state ~= nil then apply_roof_state(vehicle, options.roof_state) end
        if options.headlight_multiplier ~= nil then Native.call("set_vehicle_light_multiplier", vehicle, Util.to_number(options.headlight_multiplier, 1.0) + 0.0) end
        apply_xenon_color(vehicle, Util.first_present(options, "headlights_color", "headlight_color"))
    end

    if type(attrs.headlights) == "table" then
        apply_xenon_color(vehicle, Util.first_present(attrs.headlights, "headlight_color", "headlights_color", "color"))
    end

    local neon = attrs.neon
    if type(neon) == "table" then
        local lights = neon.lights or {}
        local enabled = { lights.left or lights[1], lights.right or lights[2], lights.front or lights[3], lights.back or lights[4] }
        for i = 0, 3 do
            if enabled[i + 1] ~= nil then Native.call("set_vehicle_neon_enabled", vehicle, i, Util.to_boolean(enabled[i + 1])) end
        end
        if type(neon.color) == "table" then Native.call("set_vehicle_neon_colour", vehicle, neon.color.r or 0, neon.color.g or 0, neon.color.b or 0) end
    end

    if wheels and type(wheels.tire_smoke_color) == "table" then
        if settings.toggle_tire_smoke_mod ~= false then Native.call("toggle_vehicle_mod", vehicle, 20, true) end
        Native.call("set_vehicle_tyre_smoke_color", vehicle, wheels.tire_smoke_color.r or 0, wheels.tire_smoke_color.g or 0, wheels.tire_smoke_color.b or 0)
    end

    apply_doors(vehicle, attrs.doors)
    apply_windows(vehicle, attrs.windows)
    apply_tires_burst(vehicle, wheels)

    local drift = type(options) == "table" and options.drift_tyres or nil
    if drift == nil and wheels then drift = wheels.drift_tires end
    if drift ~= nil then Native.call("set_vehicle_tyres_low_grip", vehicle, Util.to_boolean(drift)) end

    return true
end

function VehicleAttributes.specifies_engine(attrs)
    if type(attrs) ~= "table" then return false end
    return Util.first_present(attrs.options, "engine_on", "engine_running") ~= nil
end

function VehicleAttributes.apply_radio_station(vehicle, attrs)
    if not EntityFactory.exists(vehicle) or type(attrs) ~= "table" then return false end
    local options = attrs.options
    if type(options) ~= "table" or options.radio_station == nil then return false end
    Native.call("set_radio_to_station_index", Util.to_number(options.radio_station, 0))
    return true
end

return VehicleAttributes
