local EntityOptions = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Game = require("ClickUl_Refactor.Adapters.Game")

local function exists(entity)
    return Game.entity_exists(entity)
end

local function set_gravity(entity, has_gravity)
    Native.call("set_entity_has_gravity", entity, has_gravity)
    if Native.call("is_entity_a_vehicle", entity) then Native.call("set_vehicle_gravity", entity, has_gravity) end
end

function EntityOptions.enter_load_state(entity)
    if not exists(entity) then return false end
    Native.call("set_entity_dynamic", entity, false)
    Native.call("freeze_entity_position", entity, true)
    return true
end

function EntityOptions.restore_load_state(entity, data)
    if not exists(entity) then return false end
    data = data or {}
    if data.has_gravity ~= nil then set_gravity(entity, data.has_gravity) end
    if data.is_dynamic ~= nil then Native.call("set_entity_dynamic", entity, data.is_dynamic) end
    if data.is_frozen ~= nil then Native.call("freeze_entity_position", entity, data.is_frozen) end
    return true
end

function EntityOptions.set_collision(entity, has_collision, keep_physics)
    if not exists(entity) then return false end
    Native.call("set_entity_collision", entity, has_collision, keep_physics and true or false)
    return true
end

function EntityOptions.apply(entity, options)
    if not exists(entity) or type(options) ~= "table" then return false end

    if options.is_visible ~= nil then Native.call("set_entity_visible", entity, options.is_visible, false) end
    if options.is_invincible ~= nil then Native.call("set_entity_invincible", entity, options.is_invincible) end
    if options.has_collision ~= nil then Native.call("set_entity_collision", entity, options.has_collision, true) end
    if options.is_frozen ~= nil then Native.call("freeze_entity_position", entity, options.is_frozen) end
    if options.has_gravity ~= nil then set_gravity(entity, options.has_gravity) end
    if options.alpha ~= nil then
        local alpha = tonumber(options.alpha) or 255
        if alpha >= 255 then
            Native.call("reset_entity_alpha", entity)
        else
            Native.call("set_entity_alpha", entity, alpha, false)
        end
    end
    if options.is_on_fire then Native.call("start_entity_fire", entity) end
    if type(options.quaternion) == "table" then
        local q = options.quaternion
        Native.call("set_entity_quaternion", entity,
            (q.X or q.x or 0.0) + 0.0, (q.Y or q.y or 0.0) + 0.0,
            (q.Z or q.z or 0.0) + 0.0, (q.W or q.w or 1.0) + 0.0)
    elseif type(options.rotation) == "table" then
        local r = options.rotation
        Native.call("set_entity_rotation", entity,
            (r.Pitch or r.x or 0.0) + 0.0, (r.Roll or r.y or 0.0) + 0.0,
            (r.Yaw or r.z or 0.0) + 0.0, 2, true)
    end
    local lod_dist = options.lod_dist
    if lod_dist == nil then lod_dist = options.lod_distance end
    if lod_dist ~= nil then Native.call("set_entity_lod_dist", entity, tonumber(lod_dist) or 0) end
    if options.max_health ~= nil then Native.call("set_entity_max_health", entity, tonumber(options.max_health) or 100) end
    if options.health ~= nil then Native.call("set_entity_health", entity, tonumber(options.health) or 100) end
    if options.max_speed ~= nil then Native.call("set_entity_max_speed", entity, (tonumber(options.max_speed) or 0) + 0.0) end
    if options.is_only_damaged_by_player ~= nil then
        Native.call("set_entity_only_damaged_by_player", entity, options.is_only_damaged_by_player)
    end

    local has_proofs = options.proofs or options.is_bullet_proof ~= nil or options.is_fire_proof ~= nil
        or options.is_explosion_proof ~= nil or options.is_collision_proof ~= nil or options.is_melee_proof ~= nil
        or options.is_steam_proof ~= nil or options.is_drown_proof ~= nil
    if has_proofs then
        local p = options.proofs or {}
        local bullet = options.is_bullet_proof
        local fire = options.is_fire_proof
        local explosion = options.is_explosion_proof
        local collision = options.is_collision_proof
        local melee = options.is_melee_proof
        local steam = options.is_steam_proof
        local drown = options.is_drown_proof
        if bullet == nil then bullet = p.bullet or false end
        if fire == nil then fire = p.fire or false end
        if explosion == nil then explosion = p.explosion or false end
        if collision == nil then collision = p.collision or false end
        if melee == nil then melee = p.melee or false end
        if steam == nil then steam = p.steam or false end
        if drown == nil then drown = p.drown or false end
        Native.call("set_entity_proofs", entity, bullet, fire, explosion, collision, melee, steam, false, drown)
    end

    if options.is_dynamic ~= nil then Native.call("set_entity_dynamic", entity, options.is_dynamic and true or false) end
    if options.is_scorched ~= nil then Native.call("set_entity_render_scorched", entity, options.is_scorched and true or false) end
    if options.has_special_physics and Native.call("is_entity_an_object", entity) then
        Native.call("set_object_physics_params", entity,
            (tonumber(options.weight) or 0.0) + 0.0, 0.0, 0.0, 0.0, 0.0,
            (tonumber(options.gravity) or 0.0) + 0.0, 0.0, 0.0, 0.0, 0.0,
            (tonumber(options.buoyancy) or 0.0) + 0.0)
    end
    if options.is_light_on == true and Native.call("is_entity_a_vehicle", entity) then
        Native.call("set_vehicle_siren", entity, true)
        Native.call("set_vehicle_has_muted_sirens", entity, true)
        Native.call("set_entity_lights", entity, false)
        Native.call("trigger_siren_audio", entity)
        Native.call("set_siren_bypass_mp_driver_check", entity, true)
    end

    return true
end

return EntityOptions
