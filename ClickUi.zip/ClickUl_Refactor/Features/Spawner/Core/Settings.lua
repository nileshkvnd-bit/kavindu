local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local Settings = {}

local BASE_VEHICLE_SETTINGS <const> = {
    delete_old_vehicle = true,
    vehicle_god_mode = false,
    vehicle_engine_on = true,
    spawn_plane_in_air = false,
    random_color = false,
    random_livery = false,
    upgraded_vehicle = false,
    max_performance = false,
    clean_vehicle = true,
    bulletproof_tires = false,
    keep_velocity = false,
    in_vehicle = true,
    radio_off = false,
    use_preset = false,
    saved_vehicle_use_preset = false,
    primary_color = 216,
    secondary_color = 216,
    pearlescent_id = 216,
    wheel_color_id = 216,
    xenon_color = 10,
    neon_color = 10,
    wheel_type = 10,
    wheel_index = 129,
    custom_tires = false,
    tire_smoke_color = 11,
    window_tint = 1,
    plate_type = 7,
    plate_text = "",
    horn_id = 47,
}

local function vehicle_settings(extra)
    local result = Util.copy_table(BASE_VEHICLE_SETTINGS)
    if type(extra) == "table" then Util.merge_into(result, extra) end
    return result
end

local defaults = {
    vehicle = vehicle_settings({ use_preset = true }),
    json = vehicle_settings({
        disable_collision = false,
        force_custom_tires = false,
        apply_paint_fade = true,
    }),
    json_map = {
        teleport_to_map = true,
        delete_old_map = true,
        entity_god_mode = false,
        spawn_frozen = false,
        apply_proofs = true,
    },
    ini = vehicle_settings({
        disable_collision = false,
    }),
    menyoo = vehicle_settings({
        disable_collision = false,
        enable_ptfx = true,
    }),
    menyoo_map = {
        teleport_to_map = true,
        delete_old_map = true,
        entity_god_mode = false,
        spawn_frozen = false,
        apply_proofs = true,
    },
    json_outfit = {
        delete_old_outfit = true,
        preview_outfit = false,
        spawn_mode = 2,
        disable_collision = false,
        apply_head_features = false,
    },
    menyoo_outfit = {
        delete_old_outfit = true,
        preview_outfit = false,
        spawn_mode = 2,
        disable_collision = false,
        apply_components = true,
        apply_props = true,
        apply_decals = true,
        apply_damage_packs = true,
        apply_attachments = true,
        apply_head_features = false,
    },
}

local current = Util.copy_table(defaults)
local loaded = false
local storage = nil

Settings.OUTFIT_SPAWN_MODE = {
    SPAWN_PED = 1,
    APPLY_TO_PLAYER = 2,
    CHANGE_PLAYER_MODEL = 3,
}

local function section_ref(section)
    Settings.load()
    local value = current[section]
    assert(type(value) == "table", "unknown spawner settings section: " .. tostring(section))
    return value
end

local function queue_save()
    if not storage then return end
    storage.set_section("Spawner", Util.copy_table(current))
    storage.save()
end

local function reset_current()
    current = Util.copy_table(defaults)
    loaded = true
    storage.set_section("Spawner", Util.copy_table(current))
end

function Settings.load()
    if loaded then return true end
    local data = Util.copy_table(defaults)
    local decoded = storage and storage.get_section("Spawner") or nil
    if type(decoded) == "table" then Util.merge_into(data, decoded) end
    current = data
    loaded = true
    return true
end

function Settings.bind_storage(settings_module)
    storage = settings_module
    loaded = false
    Settings.load()
    assert(type(storage.register_reset_handler) == "function", "settings storage reset handler API is required")
    storage.register_reset_handler("Spawner", reset_current)
    queue_save()
    return true
end

function Settings.get_defaults()
    return Util.copy_table(defaults)
end

function Settings.get(section)
    return Util.copy_table(section_ref(section))
end

function Settings.update(section, values)
    assert(type(values) == "table", "spawner settings update requires table values")
    local target = section_ref(section)
    Util.merge_into(target, values)
    queue_save()
    return Util.copy_table(target)
end

function Settings.reset(section)
    Settings.load()
    if section then
        assert(type(defaults[section]) == "table", "unknown spawner settings section: " .. tostring(section))
        current[section] = Util.copy_table(defaults[section])
        queue_save()
        return Util.copy_table(current[section])
    end
    current = Util.copy_table(defaults)
    queue_save()
    return Util.copy_table(current)
end

return Settings
