local SpawnRegistry = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local VehicleRuntime = require("ClickUl_Refactor.Features.Spawner.Core.VehicleRuntime")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")

local data = {
    spawned_vehicles = {},
    json_spawned_entities = {},
    saved_spawned_entities = {},
    json_spawned_maps = {},
    json_spawned_outfits = {},
    ini_spawned_entities = {},
    menyoo_spawned_entities = {},
    menyoo_spawned_maps = {},
    menyoo_spawned_outfits = {},
    ptfx_handles = {},
    task_sequences = {},
}

local function state_list(name)
    local records = data[name]
    assert(type(records) == "table", "unknown spawner state list: " .. tostring(name))
    return records
end

local function snapshot_list(name)
    return Util.copy_table(state_list(name))
end

local function set_list(name, records)
    assert(type(data[name]) == "table", "unknown spawner state list: " .. tostring(name))
    data[name] = records or {}
end

local function clear_list(name)
    set_list(name, {})
end

local function add_record(name, record)
    local records = state_list(name)
    records[#records + 1] = record
    return record
end

local function remove_record(name, index)
    local records = state_list(name)
    if not index or index < 1 or index > #records then return nil end
    return table.remove(records, index)
end

local function entity_handle(value)
    if type(value) == "table" then return value.handle or value.entity or value.vehicle or value.spawned_ped end
    return value
end

local function entity_handles_from_list(entities)
    if type(entities) ~= "table" then return nil end

    local handles = {}
    for _, value in ipairs(entities) do
        local handle = entity_handle(value)
        if handle and handle ~= 0 then handles[#handles + 1] = handle end
    end
    return handles
end

local entity_set_from_list <const> = function(entities)
    local handles = entity_handles_from_list(entities)
    if not handles then return nil end

    local entity_set = {}
    for _, handle in ipairs(handles) do
        entity_set[handle] = true
    end
    return entity_set
end

function SpawnRegistry.snapshot()
    return Util.copy_table(data)
end

function SpawnRegistry.list(name)
    return snapshot_list(name)
end

function SpawnRegistry.add(name, record)
    return add_record(name, record)
end

local function clear_vehicle_runtime_for_entities(entities)
    return VehicleRuntime.clear_for_entities(entities) or 0
end

local function clear_attachments_for_entities(entities)
    return Attachment.clear_for_entities(entities) or 0
end

local function clear_task_sequences_for_entities(entities)
    if #(state_list("task_sequences") or {}) == 0 then return 0 end
    return require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Runner").clear_for_entities(entities) or 0
end

function SpawnRegistry.clear_runtime_for_entities(entities)
    clear_task_sequences_for_entities(entities)
    SpawnRegistry.stop_ptfx_for_entities(entities)
    clear_vehicle_runtime_for_entities(entities)
    clear_attachments_for_entities(entities)
end

function SpawnRegistry.delete_entities(entities, on_complete)
    local handles = entity_handles_from_list(entities)
    SpawnRegistry.clear_runtime_for_entities(handles)
    return EntityFactory.delete_many(handles, on_complete)
end

function SpawnRegistry.delete_entity(entity)
    if not entity or entity == 0 then return false end
    SpawnRegistry.clear_runtime_for_entities({ entity })
    return EntityFactory.delete(entity)
end

function SpawnRegistry.add_ptfx(entity, handle)
    return add_record("ptfx_handles", {
        entity = entity,
        handle = handle,
    })
end

function SpawnRegistry.stop_ptfx_records(stop_handle)
    local stopper = stop_handle or require("ClickUl_Refactor.Features.Spawner.Core.Ptfx").stop_handle
    local count = 0
    local handles = state_list("ptfx_handles")
    for _, item in ipairs(handles) do
        if stopper and item.handle and item.handle ~= 0 then
            count = count + (stopper(item.handle, item.entity, item) or 0)
        end
    end
    clear_list("ptfx_handles")
    return count
end

function SpawnRegistry.stop_ptfx_for_entities(entities)
    if #(state_list("ptfx_handles") or {}) == 0 then return 0 end
    local stopper = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx").stop_handle
    local entity_set = entity_set_from_list(entities)
    if not stopper or not entity_set then return 0 end

    local count = 0
    local remaining = {}
    for _, item in ipairs(state_list("ptfx_handles")) do
        if entity_set[item.entity] and item.handle and item.handle ~= 0 then
            count = count + (stopper(item.handle, item.entity, item) or 0)
        else
            remaining[#remaining + 1] = item
        end
    end
    set_list("ptfx_handles", remaining)
    return count
end

function SpawnRegistry.stop_ptfx_handle(entity, handle)
    local stopper = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx").stop_handle
    if not stopper or not handle or handle == 0 then return 0 end

    local count = 0
    local remaining = {}
    for _, item in ipairs(state_list("ptfx_handles")) do
        if item.handle == handle and (entity == nil or item.entity == entity) then
            count = count + (stopper(item.handle, item.entity, item) or 0)
        else
            remaining[#remaining + 1] = item
        end
    end
    set_list("ptfx_handles", remaining)
    return count
end

function SpawnRegistry.add_task_sequence(record)
    return add_record("task_sequences", record)
end

function SpawnRegistry.task_sequences()
    return snapshot_list("task_sequences")
end

function SpawnRegistry.task_sequence_records()
    return state_list("task_sequences")
end

function SpawnRegistry.replace_task_sequences(records)
    set_list("task_sequences", records)
    return records
end

function SpawnRegistry.clear_task_sequences()
    clear_list("task_sequences")
end

function SpawnRegistry.delete_entity_list(name)
    local entities = state_list(name)
    local count = SpawnRegistry.delete_entities(entities)
    clear_list(name)
    return count
end

function SpawnRegistry.update_last(name, update_record)
    local records = state_list(name)
    local record = records[#records]
    if not record then return false end
    update_record(record)
    return true
end

function SpawnRegistry.update_records(name, update_record)
    local count = 0
    for _, record in ipairs(state_list(name)) do
        update_record(record)
        count = count + 1
    end
    return count
end

function SpawnRegistry.delete_record_at(name, index, delete_record)
    local record = remove_record(name, index)
    if not record then return false end
    delete_record(record)
    return true
end

function SpawnRegistry.delete_records(name, delete_record)
    local count = 0
    local records = state_list(name)
    for _, record in ipairs(records) do
        count = count + (delete_record(record) or 0)
    end
    clear_list(name)
    return count
end

local delete_entity_record <const> = function(record, cleanup_record)
    local on_complete = cleanup_record and function() cleanup_record(record) end or nil
    return SpawnRegistry.delete_entities(record.entities, on_complete)
end

function SpawnRegistry.delete_entity_record_at(name, index, cleanup_record)
    return SpawnRegistry.delete_record_at(name, index, function(record)
        delete_entity_record(record, cleanup_record)
    end)
end

function SpawnRegistry.delete_entity_records(name, cleanup_record)
    return SpawnRegistry.delete_records(name, function(record)
        return delete_entity_record(record, cleanup_record)
    end)
end

local delete_outfit_record <const> = function(outfit)
    local entities = {}
    for _, entity in ipairs(outfit.attachments or {}) do
        entities[#entities + 1] = entity
    end
    if outfit.spawned_ped then entities[#entities + 1] = outfit.spawned_ped end
    SpawnRegistry.clear_runtime_for_entities(entities)
    if outfit.ptfx_entities then SpawnRegistry.stop_ptfx_for_entities(outfit.ptfx_entities) end
    EntityFactory.delete_many(entities)
    return 1
end

function SpawnRegistry.delete_outfit_at(name, index)
    return SpawnRegistry.delete_record_at(name, index, delete_outfit_record)
end

function SpawnRegistry.delete_outfits(name)
    return SpawnRegistry.delete_records(name, delete_outfit_record)
end

return SpawnRegistry
