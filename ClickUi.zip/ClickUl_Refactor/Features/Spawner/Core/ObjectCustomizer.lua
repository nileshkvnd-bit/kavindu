local ObjectCustomizer = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")

function ObjectCustomizer.apply(object, props)
    if not EntityFactory.exists(object) or type(props) ~= "table" then return false end
    if props.object_tint ~= nil then
        Native.set_object_tint_index(object, Util.to_number(props.object_tint, 0))
    end
    return true
end

return ObjectCustomizer
