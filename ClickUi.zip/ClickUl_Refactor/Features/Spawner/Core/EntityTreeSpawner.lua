local EntityTreeSpawner = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local VehicleAttributes = require("ClickUl_Refactor.Features.Spawner.Core.VehicleAttributes")
local PedAppearance = require("ClickUl_Refactor.Features.Spawner.Core.PedAppearance")
local ObjectCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.ObjectCustomizer")

local MAX_DEPTH <const> = 32

local function parent_coords(parent, base_coords)
    local coords = base_coords or EntityFactory.player_coords()
    if parent and parent ~= 0 then return EntityFactory.entity_coords(parent) or coords end
    return coords
end

local function world_position(node, parent, base_coords)
    local base = parent_coords(parent, base_coords)
    local offset = Util.vector3(node.offset)
    if node.position then
        local position = Util.required_vector3(node.position)
        if not position then return nil, offset, "missing_coords" end
        return position, offset
    end
    if not base then return nil, offset, "missing_coords" end
    return {
        x = base.x + offset.x,
        y = base.y + offset.y,
        z = base.z + offset.z,
    }, offset
end

local function spawn_position(node, parent, config)
    if config.spawn_at_player then
        return EntityFactory.player_coords(), Util.vector3(node.offset)
    end
    return world_position(node, parent, config.base_coords)
end

local function spawn_heading(node, config)
    if config.spawn_heading ~= nil then return config.spawn_heading end
    if config.spawn_at_player then return EntityFactory.player_heading() end
    return Util.rotation(node.world_rotation or node.rotation).z
end

local function build_options(node, config)
    local options = Util.copy_table(node.options or {})
    if config.disable_collision then options.has_collision = false end
    if options.has_collision == nil then options.has_collision = true end
    if options.is_visible == nil then options.is_visible = true end
    if config.map_settings then
        if config.map_settings.entity_god_mode then options.is_invincible = true end
        if config.map_settings.spawn_frozen then options.is_frozen = true end
        if config.map_settings.apply_proofs and node.proofs then options.proofs = node.proofs end
    end
    return options
end

local function record_entity(records, handle, entity_type, record_type)
    if record_type == "map" then
        records[#records + 1] = { handle = handle, type = entity_type }
        return
    end
    records[#records + 1] = handle
end

local function attach_child(node, handle, parent, offset, options, config)
    local attach_target = parent
    if not attach_target or attach_target == 0 then attach_target = config.parent_target end
    if not attach_target or attach_target == 0 then return false end
    local entity_type = tostring(node.type or "OBJECT"):upper()
    local ped_attributes = type(node.ped_attributes) == "table" and node.ped_attributes or {}
    local vehicle_seat = node.vehicle_seat
    if vehicle_seat == nil then vehicle_seat = node["vehicle-seat"] end
    if vehicle_seat == nil then vehicle_seat = node.seat end
    if vehicle_seat == nil then vehicle_seat = ped_attributes.seat end
    if entity_type == "PED" and vehicle_seat ~= nil then
        local seat = Util.to_number(vehicle_seat, nil)
        if seat ~= nil and seat ~= -2 and seat ~= -3 and Attachment.seat_ped_in_vehicle(handle, attach_target, seat) then return true end
    end
    if options.is_attached ~= nil and not Util.to_boolean(options.is_attached) then return false end
    if not (node.offset or node.rotation or options.bone_index) then return false end
    Attachment.attach(handle, attach_target, options.bone_index or -1, offset, Util.rotation(node.rotation), {
        active_collision = options.has_collision ~= false,
        use_soft_pinning = options.use_soft_pinning,
    })
    return true
end

local function apply_attributes(node, handle, entity_type, settings)
    if entity_type == "VEHICLE" and node.vehicle_attributes then
        VehicleAttributes.apply(handle, node.vehicle_attributes, settings)
    elseif entity_type == "PED" and node.ped_attributes then
        PedAppearance.apply_attributes(handle, node.ped_attributes)
    elseif entity_type == "OBJECT" then
        ObjectCustomizer.apply(handle, node.object_attributes or node.options)
    end
end

local function note_model(config, model)
    if model ~= nil and model ~= 0 then config.models_used[model] = true end
end

local function note_attempt(config)
    local stats = config.spawn_stats
    if type(stats) ~= "table" then return end
    stats.attempted = (stats.attempted or 0) + 1
end

local function note_success(config)
    local stats = config.spawn_stats
    if type(stats) ~= "table" then return end
    stats.spawned = (stats.spawned or 0) + 1
end

local function note_failure(config, err)
    local stats = config.spawn_stats
    if type(stats) ~= "table" then return end
    stats.failed = (stats.failed or 0) + 1
    if stats.first_error then return end
    stats.first_error = tostring(err or "spawn_failed")
end

local function spawn_ped_held_props(ped, attrs, config)
    if type(attrs) ~= "table" then return end
    local animation = attrs.animation
    if type(animation) ~= "table" or type(animation.props) ~= "table" then return end
    local coords = EntityFactory.entity_coords(ped) or EntityFactory.player_coords()
    for _, entry in ipairs(animation.props) do
        local model = entry.prop or entry.model or entry.hash
        local handle = model and EntityFactory.spawn_object(model, coords, false, true) or 0
        if handle and handle ~= 0 then
            note_model(config, EntityFactory.hash_model(model))
            local placement = entry.placement or {}
            local offset = { x = Util.to_float(placement[1], 0.0), y = Util.to_float(placement[2], 0.0), z = Util.to_float(placement[3], 0.0) }
            local rotation = { x = Util.to_float(placement[4], 0.0), y = Util.to_float(placement[5], 0.0), z = Util.to_float(placement[6], 0.0) }
            Attachment.attach(handle, ped, entry.bone, offset, rotation, {
                active_collision = false,
                rot_order = 1,
                use_basic_attach_if_ped = true,
                use_soft_pinning = true,
            })
            record_entity(config.records, handle, "OBJECT", config.record_type)
        end
    end
end

local function spawn_node(node, parent, depth, config)
    if depth > MAX_DEPTH then
        note_failure(config, "max_depth")
        return nil, "max_depth"
    end
    if type(node) ~= "table" then
        note_failure(config, "invalid_node")
        return nil, "invalid_node"
    end

    local entity_type = tostring(node.type or "OBJECT"):upper()
    if entity_type == "PARTICLE" then
        local target = parent or config.parent_target
        local particle = node.particle_attributes or node
        if node.particle_attributes and (node.offset ~= nil or node.rotation ~= nil) then
            particle = Util.copy_table(node.particle_attributes)
            if particle.offset == nil then particle.offset = node.offset end
            if particle.rotation == nil then particle.rotation = node.rotation end
        end
        local handle = Ptfx.start_looped(target, particle)
        if handle and handle > 0 and type(config.ptfx_entities) == "table" and target and target ~= 0 then
            config.ptfx_entities[#config.ptfx_entities + 1] = target
        end
        return nil
    end

    note_attempt(config)
    local position, offset, position_error = spawn_position(node, parent, config)
    if position_error then
        note_failure(config, position_error)
        return nil, position_error
    end
    local model = node.hash or node.model
    note_model(config, model)
    local handle, spawn_error = EntityFactory.spawn_by_type(entity_type, model, position, spawn_heading(node, config), nil, true)
    if not handle or handle == 0 then
        note_failure(config, spawn_error or "spawn_failed")
        return nil, spawn_error or "spawn_failed"
    end
    note_success(config)

    record_entity(config.records, handle, entity_type, config.record_type)

    local options = build_options(node, config)
    EntityOptions.apply(handle, options)
    if not attach_child(node, handle, parent, offset, options, config) then
        EntityFactory.set_coords_no_offset(handle, position)
    end
    apply_attributes(node, handle, entity_type, config.settings)
    if entity_type == "PED" then
        spawn_ped_held_props(handle, node.ped_attributes, config)
    end

    if type(node.children) == "table" then
        for _, child in ipairs(node.children) do
            local _, err = spawn_node(child, handle, depth + 1, config)
            if err and not config.continue_on_child_error then return nil, err end
        end
    end

    return handle
end

function EntityTreeSpawner.spawn(root, config)
    config = config or {}
    assert(type(config.records) == "table", "entity tree records table required")
    config.record_type = config.record_type or "handle"

    local owns_models = config.models_used == nil
    config.models_used = config.models_used or {}

    local handle, spawn_error = spawn_node(root, config.parent, config.depth or 1, config)

    if owns_models then
        EntityTreeSpawner.release_models(config.models_used)
    end
    return handle, spawn_error
end

function EntityTreeSpawner.release_models(models_used)
    if type(models_used) ~= "table" then return end
    for model in pairs(models_used) do
        EntityFactory.release_model(model)
    end
end

return EntityTreeSpawner
