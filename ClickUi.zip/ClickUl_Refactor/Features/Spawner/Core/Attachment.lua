local Attachment = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local attachment_records = {}

local function exists(entity)
    return Game.entity_exists(entity)
end

local function copy_vector3(value)
    value = Util.vector3(value)
    return { x = value.x, y = value.y, z = value.z }
end

local function copy_rotation(value)
    value = Util.rotation(value)
    return { x = value.x, y = value.y, z = value.z }
end

local function copy_options(options)
    local result = {}
    for key, value in pairs(options or {}) do
        result[key] = value
    end
    return result
end

local function current_attachment_parent(child, record)
    if Native.call("is_entity_attached", child) == false then return nil end

    local attached = Native.call("get_entity_attached_to", child)
    if attached and attached ~= 0 then return attached end

    return record.parent
end

local function clear_for_entity(entity)
    if not attachment_records[entity] then return 0 end
    attachment_records[entity] = nil
    return 1
end

local function first_free_vehicle_seat(vehicle)
    local max_passengers = Util.to_number(Native.call("get_vehicle_max_number_of_passengers", vehicle), 0)
    for seat = -1, max_passengers - 1 do
        if Native.call("is_vehicle_seat_free", vehicle, seat, 0) then return seat end
    end
    return -1
end

function Attachment.attach(child, parent, bone, offset, rotation, options)
    if not exists(child) or not exists(parent) then return false end
    options = options or {}
    offset = Util.vector3(offset)
    rotation = Util.rotation(rotation)
    local attachment_bone = bone or -1
    if type(attachment_bone) == "number" then attachment_bone = math.floor(attachment_bone) end
    local native_bone = attachment_bone

    local parent_is_ped = Native.call("is_entity_a_ped", parent)
    if native_bone ~= -1 and parent_is_ped and options.bone_is_index ~= true then
        local bone_index = Native.call("get_ped_bone_index", parent, native_bone)
        if bone_index and bone_index ~= -1 then native_bone = bone_index end
    end

    local use_basic_attach_if_ped = options.use_basic_attach_if_ped == true
    local active_collision = options.active_collision
    if active_collision == nil then active_collision = false end

    Native.attach_entity_to_entity(
        child,
        parent,
        native_bone,
        offset,
        rotation,
        options.detach_when_dead or false,
        options.use_soft_pinning or false,
        active_collision,
        use_basic_attach_if_ped,
        options.rot_order or 2,
        options.attach_offset_is_relative ~= false,
        options.mark_as_no_longer_needed or false
    )

    Native.call("process_entity_attachments", parent)

    if options.dynamic ~= nil then
        Native.call("set_entity_dynamic", child, options.dynamic and true or false)
    end

    attachment_records[child] = {
        parent = parent,
        bone = attachment_bone,
        offset = copy_vector3(offset),
        rotation = copy_rotation(rotation),
        options = copy_options(options),
    }
    return true
end

function Attachment.seat_ped_in_vehicle(ped, vehicle, seat)
    if not exists(ped) or not exists(vehicle) then return false end
    if not Native.call("is_entity_a_vehicle", vehicle) then return false end
    Native.call("set_ped_into_vehicle", ped, vehicle, Attachment.vehicle_seat(vehicle, seat, -1))
    return true
end

function Attachment.vehicle_seat(vehicle, seat, default_seat)
    local resolved = Util.to_number(seat, default_seat or -1)
    if resolved == -2 then return first_free_vehicle_seat(vehicle) end
    return resolved
end

function Attachment.update_rotation(child, rotation, is_relative)
    local record = attachment_records[child]
    if not record then return false end
    if not exists(child) then
        clear_for_entity(child)
        return false
    end

    local parent = current_attachment_parent(child, record)
    if not parent or not exists(parent) then
        clear_for_entity(child)
        return false
    end

    local next_rotation = copy_rotation(rotation)
    if is_relative then
        next_rotation.x = record.rotation.x + next_rotation.x
        next_rotation.y = record.rotation.y + next_rotation.y
        next_rotation.z = record.rotation.z + next_rotation.z
    end

    return Attachment.attach(child, parent, record.bone, record.offset, next_rotation, record.options)
end

function Attachment.clear(entity)
    return clear_for_entity(entity)
end

function Attachment.clear_for_entities(entities)
    if type(entities) ~= "table" then return 0 end
    local count = 0
    for _, entity in ipairs(entities) do
        count = count + clear_for_entity(entity)
    end
    return count
end

function Attachment.reset()
    attachment_records = {}
end

return Attachment
