local Ptfx = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local MENYOO_LOP_HANDLE <const> = -1
local MENYOO_LOP_INTERVAL_MS <const> = 810
local SKEL_HEAD <const> = 0x796e
local math_random <const> = math.random
local string_lower <const> = string.lower

local exists <const> = function(entity)
    return Game.entity_exists(entity)
end

local stop_handle <const> = function(handle, entity, record)
    if record and type(record.stop) == "function" then return record.stop() or 0 end
    if not handle or handle <= 0 then return 0 end
    Native.call("stop_particle_fx_looped", handle, false)
    return 1
end

local function first_value(...)
    for index = 1, select("#", ...) do
        local value = select(index, ...)
        if value ~= nil and value ~= "" then return value end
    end
    return nil
end

local function asset_name(ptfx)
    return first_value(ptfx.asset, ptfx.asset_name, ptfx.AssetName, ptfx.ptfx_asset, ptfx.ptfxLopAsset)
end

local function effect_name(ptfx)
    return first_value(ptfx.effect, ptfx.effect_name, ptfx.EffectName, ptfx.ptfx_effect, ptfx.ptfxLopEffect)
end

local function offset_value(ptfx)
    return ptfx.offset or ptfx.RelativePosition or ptfx.relative_position
end

local function rotation_value(ptfx)
    return ptfx.rotation or ptfx.RelativeRotation or ptfx.relative_rotation
end

local function scale_value(ptfx)
    return first_value(ptfx.scale, ptfx.Scale)
end

local function bone_index(ptfx)
    local value = first_value(ptfx.bone_index, ptfx.bone, ptfx.BoneIndex)
    if value == nil then return -1 end
    return Util.to_number(value, -1)
end

local function normalized_channel(value, default, unit)
    local number = Util.to_number(value, default)
    if number == nil then return default end
    if unit == "byte" then
        number = number / 255.0
    elseif unit ~= "unit" and number > 1.0 then
        number = number / 255.0
    end
    if number < 0.0 then return 0.0 end
    if number > 1.0 then return 1.0 end
    return number
end

local function color_value(ptfx)
    local source = ptfx.Colour or ptfx.Color
    local unit = source and "byte" or nil
    if type(source) ~= "table" then
        source = ptfx.color or ptfx.colour
        unit = first_value(ptfx.color_unit, ptfx.colorUnit, ptfx.colour_unit, ptfx.colourUnit, source and source.unit, source and source.Unit)
    end
    if unit == "bytes" or unit == "255" then unit = "byte" end
    if unit == "normalized" or unit == "float" then unit = "unit" end

    if type(source) ~= "table" then
        if ptfx.alpha == nil and ptfx.Alpha == nil then return nil end
        source = {}
    end

    local alpha_unit = unit
    if ptfx.Alpha ~= nil and unit == nil then alpha_unit = "byte" end

    return {
        r = normalized_channel(first_value(source.r, source.R, source[1]), 1.0, unit),
        g = normalized_channel(first_value(source.g, source.G, source[2]), 1.0, unit),
        b = normalized_channel(first_value(source.b, source.B, source[3]), 1.0, unit),
        a = normalized_channel(first_value(source.a, source.A, source.alpha, source.Alpha, ptfx.alpha, ptfx.Alpha), 1.0, alpha_unit),
    }
end

local function particle_shape(ptfx)
    return {
        asset = asset_name(ptfx),
        effect = effect_name(ptfx),
        offset = Util.vector3(offset_value(ptfx)),
        rotation = Util.rotation(rotation_value(ptfx)),
        scale = Util.to_number(scale_value(ptfx), 1.0) + 0.0,
        bone_index = bone_index(ptfx),
        color = color_value(ptfx),
        alpha_source = first_value(ptfx.alpha_source, ptfx.alphaSource, ptfx.AlphaSource),
    }
end

local function apply_looped_color(handle, color)
    if not color then return end
    Native.call("set_particle_fx_looped_colour", handle, color.r, color.g, color.b, false)
    Native.call("set_particle_fx_looped_alpha", handle, color.a)
end

local function apply_non_looped_color(color, alpha_source)
    if not color then return end

    local alpha = color.a
    if alpha_source and string_lower(tostring(alpha_source)) == "blue" then
        alpha = color.b
    end

    Native.call("set_particle_fx_non_looped_colour", color.r, color.g, color.b)
    Native.call("set_particle_fx_non_looped_alpha", alpha)
end

local function ped_bone_index(entity, bone)
    if not bone or bone < 0 then return bone end
    return Native.call("get_ped_bone_index", entity, bone) or bone
end

local function looped_bone_index(entity, bone)
    if not bone or bone < 0 then return bone end
    if not Native.call("is_entity_a_ped", entity) then return bone end
    return ped_bone_index(entity, bone)
end

local function start_networked_non_looped(entity, particle)
    if particle.bone_index >= 0 and Native.call("is_entity_a_ped", entity) then
        local bone = ped_bone_index(entity, particle.bone_index)
        return Native.call("start_networked_particle_fx_non_looped_on_ped_bone", particle.effect, entity, particle.offset.x, particle.offset.y, particle.offset.z, particle.rotation.x, particle.rotation.y, particle.rotation.z, bone, particle.scale, false, false, false) == true
    end

    return Native.call("start_networked_particle_fx_non_looped_on_entity", particle.effect, entity, particle.offset.x, particle.offset.y, particle.offset.z, particle.rotation.x, particle.rotation.y, particle.rotation.z, particle.scale, false, false, false) == true
end

local function random_scale()
    return 0.76 + (math_random() * 0.64)
end

local function random_color()
    Native.call("set_particle_fx_non_looped_colour", math_random(), math_random(), math_random())
end

local function vector_or_zero(value)
    return {
        x = Util.to_number(value and value.x, 0.0),
        y = Util.to_number(value and value.y, 0.0),
        z = Util.to_number(value and value.z, 0.0),
    }
end

local function trigger_menyoo_lop(entity, particle)
    if not exists(entity) then return false end
    if not Request.particle(particle.asset) then return false end

    Native.call("use_particle_fx_asset", particle.asset)
    random_color()

    local scale = random_scale()
    if Native.call("is_entity_a_ped", entity) then
        if Native.call("is_ped_a_player", entity) and entity ~= EntityFactory.player_ped() then
            local coords = vector_or_zero(Native.call("get_ped_bone_coords", entity, SKEL_HEAD, 0.0, 0.0, 0.0))
            local rotation = vector_or_zero(Native.call("get_entity_rotation", entity, 2))
            return Native.call("start_networked_particle_fx_non_looped_at_coord", particle.effect, coords.x, coords.y, coords.z, rotation.x, rotation.y, rotation.z, scale, false, false, false, false) == true
        end

        return Native.call("start_networked_particle_fx_non_looped_on_ped_bone", particle.effect, entity, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, ped_bone_index(entity, SKEL_HEAD), scale, false, false, false) == true
    end

    return Native.call("start_networked_particle_fx_non_looped_on_entity", particle.effect, entity, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, scale, false, false, false) == true
end

function Ptfx.stop_handle(handle, entity, record)
    return stop_handle(handle, entity, record)
end

function Ptfx.start_looped(entity, ptfx)
    if not exists(entity) or type(ptfx) ~= "table" then return 0 end
    local particle = particle_shape(ptfx)
    if not particle.asset or not particle.effect then return 0 end
    if not Request.particle(particle.asset) then return 0 end

    Native.call("use_particle_fx_asset", particle.asset)

    local handle

    if particle.bone_index >= 0 then
        local bone = looped_bone_index(entity, particle.bone_index)
        handle = Native.call("start_particle_fx_looped_on_entity_bone", particle.effect, entity, particle.offset.x, particle.offset.y, particle.offset.z, particle.rotation.x, particle.rotation.y, particle.rotation.z, bone, particle.scale, false, false, false) or 0
    else
        handle = Native.call("start_particle_fx_looped_on_entity", particle.effect, entity, particle.offset.x, particle.offset.y, particle.offset.z, particle.rotation.x, particle.rotation.y, particle.rotation.z, particle.scale, false, false, false) or 0
    end

    if handle and handle > 0 then
        SpawnRegistry.add_ptfx(entity, handle)
        apply_looped_color(handle, particle.color)
    end

    return handle or 0
end

function Ptfx.start_menyoo_lop(entity, ptfx)
    if not exists(entity) or type(ptfx) ~= "table" then return 0 end
    local particle = particle_shape(ptfx)

    SpawnRegistry.stop_ptfx_handle(entity, MENYOO_LOP_HANDLE)
    if not particle.asset or not particle.effect then return 0 end

    local running = true
    local next_tick = 0
    local thread_id = nil
    local record = SpawnRegistry.add_ptfx(entity, MENYOO_LOP_HANDLE) or {}
    local function remove_thread()
        local current_thread = thread_id
        thread_id = nil
        record.thread_id = nil
        if current_thread then Runtime.remove_thread(current_thread) end
    end

    thread_id = Runtime.create_thread(function()
        if not running or not exists(entity) then
            running = false
            remove_thread()
            return
        end

        local now = Runtime.get_tick_count()
        if now < next_tick then return end

        trigger_menyoo_lop(entity, particle)
        next_tick = now + MENYOO_LOP_INTERVAL_MS
    end)

    record.kind = "menyoo_lop"
    record.thread_id = thread_id
    record.stop = function()
        if not running and not thread_id then return 0 end
        running = false
        remove_thread()
        return 1
    end
    return thread_id or MENYOO_LOP_HANDLE
end

function Ptfx.start_non_looped(entity, ptfx)
    if not exists(entity) or type(ptfx) ~= "table" then return false end
    local particle = particle_shape(ptfx)
    if not particle.asset or not particle.effect then return false end
    if not Request.particle(particle.asset) then return false end

    Native.call("use_particle_fx_asset", particle.asset)
    apply_non_looped_color(particle.color, particle.alpha_source)

    return start_networked_non_looped(entity, particle)
end

function Ptfx.stop_all()
    return SpawnRegistry.stop_ptfx_records()
end

return Ptfx
