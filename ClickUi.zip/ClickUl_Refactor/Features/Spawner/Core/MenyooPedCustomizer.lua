local MenyooPedCustomizer = {}

local Hash = require("ClickUl_Refactor.Adapters.Hash")
local Native = require("ClickUl_Refactor.Adapters.Native")
local PedAppearance = require("ClickUl_Refactor.Features.Spawner.Core.PedAppearance")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local UINT32 <const> = 0x100000000
local FREEMODE_MALE <const> = 0x705E61F2
local FREEMODE_FEMALE <const> = 0x9C9EFFD8
local FREEMODE_MODELS <const> = {
    [FREEMODE_MALE] = true,
    [FREEMODE_FEMALE] = true,
}

local function unsigned_hash(value)
    if value == nil then return nil end
    local hash = tonumber(value)
    if not hash then return nil end
    if hash < 0 then hash = hash + UINT32 end
    return hash
end

local function resolve_model_hash(model)
    if model == nil then return nil end
    if type(model) == "number" then return unsigned_hash(model) end

    local text = Util.trim(model)
    if not text or text == "" then return nil end

    local hex = text:match("^0[xX]([%da-fA-F]+)$")
    if hex then return unsigned_hash(tonumber(hex, 16)) end

    local numeric = tonumber(text)
    if numeric then return unsigned_hash(numeric) end
    return unsigned_hash(Hash.joaat(text))
end

local function should_apply_saved_head_features(attrs)
    local value = attrs.head_features_was_in_array
    if value == nil then return true end
    return Util.to_boolean(value)
end

function MenyooPedCustomizer.supports_head_features(model)
    return FREEMODE_MODELS[resolve_model_hash(model)] == true
end

local function target_model(ped, model)
    return model or Native.call("get_entity_model", ped)
end

local function apply_head_features(ped, attrs, model)
    if not MenyooPedCustomizer.supports_head_features(target_model(ped, model)) then return end

    local blend = attrs.blend_data
    if type(blend) == "table" then
        Native.call("set_ped_head_blend_data", ped, 0, 0, 0, 1, 1, 1, 0.0, 0.0, 0.0, false)
        PedAppearance.apply_blend(ped, blend)
    end

    if not should_apply_saved_head_features(attrs) then return end

    if attrs.hair_color then
        Native.call("set_ped_hair_tint", ped, Util.to_number(attrs.hair_color, 0), Util.to_number(attrs.hair_highlight_color, 0))
    end
    if attrs.eye_color then
        Native.call("set_head_blend_eye_color", ped, Util.to_number(attrs.eye_color, 0))
    end
    PedAppearance.apply_facial_features(ped, attrs.facial_features)
    PedAppearance.apply_head_overlays(ped, attrs.head_overlays)
end

function MenyooPedCustomizer.apply_outfit(ped, attrs, model, opts)
    if type(attrs) ~= "table" then return false end
    opts = opts or {}
    local apply_decals = opts.decals ~= false
    local apply_components = opts.components ~= false
    local apply_props = opts.props ~= false
    local apply_damage_packs = opts.damage_packs ~= false
    local apply_head = opts.head_features ~= false

    if Util.to_boolean(attrs.has_short_height) then
        Native.call("set_ped_config_flag", ped, 223, true)
    end

    if apply_head then
        apply_head_features(ped, attrs, model)

        local facial_mood = attrs.facial_mood
        if facial_mood and facial_mood ~= "" then
            Native.call("set_facial_idle_anim_override", ped, facial_mood, "")
        end
    end

    local clear_decals = attrs.clear_decal_overlays
    if clear_decals == nil or Util.to_boolean(clear_decals) then
        Native.call("clear_ped_decorations", ped)
    end
    if apply_decals then PedAppearance.apply_decorations(ped, attrs.decorations) end

    if apply_components then PedAppearance.apply_components(ped, attrs.components) end

    if apply_props then
        Native.call("clear_all_ped_props", ped)
        PedAppearance.apply_props(ped, attrs.props)
    end

    Native.call("clear_ped_blood_damage", ped)
    Native.call("reset_ped_visible_damage", ped)
    if apply_damage_packs then PedAppearance.apply_damage_packs(ped, attrs.damage_packs) end
    return true
end

function MenyooPedCustomizer.apply_runtime_properties(ped, attrs, model, opts)
    PedAppearance.apply_menyoo_runtime_defaults(ped)
    if type(attrs) ~= "table" then return true end
    opts = opts or {}

    return PedAppearance.apply_attributes(ped, attrs, {
        apply_head_features = MenyooPedCustomizer.supports_head_features(target_model(ped, model)),
        apply_components = opts.components ~= false,
        apply_props = opts.props ~= false,
        apply_decorations = opts.decals ~= false,
        apply_damage_packs = opts.damage_packs ~= false,
    })
end

return MenyooPedCustomizer
