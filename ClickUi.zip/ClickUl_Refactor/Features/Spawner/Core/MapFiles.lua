local FileCatalog = require("ClickUl_Refactor.Core.FileCatalog")
local Fs = require("ClickUl_Refactor.Adapters.Fs")

local MapFiles = {}

local FORMATS <const> = {
    { key = "json", dir = "Json\\", extension = "json", default_folder = "Json" },
    { key = "menyoo", dir = "Menyoo\\", extension = "xml", default_folder = "Menyoo" },
}

local catalog = FileCatalog.new({
    root = function() return Fs.join(Fs.root_dir(), "Maps\\") end,
    formats = FORMATS,
})

function MapFiles.refresh()
    return catalog.refresh()
end

function MapFiles.ensure_loaded()
    return catalog.ensure_loaded()
end

function MapFiles.snapshot()
    return catalog.snapshot()
end

function MapFiles.list(format)
    return catalog.list(format)
end

function MapFiles.folders(format)
    return catalog.folders(format)
end

function MapFiles.relative_path(path)
    return catalog.relative_path(path)
end

return MapFiles
