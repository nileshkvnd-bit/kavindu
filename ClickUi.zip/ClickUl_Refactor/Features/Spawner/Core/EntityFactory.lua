local EntityFactory = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Hash = require("ClickUl_Refactor.Adapters.Hash")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Teleport = require("ClickUl_Refactor.Core.Teleport")
local EntityDelete = require("ClickUl_Refactor.Core.EntityDelete")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local joaat_hash <const> = Hash.joaat

local UINT32 <const> = 0x100000000
local math_tointeger <const> = math.tointeger
local math_floor <const> = math.floor

local function to_model_hash(value)
    if value < 0 then value = value + UINT32 end
    return math_tointeger(value) or math_floor(value)
end

local hash_model <const> = function(model)
    if type(model) == "number" then return to_model_hash(model) end
    if model == nil then return nil end
    local numeric = tonumber(model)
    if numeric then return to_model_hash(numeric) end
    return joaat_hash(tostring(model))
end

function EntityFactory.hash_model(model)
    return hash_model(model)
end

function EntityFactory.player_ped()
    return Players.local_ped()
end

function EntityFactory.player_id()
    return Players.local_id()
end

function EntityFactory.player_coords()
    return Players.local_coords()
end

function EntityFactory.entity_coords(entity)
    if not entity or entity == 0 then return nil end
    return Util.required_vector3(Native.get_entity_coords(entity, true))
end

function EntityFactory.forward_spawn_coords(distance)
    local ped = Players.local_ped()
    if not ped or ped == 0 then return nil end

    local coords = Players.local_coords()
    local dir = Util.required_vector3(Native.get_entity_forward_vector(ped))
    if not coords or not dir then return nil end
    distance = distance or 5.0
    return {
        x = coords.x + dir.x * distance,
        y = coords.y + dir.y * distance,
        z = coords.z,
    }
end

function EntityFactory.player_heading()
    return Players.local_heading()
end

function EntityFactory.request_model(model)
    return Request.model(hash_model(model))
end

function EntityFactory.exists(entity)
    return Game.entity_exists(entity)
end

function EntityFactory.release_model(model)
    local hash = hash_model(model)
    if not hash or hash == 0 then return false end
    Native.call("set_model_as_no_longer_needed", hash)
    return true
end

function EntityFactory.spawn_vehicle(model, coords, heading, keep_model_loaded)
    local hash = hash_model(model)
    if not hash or hash == 0 then return 0, "invalid_model" end
    coords = Util.required_vector3(coords)
    if not coords then return 0, "missing_coords" end
    if not EntityFactory.request_model(hash) then return 0, "model_request_failed" end
    local vehicle = Native.call("create_vehicle", hash, coords.x, coords.y, coords.z, (heading or 0.0) + 0.0, true, false, 0) or 0
    if vehicle ~= 0 and not keep_model_loaded then Native.call("set_model_as_no_longer_needed", hash) end
    if vehicle ~= 0 then return vehicle, nil end
    return 0, "spawn_failed"
end

function EntityFactory.spawn_ped(model, coords, heading, ped_type, keep_model_loaded)
    local hash = hash_model(model)
    if not hash or hash == 0 then return 0, "invalid_model" end
    coords = Util.required_vector3(coords)
    if not coords then return 0, "missing_coords" end
    if not EntityFactory.request_model(hash) then return 0, "model_request_failed" end
    local ped = Native.call("create_ped", ped_type or 26, hash, coords.x, coords.y, coords.z, (heading or 0.0) + 0.0, true, false) or 0
    if ped ~= 0 and not keep_model_loaded then Native.call("set_model_as_no_longer_needed", hash) end
    if ped ~= 0 then return ped, nil end
    return 0, "spawn_failed"
end

function EntityFactory.spawn_object(model, coords, is_dynamic, keep_model_loaded)
    local hash = hash_model(model)
    if not hash or hash == 0 then return 0, "invalid_model" end
    coords = Util.required_vector3(coords)
    if not coords then return 0, "missing_coords" end
    if not EntityFactory.request_model(hash) then return 0, "model_request_failed" end
    local obj = Native.call("create_object", hash, coords.x, coords.y, coords.z, true, false, is_dynamic ~= false) or 0
    if obj ~= 0 and not keep_model_loaded then Native.call("set_model_as_no_longer_needed", hash) end
    if obj ~= 0 then return obj, nil end
    return 0, "spawn_failed"
end

function EntityFactory.spawn_by_type(entity_type, model, coords, heading, is_dynamic, keep_model_loaded)
    entity_type = tostring(entity_type or "OBJECT"):upper()
    if entity_type == "VEHICLE" or entity_type == "VEH" or entity_type == "2" then
        return EntityFactory.spawn_vehicle(model, coords, heading, keep_model_loaded)
    end
    if entity_type == "PED" or entity_type == "1" then
        return EntityFactory.spawn_ped(model, coords, heading, 26, keep_model_loaded)
    end
    return EntityFactory.spawn_object(model, coords, is_dynamic, keep_model_loaded)
end

function EntityFactory.clear_internal_collisions(handles)
    if type(handles) ~= "table" then return false end
    local list = {}
    for _, value in ipairs(handles) do
        local handle = type(value) == "table" and (value.handle or value.entity) or value
        if handle and handle ~= 0 and EntityFactory.exists(handle) then list[#list + 1] = handle end
    end
    for i = 1, #list do
        for j = i + 1, #list do
            Native.call("set_entity_no_collision_entity", list[i], list[j], false)
        end
    end
    return true
end

function EntityFactory.delete(entity)
    return EntityDelete.delete(entity)
end

function EntityFactory.delete_many(list, on_complete)
    return EntityDelete.delete_many(list, on_complete)
end

function EntityFactory.put_player_in_vehicle(vehicle)
    local ped = EntityFactory.player_ped()
    if not ped or ped == 0 or not vehicle or vehicle == 0 then return false end
    Native.call("set_ped_into_vehicle", ped, vehicle, -1)
    return true
end

function EntityFactory.player_vehicle()
    return Players.local_vehicle()
end

function EntityFactory.teleport(entity, coords, clear_area)
    if not entity or entity == 0 then return false end
    coords = Util.required_vector3(coords)
    if not coords then return false end
    Native.call("set_entity_coords", entity, coords.x, coords.y, coords.z, false, false, false, clear_area and true or false)
    return true
end

function EntityFactory.set_coords_no_offset(entity, coords)
    if not entity or entity == 0 then return false end
    coords = Util.required_vector3(coords)
    if not coords then return false end
    Native.call("set_entity_coords_no_offset", entity, coords.x, coords.y, coords.z, true, true, true)
    return true
end

function EntityFactory.player_teleport_target()
    return Players.local_teleport_target()
end

function EntityFactory.teleport_player(coords, clear_area)
    return Teleport.to_coords(coords, { clear_area = clear_area and true or false, record_undo = false })
end

function EntityFactory.set_player_model(model)
    local hash = hash_model(model)
    if not hash or hash == 0 then return nil, "invalid_model" end
    if not EntityFactory.request_model(hash) then return nil, "model_request_failed" end
    Native.call("set_player_model", EntityFactory.player_id(), hash)
    Native.call("set_model_as_no_longer_needed", hash)
    local ped = EntityFactory.player_ped()
    if ped and ped ~= 0 then return ped, nil end
    return nil, "missing_player_ped"
end

function EntityFactory.swap_player_to_ped(ped)
    if not ped or ped == 0 then return false end
    Native.call("change_player_ped", EntityFactory.player_id(), ped, true, true)
    return true
end

function EntityFactory.set_heading_to_player(entity)
    if not EntityFactory.exists(entity) then return false end
    local heading = EntityFactory.player_heading()
    if not heading then return false end
    Native.call("set_entity_heading", entity, heading)
    return true
end

function EntityFactory.raise_aircraft_if_needed(entity, amount)
    if not EntityFactory.exists(entity) then return false end
    local model = Native.get_entity_model(entity)
    if Native.call("is_this_model_a_plane", model) or Native.call("is_this_model_a_heli", model) then
        local coords = Util.required_vector3(Native.get_entity_coords(entity, true))
        if not coords then return false end
        Native.call("set_entity_coords", entity, coords.x, coords.y, coords.z + (amount or 50.0), false, false, false, false)
        return true
    end
    return false
end

function EntityFactory.yield(ms)
    Runtime.yield(ms)
end

return EntityFactory
