local EntityBounds = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local ModelDims = require("ClickUl_Refactor.Core.ModelDims")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

function EntityBounds.model_dimensions(model)
    if not model then return nil end

    local dims = ModelDims.read(model)
    return {
        minimum = Util.vector3(dims.min),
        maximum = Util.vector3(dims.max),
    }
end

function EntityBounds.model_dim1(model)
    local dimensions = EntityBounds.model_dimensions(model)
    if not dimensions then return nil end

    return {
        x = math.abs(dimensions.minimum.x),
        y = math.abs(dimensions.minimum.y),
        z = math.abs(dimensions.minimum.z),
    }
end

function EntityBounds.entity_dim1(entity)
    local model = Native.call("get_entity_model", entity)
    return EntityBounds.model_dim1(model)
end

return EntityBounds
