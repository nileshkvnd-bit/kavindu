local VehicleCustomizer = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")

local VISUAL_MOD_SLOTS <const> = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 14, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37 }

local VEHICLE_CLASS_HELI <const> = 15
local VEHICLE_CLASS_PLANE <const> = 16

local function exists(vehicle)
    return EntityFactory.exists(vehicle)
end

local function mod_kit(vehicle)
    Native.call("set_vehicle_mod_kit", vehicle, 0)
end

local function current_extra_colors(vehicle)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local pearlescent_ptr = Pointer.int()
    local wheel_ptr = Pointer.int()
    local ok, err = xpcall(function()
        Native.call("get_vehicle_extra_colours", vehicle, pearlescent_ptr, wheel_ptr)
    end, debug.traceback)
    if not ok then
        Pointer.free(pearlescent_ptr)
        Pointer.free(wheel_ptr)
        error(err, 0)
    end

    local pearlescent = Pointer.int_value(pearlescent_ptr, 0)
    local wheel = Pointer.int_value(wheel_ptr, 0)
    Pointer.free(pearlescent_ptr)
    Pointer.free(wheel_ptr)
    return pearlescent, wheel
end

function VehicleCustomizer.set_vehicle_color(vehicle, primary, secondary)
    if not exists(vehicle) then return false end
    Native.call("clear_vehicle_custom_primary_colour", vehicle)
    Native.call("clear_vehicle_custom_secondary_colour", vehicle)
    Native.call("set_vehicle_colours", vehicle, primary or 0, secondary or 0)
    return true
end

function VehicleCustomizer.set_custom_primary_color(vehicle, r, g, b)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_custom_primary_colour", vehicle, r or 0, g or 0, b or 0)
    return true
end

function VehicleCustomizer.set_custom_secondary_color(vehicle, r, g, b)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_custom_secondary_colour", vehicle, r or 0, g or 0, b or 0)
    return true
end

function VehicleCustomizer.set_extra_colors(vehicle, pearlescent, wheel)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_extra_colours", vehicle, pearlescent or 0, wheel or 0)
    return true
end

function VehicleCustomizer.set_interior_color(vehicle, color_id)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_extra_colour_5", vehicle, color_id or 0)
    return true
end

function VehicleCustomizer.set_dashboard_color(vehicle, color_id)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_extra_colour_6", vehicle, color_id or 0)
    return true
end

function VehicleCustomizer.set_pearlescent_color(vehicle, color_id)
    if not exists(vehicle) then return false end
    local _, wheel = current_extra_colors(vehicle)
    Native.call("set_vehicle_extra_colours", vehicle, color_id or 0, wheel or 0)
    return true
end

function VehicleCustomizer.set_wheel_color(vehicle, color_id)
    if not exists(vehicle) then return false end
    local pearlescent = current_extra_colors(vehicle)
    Native.call("set_vehicle_extra_colours", vehicle, pearlescent or 0, color_id or 0)
    return true
end

function VehicleCustomizer.set_engine_on(vehicle, on)
    if not exists(vehicle) then return false end
    on = on and true or false
    Native.call("set_vehicle_engine_on", vehicle, on, true, false)
    if on then
        Native.call("set_vehicle_keep_engine_on_when_abandoned", vehicle, true)
        local class = Native.call("get_vehicle_class", vehicle)
        if class == VEHICLE_CLASS_HELI or class == VEHICLE_CLASS_PLANE then
            Native.call("set_heli_blades_full_speed", vehicle)
        end
    end
    return true
end

function VehicleCustomizer.set_radio_enabled(vehicle, enabled)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_radio_enabled", vehicle, enabled and true or false)
    return true
end

function VehicleCustomizer.set_invincible(vehicle, enabled)
    if not exists(vehicle) then return false end
    Native.call("set_entity_invincible", vehicle, enabled and true or false)
    return true
end

function VehicleCustomizer.set_driver_visible(vehicle, visible)
    if not exists(vehicle) then return false end
    local driver = Native.call("get_ped_in_vehicle_seat", vehicle, -1, 0)
    if not driver or driver == 0 then return false end
    Native.call("set_entity_visible", driver, visible and true or false, false)
    return true
end

function VehicleCustomizer.clean_vehicle(vehicle)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_dirt_level", vehicle, 0.0)
    return true
end

function VehicleCustomizer.set_bulletproof_tires(vehicle, enabled)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_tyres_can_burst", vehicle, not (enabled and true or false))
    return true
end

function VehicleCustomizer.get_livery_count(vehicle)
    if not exists(vehicle) then return 0 end
    mod_kit(vehicle)
    return Native.call("get_num_vehicle_mods", vehicle, 48) or 0
end

function VehicleCustomizer.set_livery(vehicle, livery_index)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("set_vehicle_mod", vehicle, 48, livery_index, false)
    return true
end

function VehicleCustomizer.set_all_neons_enabled(vehicle, enabled)
    if not exists(vehicle) then return false end
    for i = 0, 3 do Native.call("set_vehicle_neon_enabled", vehicle, i, enabled and true or false) end
    return true
end

function VehicleCustomizer.set_neon_color(vehicle, r, g, b)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_neon_colour", vehicle, r or 0, g or 0, b or 0)
    return true
end

function VehicleCustomizer.set_xenon_enabled(vehicle, enabled)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("toggle_vehicle_mod", vehicle, 22, enabled and true or false)
    return true
end

function VehicleCustomizer.set_xenon_color(vehicle, color_index)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("toggle_vehicle_mod", vehicle, 22, true)
    Native.call("set_vehicle_xenon_light_color_index", vehicle, color_index or 0)
    return true
end

function VehicleCustomizer.set_wheel_type(vehicle, wheel_type)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("set_vehicle_wheel_type", vehicle, wheel_type or 0)
    return true
end

function VehicleCustomizer.set_front_wheels(vehicle, wheel_index, custom_tires)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    local index = wheel_index or -1
    if index >= 0 then
        local count = Native.call("get_num_vehicle_mods", vehicle, 23) or 0
        if index >= count then index = count - 1 end
    end
    Native.call("set_vehicle_mod", vehicle, 23, index, custom_tires and true or false)
    return true
end

function VehicleCustomizer.set_tire_smoke_enabled(vehicle, enabled)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("toggle_vehicle_mod", vehicle, 20, enabled and true or false)
    return true
end

function VehicleCustomizer.set_tire_smoke_color(vehicle, r, g, b)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    Native.call("toggle_vehicle_mod", vehicle, 20, true)
    Native.call("set_vehicle_tyre_smoke_color", vehicle, r or 0, g or 0, b or 0)
    return true
end

function VehicleCustomizer.set_window_tint(vehicle, tint_level)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_window_tint", vehicle, tint_level or 0)
    return true
end

function VehicleCustomizer.set_plate_type(vehicle, plate_type)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_number_plate_text_index", vehicle, plate_type or 0)
    return true
end

function VehicleCustomizer.set_plate_text(vehicle, text)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_number_plate_text", vehicle, tostring(text or ""))
    return true
end

function VehicleCustomizer.set_horn(vehicle, horn_id)
    if not exists(vehicle) or not horn_id or horn_id < 0 then return false end
    mod_kit(vehicle)
    local max_horns = Native.call("get_num_vehicle_mods", vehicle, 14) or 0
    if max_horns > 0 and horn_id >= max_horns then horn_id = max_horns - 1 end
    Native.call("set_vehicle_mod", vehicle, 14, horn_id, false)
    return true
end

function VehicleCustomizer.get_speed(vehicle)
    if not exists(vehicle) then return 0 end
    return Native.call("get_entity_speed", vehicle) or 0
end

function VehicleCustomizer.set_forward_speed(vehicle, speed)
    if not exists(vehicle) or not speed or speed <= 0 then return false end
    Native.call("set_vehicle_forward_speed", vehicle, speed + 0.0)
    return true
end

function VehicleCustomizer.apply_max_performance(vehicle)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    for _, slot in ipairs({ 11, 12, 13, 15, 16 }) do
        local count = Native.call("get_num_vehicle_mods", vehicle, slot)
        if count and count > 0 then Native.call("set_vehicle_mod", vehicle, slot, count - 1, false) end
    end
    Native.call("toggle_vehicle_mod", vehicle, 18, true)
    Native.call("set_vehicle_tyres_can_burst", vehicle, false)
    return true
end

function VehicleCustomizer.apply_max_visual_upgrades(vehicle)
    if not exists(vehicle) then return false end
    mod_kit(vehicle)
    for _, slot in ipairs(VISUAL_MOD_SLOTS) do
        local count = Native.call("get_num_vehicle_mods", vehicle, slot)
        if count and count > 0 then Native.call("set_vehicle_mod", vehicle, slot, count - 1, false) end
    end

    local livery_mod_count = Native.call("get_num_vehicle_mods", vehicle, 48) or 0
    if livery_mod_count > 0 then
        Native.call("set_vehicle_mod", vehicle, 48, livery_mod_count - 1, false)
    end
    return true
end

return VehicleCustomizer
