local WorldMarker = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityBounds = require("ClickUl_Refactor.Features.Spawner.Core.EntityBounds")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local WorldProbe = require("ClickUl_Refactor.Features.Spawner.Core.WorldMarkerProbe")
local WorldText = require("ClickUl_Refactor.Features.Spawner.Core.WorldMarkerText")

local DRAW_DISTANCE_SQUARED <const> = 6400.0
local NAME_DISTANCE_SQUARED <const> = 1600.0
local MARKERS_VISIBLE <const> = false
local active_records = {}
local teleport_locked = false

local function number_field(value, ...)
    if type(value) ~= "table" then return 0.0 end
    for i = 1, select("#", ...) do
        local key = select(i, ...)
        if value[key] ~= nil then return Util.to_number(value[key], 0.0) end
    end
    return 0.0
end

local function marker_bool(value)
    return value == true
end

local function color_value(marker)
    local value = marker and marker.Colour or {}
    return {
        r = Util.to_number(value.r or value.R, 0),
        g = Util.to_number(value.g or value.G, 0),
        b = Util.to_number(value.b or value.B, 0),
        a = Util.to_number(value.a or value.A, 0),
    }
end

local function color_equal(left, right)
    left = color_value(left)
    right = color_value(right)
    return left.r == right.r
        and left.g == right.g
        and left.b == right.b
        and left.a == right.a
end

local function vector_equal(left, right)
    return number_field(left, "x", "X") == number_field(right, "x", "X")
        and number_field(left, "y", "Y") == number_field(right, "y", "Y")
        and number_field(left, "z", "Z") == number_field(right, "z", "Z")
end

local function marker_static_position(marker)
    return {
        x = number_field(marker, "X", "x"),
        y = number_field(marker, "Y", "y"),
        z = number_field(marker, "Z", "z"),
    }
end

local function marker_static_rotation(marker)
    return {
        x = number_field(marker, "RotX", "rotX", "x", "X"),
        y = number_field(marker, "RotY", "rotY", "y", "Y"),
        z = number_field(marker, "RotZ", "rotZ", "z", "Z"),
    }
end

local function attachment_equal(left, right)
    left = left or {}
    right = right or {}
    return number_field(left, "InitHandle") == number_field(right, "InitHandle")
        and vector_equal(left.Offset, right.Offset)
        and vector_equal(left.Rotation, right.Rotation)
end

function WorldMarker.same_marker(left, right)
    if type(left) ~= "table" or type(right) ~= "table" then return false end
    if tostring(left.Name or "") ~= tostring(right.Name or "") then return false end
    if Util.to_number(left.Type, 0) ~= Util.to_number(right.Type, 0) then return false end
    if Util.to_number(left.Scale, 0.0) ~= Util.to_number(right.Scale, 0.0) then return false end
    if marker_bool(left.ShowName) ~= marker_bool(right.ShowName) then return false end
    if marker_bool(left.RotateContinuously) ~= marker_bool(right.RotateContinuously) then return false end
    if marker_bool(left.AllowVehicles) ~= marker_bool(right.AllowVehicles) then return false end
    if not color_equal(left, right) then return false end

    local left_attachment = left.Attachment
    local right_attachment = right.Attachment
    if number_field(left_attachment, "InitHandle") ~= number_field(right_attachment, "InitHandle") then
        if not vector_equal(marker_static_position(left), marker_static_position(right)) then return false end
        if not vector_equal(marker_static_rotation(left), marker_static_rotation(right)) then return false end
    end
    return attachment_equal(left_attachment, right_attachment)
end

local function resolve_handle(init_handle, handle_map)
    if not init_handle or type(handle_map) ~= "table" then return nil end
    return handle_map[init_handle] or handle_map[tostring(init_handle)]
end

local function resolve_existing_handle(init_handle, handle_map)
    local handle = resolve_handle(init_handle, handle_map)
    if not handle or handle == 0 or not EntityFactory.exists(handle) then return nil end
    return handle
end

local function register_marker_handles(markers)
    local result = {}
    for _, marker in ipairs(markers or {}) do
        local initial = marker and marker.InitialHandle
        if initial and initial ~= 0 then
            result[initial] = marker
            result[tostring(initial)] = marker
        end
    end
    return result
end

local function point_position(point, handle_map, track_last_position)
    local attachment = point and point.Attachment
    local attached_to = attachment and resolve_existing_handle(attachment.InitHandle, handle_map)
    if attached_to then
        local offset = attachment.Offset or {}
        local coords = Native.call(
            "get_offset_from_entity_in_world_coords",
            attached_to,
            Util.to_number(offset.x or offset.X, 0.0),
            Util.to_number(offset.y or offset.Y, 0.0),
            Util.to_number(offset.z or offset.Z, 0.0)
        )
        local position = Util.vector3(coords)
        if track_last_position and position then point._runtime_position = position end
        return position
    end

    if track_last_position and point and point._runtime_position then
        return {
            x = point._runtime_position.x,
            y = point._runtime_position.y,
            z = point._runtime_position.z,
        }
    end

    return {
        x = Util.to_number(point and (point.X or point.x), 0.0),
        y = Util.to_number(point and (point.Y or point.y), 0.0),
        z = Util.to_number(point and (point.Z or point.z), 0.0),
    }
end

local function marker_position(marker, handle_map)
    return point_position(marker, handle_map, true)
end

local function attached_entity(point, handle_map)
    local attachment = point and point.Attachment
    return attachment and resolve_existing_handle(attachment.InitHandle, handle_map) or nil
end

local function marker_rotation(marker, handle_map)
    local result = {
        x = Util.to_number(marker and marker.RotX, 0.0),
        y = Util.to_number(marker and marker.RotY, 0.0),
        z = Util.to_number(marker and marker.RotZ, 0.0),
    }
    local attached_to = attached_entity(marker, handle_map)
    if not attached_to then return result end

    local base = Util.vector3(Native.call("get_entity_rotation", attached_to, 2))
    local attachment = marker.Attachment or {}
    local rotation = attachment.Rotation or {}
    return {
        x = Util.to_number(rotation.x or rotation.X, 0.0),
        y = Util.to_number(rotation.y or rotation.Y, 0.0),
        z = base.z + Util.to_number(rotation.z or rotation.Z, 0.0),
    }
end

local function draw(marker, handle_map, position)
    local color = color_value(marker)
    local scale = Util.to_number(marker.Scale, 1.0)
    position = position or marker_position(marker, handle_map)
    local rotation = marker_rotation(marker, handle_map)
    Native.call(
        "draw_marker",
        Util.to_number(marker.Type, 0),
        position.x,
        position.y,
        position.z,
        0.0,
        0.0,
        0.0,
        rotation.x,
        rotation.y,
        rotation.z,
        scale,
        scale,
        scale,
        color.r,
        color.g,
        color.b,
        color.a,
        false,
        false,
        2,
        marker.RotateContinuously == true,
        "",
        "",
        false
    )
end

local function distance_squared(a, b)
    local dx = a.x - b.x
    local dy = a.y - b.y
    local dz = a.z - b.z
    return dx * dx + dy * dy + dz * dz
end

local function los_name_target(position, camera, scale)
    local dx = position.x - camera.x
    local dy = position.y - camera.y
    local dz = position.z - camera.z
    local distance = math.sqrt(dx * dx + dy * dy + dz * dz)
    if distance <= 0.0 then return position end

    return {
        x = position.x,
        y = position.y - (dy / distance) * scale,
        z = position.z,
    }
end

local function draw_name(marker, position, context)
    if marker.ShowName ~= true or not context.coords then return end
    if distance_squared(context.coords, position) >= NAME_DISTANCE_SQUARED then return end
    local camera = WorldProbe.camera_coords()
    if not camera then return end
    local target = los_name_target(position, camera, Util.to_number(marker.Scale, 1.0))
    if not WorldProbe.clear_los(camera, target) then return end
    WorldText.draw_world(marker.Name, position, {
        font = 7,
        scale_x = 0.3,
        scale_y = 0.3,
        center = true,
        outline = true,
    })
end

local function destination_point(marker, marker_map)
    local destination = marker and marker.Destination
    if type(destination) ~= "table" then return nil end

    local link = destination.LinkInitHandle
    if not link or link == 0 or type(marker_map) ~= "table" then return destination end
    local linked_marker = marker_map[link] or marker_map[tostring(link)]
    return linked_marker or destination
end

local function destination_info(marker, handle_map, marker_map)
    local point = destination_point(marker, marker_map)
    if not point then return nil end

    local coords = point_position(point, handle_map)
    if coords.x == 0.0 and coords.y == 0.0 and coords.z == 0.0 then return nil end

    local heading = Util.to_number(marker.DestinationHeading, 0.0)
    local attached_to = attached_entity(point, handle_map)
    if attached_to then
        heading = Util.vector3(Native.call("get_entity_rotation", attached_to, 2)).z + heading
    end
    return coords, heading
end

local function marker_trigger_radius(marker)
    local scale = Util.to_number(marker and marker.Scale, 1.0)
    if scale <= 0.0 then return 0.0 end
    return scale
end

local function within_marker(position, marker_position_value, marker, extra_radius)
    local radius = marker_trigger_radius(marker) + (extra_radius or 0.0)
    if radius <= 0.0 then return false end
    return distance_squared(position, marker_position_value) < radius * radius
end

function WorldMarker.is_marker_in_range(marker, handle_map, center, radius)
    center = Util.required_vector3(center)
    radius = Util.to_number(radius, 0.0)
    if not marker or not center or radius <= 0.0 then return false end

    local position = marker_position(marker, handle_map)
    return distance_squared(center, position) < radius * radius
end

local function vehicle_check_points(vehicle, coords)
    local points = { coords }
    local dim1 = EntityBounds.entity_dim1(vehicle)
    if not dim1 then return points end

    local half_z = dim1.z / 2.0
    local offsets = {
        { x = 0.0, y = dim1.y, z = -half_z },
        { x = 0.0, y = -dim1.y, z = -half_z },
        { x = dim1.x, y = 0.0, z = -half_z },
        { x = -dim1.x, y = 0.0, z = -half_z },
    }
    for _, offset in ipairs(offsets) do
        points[#points + 1] = Util.vector3(Native.call(
            "get_offset_from_entity_in_world_coords",
            vehicle,
            offset.x,
            offset.y,
            offset.z
        ))
    end
    return points
end

local function build_frame_context(player_coords)
    local vehicle = EntityFactory.player_vehicle()
    local in_vehicle = vehicle ~= nil and vehicle ~= 0

    local vehicle_ctx = nil
    if in_vehicle then
        local vehicle_coords = EntityFactory.entity_coords(vehicle)
        if vehicle_coords then
            vehicle_ctx = {
                entity = vehicle,
                coords = vehicle_coords,
                check_points = vehicle_check_points(vehicle, vehicle_coords),
                is_vehicle = true,
                in_vehicle = true,
            }
        end
    end

    return {
        in_vehicle = in_vehicle,
        vehicle = vehicle_ctx,
        player = {
            entity = EntityFactory.player_ped(),
            coords = player_coords,
            check_points = { player_coords },
            is_vehicle = false,
            in_vehicle = in_vehicle,
        },
    }
end

local function marker_context(marker, frame)
    if marker.AllowVehicles == true and frame.vehicle then return frame.vehicle end
    return frame.player
end

local function context_within_marker(context, position, marker, extra_radius)
    for _, coords in ipairs(context.check_points or {}) do
        if coords and within_marker(coords, position, marker, extra_radius) then return true end
    end
    return false
end

local function record_inside_any_marker(record, frame)
    for _, marker in ipairs(record.markers or {}) do
        local context = marker_context(marker, frame)
        local position = marker_position(marker, record.marker_handle_map)
        if context.coords and context_within_marker(context, position, marker, 0.36) then return true end
    end
    return false
end

local function player_inside_any_marker(frame)
    for record in pairs(active_records) do
        if record_inside_any_marker(record, frame) then return true end
    end
    return false
end

local function teleport_no_offset(entity, destination)
    if not entity or entity == 0 then return false end
    destination = Util.required_vector3(destination)
    if not destination then return false end

    Request.control(entity, false)
    Runtime.yield(20)
    Native.call("set_entity_coords_no_offset", entity, destination.x, destination.y, destination.z, true, true, true)
    return true
end

local function can_trigger_marker(record, marker, position, context, handle_map, marker_map)
    local destination, heading = destination_info(marker, handle_map, marker_map)
    if not destination or not context.coords then return nil end
    if context.in_vehicle and marker.AllowVehicles ~= true then return nil end

    if not context.coords or not context_within_marker(context, position, marker, 0.0) then return nil end

    teleport_locked = true
    return destination, context.entity, context.is_vehicle, heading
end

local function update_marker(record, marker, handle_map, marker_map, frame)
    local position = marker_position(marker, handle_map)
    local context = marker_context(marker, frame)
    if MARKERS_VISIBLE and context.coords and distance_squared(context.coords, position) < DRAW_DISTANCE_SQUARED then
        draw(marker, handle_map, position)
        draw_name(marker, position, context)
    end

    if teleport_locked then return end

    local destination, move_target, is_vehicle, heading = can_trigger_marker(record, marker, position, context, handle_map, marker_map)
    if not destination then return end

    Native.call("do_screen_fade_out", 5)
    teleport_no_offset(move_target, destination)
    Native.call("set_entity_heading", move_target, heading)
    if is_vehicle then VehicleCustomizer.set_forward_speed(move_target, 4.2) end
    Native.call("set_gameplay_cam_relative_heading", 0.0)
    Native.call("set_gameplay_cam_relative_pitch", 0.0, 1.0)
    Runtime.yield(100)
    Native.call("do_screen_fade_in", 300)
end

function WorldMarker.start(record, markers, handle_map)
    if type(record) ~= "table" or type(markers) ~= "table" or #markers == 0 then return nil end
    if record.marker_thread_id then WorldMarker.stop(record) end

    record.markers = markers
    record.marker_handle_map = handle_map or record.marker_handle_map or {}
    record.marker_initial_map = register_marker_handles(markers)
    record.markers_active = true
    record.markers_stopped = false
    active_records[record] = true
    record.marker_thread_id = Runtime.create_thread(function()
        if not record.markers_active then
            WorldMarker.stop(record)
            return
        end

        local player_coords = EntityFactory.player_coords()
        local frame = build_frame_context(player_coords)
        if teleport_locked then
            teleport_locked = player_inside_any_marker(frame)
        end
        for _, marker in ipairs(record.markers or {}) do
            update_marker(record, marker, record.marker_handle_map, record.marker_initial_map, frame)
        end
    end)
    return record.marker_thread_id
end

function WorldMarker.stop(record)
    if type(record) ~= "table" then return 0 end

    record.markers_active = false
    record.markers_stopped = true
    local thread_id = record.marker_thread_id
    record.marker_thread_id = nil
    record.marker_initial_map = nil
    active_records[record] = nil
    if not next(active_records) then
        teleport_locked = false
    end
    if not thread_id then return 0 end

    Runtime.remove_thread(thread_id)
    return 1
end

return WorldMarker
