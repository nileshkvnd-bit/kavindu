local VehicleSpawnSettings = {}

local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")

local math_random <const> = math.random

function VehicleSpawnSettings.apply_flags(vehicle, settings)
    if settings.vehicle_engine_on ~= nil then VehicleCustomizer.set_engine_on(vehicle, settings.vehicle_engine_on) end
    if settings.radio_off then VehicleCustomizer.set_radio_enabled(vehicle, false) end
    if settings.vehicle_god_mode then VehicleCustomizer.set_invincible(vehicle, true) end
    if settings.clean_vehicle then VehicleCustomizer.clean_vehicle(vehicle) end
    if settings.bulletproof_tires then VehicleCustomizer.set_bulletproof_tires(vehicle, true) end
    if settings.max_performance then VehicleCustomizer.apply_max_performance(vehicle) end
    if settings.upgraded_vehicle then VehicleCustomizer.apply_max_visual_upgrades(vehicle) end
end

function VehicleSpawnSettings.apply_randomization(vehicle, settings)
    if settings.random_color then
        VehicleCustomizer.set_vehicle_color(vehicle, math_random(0, 159), math_random(0, 159))
    end
    if settings.random_livery then
        local count = VehicleCustomizer.get_livery_count(vehicle)
        if count > 0 then VehicleCustomizer.set_livery(vehicle, math_random(0, count - 1)) end
    end
end

function VehicleSpawnSettings.captured_speed(settings)
    if not (settings.keep_velocity and settings.in_vehicle) then return 0 end
    local current_vehicle = EntityFactory.player_vehicle()
    if not current_vehicle or current_vehicle == 0 then return 0 end
    return VehicleCustomizer.get_speed(current_vehicle)
end

return VehicleSpawnSettings
