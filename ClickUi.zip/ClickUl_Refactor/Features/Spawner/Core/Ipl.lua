local Ipl = {}

local Native = require("ClickUl_Refactor.Adapters.Native")

function Ipl.request(name)
    if not name or name == "" then return false end
    Native.call("request_ipl", name)
    return true
end

function Ipl.remove(name)
    if not name or name == "" then return false end
    if not Native.call("is_ipl_active", name) then return false end
    Native.call("remove_ipl", name)
    return true
end

function Ipl.remove_many(list)
    local count = 0
    if type(list) ~= "table" then return count end
    for _, name in ipairs(list) do
        if Ipl.remove(name) then count = count + 1 end
    end
    return count
end

function Ipl.enter_map_state(options)
    if type(options) ~= "table" then return false end
    local load_mp_maps = options.load_mp_maps == true
    local load_sp_maps = options.load_sp_maps == true
    if not load_mp_maps and not load_sp_maps then return false end

    Native.call("set_instance_priority_mode", true)
    if load_mp_maps then Native.call("on_enter_mp") end
    if load_sp_maps then Native.call("on_enter_sp") end
    return true
end

function Ipl.leave_map_state(options)
    if type(options) ~= "table" then return false end
    if options.load_mp_maps ~= true and options.load_sp_maps ~= true then return false end

    Native.call("set_instance_priority_mode", false)
    return true
end

function Ipl.cleanup_map(map_data)
    if not map_data or map_data.ipl_cleaned then return 0 end
    map_data.ipl_cleaned = true
    return Ipl.remove_many(map_data.loaded_ipls)
end

return Ipl
