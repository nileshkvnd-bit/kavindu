local Blip = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

function Blip.create_coord(coords, options)
    coords = Util.required_vector3(coords)
    if not coords then return 0 end
    options = options or {}

    local blip = Native.call("add_blip_for_coord", coords.x, coords.y, coords.z) or 0
    if blip == 0 then return 0 end

    if options.flashing ~= nil then Native.call("set_blip_flashes", blip, options.flashing == true) end
    if options.scale ~= nil then Native.call("set_blip_scale", blip, Util.to_number(options.scale, 1.0)) end
    if options.friendly ~= nil then Native.call("set_blip_as_friendly", blip, options.friendly == true) end
    if options.sprite ~= nil then Native.call("set_blip_sprite", blip, Util.to_number(options.sprite, 1)) end
    if options.colour ~= nil then Native.call("set_blip_colour", blip, Util.to_number(options.colour, 0)) end
    if options.alpha ~= nil then Native.call("set_blip_alpha", blip, Util.to_number(options.alpha, 255)) end

    local label = Util.trim(options.label)
    if label and label ~= "" then
        Native.call("begin_text_command_set_blip_name", "STRING")
        Native.call("add_text_component_substring_player_name", label)
        Native.call("end_text_command_set_blip_name", blip)
    end

    return blip
end

function Blip.remove(blip)
    if not blip or blip == 0 then return false end
    if Native.call("does_blip_exist", blip) ~= true then return false end

    local ptr = Pointer.int_with_value(blip)
    local ok, err = xpcall(function()
        Native.call("remove_blip", ptr)
    end, debug.traceback)
    Pointer.free(ptr)
    if not ok then error(err, 0) end
    return true
end

return Blip
