local PedAppearance = {}

local Hash = require("ClickUl_Refactor.Adapters.Hash")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function resolve_hash(value)
    if value == nil then return nil end
    if type(value) == "number" then return value end
    local text = Util.trim(value)
    if not text or text == "" then return nil end
    if text:lower() == "weapon_unarmed" then return nil end

    local hex = text:match("^0[xX]([%da-fA-F]+)$")
    if hex then return tonumber(hex, 16) end

    local numeric = tonumber(text)
    if numeric then return numeric end
    return Hash.joaat(text)
end

local function apply_weapon(ped, weapon)
    local weapon_hash = resolve_hash(weapon)
    if not weapon_hash or weapon_hash == 0 then return end
    if not Request.weapon(weapon_hash) then return end
    Native.call("give_weapon_to_ped", ped, weapon_hash, 9999, false, true)
    Native.call("set_current_ped_weapon", ped, weapon_hash, true)
end

local function apply_relationship_group(ped, attrs)
    local group = attrs.relationship_group
    if group == nil then return end

    local group_hash = resolve_hash(group)
    if group_hash then Native.call("set_ped_relationship_group_hash", ped, group_hash) end
end

local function apply_combat(ped, attrs)
    local ability = attrs.combat_ability
    if ability ~= nil then
        local value = Util.to_number(ability, 0)
        Native.call("set_ped_combat_attributes", ped, 46, value > 0)
        Native.call("set_ped_combat_attributes", ped, 5, value > 1)
    end

    local range = attrs.combat_range
    if range ~= nil then Native.call("set_ped_combat_range", ped, Util.to_number(range, 0)) end

    local movement = attrs.combat_movement
    if movement ~= nil then Native.call("set_ped_combat_movement", ped, Util.to_number(movement, 0)) end
end

local function is_enabled(value)
    return value ~= nil and Util.to_boolean(value)
end

local function overlay_colour_type(overlay_id)
    local id = Util.to_number(overlay_id, 0)
    if id == 1 or id == 2 or id == 4 or id == 10 then return 1 end
    if id == 5 or id == 8 then return 2 end
    return 0
end

local function should_apply_saved_head_features(attrs)
    local value = attrs.head_features_was_in_array
    if value == nil then return true end
    return Util.to_boolean(value)
end

local function apply_ped_config_flags(ped, flags)
    if type(flags) ~= "table" then return false end
    for flag_id, value in pairs(flags) do
        if value ~= nil then
            Native.call("set_ped_config_flag", ped, Util.to_number(flag_id, 0), Util.to_boolean(value))
        end
    end
    return true
end

local math_floor <const> = math.floor
local math_tointeger <const> = math.tointeger
local function to_int(value, default)
    local n = Util.to_number(value, default)
    if n == nil then return default end
    return math_tointeger(n) or math_floor(n)
end

function PedAppearance.apply_components(ped, components)
    if type(components) ~= "table" then return false end
    for component_id, data in pairs(components) do
        if type(data) == "table" then
            local drawable = to_int(data.drawable or data.drawable_variation or data.comp_id or data[1], 0)
            if drawable >= 0 then
                Native.call(
                    "set_ped_component_variation",
                    ped,
                    to_int(component_id, 0),
                    drawable,
                    to_int(data.texture or data.texture_variation or data.texture_id or data[2], 0),
                    to_int(data.palette or data.palette_variation or data[3], 0)
                )
            end
        end
    end
    return true
end

function PedAppearance.apply_default_components(ped)
    if not ped or ped == 0 then return false end
    Native.call("set_ped_default_component_variation", ped)
    return true
end

function PedAppearance.apply_props(ped, props)
    if type(props) ~= "table" then return false end
    for prop_id, data in pairs(props) do
        local id = to_int(prop_id, 0)
        if data == -1 then
            Native.call("clear_ped_prop", ped, id)
        elseif type(data) == "table" then
            local drawable = to_int(data.drawable or data.drawable_variation or data.prop_id or data[1], -1)
            if drawable < 0 then
                Native.call("clear_ped_prop", ped, id)
            else
                Native.call("set_ped_prop_index", ped, id, drawable, to_int(data.texture or data.texture_variation or data.texture_id or data[2], 0), true)
            end
        end
    end
    return true
end

function PedAppearance.apply_head_overlays(ped, overlays)
    if type(overlays) ~= "table" then return false end
    for overlay_id, data in pairs(overlays) do
        if type(data) == "table" then
            local id = to_int(overlay_id, 0)
            Native.call("set_ped_head_overlay", ped, id, to_int(data.index or data[1], 255), Util.to_number(data.opacity or data[2], 1.0))
            local color = Util.first_present(data, "color_id", "colour_id", "color", "colour", 4)
            local secondary = Util.first_present(data, "secondary_color_id", "secondary_colour_id", "color2", "colour2", 5)
            if data.color_type or data.colour_type or color ~= nil or data[3] then
                Native.call("set_ped_head_overlay_tint", ped, id, to_int(data.color_type or data.colour_type or data[3], overlay_colour_type(id)), to_int(color, 0), to_int(secondary, 0))
            end
        end
    end
    return true
end

function PedAppearance.apply_decorations(ped, decorations)
    if type(decorations) ~= "table" then return false end
    for _, data in ipairs(decorations) do
        if type(data) == "table" then
            local collection = resolve_hash(data.collection or data.Collection or data[1])
            local value = resolve_hash(data.value or data.Value or data.overlay or data.Overlay or data[2])
            if collection and value then
                Native.call("add_ped_decoration_from_hashes", ped, collection, value)
            end
        end
    end
    return true
end

function PedAppearance.apply_damage_packs(ped, packs)
    if type(packs) ~= "table" then return false end
    for _, name in ipairs(packs) do
        if type(name) == "string" and name ~= "" then
            Native.call("apply_ped_damage_pack", ped, name, 1.0, 1.0)
        end
    end
    return true
end

function PedAppearance.apply_blend(ped, blend)
    if type(blend) ~= "table" then return false end
    Native.call(
        "set_ped_head_blend_data",
        ped,
        to_int(blend.shape_first or blend.shapeFirst or blend.ShapeFirst, 0),
        to_int(blend.shape_second or blend.shapeSecond or blend.ShapeSecond, 0),
        to_int(blend.shape_third or blend.shapeThird or blend.ShapeThird, 0),
        to_int(blend.skin_first or blend.skinFirst or blend.SkinFirst, 0),
        to_int(blend.skin_second or blend.skinSecond or blend.SkinSecond, 0),
        to_int(blend.skin_third or blend.skinThird or blend.SkinThird, 0),
        Util.to_number(blend.mix_shape or blend.mixShape or blend.ShapeMix, 0.0),
        Util.to_number(blend.mix_skin or blend.mixSkin or blend.SkinMix, 0.0),
        Util.to_number(blend.mix_third or blend.mixThird or blend.ThirdMix, 0.0),
        Util.to_boolean(Util.first_present(blend, "is_parent", "isParent", "IsParent", "IsP"))
    )
    return true
end

function PedAppearance.apply_facial_features(ped, features)
    if type(features) ~= "table" then return false end
    for id, value in pairs(features) do
        Native.call("set_ped_micro_morph", ped, to_int(id, 0), Util.to_number(value, 0.0))
    end
    return true
end

local function apply_ped_behavior(ped, attrs)
    local health = attrs.health
    local max_health = attrs.max_health
    if max_health ~= nil then
        local value = Util.to_number(max_health, 200)
        Native.call("set_ped_max_health", ped, value)
        if health == nil then Native.call("set_entity_health", ped, value) end
    end
    if health ~= nil then Native.call("set_entity_health", ped, Util.to_number(health, 200)) end
    local armour = attrs.armor
    if armour ~= nil then Native.call("set_ped_armour", ped, Util.to_number(armour, 0)) end
    if attrs.keep_on_task ~= nil then Native.call("set_ped_keep_task", ped, Util.to_boolean(attrs.keep_on_task)) end
    if attrs.block_events ~= nil then Native.call("set_blocking_of_non_temporary_events", ped, Util.to_boolean(attrs.block_events)) end
    if attrs.can_ragdoll ~= nil then
        local can_ragdoll = Util.to_boolean(attrs.can_ragdoll)
        Native.call("set_ped_can_ragdoll", ped, can_ragdoll)
    end
    if attrs.ragdoll_on_collision ~= nil then
        Native.call("set_ped_ragdoll_on_collision", ped, Util.to_boolean(attrs.ragdoll_on_collision))
    end
    if attrs.is_still ~= nil then Native.call("set_blocking_of_non_temporary_events", ped, Util.to_boolean(attrs.is_still)) end
    if attrs.has_short_height ~= nil then
        Native.call("set_ped_config_flag", ped, 223, Util.to_boolean(attrs.has_short_height))
    end
    apply_ped_config_flags(ped, attrs.ped_config_flags)
    apply_weapon(ped, attrs.current_weapon)
    apply_relationship_group(ped, attrs)
    apply_combat(ped, attrs)

    local movement = attrs.movement_clipset
    if movement and Request.anim_set(movement) then
        local transition = Util.to_number(attrs.movement_clipset_transition, 1.0)
        Native.call("set_ped_movement_clipset", ped, movement, transition)
    end

    local weapon_movement = attrs.weapon_movement_clipset
    if weapon_movement and Request.anim_set(weapon_movement) then
        Native.call("set_ped_weapon_movement_clipset", ped, weapon_movement)
    end

    local facial_mood = attrs.facial_mood
    if facial_mood and facial_mood ~= "" then
        Native.call("set_facial_idle_anim_override", ped, facial_mood, "")
    end

    local animation = attrs.animation
    local anim_table = type(animation) == "table" and animation or nil
    local scenario = attrs.scenario or (anim_table and anim_table.scenario)
    local scenario_active = attrs.scenario_active
    if scenario and scenario ~= "" and (scenario_active == nil or Util.to_boolean(scenario_active)) then
        PedAppearance.apply_scenario(ped, scenario)
    end

    local anim_active = attrs.animation_active
    if anim_table and (anim_active == nil or Util.to_boolean(anim_active)) then
        PedAppearance.apply_animation(ped, anim_table)
    end

    local keep_task = attrs.ignore_events
    if is_enabled(keep_task) or is_enabled(anim_active) or is_enabled(scenario_active) then
        Native.call("set_blocking_of_non_temporary_events", ped, true)
        Native.call("set_ped_keep_task", ped, true)
    end
end

function PedAppearance.apply_attributes(ped, attrs, options)
    if type(attrs) ~= "table" then return false end
    options = options or {}
    local clear_decals = attrs.clear_decal_overlays
    if clear_decals ~= nil and Util.to_boolean(clear_decals) then
        Native.call("clear_ped_decorations", ped)
    end
    if options.apply_components ~= false then PedAppearance.apply_components(ped, attrs.components) end
    if options.apply_props ~= false then PedAppearance.apply_props(ped, attrs.props) end

    if options.apply_head_features ~= false then
        PedAppearance.apply_blend(ped, attrs.blend_data)
    end

    if options.apply_head_features ~= false and should_apply_saved_head_features(attrs) then
        PedAppearance.apply_head_overlays(ped, attrs.head_overlays)
        PedAppearance.apply_facial_features(ped, attrs.facial_features)

        local hair_color = attrs.hair_color
        if hair_color ~= nil then
            Native.call("set_ped_hair_tint", ped, to_int(hair_color, 0), to_int(attrs.hair_highlight_color, 0))
        end
        local eye_color = attrs.eye_color
        if eye_color ~= nil then
            Native.call("set_head_blend_eye_color", ped, to_int(eye_color, 0))
        end
    end
    if options.apply_decorations ~= false then PedAppearance.apply_decorations(ped, attrs.decorations) end
    if options.apply_damage_packs ~= false then PedAppearance.apply_damage_packs(ped, attrs.damage_packs) end

    if options.apply_behavior ~= false then
        apply_ped_behavior(ped, attrs)
    end

    return true
end

function PedAppearance.apply_menyoo_runtime_defaults(ped)
    Native.call("set_ped_can_switch_weapon", ped, false)
    Native.call("set_ped_path_can_use_climbovers", ped, true)
    Native.call("set_ped_path_can_use_ladders", ped, true)
    Native.call("set_ped_path_can_drop_from_height", ped, true)
    Native.call("set_ped_combat_ability", ped, 2)
    Native.call("set_ped_combat_movement", ped, 2)
    return true
end

function PedAppearance.apply_animation(ped, animation)
    if type(animation) ~= "table" then return false end
    local dict = animation.dict or animation.dictionary
    local name = animation.clip or animation.anim or animation.name
    if not dict or not name then return false end
    if not Request.anim(dict) then return false end
    local flag = animation.flag or animation.flags
    Native.call(
        "task_play_anim",
        ped,
        dict,
        name,
        Util.to_number(animation.blend_in, 8.0),
        Util.to_number(animation.blend_out, 8.0),
        Util.to_number(animation.duration, -1),
        Util.to_number(flag, 1),
        Util.to_number(animation.playback_rate, 0.0),
        false,
        0,
        false
    )
    return true
end

function PedAppearance.apply_scenario(ped, scenario)
    if not scenario or scenario == "" then return false end
    Native.call("task_start_scenario_in_place", ped, scenario, 0, true)
    return true
end

return PedAppearance
