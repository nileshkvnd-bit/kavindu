local CoreUtil = require("ClickUl_Refactor.Core.Util")

return {
    trim = CoreUtil.trim,
    to_number = CoreUtil.to_number,
    to_float = CoreUtil.to_float,
    to_boolean = CoreUtil.to_boolean,
    copy_table = CoreUtil.copy_table,
    merge_into = CoreUtil.merge_into,
    first_present = CoreUtil.first_present,
    vector3 = CoreUtil.vector3,
    required_vector3 = CoreUtil.required_vector3,
    rotation = CoreUtil.rotation,
}
