local VehicleModEditor = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local VehicleColorNames = require("ClickUl_Refactor.Features.Spawner.Core.VehicleColorNames")
local VehicleColorGxtMap = require("ClickUl_Refactor.Features.Spawner.Core.VehicleColorGxtMap")

local INDEXED_SLOTS <const> = {
    { slot = 11, key = "Engine", category = "performance" },
    { slot = 12, key = "Brakes", category = "performance" },
    { slot = 13, key = "Transmission", category = "performance" },
    { slot = 15, key = "Suspension", category = "performance" },
    { slot = 16, key = "Armor", category = "performance" },
    { slot = 0, key = "Spoiler", category = "cosmetic" },
    { slot = 1, key = "Front Bumper", category = "cosmetic" },
    { slot = 2, key = "Rear Bumper", category = "cosmetic" },
    { slot = 3, key = "Side Skirt", category = "cosmetic" },
    { slot = 4, key = "Exhaust", category = "cosmetic" },
    { slot = 5, key = "Frame", category = "cosmetic" },
    { slot = 6, key = "Grille", category = "cosmetic" },
    { slot = 7, key = "Hood", category = "cosmetic" },
    { slot = 8, key = "Fender", category = "cosmetic" },
    { slot = 9, key = "Right Fender", category = "cosmetic" },
    { slot = 10, key = "Roof", category = "cosmetic" },
    { slot = 25, key = "Plate Holder", category = "cosmetic" },
    { slot = 26, key = "Vanity Plate", category = "cosmetic" },
    { slot = 27, key = "Trim Design", category = "cosmetic" },
    { slot = 28, key = "Ornaments", category = "cosmetic" },
    { slot = 29, key = "Dashboard", category = "cosmetic" },
    { slot = 30, key = "Dial Design", category = "cosmetic" },
    { slot = 31, key = "Door Speakers", category = "cosmetic" },
    { slot = 32, key = "Seats", category = "cosmetic" },
    { slot = 33, key = "Steering Wheel", category = "cosmetic" },
    { slot = 34, key = "Shifter Leavers", category = "cosmetic" },
    { slot = 35, key = "Plaques", category = "cosmetic" },
    { slot = 36, key = "Speakers", category = "cosmetic" },
    { slot = 37, key = "Trunk", category = "cosmetic" },
    { slot = 38, key = "Hydraulics", category = "cosmetic" },
    { slot = 39, key = "Engine Block", category = "cosmetic" },
    { slot = 40, key = "Air Filter", category = "cosmetic" },
    { slot = 41, key = "Struts", category = "cosmetic" },
    { slot = 42, key = "Arch Cover", category = "cosmetic" },
    { slot = 43, key = "Aerials", category = "cosmetic" },
    { slot = 44, key = "Trim", category = "cosmetic" },
    { slot = 45, key = "Tank", category = "cosmetic" },
    { slot = 46, key = "Left Door", category = "cosmetic" },
    { slot = 47, key = "Right Door", category = "cosmetic" },
    { slot = 49, key = "Light Bar", category = "cosmetic" },
}

local TYRE_SMOKE_SLOT <const> = 20
local XENON_SLOT <const> = 22
local FRONT_WHEEL_SLOT <const> = 23
local BACK_WHEEL_SLOT <const> = 24
local EXTRA_MAX <const> = 14

local PERF_LABEL_PREFIX <const> = {
    [11] = "CMOD_ENG_",
    [12] = "CMOD_BRA_",
    [13] = "CMOD_GBX_",
    [15] = "CMOD_SUS_",
    [16] = "CMOD_ARM_",
}

local CATEGORY_GXT_KEYS <const> = {
    [7] = "CMOD_MOD_HOD",
    [11] = "CMOD_MOD_ENG",
    [12] = "CMOD_MOD_BRA",
    [13] = "CMOD_MOD_TRN",
    [14] = "CMOD_MOD_HRN",
    [15] = "CMOD_MOD_SUS",
    [16] = "CMOD_MOD_ARM",
    [25] = "CMM_MOD_S0",
    [26] = "CMM_MOD_S1",
    [27] = "CMM_MOD_S2",
    [28] = "CMM_MOD_S3",
    [29] = "CMM_MOD_S4",
    [30] = "CMM_MOD_S5",
    [31] = "CMM_MOD_S6",
    [32] = "CMM_MOD_S7",
    [33] = "CMM_MOD_S8",
    [34] = "CMM_MOD_S9",
    [35] = "CMM_MOD_S10",
    [36] = "CMM_MOD_S11",
    [37] = "CMM_MOD_S12",
    [38] = "CMM_MOD_S13",
    [39] = "CMM_MOD_S14",
    [40] = "CMM_MOD_S15",
    [41] = "CMM_MOD_S16",
    [42] = "CMM_MOD_S17",
    [43] = "CMM_MOD_S18",
    [44] = "CMM_MOD_S19",
    [45] = "CMM_MOD_S20",
    [48] = "CMM_MOD_S23",
}
local category_name_cache = {}

local HORN_SLOT <const> = 14

local HORN_LABEL_KEY <const> = {
    [0] = "CMOD_HRN_TRK", [1] = "CMOD_HRN_COP", [2] = "CMOD_HRN_CLO",
    [3] = "CMOD_HRN_MUS1", [4] = "CMOD_HRN_MUS2", [5] = "CMOD_HRN_MUS3",
    [6] = "CMOD_HRN_MUS4", [7] = "CMOD_HRN_MUS5", [8] = "CMOD_HRN_SAD",
    [9] = "HORN_CLAS1", [10] = "HORN_CLAS2", [11] = "HORN_CLAS3", [12] = "HORN_CLAS4",
    [13] = "HORN_CLAS5", [14] = "HORN_CLAS6", [15] = "HORN_CLAS7",
    [16] = "HORN_CNOTE_C0", [17] = "HORN_CNOTE_D0", [18] = "HORN_CNOTE_E0",
    [19] = "HORN_CNOTE_F0", [20] = "HORN_CNOTE_G0", [21] = "HORN_CNOTE_A0",
    [22] = "HORN_CNOTE_B0", [23] = "HORN_CNOTE_C1",
    [24] = "HORN_HIPS1", [25] = "HORN_HIPS2", [26] = "HORN_HIPS3", [27] = "HORN_HIPS4",
    [28] = "HORN_INDI_1", [29] = "HORN_INDI_2", [30] = "HORN_INDI_3", [31] = "HORN_INDI_4",
    [32] = "HORN_LUXE2", [33] = "HORN_LUXE1", [34] = "HORN_LUXE3",
    [38] = "HORN_HWEEN1", [40] = "HORN_HWEEN2",
    [42] = "HORN_LOWRDER1", [44] = "HORN_LOWRDER2",
    [46] = "HORN_XM15_1", [47] = "HORN_XM15_2", [48] = "HORN_XM15_3",
}

local function exists(vehicle)
    return vehicle and vehicle ~= 0 and EntityFactory.exists(vehicle)
end

local function read_ints(vehicle, native_name, n)
    local ptrs = {}
    for i = 1, n do ptrs[i] = Pointer.int() end
    local ok, result = xpcall(function()
        Native.call(native_name, vehicle, table.unpack(ptrs))
        local vals = {}
        for i = 1, n do vals[i] = Pointer.int_value(ptrs[i], 0) end
        return vals
    end, debug.traceback)
    for i = 1, n do Pointer.free(ptrs[i]) end
    if not ok then error(result, 0) end
    return result
end

function VehicleModEditor.indexed_slots()
    return INDEXED_SLOTS
end

function VehicleModEditor.current_vehicle()
    local vehicle = EntityFactory.player_vehicle()
    if exists(vehicle) then return vehicle end
    return 0
end

function VehicleModEditor.prepare(vehicle)
    if not exists(vehicle) then return false end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    return true
end

function VehicleModEditor.slot_state(vehicle, slot)
    if not exists(vehicle) then return nil end
    local count = Native.call("get_num_vehicle_mods", vehicle, slot) or 0
    if count <= 0 then return nil end
    local current = Native.call("get_vehicle_mod", vehicle, slot) or -1
    return { slot = slot, count = count, current = current }
end

local function resolve_label(key)
    if type(key) ~= "string" or key == "" then return nil end
    local name = Native.get_filename_for_audio_conversation(key)
    if type(name) ~= "string" or name == "" or name == "NULL" then return nil end
    return (name:gsub("\u{00B5}", ""))
end

function VehicleModEditor.slot_category_name(slot)
    local cached = category_name_cache[slot]
    if cached ~= nil then return cached end
    local gxt_key = CATEGORY_GXT_KEYS[slot]
    if not gxt_key then return nil end
    local name = resolve_label(gxt_key)
    category_name_cache[slot] = name or false
    return name
end

function VehicleModEditor.gxt_text(key)
    return resolve_label(key)
end

local DYNAMIC_SLOTS <const> = { [0] = true, [1] = true, [2] = true, [3] = true, [4] = true, [5] = true, [6] = true, [8] = true, [9] = true, [10] = true }
function VehicleModEditor.slot_name_dynamic(vehicle, slot)
    if not DYNAMIC_SLOTS[slot] or not exists(vehicle) then return nil end
    local name = Native.get_mod_slot_name(vehicle, slot)
    if type(name) ~= "string" or name == "" then return nil end
    if name:find("_", 1, true) then
        return resolve_label(name)
    end
    return nil
end

function VehicleModEditor.mod_name(vehicle, slot, index)
    if index == nil or index < 0 then return nil end
    local perf_prefix = PERF_LABEL_PREFIX[slot]
    if perf_prefix then return resolve_label(perf_prefix .. tostring(index + 1)) end
    if slot == HORN_SLOT then return resolve_label(HORN_LABEL_KEY[index]) end
    if not exists(vehicle) then return nil end
    return resolve_label(Native.get_mod_text_label(vehicle, slot, index))
end

local COLOR_FINISHES <const> = {
    { type = 0, key = "Classic",     gxt = "CMOD_COL1_1" },
    { type = 1, key = "Metallic",    gxt = "CMOD_COL1_3" },
    { type = 2, key = "Pearlescent", gxt = "CMOD_COL1_6" },
    { type = 3, key = "Matte",       gxt = "CMOD_COL1_5" },
    { type = 4, key = "Metal",       gxt = "CMOD_COL1_4" },
    { type = 5, key = "Chrome",      gxt = "CMOD_COL1_0" },
    { type = 6, key = "Chameleon",   gxt = "CMOD_COL1_7" },
}

local finish_name_cache = {}

function VehicleModEditor.color_finishes()
    return COLOR_FINISHES
end

function VehicleModEditor.finish_name(paint_type)
    local cached = finish_name_cache[paint_type]
    if cached ~= nil then return cached end
    local gxt
    for _, f in ipairs(COLOR_FINISHES) do
        if f.type == paint_type then gxt = f.gxt; break end
    end
    local name = gxt and resolve_label(gxt) or nil
    finish_name_cache[paint_type] = name or false
    return name
end

function VehicleModEditor.get_mod_color(vehicle, which)
    if not exists(vehicle) then return nil end
    local values = nil
    if which == 2 then
        values = read_ints(vehicle, "get_vehicle_mod_color_2", 2)
    else
        values = read_ints(vehicle, "get_vehicle_mod_color_1", 3)
    end
    return { type = values[1] or 0, index = values[2] or 0 }
end

function VehicleModEditor.scan_color_names(vehicle, paint_type)
    if not exists(vehicle) then return {} end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    local count = Native.call("get_num_mod_colors", paint_type, true) or 0
    if count <= 0 then return {} end

    local mc1 = read_ints(vehicle, "get_vehicle_mod_color_1", 3)
    local mc2 = read_ints(vehicle, "get_vehicle_mod_color_2", 2)
    local cols = read_ints(vehicle, "get_vehicle_colours", 2)
    local extra = read_ints(vehicle, "get_vehicle_extra_colours", 2)
    local prim_custom = Native.call("get_is_vehicle_primary_colour_custom", vehicle) and true or false
    local sec_custom = Native.call("get_is_vehicle_secondary_colour_custom", vehicle) and true or false
    local cp = read_ints(vehicle, "get_vehicle_custom_primary_colour", 3)
    local cs = read_ints(vehicle, "get_vehicle_custom_secondary_colour", 3)

    local function restore_colors()
        if prim_custom then
            Native.call("set_vehicle_custom_primary_colour", vehicle, cp[1], cp[2], cp[3])
        else
            Native.call("clear_vehicle_custom_primary_colour", vehicle)
        end
        if sec_custom then
            Native.call("set_vehicle_custom_secondary_colour", vehicle, cs[1], cs[2], cs[3])
        else
            Native.call("clear_vehicle_custom_secondary_colour", vehicle)
        end
        Native.call("set_vehicle_colours", vehicle, cols[1], cols[2])
        Native.call("set_vehicle_extra_colours", vehicle, extra[1], extra[2])
        Native.call("set_vehicle_mod_color_2", vehicle, mc2[1], mc2[2])
        Native.call("set_vehicle_mod_color_1", vehicle, mc1[1], mc1[2], mc1[3])
    end

    local ok, result = xpcall(function()
        local names = {}
        for idx = 0, count - 1 do
            Native.call("set_vehicle_mod_color_1", vehicle, paint_type, idx, idx)
            names[idx + 1] = resolve_label(Native.get_vehicle_mod_color_1_name(vehicle, false)) or ("#" .. tostring(idx))
        end
        return names
    end, debug.traceback)

    local restore_ok, restore_err = xpcall(restore_colors, debug.traceback)
    if not restore_ok then error(restore_err, 0) end
    if not ok then error(result, 0) end
    return result
end

function VehicleModEditor.set_mod_color(vehicle, which, paint_type, index)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    if which == 2 then
        Native.call("clear_vehicle_custom_secondary_colour", vehicle)
        Native.call("set_vehicle_mod_color_2", vehicle, paint_type, index)
    else
        Native.call("clear_vehicle_custom_primary_colour", vehicle)
        Native.call("set_vehicle_mod_color_1", vehicle, paint_type, index, index)
    end
end

local std_color_gxt_cache = {}

local function standard_gxt_name(index)
    local cached = std_color_gxt_cache[index]
    if cached ~= nil then return cached or nil end
    local key = VehicleColorGxtMap[index]
    local name = key and resolve_label(key) or nil
    std_color_gxt_cache[index] = name or false
    return name
end

local std_category_cache = {}

function VehicleModEditor.standard_color_category(language, category_key)
    local by_lang = std_category_cache[language]
    if not by_lang then
        by_lang = {}
        std_category_cache[language] = by_lang
    end
    local cached = by_lang[category_key]
    if cached then return cached end
    local base = VehicleColorNames.category(language, category_key)
    local labels = {}
    for i = 1, #base.indices do
        labels[i] = standard_gxt_name(base.indices[i]) or base.labels[i]
    end
    local group = { indices = base.indices, labels = labels }
    by_lang[category_key] = group
    return group
end

local WHEEL_TYPE_LABEL_KEY <const> = {
    [0] = "CMOD_WHE1_5",
    [1] = "CMOD_WHE1_3",
    [2] = "CMOD_WHE1_2",
    [3] = "CMOD_WHE1_6",
    [4] = "CMOD_WHE1_4",
    [5] = "CMOD_WHE1_7",
    [6] = "CMOD_WHE1_0",
    [7] = "CMOD_WHE1_1",
    [8] = "CMOD_WHE1_8",
    [9] = "CMOD_WHE1_9",
    [10] = "CMOD_WHE1_10",
    [11] = "CMOD_WHE1_11",
    [12] = "CMOD_WHE1_12",
}
local WHEEL_TYPE_COUNT <const> = 13
local wheel_type_name_cache

function VehicleModEditor.wheel_type_names()
    if wheel_type_name_cache then return wheel_type_name_cache end
    local names = {}
    for id = 0, WHEEL_TYPE_COUNT - 1 do
        names[id + 1] = resolve_label(WHEEL_TYPE_LABEL_KEY[id]) or ("#" .. tostring(id))
    end
    wheel_type_name_cache = names
    return names
end

local WHEEL_STYLE_COUNT <const> = {
    [0] = 50,
    [1] = 36,
    [2] = 30,
    [3] = 38,
    [4] = 35,
    [5] = 48,
    [6] = 72,
    [7] = 40,
    [8] = 217,
    [9] = 217,
    [10] = 140,
    [11] = 210,
    [12] = 210,
}

function VehicleModEditor.wheel_style_count(wheel_type_id)
    return WHEEL_STYLE_COUNT[wheel_type_id] or 0
end

local HORN_CATEGORIES <const> = {
    { key = "Basic Horns",     indices = { 0, 1, 2, 8 } },
    { key = "Musical Horns",   indices = { 3, 4, 5, 6, 7 } },
    { key = "Classical Horns", indices = { 9, 10, 11, 12, 13, 14, 15, 32, 33, 34 } },
    { key = "Scale Horns",     indices = { 16, 17, 18, 19, 20, 21, 22, 23 } },
    { key = "Jazz Horns",      indices = { 24, 25, 26, 27 } },
    { key = "Anthem Horns",    indices = { 28, 29, 30, 31 } },
    { key = "Halloween Horns", indices = { 38, 40 } },
    { key = "Special Horns",   indices = { 42, 44, 46, 47, 48 } },
}

function VehicleModEditor.horn_categories()
    return HORN_CATEGORIES
end

function VehicleModEditor.horn_slot()
    return HORN_SLOT
end

local horn_preset_cache

function VehicleModEditor.horn_preset_names()
    if horn_preset_cache then return horn_preset_cache end
    local list = { { id = -1 } }
    for _, cat in ipairs(HORN_CATEGORIES) do
        for _, idx in ipairs(cat.indices) do
            local name = resolve_label(HORN_LABEL_KEY[idx])
            if name then list[#list + 1] = { id = idx, name = name } end
        end
    end
    horn_preset_cache = list
    return list
end

function VehicleModEditor.horn_state(vehicle)
    if not exists(vehicle) then return nil end
    local count = Native.call("get_num_vehicle_mods", vehicle, HORN_SLOT) or 0
    if count <= 0 then return nil end
    return { count = count, current = Native.call("get_vehicle_mod", vehicle, HORN_SLOT) or -1 }
end

function VehicleModEditor.set_mod(vehicle, slot, value)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_mod", vehicle, slot, value or -1, false)
end

function VehicleModEditor.toggle_mod(vehicle, slot, on)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    Native.call("toggle_vehicle_mod", vehicle, slot, on and true or false)
end

local function ptr_pair(vehicle, native_name)
    local values = read_ints(vehicle, native_name, 2)
    return values[1], values[2]
end

local function ptr_one(vehicle, native_name)
    local values = read_ints(vehicle, native_name, 1)
    return values[1]
end

local function ptr_triple(vehicle, native_name)
    local values = read_ints(vehicle, native_name, 3)
    return values[1], values[2], values[3]
end

function VehicleModEditor.toggle_on(vehicle, slot)
    if not exists(vehicle) then return false end
    return Native.call("is_toggle_mod_on", vehicle, slot) and true or false
end

function VehicleModEditor.read_paint(vehicle)
    if not exists(vehicle) then return {} end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    local pearl, wheel = ptr_pair(vehicle, "get_vehicle_extra_colours")
    local cpr, cpg, cpb = ptr_triple(vehicle, "get_vehicle_custom_primary_colour")
    local csr, csg, csb = ptr_triple(vehicle, "get_vehicle_custom_secondary_colour")
    return {
        pearlescent = pearl,
        wheel_color = wheel,
        custom_primary = { r = cpr or 255, g = cpg or 255, b = cpb or 255 },
        custom_secondary = { r = csr or 0, g = csg or 0, b = csb or 0 },
        interior = ptr_one(vehicle, "get_vehicle_extra_colour_5"),
        dashboard = ptr_one(vehicle, "get_vehicle_dashboard_colour"),
    }
end

function VehicleModEditor.read_wheels(vehicle)
    if not exists(vehicle) then return {} end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    return {
        wheel_type = Native.call("get_vehicle_wheel_type", vehicle) or 0,
        front = VehicleModEditor.wheel_state(vehicle, FRONT_WHEEL_SLOT),
        back = VehicleModEditor.wheel_state(vehicle, BACK_WHEEL_SLOT),
    }
end

function VehicleModEditor.read_liveries(vehicle)
    if not exists(vehicle) then return {} end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    return {
        livery = Native.call("get_vehicle_mod", vehicle, 48) or -1,
        livery_count = Native.call("get_num_vehicle_mods", vehicle, 48) or 0,
        livery2 = Native.get_vehicle_livery2(vehicle) or -1,
        livery2_count = Native.get_vehicle_livery2_count(vehicle) or 0,
    }
end

function VehicleModEditor.read_lights(vehicle)
    if not exists(vehicle) then return {} end
    local neon_on = false
    for i = 0, 3 do
        if Native.call("get_vehicle_neon_enabled", vehicle, i) then neon_on = true break end
    end
    local nr, ng, nb = ptr_triple(vehicle, "get_vehicle_neon_colour")
    return {
        xenon = VehicleModEditor.toggle_on(vehicle, XENON_SLOT),
        xenon_color = Native.call("get_vehicle_xenon_lights_colour", vehicle),
        window_tint = Native.call("get_vehicle_window_tint", vehicle) or 0,
        neon = neon_on,
        neon_color = { r = nr, g = ng, b = nb },
    }
end

function VehicleModEditor.read_tyres(vehicle)
    if not exists(vehicle) then return {} end
    local sr, sg, sb = ptr_triple(vehicle, "get_vehicle_tyre_smoke_color")
    return {
        bulletproof = not (Native.call("get_vehicle_tyres_can_burst", vehicle) and true or false),
        drift = Native.call("get_vehicle_tyres_are_low_grip", vehicle) and true or false,
        tyre_smoke = VehicleModEditor.toggle_on(vehicle, TYRE_SMOKE_SLOT),
        smoke_color = { r = sr or 255, g = sg or 255, b = sb or 255 },
    }
end

function VehicleModEditor.read_plate(vehicle)
    if not exists(vehicle) then return {} end
    return {
        plate_index = Native.call("get_vehicle_number_plate_text_index", vehicle) or 0,
        plate_text = Native.get_vehicle_number_plate_text(vehicle) or "",
    }
end

function VehicleModEditor.read_extras(vehicle)
    if not exists(vehicle) then return {} end
    local extras = {}
    for id = 1, EXTRA_MAX do
        if Native.call("does_extra_exist", vehicle, id) then
            extras[id] = Native.call("is_vehicle_extra_turned_on", vehicle, id) and true or false
        end
    end
    return extras
end

function VehicleModEditor.wheel_state(vehicle, slot)
    if not exists(vehicle) then return { count = 0, current = -1 } end
    return {
        count = Native.call("get_num_vehicle_mods", vehicle, slot) or 0,
        current = Native.call("get_vehicle_mod", vehicle, slot) or -1,
        variation = Native.call("get_vehicle_mod_variation", vehicle, slot) and true or false,
    }
end

function VehicleModEditor.extra_slots()
    return EXTRA_MAX
end


function VehicleModEditor.set_wheel(vehicle, slot, value, custom)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_mod_kit", vehicle, 0)
    Native.call("set_vehicle_mod", vehicle, slot, value or -1, custom and true or false)
end

function VehicleModEditor.set_roof_livery(vehicle, index)
    if not exists(vehicle) then return end
    Native.set_vehicle_livery2(vehicle, index)
end

function VehicleModEditor.set_drift(vehicle, on)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_tyres_low_grip", vehicle, on and true or false)
end

function VehicleModEditor.set_extra(vehicle, id, on)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_extra", vehicle, id, not (on and true or false))
end

function VehicleModEditor.repair(vehicle)
    if not exists(vehicle) then return end
    Native.call("set_vehicle_fixed", vehicle)
    Native.call("set_vehicle_deformation_fixed", vehicle)
end

return VehicleModEditor
