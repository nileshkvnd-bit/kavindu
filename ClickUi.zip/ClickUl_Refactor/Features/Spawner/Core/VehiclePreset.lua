local VehiclePreset = {}

local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local VehicleColorNames = require("ClickUl_Refactor.Features.Spawner.Core.VehicleColorNames")

VehiclePreset.PLATE_TYPES = {
    "Blue on White 1",
    "Yellow on Black",
    "Yellow on Blue",
    "Blue on White 2",
    "Blue on White 3",
    "North Yankton",
    "eCola",
    "Las Venturas",
    "Liberty City",
    "LS Car Meet",
    "LS Panic",
    "LS Pounders",
    "Sprunk",
}

VehiclePreset.WINDOW_TINTS = {
    "None",
    "Pure Black",
    "Dark Smoke",
    "Light Smoke",
    "Stock",
    "Limo",
    "Green",
}

VehiclePreset.NEON_PRESETS = {
    { name = "None", value = nil },
    { name = "White", value = { r = 255, g = 255, b = 255 } },
    { name = "Blue", value = { r = 0, g = 0, b = 255 } },
    { name = "Electric Blue", value = { r = 0, g = 150, b = 255 } },
    { name = "Mint Green", value = { r = 0, g = 255, b = 140 } },
    { name = "Lime Green", value = { r = 0, g = 255, b = 0 } },
    { name = "Yellow", value = { r = 255, g = 255, b = 0 } },
    { name = "Golden", value = { r = 255, g = 200, b = 0 } },
    { name = "Orange", value = { r = 255, g = 100, b = 0 } },
    { name = "Red", value = { r = 255, g = 0, b = 0 } },
    { name = "Pink", value = { r = 255, g = 0, b = 255 } },
    { name = "Hot Pink", value = { r = 255, g = 50, b = 150 } },
    { name = "Purple", value = { r = 150, g = 0, b = 255 } },
}

VehiclePreset.SMOKE_PRESETS = {
    { name = "None", value = nil },
    { name = "White", value = { r = 255, g = 255, b = 255 } },
    { name = "Black", value = { r = 20, g = 20, b = 20 } },
    { name = "Blue", value = { r = 0, g = 150, b = 255 } },
    { name = "Yellow", value = { r = 255, g = 255, b = 0 } },
    { name = "Orange", value = { r = 255, g = 128, b = 0 } },
    { name = "Red", value = { r = 255, g = 0, b = 0 } },
    { name = "Green", value = { r = 0, g = 255, b = 0 } },
    { name = "Purple", value = { r = 150, g = 0, b = 255 } },
    { name = "Pink", value = { r = 255, g = 50, b = 150 } },
    { name = "Patriot", value = { r = 0, g = 0, b = 0 } },
}

VehiclePreset.XENON_PRESETS = {
    { name = "Default", id = -1 },
    { name = "White", id = 0 },
    { name = "Blue", id = 1 },
    { name = "Electric Blue", id = 2 },
    { name = "Mint Green", id = 3 },
    { name = "Lime Green", id = 4 },
    { name = "Yellow", id = 5 },
    { name = "Golden", id = 6 },
    { name = "Orange", id = 7 },
    { name = "Red", id = 8 },
    { name = "Pony Pink", id = 9 },
    { name = "Hot Pink", id = 10 },
    { name = "Purple", id = 11 },
    { name = "Blacklight", id = 12 },
}

VehiclePreset.WHEEL_TYPES = {
    { name = "Stock", id = -1 },
    { name = "Sport", id = 0 },
    { name = "Muscle", id = 1 },
    { name = "Lowrider", id = 2 },
    { name = "SUV", id = 3 },
    { name = "Offroad", id = 4 },
    { name = "Tuner", id = 5 },
    { name = "Biker", id = 6 },
    { name = "High End", id = 7 },
    { name = "Benny's Original", id = 8 },
    { name = "Benny's Bespoke", id = 9 },
    { name = "Open Wheel", id = 10 },
    { name = "Street", id = 11 },
    { name = "Track", id = 12 },
}

function VehiclePreset.option_names(list)
    local result = {}
    for i = 1, #list do result[i] = list[i].name or tostring(list[i]) end
    return result
end

function VehiclePreset.apply(vehicle, settings, use_saved_preset)
    if not vehicle or vehicle == 0 or type(settings) ~= "table" then return false end
    local should_apply = use_saved_preset and settings.saved_vehicle_use_preset or settings.use_preset
    if not should_apply then return false end

    VehicleCustomizer.set_vehicle_color(vehicle, settings.primary_color or 0, settings.secondary_color or 0)

    VehicleCustomizer.set_extra_colors(vehicle, settings.pearlescent_id or 0, settings.wheel_color_id or 0)

    local xenon = VehiclePreset.XENON_PRESETS[settings.xenon_color or 1]
    if xenon then
        if xenon.id == -1 then
            VehicleCustomizer.set_xenon_enabled(vehicle, false)
        else
            VehicleCustomizer.set_xenon_color(vehicle, xenon.id)
        end
    end

    local neon = VehiclePreset.NEON_PRESETS[settings.neon_color or 1]
    if neon and neon.value then
        VehicleCustomizer.set_neon_color(vehicle, neon.value.r, neon.value.g, neon.value.b)
        VehicleCustomizer.set_all_neons_enabled(vehicle, true)
    else
        VehicleCustomizer.set_all_neons_enabled(vehicle, false)
    end

    local wheel = VehiclePreset.WHEEL_TYPES[settings.wheel_type or 1]
    if wheel and wheel.id and wheel.id >= 0 then VehicleCustomizer.set_wheel_type(vehicle, wheel.id) end
    VehicleCustomizer.set_front_wheels(vehicle, settings.wheel_index or -1, settings.custom_tires)

    local smoke = VehiclePreset.SMOKE_PRESETS[settings.tire_smoke_color or 1]
    if smoke and smoke.value then
        VehicleCustomizer.set_tire_smoke_color(vehicle, smoke.value.r, smoke.value.g, smoke.value.b)
    else
        VehicleCustomizer.set_tire_smoke_enabled(vehicle, false)
    end

    VehicleCustomizer.set_window_tint(vehicle, (settings.window_tint or 1) - 1)
    VehicleCustomizer.set_plate_type(vehicle, (settings.plate_type or 1) - 1)
    if settings.plate_text and settings.plate_text ~= "" then VehicleCustomizer.set_plate_text(vehicle, settings.plate_text) end
    VehicleCustomizer.set_horn(vehicle, settings.horn_id or -1)
    return true
end

function VehiclePreset.apply_neon_preset(vehicle, index)
    local preset = VehiclePreset.NEON_PRESETS[index]
    if preset and preset.value then
        VehicleCustomizer.set_neon_color(vehicle, preset.value.r, preset.value.g, preset.value.b)
        return preset.value
    end
    return nil
end

function VehiclePreset.apply_smoke_preset(vehicle, index)
    local preset = VehiclePreset.SMOKE_PRESETS[index]
    if preset and preset.value then
        VehicleCustomizer.set_tire_smoke_color(vehicle, preset.value.r, preset.value.g, preset.value.b)
        return preset.value
    end
    return nil
end

local function preset_index_for_rgb(presets, r, g, b)
    for i = 1, #presets do
        local v = presets[i].value
        if v and v.r == r and v.g == g and v.b == b then return i end
    end
    return 1
end

function VehiclePreset.neon_preset_index(r, g, b)
    return preset_index_for_rgb(VehiclePreset.NEON_PRESETS, r, g, b)
end

function VehiclePreset.smoke_preset_index(r, g, b)
    return preset_index_for_rgb(VehiclePreset.SMOKE_PRESETS, r, g, b)
end

function VehiclePreset.color_category_keys()
    return VehicleColorNames.category_keys()
end

function VehiclePreset.color_category(language, category_key)
    return VehicleColorNames.category(language, category_key)
end

function VehiclePreset.color_category_of(_language, color_index)
    return VehicleColorNames.category_of(color_index)
end

return VehiclePreset
