local VehicleSpawner = {}

local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local VehiclePreset = require("ClickUl_Refactor.Features.Spawner.Core.VehiclePreset")
local VehicleSpawnSettings = require("ClickUl_Refactor.Features.Spawner.Core.VehicleSpawnSettings")

local function apply_vehicle_settings(vehicle, settings)
    VehicleSpawnSettings.apply_flags(vehicle, settings)
    VehicleSpawnSettings.apply_randomization(vehicle, settings)
    VehiclePreset.apply(vehicle, settings, false)
    if settings.spawn_plane_in_air then EntityFactory.raise_aircraft_if_needed(vehicle, 50.0) end
    if settings.in_vehicle then EntityFactory.put_player_in_vehicle(vehicle) end
end

function VehicleSpawner.spawn_model(model, opts)
    opts = opts or {}
    local settings = Settings.get("vehicle")
    local saved_speed = VehicleSpawnSettings.captured_speed(settings)
    if settings.delete_old_vehicle then VehicleSpawner.delete_all() end

    local coords = opts.coords or EntityFactory.forward_spawn_coords(opts.distance or 5.0)
    local heading = opts.heading or EntityFactory.player_heading()
    local vehicle, err = EntityFactory.spawn_vehicle(model, coords, heading)
    if not vehicle or vehicle == 0 then return 0, err or "spawn_failed" end

    apply_vehicle_settings(vehicle, settings)
    if settings.in_vehicle and saved_speed > 0 then VehicleCustomizer.set_forward_speed(vehicle, saved_speed) end
    SpawnRegistry.add("spawned_vehicles", {
        handle = vehicle,
        model = model,
        label = opts.label,
    })
    return vehicle, nil
end

function VehicleSpawner.delete_all()
    return SpawnRegistry.delete_entity_list("spawned_vehicles")
end

function VehicleSpawner.delete_current()
    local vehicle = EntityFactory.player_vehicle()
    if not vehicle or vehicle == 0 then return false end
    return SpawnRegistry.delete_entity(vehicle)
end

function VehicleSpawner.get_spawned()
    return SpawnRegistry.list("spawned_vehicles")
end

return VehicleSpawner
