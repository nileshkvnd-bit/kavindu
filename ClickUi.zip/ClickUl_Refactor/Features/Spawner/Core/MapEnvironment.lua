local MapEnvironment = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Pools = require("ClickUl_Refactor.Adapters.Pools")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function interior_id(entry)
    entry = entry or {}
    local id = Util.to_number(entry.id or entry.ID, -1)
    if id ~= -1 then return id end

    local coords = Util.required_vector3(entry.coords or entry.Coords)
    if not coords then return id end
    return Native.call("get_interior_at_coords", coords.x, coords.y, coords.z)
end

local function interior_valid(id)
    return id ~= nil and Native.call("is_valid_interior", id) == true
end

local function interior_prop_name(prop)
    return Util.trim(prop and (prop.name or prop.Name))
end

function MapEnvironment.clear_world(center, radius)
    radius = Util.to_number(radius, 0)
    center = Util.required_vector3(center)
    if not center or radius <= 0 then return false end

    local excluded = {}
    local function exclude(entity)
        if entity and entity ~= 0 then excluded[entity] = true end
    end
    exclude(EntityFactory.player_ped())
    exclude(EntityFactory.player_vehicle())
    local radius_squared = radius * radius
    local targets = {}
    for _, entity in ipairs(Pools.entity_handles(true)) do
        if entity and entity ~= 0 and not excluded[entity] then
            local coords = EntityFactory.entity_coords(entity)
            if coords then
                local dx = coords.x - center.x
                local dy = coords.y - center.y
                local dz = coords.z - center.z
                if dx * dx + dy * dy + dz * dz <= radius_squared then
                    targets[#targets + 1] = entity
                end
            end
        end
    end
    local count = EntityFactory.delete_many(targets)
    Runtime.yield(0)
    return count
end

function MapEnvironment.set_weather(weather)
    weather = Util.trim(weather)
    if not weather or weather == "" then return false end

    Native.call("clear_override_weather")
    Native.call("set_weather_type_overtime_persist", weather, 3.0)
    return true
end

function MapEnvironment.set_timecycle(modifier, strength)
    modifier = Util.trim(modifier)
    if not modifier or modifier == "" then return false end

    Native.call("set_timecycle_modifier", modifier)
    Native.call("set_timecycle_modifier_strength", Util.to_number(strength, 1.0))
    return true
end

function MapEnvironment.begin_loading(coords)
    coords = Util.required_vector3(coords)
    local original_coords = EntityFactory.player_coords()

    local used_loading_coords = coords ~= nil
    if used_loading_coords then
        EntityFactory.teleport_player(coords, true)
        Runtime.yield(1400)
    end

    return {
        original_coords = original_coords,
        used_loading_coords = used_loading_coords,
    }
end

function MapEnvironment.finish_loading(state, reference_coords, teleport_to_reference)
    state = state or {}
    local reference = Util.required_vector3(reference_coords)
    local original = Util.required_vector3(state.original_coords)

    if teleport_to_reference and reference then
        EntityFactory.teleport_player(reference, true)
    elseif state.used_loading_coords and original then
        EntityFactory.teleport_player(original, true)
    end

    Runtime.yield(200)
    Native.call("do_screen_fade_in", 300)
end

function MapEnvironment.enable_interiors(interiors)
    local count = 0
    for _, entry in ipairs(interiors or {}) do
        local id = interior_id(entry)
        if interior_valid(id) then
            if entry.enable == false then
                if not Native.call("is_interior_disabled", id) then
                    Native.call("disable_interior", id, true)
                end
            else
                Native.call("pin_interior_in_memory", id)
                if Native.call("is_interior_disabled", id) then
                    Native.call("disable_interior", id, false)
                end
                for _, prop in ipairs(entry.props or {}) do
                    local name = interior_prop_name(prop)
                    if name and name ~= "" then
                        if prop.enable == false then
                            Native.call("deactivate_interior_entity_set", id, name)
                        else
                            Native.call("activate_interior_entity_set", id, name)
                        end
                    end
                end
                Native.call("refresh_interior", id)
            end
            count = count + 1
        end
    end
    return count
end

function MapEnvironment.cap_interiors(interiors)
    local count = 0
    for _, entry in ipairs(interiors or {}) do
        local id = interior_id(entry)
        if interior_valid(id) then
            Native.call("cap_interior", id, entry.cap ~= false)
            count = count + 1
        end
    end
    return count
end

function MapEnvironment.apply_interiors(environment)
    environment = environment or {}
    return MapEnvironment.enable_interiors(environment.InteriorsToEnable)
        + MapEnvironment.cap_interiors(environment.InteriorsToCap)
end

return MapEnvironment
