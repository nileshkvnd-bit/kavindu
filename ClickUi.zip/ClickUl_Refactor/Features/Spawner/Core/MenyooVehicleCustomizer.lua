local MenyooVehicleCustomizer = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local VehicleAttributes = require("ClickUl_Refactor.Features.Spawner.Core.VehicleAttributes")
local VehicleRuntime = require("ClickUl_Refactor.Features.Spawner.Core.VehicleRuntime")

local WHEELS_INVISIBLE_FORCE <const> = math.huge
local WHEELS_INVISIBLE_STEP_DELAY_MS <const> = 100

local DOOR_INDICES <const> = {
    FrontLeftDoor = 0,
    FrontRightDoor = 1,
    BackLeftDoor = 2,
    BackRightDoor = 3,
    Hood = 4,
    Trunk = 5,
    Trunk2 = 6,
}

local TYRE_INDICES <const> = {
    FrontLeft = 0,
    FrontRight = 1,
    BackLeft = 4,
    BackRight = 5,
}

local function tyre_index(key)
    if type(key) == "number" then return key end
    return TYRE_INDICES[key]
end

local function apply_door_states(vehicle, open_doors, broken_doors)
    if type(open_doors) == "table" then
        for door, open in pairs(open_doors) do
            local index = DOOR_INDICES[door] or Util.to_number(door, nil)
            if index then
                if Util.to_boolean(open) then
                    Native.call("set_vehicle_door_open", vehicle, index, false, true)
                else
                    Native.call("set_vehicle_door_shut", vehicle, index, true)
                end
            end
        end
    end

    if type(broken_doors) == "table" then
        for door, broken in pairs(broken_doors) do
            local index = DOOR_INDICES[door] or Util.to_number(door, nil)
            if index and Util.to_boolean(broken) then
                Native.call("set_door_allowed_to_be_broken_off", vehicle, index, true)
                Native.call("set_vehicle_door_broken", vehicle, index, true)
            end
        end
    end
end

local function apply_flat_door_states(vehicle, doors)
    if type(doors) ~= "table" then return end
    for door, state in pairs(doors) do
        local index = DOOR_INDICES[door] or Util.to_number(door, nil)
        local value = Util.to_number(state, 0)
        if index then
            if value == 0 then
                Native.call("set_vehicle_door_shut", vehicle, index, false)
            elseif value == 1 or value == 2 then
                Native.call("set_vehicle_door_open", vehicle, index, false, false)
            elseif value == 3 then
                Native.call("set_vehicle_door_broken", vehicle, index, true)
            end
        end
    end
end

local function apply_burst_tyres(vehicle, tyres)
    if type(tyres) ~= "table" then return end
    for tyre, bursted in pairs(tyres) do
        local index = tyre_index(tyre)
        if index and Util.to_boolean(bursted) then
            Native.call("set_vehicle_tyres_can_burst", vehicle, true)
            Native.call("set_vehicle_tyre_burst", vehicle, index, true, 1000.0)
        end
    end
end

local function apply_flat_tyre_states(vehicle, tyres)
    if type(tyres) ~= "table" then return end
    for tyre, bursted in pairs(tyres) do
        local index = tyre_index(tyre)
        if index then
            if bursted == true or bursted == 1 or bursted == "true" then
                Native.call("set_vehicle_tyres_can_burst", vehicle, true)
                Native.call("set_vehicle_tyre_burst", vehicle, index, true, 1000.0)
            else
                Native.call("set_vehicle_tyre_fixed", vehicle, index)
            end
        end
    end
end

local function apply_wheels_invisible(vehicle)
    Request.control(vehicle, true)
    Native.call("set_vehicle_forward_speed", vehicle, WHEELS_INVISIBLE_FORCE)
    Runtime.yield(WHEELS_INVISIBLE_STEP_DELAY_MS)

    Native.call("set_vehicle_cheat_power_increase", vehicle, WHEELS_INVISIBLE_FORCE)
    Native.call("modify_vehicle_top_speed", vehicle, WHEELS_INVISIBLE_FORCE)
    Native.call(
        "apply_force_to_entity",
        vehicle,
        1,
        0.0,
        0.0,
        -WHEELS_INVISIBLE_FORCE,
        0.0,
        0.0,
        0.0,
        0,
        true,
        true,
        true,
        false,
        true
    )
    Runtime.yield(WHEELS_INVISIBLE_STEP_DELAY_MS)

    VehicleRuntime.restore_power_modifiers(vehicle)
end

function MenyooVehicleCustomizer.apply(vehicle, attrs)
    if not EntityFactory.exists(vehicle) or type(attrs) ~= "table" then return false end
    VehicleAttributes.apply(vehicle, attrs.vehicle_attributes or {}, {
        toggle_tire_smoke_mod = false,
    })

    apply_flat_tyre_states(vehicle, attrs.tyre_states)
    apply_burst_tyres(vehicle, attrs.burst_tyres)
    if attrs.reduced_grip ~= nil then Native.call("set_vehicle_reduce_grip", vehicle, Util.to_boolean(attrs.reduced_grip)) end
    if attrs.engine_sound_name and attrs.engine_sound_name ~= "" then Native.call("force_use_audio_game_object", vehicle, tostring(attrs.engine_sound_name)) end
    if Util.to_boolean(attrs.wheels_invisible) then apply_wheels_invisible(vehicle) end
    VehicleRuntime.apply_modifiers(vehicle, attrs.runtime_modifiers)
    apply_flat_door_states(vehicle, attrs.doors)
    apply_door_states(vehicle, attrs.doors_open, attrs.doors_broken)

    return true
end

return MenyooVehicleCustomizer
