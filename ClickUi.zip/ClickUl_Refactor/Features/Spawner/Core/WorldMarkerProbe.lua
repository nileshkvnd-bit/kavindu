local WorldMarkerProbe = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local SHAPE_TEST_COMPLETE <const> = 2
local INTERSECT_EVERYTHING <const> = 511
local pointer_scr_vec3 <const> = Pointer.scr_vec3

function WorldMarkerProbe.clear_los(start_coords, end_coords, ignore_entity, flags)
    start_coords = Util.required_vector3(start_coords)
    end_coords = Util.required_vector3(end_coords)
    if not start_coords or not end_coords then return false end

    local handle = Native.call(
        "start_expensive_synchronous_shape_test_los_probe",
        start_coords.x,
        start_coords.y,
        start_coords.z,
        end_coords.x,
        end_coords.y,
        end_coords.z,
        flags or INTERSECT_EVERYTHING,
        ignore_entity or 0,
        7
    )
    if not handle or handle == 0 then return false end

    local hit = Pointer.int()
    local end_point = pointer_scr_vec3()
    local normal = pointer_scr_vec3()
    local entity_hit = Pointer.int()
    local ok, result = xpcall(function()
        local state = Native.call("get_shape_test_result", handle, hit, end_point, normal, entity_hit)
        if state ~= SHAPE_TEST_COMPLETE then return false end
        return Pointer.int_value(hit, 0) == 0
    end, debug.traceback)
    Pointer.free(hit)
    Pointer.free(end_point)
    Pointer.free(normal)
    Pointer.free(entity_hit)
    if not ok then error(result, 0) end
    return result
end

function WorldMarkerProbe.camera_coords()
    return Util.vector3(Native.call("get_final_rendered_cam_coord"))
end

return WorldMarkerProbe
