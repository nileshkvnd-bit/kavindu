local WorldMarkerText = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function text_value(value)
    value = tostring(value or "")
    if value == "" then return nil end
    return value
end

function WorldMarkerText.screen_position(coords)
    coords = Util.required_vector3(coords)
    if not coords then return nil end

    local x = Pointer.float()
    local y = Pointer.float()
    local ok, result = xpcall(function()
        local visible = Native.call("get_screen_coord_from_world_coord", coords.x, coords.y, coords.z, x, y)
        if visible ~= true then return nil end
        return {
            x = Pointer.float_value(x, 0.0),
            y = Pointer.float_value(y, 0.0),
        }
    end, debug.traceback)
    Pointer.free(x)
    Pointer.free(y)
    if not ok then error(result, 0) end
    return result
end

function WorldMarkerText.draw_screen(text, x, y, options)
    text = text_value(text)
    if not text then return false end
    options = options or {}

    Native.call("set_text_font", Util.to_number(options.font, 7))
    Native.call("set_text_scale", Util.to_number(options.scale_x, 0.3), Util.to_number(options.scale_y, 0.3))
    Native.call("set_text_centre", options.center ~= false)
    if options.outline ~= false then Native.call("set_text_outline") end
    local colour = options.colour or options.color or {}
    Native.call(
        "set_text_colour",
        Util.to_number(colour.r or colour.R, 255),
        Util.to_number(colour.g or colour.G, 255),
        Util.to_number(colour.b or colour.B, 255),
        Util.to_number(colour.a or colour.A, 255)
    )
    Native.call("begin_text_command_display_text", "STRING")
    Native.call("add_text_component_substring_player_name", text)
    Native.call("end_text_command_display_text", x, y, 0)
    return true
end

function WorldMarkerText.draw_world(text, coords, options)
    local screen = WorldMarkerText.screen_position(coords)
    if not screen then return false end
    return WorldMarkerText.draw_screen(text, screen.x, screen.y, options)
end

return WorldMarkerText
