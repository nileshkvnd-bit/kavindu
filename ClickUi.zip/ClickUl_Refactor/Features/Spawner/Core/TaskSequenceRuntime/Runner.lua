local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local ctx = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Context")
local Types = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Types")
local BasicTasks = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.BasicTasks")
local FxTasks = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.FxTasks")
local PedTasks = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.PedTasks")
local VehicleTasks = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.VehicleTasks")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")

local Runner = {}
local active_states = {}
local record_states = {}

local TASK_DEFAULTS = {
    [Types.SNAP_TASKS] = { duration = -1, keep_after = -2, looped = false },
    [Types.END_SEQUENCE] = { duration = -1, keep_after = -2, looped = false },
    [Types.NOTHING] = { duration = 22000, keep_after = -2, looped = false },
    [Types.PAUSE] = { duration = 10000, keep_after = 0, looped = false },
    [Types.USE_PHONE] = { duration = 10000, keep_after = 0, looped = false },
    [Types.WRITHE] = { duration = 10000, keep_after = 0, looped = false },
    [Types.GO_TO_COORD] = { duration = 10000, keep_after = 0, looped = false },
    [Types.FOLLOW_ROUTE] = { duration = 40000, keep_after = -2, looped = false },
    [Types.PATROL_IN_RANGE] = { duration = 10000, keep_after = -2, looped = false },
    [Types.WANDER_FREELY] = { duration = 10000, keep_after = -2, looped = false },
    [Types.SCENARIO] = { duration = 10000, keep_after = -2, looped = false },
    [Types.FIGHT_HATED_TARGETS] = { duration = 10000, keep_after = -2, looped = false },
    [Types.SPEAK_TO_PED] = { duration = 10000, keep_after = -2, looped = false },
    [Types.FLEE_FROM_COORD] = { duration = 10000, keep_after = 0, looped = false },
    [Types.SPEECH] = { duration = -2, keep_after = -2, looped = false },
    [Types.NEAREST_APPROPRIATE_ACTION] = { duration = 10000, keep_after = -2, looped = false },
    [Types.SLIDE_TO_COORD] = { duration = 10000, keep_after = -2, looped = false },
    [Types.SEEK_COVER_AT_COORD] = { duration = 10000, keep_after = 0, looped = false },
    [Types.FACE_DIRECTION] = { duration = 1000, keep_after = -2, looped = false },
    [Types.FACE_ENTITY] = { duration = 1000, keep_after = -2, looped = false },
    [Types.TELEPORT_TO_COORD] = { duration = -2, keep_after = -2, looped = false },
    [Types.FOLLOW_ENTITY] = { duration = 10000, keep_after = 0, looped = false },
    [Types.THROW_PROJECTILE] = { duration = 1000, keep_after = -2, looped = false },
    [Types.ACHIEVE_PUSH_FORCE] = { duration = -2, keep_after = -2, looped = false },
    [Types.FREEZE_IN_PLACE] = { duration = -2, keep_after = -2, looped = false },
    [Types.EMPTY_VEHICLE] = { duration = -1, keep_after = -2, looped = false },
    [Types.DRIVE_WANDER] = { duration = 10000, keep_after = -2, looped = false },
    [Types.DRIVE_TO_COORD] = { duration = 10000, keep_after = -2, looped = false },
    [Types.DRIVE_FOLLOW_ENTITY] = { duration = 10000, keep_after = -2, looped = false },
    [Types.DRIVE_LAND_PLANE] = { duration = 10000, keep_after = -2, looped = false },
    [Types.CHANGE_OPACITY] = { duration = -2, keep_after = -2, looped = false },
    [Types.PLAY_ANIM] = { duration = 10000, keep_after = 0, looped = false },
    [Types.FIGHT_PED] = { duration = 10000, keep_after = 0, looped = false },
    [Types.ENTER_VEHICLE] = { duration = 3000, keep_after = 1, looped = false },
    [Types.EXIT_VEHICLE] = { duration = -1, keep_after = -2, looped = false },
    [Types.WARP_INTO_VEHICLE] = { duration = -2, keep_after = -2, looped = false },
    [Types.ACHIEVE_VEHICLE_FORWARD_SPEED] = { duration = 10000, keep_after = -2, looped = true },
    [Types.ACHIEVE_VELOCITY] = { duration = 1000, keep_after = -2, looped = true },
    [Types.OSCILLATE_TO_POINT] = { duration = 5000, keep_after = -2, looped = true },
    [Types.OSCILLATE_TO_ENTITY] = { duration = 5000, keep_after = -2, looped = true },
    [Types.PTFX] = { duration = 1000, keep_after = -2, looped = true },
    [Types.LOOK_AT_COORD] = { duration = 10000, keep_after = 0, looped = false },
    [Types.LOOK_AT_ENTITY] = { duration = 10000, keep_after = 0, looped = false },
    [Types.SHOOT_AT_COORD] = { duration = 1000, keep_after = -2, looped = false },
    [Types.SHOOT_AT_ENTITY] = { duration = 5000, keep_after = 0, looped = false },
    [Types.CHANGE_TEXTURE_VARIATION] = { duration = -2, keep_after = -2, looped = false },
    [Types.SET_HEALTH] = { duration = -2, keep_after = -2, looped = false },
    [Types.SET_ACTIVE_WEAPON] = { duration = -2, keep_after = -2, looped = false },
    [Types.ROTATE] = { duration = -2, keep_after = -2, looped = false },
    [Types.AIM_AT_COORD] = { duration = 1000, keep_after = -2, looped = false },
    [Types.AIM_AT_ENTITY] = { duration = 5000, keep_after = 0, looped = false },
    [Types.ADD_BLIP] = { duration = -2, keep_after = -2, looped = false },
    [Types.REMOVE_BLIP] = { duration = -1, keep_after = -2, looped = false },
}

local HANDLERS = {
    [Types.SNAP_TASKS] = BasicTasks.run_snap_tasks_task,
    [Types.END_SEQUENCE] = BasicTasks.run_end_sequence_task,
    [Types.NOTHING] = function() return nil end,
    [Types.PAUSE] = BasicTasks.run_pause_task,
    [Types.USE_PHONE] = BasicTasks.run_use_phone_task,
    [Types.WRITHE] = PedTasks.run_writhe_task,
    [Types.GO_TO_COORD] = PedTasks.run_go_to_coord_task,
    [Types.FOLLOW_ROUTE] = PedTasks.run_follow_route_task,
    [Types.PATROL_IN_RANGE] = PedTasks.run_patrol_in_range_task,
    [Types.WANDER_FREELY] = PedTasks.run_wander_freely_task,
    [Types.SCENARIO] = PedTasks.run_scenario_task,
    [Types.FIGHT_HATED_TARGETS] = PedTasks.run_fight_hated_targets_task,
    [Types.FIGHT_PED] = PedTasks.run_fight_ped_task,
    [Types.SPEAK_TO_PED] = PedTasks.run_speak_to_ped_task,
    [Types.PLAY_ANIM] = PedTasks.run_play_anim_task,
    [Types.FLEE_FROM_COORD] = PedTasks.run_flee_from_coord_task,
    [Types.SPEECH] = PedTasks.run_speech_task,
    [Types.NEAREST_APPROPRIATE_ACTION] = PedTasks.run_nearest_appropriate_action_task,
    [Types.SLIDE_TO_COORD] = PedTasks.run_slide_to_coord_task,
    [Types.SEEK_COVER_AT_COORD] = PedTasks.run_seek_cover_at_coord_task,
    [Types.FACE_DIRECTION] = PedTasks.run_face_direction_task,
    [Types.FACE_ENTITY] = PedTasks.run_face_entity_task,
    [Types.TELEPORT_TO_COORD] = BasicTasks.run_teleport_to_coord_task,
    [Types.FOLLOW_ENTITY] = PedTasks.run_follow_entity_task,
    [Types.THROW_PROJECTILE] = PedTasks.run_throw_projectile_task,
    [Types.ACHIEVE_VELOCITY] = BasicTasks.run_achieve_velocity_task,
    [Types.ACHIEVE_PUSH_FORCE] = BasicTasks.run_achieve_push_force_task,
    [Types.OSCILLATE_TO_POINT] = BasicTasks.run_oscillate_to_point_task,
    [Types.FREEZE_IN_PLACE] = BasicTasks.run_freeze_in_place_task,
    [Types.ACHIEVE_VEHICLE_FORWARD_SPEED] = VehicleTasks.run_achieve_vehicle_forward_speed_task,
    [Types.ENTER_VEHICLE] = VehicleTasks.run_enter_vehicle_task,
    [Types.EXIT_VEHICLE] = VehicleTasks.run_exit_vehicle_task,
    [Types.WARP_INTO_VEHICLE] = VehicleTasks.run_warp_into_vehicle_task,
    [Types.EMPTY_VEHICLE] = VehicleTasks.run_empty_vehicle_task,
    [Types.DRIVE_WANDER] = VehicleTasks.run_drive_wander_task,
    [Types.DRIVE_TO_COORD] = VehicleTasks.run_drive_to_coord_task,
    [Types.DRIVE_FOLLOW_ENTITY] = VehicleTasks.run_drive_follow_entity_task,
    [Types.DRIVE_LAND_PLANE] = VehicleTasks.run_drive_land_plane_task,
    [Types.CHANGE_OPACITY] = BasicTasks.run_change_opacity_task,
    [Types.PTFX] = FxTasks.run_ptfx_task,
    [Types.LOOK_AT_COORD] = PedTasks.run_look_at_coord_task,
    [Types.LOOK_AT_ENTITY] = PedTasks.run_look_at_entity_task,
    [Types.SHOOT_AT_COORD] = PedTasks.run_shoot_at_coord_task,
    [Types.SHOOT_AT_ENTITY] = PedTasks.run_shoot_at_entity_task,
    [Types.CHANGE_TEXTURE_VARIATION] = BasicTasks.run_change_texture_variation_task,
    [Types.SET_HEALTH] = BasicTasks.run_set_health_task,
    [Types.SET_ACTIVE_WEAPON] = BasicTasks.run_set_active_weapon_task,
    [Types.ROTATE] = BasicTasks.run_rotate_task,
    [Types.OSCILLATE_TO_ENTITY] = BasicTasks.run_oscillate_to_entity_task,
    [Types.AIM_AT_COORD] = PedTasks.run_aim_at_coord_task,
    [Types.AIM_AT_ENTITY] = PedTasks.run_aim_at_entity_task,
    [Types.ADD_BLIP] = BasicTasks.run_add_blip_task,
    [Types.REMOVE_BLIP] = BasicTasks.run_remove_blip_task,
}

local END_HANDLERS = {
    [Types.PTFX] = FxTasks.end_ptfx_task,
    [Types.LOOK_AT_COORD] = PedTasks.end_look_at_task,
    [Types.LOOK_AT_ENTITY] = PedTasks.end_look_at_task,
}

local function task_defaults(task)
    return TASK_DEFAULTS[ctx.task_type(task)] or {}
end

local function task_duration(task)
    local defaults = task_defaults(task)
    return ctx.Util.to_number(task and task.Duration, defaults.duration or 1000)
end

local function task_keep_after(task)
    local defaults = task_defaults(task)
    return ctx.Util.to_number(task and task.KeepTaskRunningAfterTime, defaults.keep_after or -2)
end

local function task_is_looped(task)
    if task and task.IsLoopedTask ~= nil then return task.IsLoopedTask == true end
    return task_defaults(task).looped == true
end

local function run_handler(state, task)
    local handler = HANDLERS[ctx.task_type(task)]
    if not handler then return "task_type_unsupported" end
    return handler(state.entity, task, state.handle_map)
end

local function run_end_handler(state, task)
    local handler = END_HANDLERS[ctx.task_type(task)]
    if handler then return handler(state.entity, task, state.handle_map) end
    return nil
end

local function activate_state(state)
    if #state.tasks == 0 then
        state.active = false
        state.progress = 0
        return state
    end

    state.active = true
    state.just_jumped = true
    state.progress = 1
    state.timer = Runtime.get_tick_count() + task_duration(state.tasks[1])
    return state
end

local function update_record_from_state(state, active)
    local record = state and state.record
    if not record or record_states[record] ~= state then return end

    record.active = active == true
    record.first_error = state.first_error
    if not record.active then record_states[record] = nil end
end

function Runner.create_state(entity, sequence, handle_map)
    local state = {
        entity = entity,
        sequence = sequence,
        tasks = type(sequence) == "table" and sequence.tasks or {},
        handle_map = handle_map,
        active = false,
        progress = 0,
        timer = 0,
        just_jumped = false,
        first_error = nil,
        thread_id = nil,
    }
    return activate_state(state)
end

function Runner.stop(state)
    if type(state) ~= "table" then return end
    state.active = false
    state.progress = 0
    state.just_jumped = false
    active_states[state] = nil
    update_record_from_state(state, false)
    if state.thread_id then
        Runtime.remove_thread(state.thread_id)
        state.thread_id = nil
    end
end

local function finish_sequence(state)
    state.active = false
    state.progress = 0
    state.just_jumped = false
    update_record_from_state(state, false)
    if not state.thread_id then active_states[state] = nil end
end

function Runner.tick_once(state)
    if type(state) ~= "table" or not state.active or #state.tasks == 0 then return nil end
    if state.progress < 1 or state.progress > #state.tasks then state.progress = 1 end

    local task = state.tasks[state.progress]
    if state.just_jumped or task_is_looped(task) then
        local err = run_handler(state, task)
        state.first_error = state.first_error or err
        state.just_jumped = false
        if ctx.task_type(task) == Types.END_SEQUENCE then
            finish_sequence(state)
            return err
        end
    end

    if Runtime.get_tick_count() > state.timer then
        if task_keep_after(task) <= 0 then
            local err = run_end_handler(state, task)
            state.first_error = state.first_error or err
        end

        local next_task_index = state.progress + 1
        if next_task_index > #state.tasks then next_task_index = 1 end
        state.just_jumped = true
        state.progress = state.progress + 1
        state.timer = Runtime.get_tick_count() + task_duration(state.tasks[next_task_index])
    end

    if state.progress > #state.tasks then activate_state(state) end
    return state.first_error
end

local function schedule(state)
    if not state.active then return end
    local thread_id
    thread_id = Runtime.create_thread(function()
        if state.active then Runner.tick_once(state) end
        if state.active then return end

        local current_thread = state.thread_id
        state.thread_id = nil
        active_states[state] = nil
        update_record_from_state(state, false)
        if current_thread then Runtime.remove_thread(current_thread) end
    end)
    state.thread_id = thread_id
end

local function start_record_state(record)
    if type(record) ~= "table" or type(record.sequence) ~= "table" then return nil end

    local active_state = record_states[record]
    if active_state then Runner.stop(active_state) end

    local state = Runner.create_state(record.entity, record.sequence, record.handle_map)
    state.record = record
    record_states[record] = state
    record.active = state.active
    record.first_error = nil

    if state.active then active_states[state] = true end
    local first_error = Runner.tick_once(state)
    record.active = state.active
    record.first_error = first_error or state.first_error
    if not state.active then record_states[record] = nil end
    schedule(state)
    return first_error, state
end

function Runner.register(entity, sequence, handle_map)
    if type(sequence) ~= "table" then return nil end

    return SpawnRegistry.add_task_sequence({
        entity = entity,
        sequence = sequence,
        handle_map = handle_map,
        active = false,
        first_error = nil,
    })
end

function Runner.start(entity, sequence, handle_map)
    local record = Runner.register(entity, sequence, handle_map)
    if not record or sequence.autoStart == false then return nil, nil, record end

    local first_error, state = start_record_state(record)
    return first_error, state, record
end

function Runner.start_many(records, handle_map)
    local first_error = nil
    local states = {}
    for _, record in ipairs(records or {}) do
        local error, state = Runner.start(record.handle, record.sequence, handle_map)
        first_error = first_error or error
        if state then states[#states + 1] = state end
    end
    return first_error, states
end

function Runner.registered()
    return SpawnRegistry.task_sequences()
end

local function live_record(target)
    local index = tonumber(target)
    if not index then return nil end
    return SpawnRegistry.task_sequence_records()[index]
end

function Runner.start_registered(target)
    local record = live_record(target)
    if not record then return nil end
    return start_record_state(record)
end

function Runner.start_all_registered()
    local first_error = nil
    local states = {}
    for _, record in ipairs(SpawnRegistry.task_sequence_records()) do
        local error, state = start_record_state(record)
        first_error = first_error or error
        if state then states[#states + 1] = state end
    end
    return first_error, states
end

local function stop_record(record)
    if not record then return 0 end

    local state = record_states[record]
    if state then Runner.stop(state) end
    if record.entity and record.entity ~= 0 and ctx.Game.entity_exists(record.entity) and ctx.Native.call("is_entity_a_ped", record.entity) then
        ctx.Native.call("task_clear_look_at", record.entity)
        ctx.Native.call("clear_ped_tasks_immediately", record.entity)
    end
    record.active = false
    record.first_error = nil
    return 1
end

function Runner.stop_registered(target)
    return stop_record(live_record(target))
end

function Runner.stop_all_registered()
    local count = 0
    for _, record in ipairs(SpawnRegistry.task_sequence_records()) do
        count = count + stop_record(record)
    end
    return count
end

function Runner.clear_for_entities(entities)
    if type(entities) ~= "table" then return 0 end

    local entity_set = {}
    for _, entity in ipairs(entities) do
        if entity and entity ~= 0 then entity_set[entity] = true end
    end

    local removed_records = 0
    local remaining_records = {}
    for _, record in ipairs(SpawnRegistry.task_sequence_records()) do
        if entity_set[record.entity] then
            removed_records = removed_records + stop_record(record)
        else
            remaining_records[#remaining_records + 1] = record
        end
    end
    SpawnRegistry.replace_task_sequences(remaining_records)

    local states = {}
    for state in pairs(active_states) do
        if entity_set[state.entity] then states[#states + 1] = state end
    end

    local orphan_states = 0
    for _, state in ipairs(states) do
        orphan_states = orphan_states + 1
        Runner.stop(state)
    end
    return removed_records + orphan_states
end

function Runner.reset()
    local states = {}
    for state in pairs(active_states) do
        states[#states + 1] = state
    end
    for _, state in ipairs(states) do
        Runner.stop(state)
    end
    record_states = {}
    SpawnRegistry.clear_task_sequences()
end

return Runner
