local ctx = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Context")
local Types = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Types")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")

local VehicleTasks = {}

local Game = ctx.Game
local Native = ctx.Native
local Util = ctx.Util
local current_vehicle = ctx.current_vehicle
local mapped_entity = ctx.mapped_entity
local target_entity = ctx.target_entity
local task_lifetime_duration_ms = ctx.task_lifetime_duration_ms

function VehicleTasks.run_warp_into_vehicle_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local vehicle_key = task.VehicleInitHandle or task.vehicle_init_handle
    local vehicle = mapped_entity(vehicle_key, handle_map)
    if not vehicle then return "task_missing_vehicle" end

    if not Game.entity_exists(target) or not Game.entity_exists(vehicle) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end
    if not Native.call("is_entity_a_vehicle", vehicle) then return nil end
    local seat = Util.to_number(task.SeatIndex, -1)
    Attachment.seat_ped_in_vehicle(target, vehicle, seat)
    return nil
end

function VehicleTasks.run_enter_vehicle_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local vehicle = mapped_entity(task.VehicleInitHandle, handle_map)
    if not vehicle then return "task_missing_vehicle" end

    if not Game.entity_exists(target) or not Game.entity_exists(vehicle) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end
    if not Native.call("is_entity_a_vehicle", vehicle) then return nil end

    local seat = Util.to_number(task.SeatIndex, -1)
    seat = Attachment.vehicle_seat(vehicle, seat, -1)
    Native.call("task_enter_vehicle", target, vehicle, task_lifetime_duration_ms(task, 3000) + 200, seat, 1.0, 1, 0)
    return nil
end

function VehicleTasks.run_exit_vehicle_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local vehicle = current_vehicle(target)
    if vehicle then
        Native.call("task_leave_vehicle", target, vehicle, 0)
    else
        Native.call("task_leave_any_vehicle", target, 0, 0)
    end
    return nil
end

function VehicleTasks.run_achieve_vehicle_forward_speed_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local speed = Util.to_number(task.SpeedInKmph, 10.0) / 3.6
    local on_ground_only = task.OnGroundOnly == true

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_vehicle", target) then return nil end

    local function apply_forward_speed()
        if not Game.entity_exists(target) then return false end
        if on_ground_only and not Native.call("is_vehicle_on_all_wheels", target) then return true end

        Native.call("set_vehicle_forward_speed", target, speed)
        return true
    end

    apply_forward_speed()
    return nil
end

function VehicleTasks.run_drive_wander_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local speed = Util.to_number(task.SpeedInKmph, 10.0) / 3.6

    local vehicle = current_vehicle(target)
    if not vehicle then return nil end

    Native.call("set_drive_task_max_cruise_speed", target, speed + 1.0)
    Native.call("task_vehicle_drive_wander", target, vehicle, speed, Util.to_number(task.DrivingStyle, Types.NORMAL_DRIVING_STYLE))
    return nil
end

function VehicleTasks.run_drive_to_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local destination = Util.vector3(task.Destination)
    local speed = Util.to_number(task.SpeedInKmph, 10.0) / 3.6
    local driving_style = Util.to_number(task.DrivingStyle, Types.NORMAL_DRIVING_STYLE)

    local vehicle = current_vehicle(target)
    if not vehicle then return nil end

    Native.call("set_drive_task_max_cruise_speed", target, speed + 1.0)
    local model = Native.call("get_entity_model", vehicle)
    if Native.call("is_this_model_a_heli", model) then
        Native.call("task_heli_mission", target, vehicle, 0, 0, destination.x, destination.y, destination.z, 4, speed, 50.0, -1.0, 10000, 100, -1.0, 0)
        return nil
    end

    if Native.call("is_this_model_a_plane", model) then
        Native.call("task_plane_mission", target, vehicle, 0, 0, destination.x, destination.y, destination.z, 4, speed, 50.0, -1.0, 100, 200, 0)
        return nil
    end

    if Native.call("is_this_model_a_boat", model) then
        Native.call("task_boat_mission", target, vehicle, 0, 0, destination.x, destination.y, destination.z, 4, speed, 786469, 10.0, 1071)
        return nil
    end

    Native.call(
        "task_vehicle_drive_to_coord_longrange",
        target,
        vehicle,
        destination.x,
        destination.y,
        destination.z,
        speed,
        driving_style,
        2.0
    )
    return nil
end

function VehicleTasks.run_drive_follow_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local follow_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not follow_target then return "task_missing_target" end

    local vehicle = current_vehicle(target)
    if not vehicle or not Game.entity_exists(follow_target) then return nil end

    Native.call(
        "task_vehicle_follow",
        target,
        vehicle,
        follow_target,
        Util.to_number(task.SpeedInKmph, 10.0) / 3.6,
        Util.to_number(task.DrivingStyle, Types.NORMAL_DRIVING_STYLE),
        math.floor(Util.to_number(task.MinDistance, 3.0))
    )
    return nil
end

function VehicleTasks.run_drive_land_plane_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local runway_start = Util.vector3(task.RunwayStart)
    local runway_end = Util.vector3(task.RunwayEnd)

    local vehicle = current_vehicle(target)
    if not vehicle then return nil end

    Native.call(
        "task_plane_land",
        target,
        vehicle,
        runway_start.x,
        runway_start.y,
        runway_start.z,
        runway_end.x,
        runway_end.y,
        runway_end.z
    )
    return nil
end

function VehicleTasks.run_empty_vehicle_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_vehicle", target) then return nil end

    Native.call("task_everyone_leave_vehicle", target)
    return nil
end

return VehicleTasks
