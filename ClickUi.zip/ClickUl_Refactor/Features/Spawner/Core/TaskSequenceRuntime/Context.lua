local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Pools = require("ClickUl_Refactor.Adapters.Pools")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local math_abs <const> = math.abs
local math_atan <const> = math.atan
local math_cos <const> = math.cos
local math_deg <const> = math.deg
local math_rad <const> = math.rad
local math_random <const> = math.random
local math_sin <const> = math.sin

local Context = {
    Runtime = Runtime,
    Game = Game,
    Native = Native,
    Pointer = Pointer,
    Request = Request,
    Pools = Pools,
    EntityFactory = EntityFactory,
    Ptfx = Ptfx,
    Util = Util,
    math_cos = math_cos,
    math_rad = math_rad,
    math_random = math_random,
    math_sin = math_sin,
}

local function task_type(task)
    return Util.to_number(task and task.Type, nil)
end

local function target_entity(default_entity)
    return default_entity
end

local function current_vehicle(ped)
    if not Game.entity_exists(ped) then return nil end
    if not Native.call("is_entity_a_ped", ped) then return nil end
    if not Native.call("is_ped_in_any_vehicle", ped, false) then return nil end

    local vehicle = Native.call("get_vehicle_ped_is_in", ped, false)
    if not Game.entity_exists(vehicle) then return nil end
    return vehicle
end

local function mapped_entity(handle, handle_map)
    if handle == nil then return nil end
    if tostring(handle):upper() == "PLAYER" then return EntityFactory.player_ped() end
    return handle_map and (handle_map[handle] or handle_map[tostring(handle)]) or nil
end

local function ptfx_data(task)
    return {
        AssetName = task.AssetName,
        EffectName = task.EffectName,
        Scale = task.Scale,
        Colour = task.Colour,
        RelativePosition = task.RelativePosition,
        RelativeRotation = task.RelativeRotation,
        AlphaSource = "blue",
    }
end

local function task_duration_ms(task, default_ms)
    local ms = Util.to_number(task and task.Duration, default_ms or 0)
    if not ms or ms < 0 then return 0 end
    return ms
end

local function task_lifetime_duration_ms(task, default_ms)
    if Util.to_number(task and task.KeepTaskRunningAfterTime, 0) > 0 then return -1 end
    return task_duration_ms(task, default_ms)
end

local function rotation_to_direction(rotation)
    local pitch = math_rad(Util.to_number(rotation.x, 0.0))
    local yaw = math_rad(Util.to_number(rotation.z, 0.0))
    local cos_pitch = math_abs(math_cos(pitch))
    return {
        x = -math_sin(yaw) * cos_pitch,
        y = math_cos(yaw) * cos_pitch,
        z = math_sin(pitch),
    }
end

local function add_rotation(base, delta)
    return {
        x = Util.to_float(base and base.x, 0.0) + Util.to_float(delta and delta.x, 0.0),
        y = Util.to_float(base and base.y, 0.0) + Util.to_float(delta and delta.y, 0.0),
        z = Util.to_float(base and base.z, 0.0) + Util.to_float(delta and delta.z, 0.0),
    }
end

local function task_heading_rotation(task)
    return {
        x = Util.to_float(task.Pitch, 0.0),
        y = 0.0,
        z = Util.to_float(task.Heading, 0.0),
    }
end

local function heading_between(source, destination)
    local delta_x = Util.to_number(destination.x, 0.0) - Util.to_number(source.x, 0.0)
    local delta_y = Util.to_number(destination.y, 0.0) - Util.to_number(source.y, 0.0)
    return math_deg(math_atan(-delta_x, delta_y))
end

local function squared_distance(a, b)
    local delta_x = Util.to_number(a.x, 0.0) - Util.to_number(b.x, 0.0)
    local delta_y = Util.to_number(a.y, 0.0) - Util.to_number(b.y, 0.0)
    local delta_z = Util.to_number(a.z, 0.0) - Util.to_number(b.z, 0.0)
    return delta_x * delta_x + delta_y * delta_y + delta_z * delta_z
end

local function entity_within_radius(source_coords, entity, radius)
    if radius < 0 then return false end

    local coords = Util.vector3(Native.get_entity_coords(entity, true))
    return squared_distance(source_coords, coords) <= radius * radius
end

local function task_position(task)
    return Util.vector3(task.TargetPos or task.Position or task.Coord or task.Destination)
end

local function task_rotation(task)
    return {
        x = Util.to_float(task.Pitch, 0.0),
        y = Util.to_float(task.Roll, 0.0),
        z = Util.to_float(task.Yaw, 0.0),
    }
end

Context.task_type = task_type
Context.target_entity = target_entity
Context.current_vehicle = current_vehicle
Context.mapped_entity = mapped_entity
Context.ptfx_data = ptfx_data
Context.task_duration_ms = task_duration_ms
Context.task_lifetime_duration_ms = task_lifetime_duration_ms
Context.rotation_to_direction = rotation_to_direction
Context.add_rotation = add_rotation
Context.task_heading_rotation = task_heading_rotation
Context.heading_between = heading_between
Context.entity_within_radius = entity_within_radius
Context.task_position = task_position
Context.task_rotation = task_rotation

return Context
