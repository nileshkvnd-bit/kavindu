local ctx = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Context")

local FxTasks = {}

local Runtime = ctx.Runtime
local Game = ctx.Game
local Ptfx = ctx.Ptfx
local ptfx_data = ctx.ptfx_data
local target_entity = ctx.target_entity
local Util = ctx.Util

local timers = setmetatable({}, { __mode = "k" })

function FxTasks.run_ptfx_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local data = ptfx_data(task)

    if not Game.entity_exists(target) then return nil end

    local duration = Util.to_number(task and task.Duration, 1000)
    if duration == -2 then
        Ptfx.start_non_looped(target, data)
        return nil
    end

    local now = Runtime.get_tick_count()
    local next_at = timers[task]
    if next_at and now <= next_at then return nil end

    Ptfx.start_non_looped(target, data)
    local interval = Util.to_number(task.Delay, 500)
    if interval <= 0 then
        timers[task] = now
    else
        timers[task] = now + interval
    end
    return nil
end

function FxTasks.end_ptfx_task(_, task)
    timers[task] = nil
    return nil
end

function FxTasks.reset()
    timers = setmetatable({}, { __mode = "k" })
end

return FxTasks
