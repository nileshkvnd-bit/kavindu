local ctx = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Context")
local Types = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Types")

local PedTasks = {}

local Game = ctx.Game
local Native = ctx.Native
local Request = ctx.Request
local Pools = ctx.Pools
local EntityFactory = ctx.EntityFactory
local Util = ctx.Util
local entity_within_radius = ctx.entity_within_radius
local heading_between = ctx.heading_between
local mapped_entity = ctx.mapped_entity
local target_entity = ctx.target_entity
local task_lifetime_duration_ms = ctx.task_lifetime_duration_ms
local task_position = ctx.task_position
local math_cos = ctx.math_cos
local math_floor = math.floor
local math_rad = ctx.math_rad
local math_random = ctx.math_random
local math_sin = ctx.math_sin

local function animation_duration(target, task, dict, name)
    if task.OverrideDurationToNormalSpeedAnimDuration ~= true then
        return Util.to_number(task.Duration, -1)
    end

    local seconds = Native.call("get_entity_anim_total_time", target, dict, name)
    if not seconds or seconds <= 0 then return Util.to_number(task.Duration, -1) end
    return math_floor(seconds * 1000.0 + 0.5)
end

local function fill_current_weapon_ammo(ped)
    local weapon = Native.call("get_selected_ped_weapon", ped)
    if not weapon or weapon == 0 then return end
    Native.call("set_ped_ammo", ped, weapon, 9999, 0)
    Native.call("set_ped_infinite_ammo", ped, true, weapon)
end

function PedTasks.run_play_anim_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local dict = task.AnimDict or task.anim_dict
    local name = task.AnimName or task.anim_name
    if not dict or not name then return "task_missing_anim" end

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end
    if not Request.anim(dict) then return nil end

    Native.call(
        "task_play_anim",
        target,
        dict,
        name,
        Util.to_number(task.Speed, 8.0),
        Util.to_number(task.SpeedMultiplier, -8.0),
        animation_duration(target, task, dict, name),
        Util.to_number(task.Flag, 1),
        0.0,
        task.LockPos == true,
        0,
        task.LockPos == true
    )
    return nil
end

function PedTasks.run_speech_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local speech_name = task.SpeechName or task.speech_name
    if not speech_name or speech_name == "" then return "task_missing_speech" end

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call(
        "play_ped_ambient_speech_with_voice_native",
        target,
        speech_name,
        task.VoiceName or task.voice_name or "",
        task.ParamName or task.param_name or "SPEECH_PARAMS_FORCE",
        false
    )
    return nil
end

function PedTasks.run_scenario_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local scenario = task.ScenarioName or task.scenario_name
    if not scenario or scenario == "" then return "task_missing_scenario" end

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end
    Native.call("task_start_scenario_in_place", target, scenario, 0, true)
    return nil
end

function PedTasks.run_writhe_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_writhe", target, EntityFactory.player_ped() or 0, task_lifetime_duration_ms(task, 10000), 0, 0, 0)
    return nil
end

function PedTasks.run_patrol_in_range_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local coord = task.Coord and Util.vector3(task.Coord) or Util.vector3(Native.get_entity_coords(target, true))
    Native.call("task_wander_in_area", target, coord.x, coord.y, coord.z, Util.to_number(task.Radius, 12.0), 1.0, 0.0)
    return nil
end

function PedTasks.run_wander_freely_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_wander_standard", target, 10.0, 10)
    return nil
end

function PedTasks.run_face_direction_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local position = Util.vector3(Native.get_entity_coords(target, true))
    local heading = math_rad(Util.to_number(task.Heading, 0.0))
    Native.call(
        "task_turn_ped_to_face_coord",
        target,
        position.x + math_cos(heading) * 2.0,
        position.y + math_sin(heading) * 2.0,
        position.z,
        task_lifetime_duration_ms(task, 1000) + 200
    )
    return nil
end

function PedTasks.run_face_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local face_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not face_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(face_target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_turn_ped_to_face_entity", target, face_target, task_lifetime_duration_ms(task, 1000) + 200)
    return nil
end

function PedTasks.run_speak_to_ped_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local speech_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not speech_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(speech_target) then return nil end
    if not Native.call("is_entity_a_ped", target) or not Native.call("is_entity_a_ped", speech_target) then return nil end

    Native.call("task_chat_to_ped", target, speech_target, 16, 0.0, 0.0, 0.0, 0.0, 0.0)
    return nil
end

function PedTasks.run_go_to_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local destination = Util.vector3(task.Destination)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local position = Util.vector3(Native.get_entity_coords(target, true))
    Native.call(
        "task_go_straight_to_coord",
        target,
        destination.x,
        destination.y,
        destination.z,
        Util.to_number(task.Speed, 1.0),
        task_lifetime_duration_ms(task, 10000),
        heading_between(position, destination),
        0.0
    )
    return nil
end

function PedTasks.run_follow_route_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local route = task.Route
    if type(route) ~= "table" or #route == 0 then return "task_missing_route" end

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_flush_route")
    for _, point in ipairs(route) do
        local coord = Util.vector3(point)
        Native.call("task_extend_route", coord.x, coord.y, coord.z)
    end
    Native.call("task_follow_point_route", target, Util.to_number(task.Speed, 1.0), 0)
    return nil
end

function PedTasks.run_slide_to_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local destination = Util.vector3(task.Destination)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call(
        "task_ped_slide_to_coord",
        target,
        destination.x,
        destination.y,
        destination.z,
        Util.to_number(task.Heading, 0.0),
        Util.to_number(task.Speed, 10.0)
    )
    return nil
end

function PedTasks.run_seek_cover_at_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local cover_pos = Util.vector3(task.CoverPos)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("set_ped_to_load_cover", target, true)
    Native.call("task_put_ped_directly_into_cover", target, cover_pos.x, cover_pos.y, cover_pos.z, task_lifetime_duration_ms(task, 10000), true, 0.5, true, true, 0, false)
    Native.call("set_ped_can_peek_in_cover", target, task.CanPeakInCover ~= false)
    Native.call("set_ped_combat_attributes", target, 34, true)
    return nil
end

function PedTasks.run_follow_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local follow_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not follow_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(follow_target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call(
        "task_follow_to_offset_of_entity",
        target,
        follow_target,
        math_random(-100, 100) / 100,
        math_random(-150, 50) / 100,
        0.0,
        Util.to_number(task.Speed, 1.0),
        task_lifetime_duration_ms(task, 10000),
        0.1,
        true
    )
    return nil
end

function PedTasks.run_throw_projectile_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local position = task_position(task)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_throw_projectile", target, position.x, position.y, position.z, 0, 0)
    return nil
end

function PedTasks.run_look_at_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local position = task_position(task)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_look_at_coord", target, position.x, position.y, position.z, task_lifetime_duration_ms(task, 10000), 0, 2)
    return nil
end

function PedTasks.run_look_at_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local look_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not look_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(look_target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_look_at_entity", target, look_target, task_lifetime_duration_ms(task, 10000), 0, 2)
    return nil
end

function PedTasks.end_look_at_task(entity, task, handle_map)
    if Util.to_number(task and task.KeepTaskRunningAfterTime, 0) ~= 0 then return nil end

    local target = target_entity(entity, task, handle_map)
    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_clear_look_at", target)
    return nil
end

function PedTasks.run_aim_at_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local position = task_position(task)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_aim_gun_at_coord", target, position.x, position.y, position.z, task_lifetime_duration_ms(task, 1000), false, false)
    return nil
end

function PedTasks.run_aim_at_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local aim_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not aim_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(aim_target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_aim_gun_at_entity", target, aim_target, task_lifetime_duration_ms(task, 5000), false)
    return nil
end

function PedTasks.run_shoot_at_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local position = task_position(task)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    fill_current_weapon_ammo(target)
    Native.call("task_shoot_at_coord", target, position.x, position.y, position.z, task_lifetime_duration_ms(task, 1000), Types.DEFAULT_FULL_AUTO_FIRING_PATTERN)
    return nil
end

function PedTasks.run_shoot_at_entity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local shoot_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not shoot_target then return "task_missing_target" end

    if not Game.entity_exists(target) or not Game.entity_exists(shoot_target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    fill_current_weapon_ammo(target)
    Native.call("task_shoot_at_entity", target, shoot_target, task_lifetime_duration_ms(task, 5000), Types.DEFAULT_FULL_AUTO_FIRING_PATTERN)
    return nil
end

function PedTasks.run_fight_ped_task(entity, task, handle_map)
    local combat_target = mapped_entity(task.TargetInitHandle, handle_map)
    if not combat_target then return "task_missing_target" end

    if not Game.entity_exists(entity) or not Game.entity_exists(combat_target) then return nil end
    if not Native.call("is_entity_a_ped", entity) or not Native.call("is_entity_a_ped", combat_target) then return nil end

    local duration = task_lifetime_duration_ms(task, 10000)
    if duration < 0 then
        Native.call("task_combat_ped", entity, combat_target, 0, 16)
    else
        Native.call("task_combat_ped_timed", entity, combat_target, duration, 0)
    end
    return nil
end

function PedTasks.run_fight_hated_targets_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local radius = Util.to_number(task.Radius, 12.0)
    local duration = task_lifetime_duration_ms(task, 10000)
    local source_coords = Util.vector3(Native.get_entity_coords(target, true))

    Native.run_task_sequence(target, function()
        if duration < 0 then
            Native.call("task_combat_hated_targets_around_ped", 0, radius, 0)
        else
            Native.call("task_combat_hated_targets_around_ped_timed", 0, radius, duration, 0)
        end

        local source_group = Native.call("get_ped_relationship_group_hash", target)
        for _, ped in ipairs(Pools.ped_handles(true)) do
            if ped ~= target and Game.entity_exists(ped) and entity_within_radius(source_coords, ped, radius) then
                local relationship = Native.call("get_relationship_between_peds", target, ped)
                if relationship ~= Types.PED_RELATIONSHIP_DISLIKE and relationship ~= Types.PED_RELATIONSHIP_HATE then
                    local target_group = Native.call("get_ped_relationship_group_hash", ped)
                    relationship = Native.call("get_relationship_between_groups", source_group, target_group)
                end

                if relationship == Types.PED_RELATIONSHIP_DISLIKE or relationship == Types.PED_RELATIONSHIP_HATE then
                    if duration < 0 then
                        Native.call("task_combat_ped", 0, ped, 0, 16)
                    else
                        Native.call("task_combat_ped_timed", 0, ped, duration, 0)
                    end
                end
            end
        end
    end)
    return nil
end

function PedTasks.run_flee_from_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local origin = Util.vector3(task.Origin)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_smart_flee_coord", target, origin.x, origin.y, origin.z, 100.0, task_lifetime_duration_ms(task, 10000), false, false)
    return nil
end

function PedTasks.run_nearest_appropriate_action_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    local position = Util.vector3(Native.get_entity_coords(target, true))
    local radius = Util.to_number(task.SearchRadius, 4.0)
    if task.Warp ~= false then
        Native.call("task_use_nearest_scenario_to_coord_warp", target, position.x, position.y, position.z, radius, 0)
    else
        Native.call("task_use_nearest_scenario_to_coord", target, position.x, position.y, position.z, radius, 0)
    end
    return nil
end

return PedTasks
