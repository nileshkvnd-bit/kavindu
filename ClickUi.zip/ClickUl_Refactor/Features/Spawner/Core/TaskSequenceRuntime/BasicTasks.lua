local ctx = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Context")
local Types = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Types")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")
local Blip = require("ClickUl_Refactor.Features.Spawner.Core.Blip")

local BasicTasks = {}

local Game = ctx.Game
local Native = ctx.Native
local Request = ctx.Request
local Util = ctx.Util
local EntityFactory = ctx.EntityFactory
local add_rotation = ctx.add_rotation
local rotation_to_direction = ctx.rotation_to_direction
local target_entity = ctx.target_entity
local task_duration_ms = ctx.task_duration_ms
local task_heading_rotation = ctx.task_heading_rotation
local task_lifetime_duration_ms = ctx.task_lifetime_duration_ms
local task_rotation = ctx.task_rotation

local function ensure_weapon_ammo(ped, weapon_hash)
    weapon_hash = Util.to_number(weapon_hash, 0)
    if weapon_hash == 0 then return nil, "task_missing_weapon" end
    if not Request.weapon(weapon_hash) then return nil, "weapon_request_failed" end
    Native.call("give_weapon_to_ped", ped, weapon_hash, 9999, false, true)
    Native.call("set_ped_ammo", ped, weapon_hash, 9999, 0)
    Native.call("set_ped_infinite_ammo", ped, true, weapon_hash)
    return weapon_hash
end

function BasicTasks.run_use_phone_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    if Util.to_number(task.KeepTaskRunningAfterTime, 0) > 0 then
        Native.call("task_use_mobile_phone", target, 1, 0)
        return nil
    end

    Native.call("task_use_mobile_phone_timed", target, task_duration_ms(task, 10000))
    return nil
end

function BasicTasks.run_end_sequence_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_clear_look_at", target)
    Native.call("clear_ped_tasks_immediately", target)
    return nil
end

function BasicTasks.run_snap_tasks_task(entity, task, handle_map)
    return BasicTasks.run_end_sequence_task(entity, task, handle_map)
end

function BasicTasks.run_pause_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end

    Native.call("task_pause", target, task_lifetime_duration_ms(task, 10000))
    return nil
end

function BasicTasks.run_set_health_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end

    Native.call("set_entity_health", target, Util.to_number(task.HealthValue, 500))
    return nil
end

function BasicTasks.run_set_active_weapon_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_a_ped", target) then return nil end
    if task.WeaponHash == nil then return "task_missing_weapon" end

    local weapon_hash, weapon_error = ensure_weapon_ammo(target, task.WeaponHash)
    if not weapon_hash then return weapon_error end
    Native.call("set_current_ped_weapon", target, weapon_hash, true)
    Native.call("set_ped_can_switch_weapon", target, false)
    return nil
end

function BasicTasks.run_freeze_in_place_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local freeze_type = Util.to_number(task.FreezeType, 0)

    if not Game.entity_exists(target) then return nil end

    if freeze_type == 0 then
        Native.call("freeze_entity_position", target, true)
    elseif freeze_type == 1 then
        Native.call("freeze_entity_position", target, false)
    elseif freeze_type == 2 then
        Native.call("freeze_entity_position", target, true)
        Native.call("freeze_entity_position", target, false)
    end
    return nil
end

function BasicTasks.run_change_opacity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local opacity = Util.to_number(task.OpacityValue, 269)

    if not Game.entity_exists(target) then return nil end

    if opacity == 269 then
        Native.call("reset_entity_alpha", target)
    else
        Native.call("set_entity_alpha", target, opacity, false)
    end
    return nil
end

function BasicTasks.run_achieve_velocity_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local magnitude = Util.to_number(task.Magnitude, 1.0)

    if not Game.entity_exists(target) then return nil end

    local function apply_velocity()
        if not Game.entity_exists(target) then return false end

        local rotation = task_heading_rotation(task)
        if task.IsRelative ~= false then
            rotation = add_rotation(Native.call("get_entity_rotation", target, 2), rotation)
        end

        local direction = rotation_to_direction(rotation)
        Native.call("set_entity_velocity", target, direction.x * magnitude, direction.y * magnitude, direction.z * magnitude)
        return true
    end

    apply_velocity()
    return nil
end

function BasicTasks.run_achieve_push_force_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local rotation = task_heading_rotation(task)
    local direction = rotation_to_direction(rotation)
    local magnitude = Util.to_number(task.Magnitude, 1.0)
    local offset = Util.vector3(task.OffsetVector)

    if not Game.entity_exists(target) then return nil end

    Native.call(
        "apply_force_to_entity",
        target,
        Util.to_number(task.ForceType, 1),
        direction.x * magnitude,
        direction.y * magnitude,
        direction.z * magnitude,
        offset.x,
        offset.y,
        offset.z,
        0,
        task.IsRelative == true,
        true,
        true,
        false,
        true
    )
    return nil
end

function BasicTasks.run_oscillate_to_point_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local point = Util.vector3(task.Point)
    local angular_frequency = Util.to_number(task.AngularFrequency, 0.4)
    local damp_ratio = Util.to_number(task.DampRatio, 0.1)
    local angular_frequency_sq = angular_frequency * angular_frequency
    local velocity_scale = 2.0 * angular_frequency * damp_ratio

    if not Game.entity_exists(target) then return nil end

    local function apply_oscillation()
        if not Game.entity_exists(target) then return false end

        local position = Util.vector3(Native.get_entity_coords(target, true))
        local velocity = Util.vector3(Native.call("get_entity_velocity", target))
        local force_x = (point.x - position.x) * angular_frequency_sq - velocity.x * velocity_scale
        local force_y = (point.y - position.y) * angular_frequency_sq - velocity.y * velocity_scale
        local force_z = (point.z - position.z) * angular_frequency_sq - velocity.z * velocity_scale + 0.1

        Native.call("apply_force_to_entity", target, 3, force_x, force_y, force_z, 0.0, 0.0, 0.0, 0, false, true, true, false, true)
        return true
    end

    apply_oscillation()
    return nil
end

function BasicTasks.run_oscillate_to_entity_task(entity, task, handle_map)
    local target = entity
    local oscillate_target = ctx.mapped_entity(task.TargetInitHandle, handle_map)
    if not oscillate_target then return "task_missing_target" end

    local offset = Util.vector3(task.OffsetVector)
    local angular_frequency = Util.to_number(task.AngularFrequency, 0.4)
    local damp_ratio = Util.to_number(task.DampRatio, 0.1)
    local angular_frequency_sq = angular_frequency * angular_frequency
    local velocity_scale = 2.0 * angular_frequency * damp_ratio

    if not Game.entity_exists(target) or not Game.entity_exists(oscillate_target) then return nil end

    local function apply_oscillation()
        if not Game.entity_exists(target) or not Game.entity_exists(oscillate_target) then return false end

        local position = Util.vector3(Native.get_entity_coords(target, true))
        local target_position = Util.vector3(Native.call(
            "get_offset_from_entity_in_world_coords",
            oscillate_target,
            offset.x,
            offset.y,
            offset.z
        ))
        local velocity = Util.vector3(Native.call("get_entity_velocity", target))
        local force_x = (target_position.x - position.x) * angular_frequency_sq - velocity.x * velocity_scale
        local force_y = (target_position.y - position.y) * angular_frequency_sq - velocity.y * velocity_scale
        local force_z = (target_position.z - position.z) * angular_frequency_sq - velocity.z * velocity_scale + 0.1

        Native.call("apply_force_to_entity", target, 3, force_x, force_y, force_z, 0.0, 0.0, 0.0, 0, false, true, true, false, true)
        return true
    end

    apply_oscillation()
    return nil
end

function BasicTasks.run_change_texture_variation_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end
    if not Native.call("is_entity_an_object", target) then return nil end

    Native.set_object_tint_index(target, Util.to_number(task.NewValue, 0))
    return nil
end

function BasicTasks.run_add_blip_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end

    local blip = Native.call("get_blip_from_entity", target)
    if blip and blip ~= 0 and Native.call("does_blip_exist", blip) then return nil end

    blip = Native.call("add_blip_for_entity", target)
    if not blip or blip == 0 then return nil end

    Native.call("set_blip_as_friendly", blip, task.IsFriendly == true)
    Native.call("set_blip_flashes", blip, task.IsFlashing == true)
    Native.call("set_blip_sprite", blip, Util.to_number(task.Icon, Types.DEFAULT_BLIP_ICON))
    Native.call("set_blip_scale", blip, Util.to_number(task.BlipScale or task.Scale, Types.DEFAULT_BLIP_SCALE))
    Native.call("set_blip_colour", blip, Util.to_number(task.BlipColour, Types.DEFAULT_BLIP_COLOUR))
    Native.call("set_blip_alpha", blip, Util.to_number(task.Alpha, Types.DEFAULT_BLIP_ALPHA))
    if task.Label and task.Label ~= "" then
        Native.call("begin_text_command_set_blip_name", "STRING")
        Native.call("add_text_component_substring_player_name", task.Label)
        Native.call("end_text_command_set_blip_name", blip)
    end
    Native.call("set_blip_as_short_range", blip, task.IsShortRange == true)
    Native.call("set_blip_route", blip, task.ShowRoute == true)
    if Util.to_number(task.ShowNumber, 0) ~= 0 then
        Native.call("show_number_on_blip", blip, Util.to_number(task.ShowNumber, 0))
    end
    return nil
end

function BasicTasks.run_remove_blip_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end

    local blip = Native.call("get_blip_from_entity", target)
    if not blip or blip == 0 then return nil end
    if not Native.call("does_blip_exist", blip) then return nil end

    Blip.remove(blip)
    return nil
end

function BasicTasks.run_rotate_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)

    if not Game.entity_exists(target) then return nil end

    local rotation = task_rotation(task)
    local is_relative = task.IsRelative == true
    if Attachment.update_rotation(target, rotation, is_relative) then return nil end

    if is_relative then
        local current = Native.call("get_entity_rotation", target, 2)
        if current then
            rotation.x = Util.to_number(current.x, 0.0) + rotation.x
            rotation.y = Util.to_number(current.y, 0.0) + rotation.y
            rotation.z = Util.to_number(current.z, 0.0) + rotation.z
        end
    end

    Native.call("set_entity_rotation", target, rotation.x, rotation.y, rotation.z, 2, true)
    return nil
end

function BasicTasks.run_teleport_to_coord_task(entity, task, handle_map)
    local target = target_entity(entity, task, handle_map)
    local destination = Util.vector3(task.Destination)

    if not Game.entity_exists(target) then return nil end

    local move_target = target
    if task.TakeVehicleToo ~= false and Native.call("is_entity_a_ped", target) and Native.call("is_ped_in_any_vehicle", target, false) then
        local vehicle = Native.call("get_vehicle_ped_is_in", target, false)
        if Game.entity_exists(vehicle) then
            move_target = vehicle
        end
    end

    EntityFactory.teleport(move_target, destination, true)
    return nil
end

return BasicTasks
