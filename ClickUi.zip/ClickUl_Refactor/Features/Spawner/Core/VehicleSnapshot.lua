local VehicleSnapshot = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")

local function ptr_values(native_name, vehicle, count)
    local ptrs = {}
    for i = 1, count do ptrs[i] = Pointer.int() end
    local ok, result = xpcall(function()
        Native.call(native_name, vehicle, table.unpack(ptrs))
        local values = {}
        for i = 1, count do values[i] = Pointer.int_value(ptrs[i], 0) end
        return values
    end, debug.traceback)
    for i = 1, count do Pointer.free(ptrs[i]) end
    if not ok then error(result, 0) end
    return result
end

local function mod_values(vehicle)
    local mods = {}
    for slot = 0, 48 do
        local toggle = slot >= 17 and slot <= 22
        if toggle then
            mods[#mods + 1] = Native.call("is_toggle_mod_on", vehicle, slot) and true or false
        else
            mods[#mods + 1] = Native.call("get_vehicle_mod", vehicle, slot) or -1
        end
    end
    return mods
end

function VehicleSnapshot.current()
    local vehicle = EntityFactory.player_vehicle()
    if not vehicle or vehicle == 0 then return nil, "missing_current_vehicle" end
    if not EntityFactory.exists(vehicle) then return nil, "missing_current_vehicle" end

    Native.call("set_vehicle_mod_kit", vehicle, 0)
    local colors = ptr_values("get_vehicle_colours", vehicle, 2)
    local custom_primary = ptr_values("get_vehicle_custom_primary_colour", vehicle, 3)
    local custom_secondary = ptr_values("get_vehicle_custom_secondary_colour", vehicle, 3)
    local primary_is_custom = Native.call("get_is_vehicle_primary_colour_custom", vehicle) and true or false
    local secondary_is_custom = Native.call("get_is_vehicle_secondary_colour_custom", vehicle) and true or false
    local extra_colors = ptr_values("get_vehicle_extra_colours", vehicle, 2)
    local interior_color = ptr_values("get_vehicle_extra_colour_5", vehicle, 1)
    local dashboard_color = ptr_values("get_vehicle_dashboard_colour", vehicle, 1)
    local neon_color = ptr_values("get_vehicle_neon_colour", vehicle, 3)
    local tire_color = ptr_values("get_vehicle_tyre_smoke_color", vehicle, 3)

    return {
        model = Native.get_entity_model(vehicle),
        colors = colors,
        ["custom decal"] = { false, false },
        ["custom primary"] = custom_primary,
        ["custom secondary"] = custom_secondary,
        ["is custom primary"] = primary_is_custom,
        ["is custom secondary"] = secondary_is_custom,
        ["extra color 5"] = interior_color[1] or 0,
        ["extra colors"] = extra_colors,
        ["dashboard colour"] = dashboard_color[1] or 0,
        ["garage bitset"] = -1,
        mods = mod_values(vehicle),
        ["neon color"] = neon_color,
        ["neon enabled"] = {
            Native.call("get_vehicle_neon_enabled", vehicle, 0) and true or false,
            Native.call("get_vehicle_neon_enabled", vehicle, 1) and true or false,
            Native.call("get_vehicle_neon_enabled", vehicle, 2) and true or false,
            Native.call("get_vehicle_neon_enabled", vehicle, 3) and true or false,
        },
        ["plate index"] = Native.call("get_vehicle_number_plate_text_index", vehicle) or 0,
        ["plate text"] = Native.call("get_vehicle_number_plate_text", vehicle) or "        ",
        ["tire color"] = tire_color,
        ["wheel type"] = Native.call("get_vehicle_wheel_type", vehicle) or 0,
        ["window tint"] = Native.call("get_vehicle_window_tint", vehicle) or -1,
        bulletproof = not (Native.call("get_vehicle_tyres_can_burst", vehicle) and true or false),
    }, nil
end

return VehicleSnapshot
