local VehicleSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Parser = require("ClickUl_Refactor.Features.Spawner.Ini.Parser")
local Normalizer = require("ClickUl_Refactor.Features.Spawner.Ini.Normalizer")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local VehiclePreset = require("ClickUl_Refactor.Features.Spawner.Core.VehiclePreset")
local VehicleSpawnSettings = require("ClickUl_Refactor.Features.Spawner.Core.VehicleSpawnSettings")
local VehicleAttributes = require("ClickUl_Refactor.Features.Spawner.Core.VehicleAttributes")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")
local EntityTreeSpawner = require("ClickUl_Refactor.Features.Spawner.Core.EntityTreeSpawner")

local REGISTRY_KEY <const> = "ini_spawned_entities"

local function apply_vehicle_settings(vehicle, settings)
    VehicleSpawnSettings.apply_flags(vehicle, settings)
    VehicleSpawnSettings.apply_randomization(vehicle, settings)
    VehiclePreset.apply(vehicle, settings, false)
    if settings.spawn_plane_in_air then EntityFactory.raise_aircraft_if_needed(vehicle, 50.0) end
end

local function root_heading(root)
    local rotation = root.world_rotation or root.rotation
    if type(rotation) ~= "table" then
        root.world_rotation = { z = EntityFactory.player_heading() }
    elseif rotation.z == nil and rotation.Z == nil and rotation.Yaw == nil then
        rotation.z = EntityFactory.player_heading()
    end
end

function VehicleSpawner.spawn_data(data, spawn_coords)
    if type(data) ~= "table" then return 0, {}, "unsupported_ini_format" end
    local settings = Settings.get("ini")
    local root_type = tostring(data.type or "VEHICLE"):upper()
    if not data.hash and not data.model then return 0, {}, "missing_model" end

    if spawn_coords then data.position = spawn_coords end
    root_heading(data)

    local saved_speed = 0
    if root_type == "VEHICLE" then saved_speed = VehicleSpawnSettings.captured_speed(settings) end
    if root_type == "VEHICLE" and settings.delete_old_vehicle then
        SpawnRegistry.delete_entity_records(REGISTRY_KEY)
    end

    local entities = {}
    local root, spawn_error = EntityTreeSpawner.spawn(data, {
        records = entities,
        base_coords = EntityFactory.forward_spawn_coords(5.0),
        disable_collision = settings.disable_collision,
        settings = settings,
    })
    if spawn_error then
        SpawnRegistry.delete_entities(entities)
        return 0, entities, spawn_error
    end
    if not root or root == 0 then return 0, entities, "spawn_failed" end

    EntityFactory.clear_internal_collisions(entities)

    if root_type == "VEHICLE" then
        local vehicle_settings = settings
        if VehicleAttributes.specifies_engine(data.vehicle_attributes) then
            vehicle_settings = Util.copy_table(settings)
            vehicle_settings.vehicle_engine_on = nil
        end
        apply_vehicle_settings(root, vehicle_settings)
        if settings.in_vehicle then
            if EntityFactory.put_player_in_vehicle(root) and data.vehicle_attributes then
                VehicleAttributes.apply_radio_station(root, data.vehicle_attributes)
            end
            if saved_speed > 0 then VehicleCustomizer.set_forward_speed(root, saved_speed) end
        end
    end

    SpawnRegistry.add(REGISTRY_KEY, { entities = entities })
    return root, entities, spawn_error
end

function VehicleSpawner.spawn_parsed(parsed, spawn_coords)
    local data, normalize_error = Normalizer.normalize(parsed)
    if not data then return 0, {}, normalize_error end
    return VehicleSpawner.spawn_data(data, spawn_coords)
end

function VehicleSpawner.spawn_string(content, spawn_coords)
    return VehicleSpawner.spawn_parsed(Parser.parse(content), spawn_coords)
end

function VehicleSpawner.spawn_file(path, spawn_coords)
    local content, read_error = Fs.read_text(path)
    if not content then return 0, {}, read_error end
    local root, entities, err = VehicleSpawner.spawn_string(content, spawn_coords)
    if root and root ~= 0 then
        SpawnRegistry.update_last(REGISTRY_KEY, function(record)
            record.file_path = path
        end)
    end
    return root, entities, err
end

function VehicleSpawner.delete(index)
    return SpawnRegistry.delete_entity_record_at(REGISTRY_KEY, index)
end

function VehicleSpawner.delete_all()
    return SpawnRegistry.delete_entity_records(REGISTRY_KEY)
end

function VehicleSpawner.get_spawned()
    return SpawnRegistry.list(REGISTRY_KEY)
end

function VehicleSpawner.get_type(content)
    return Parser.get_type(content)
end

return VehicleSpawner
