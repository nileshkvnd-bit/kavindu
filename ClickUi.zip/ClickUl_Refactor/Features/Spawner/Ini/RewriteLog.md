# INI Rewrite Log

## 2026-06-10 Round 1

- Replaced the old `type1/type3` INI parsing path with an ordered parser plus `Ini.Normalizer`.
- Normalized supported INI dialects into the shared entity tree shape:
  - `[Vehicle]` with numeric or `Attached ...` sections.
  - FSX-style `ObjectN` / `VehicleN` / `PedN` graph sections with `SelfNumeration` and `AttachNumeration`.
  - Pure numeric entity sections.
  - Split `[Model]` / `[Mods]` / `[Toggles]` / `[Extras]` vehicle files.
- Moved common runtime code out of JSON-specific names:
  - `Json.EntityTreeSpawner` -> `Core.EntityTreeSpawner`.
  - `JsonVehicleCustomizer` -> `Core.VehicleAttributes`.
- Kept format-specific work in `Features/Spawner/Ini`: parsing and dialect normalization only.
- Updated JSON and INI spawners to reuse `Core.EntityTreeSpawner` and `Core.VehicleAttributes`.
- Added parser/normalizer tests for realistic INI fields:
  - spaced `plate text`.
  - `Vehicle Mods` / `Vehicle Toggles` / `Vehicle Extras`.
  - `x offset` / lowercase `pitch/roll/yaw`.
  - FSX comma decimals and `Vehicle0...` auxiliary sections.
- Verified:
  - Lua syntax check passed.
  - `Tests/SpawnerParsers.lua` passed.

Pending:
- Sub-agent review for architecture boundaries, real-sample compatibility, and Lexis API reuse.
- Full AGENTS validation command set after review fixes.

## 2026-06-11 Round 2

- Removed old compatibility residue:
  - `worldRotation` is no longer accepted by the shared entity tree runtime.
  - `Ini.VehicleSpawner.spawn_parsed` no longer carries the unused legacy INI type argument.
- Tightened INI parsing and normalization:
  - Preserves intentional plate-text leading spaces while still trimming formatting spaces in `Key = Value`.
  - Classifies `Attached Vehicle N` as `VEHICLE` and `Attached Ped N` as `PED`.
  - Honors FSX `VehicleNIsCustomPrimary` / `VehicleNIsCustomSecondary` before applying custom colors.
  - Maps Keks type-4 root fields into shared vehicle attributes: `Plate`, `Tint`, `Wheels`, `NeonEnabled`, `PaintFade`, `DashColor`, `DashLightColor`.
- Removed silent root fallback in graph relationships:
  - Missing attachment parent returns `missing_attachment_parent`.
  - Missing aux-section target returns `missing_aux_target`.
- Kept runtime behavior in Core:
  - INI and JSON vehicle roots now pass `disable_collision` into the shared tree/root option path.
  - JSON map tree spawn failure now deletes partial entities through `SpawnRegistry.delete_entities`.
  - `VehicleAttributes` applies paint fade by default unless settings explicitly set `apply_paint_fade = false`.
- Added focused parser/spawner tests for the above cases.
- Post-review fixes:
  - `IsAttached=true` without `AttachNumeration` now returns `missing_attachment_parent` instead of attaching to root.
  - Keks `PrimaryPaintT` / `SecondaryPaintT` now gate root RGB custom paint values.
  - Shared `SpawnRegistry.delete_entities` normalizes map records before clearing PTFX, attachments, vehicle runtime, and task sequences.
  - `[Vehicle]` / `[Attached ...]` and numeric INI dialects now honor `SelfNumeration` / `AttachNumeration` for nested attachment chains.
  - Keks `WheelColor` / `WheelsColor`, `custom tyres`, `EngineOn` / `IsEngineOn`, and numeric `Radio` are preserved in shared vehicle attributes.

Verified:
- `luac54 -p` passed for `ClickUl_Refactor`.
- `Tests/SpawnerParsers.lua` passed.
- `Tests/CoreCaches.lua` passed.
- AGENTS boundary scans found no old `ClickUl.*` require, direct Lexis global use outside `Adapters/Tests`, or removed compatibility names.
- Final sub-agent compatibility and architecture/API boundary reviews passed.

Residual risks:
- Bad INI files with duplicate/self-referential `SelfNumeration` can still produce invalid attachment graphs.
- `Radio` uses GTA's radio station native and still needs Lexis in-game smoke testing for timing-sensitive behavior.

## 2026-06-25 Round 3

- Restored the explicit attachment-parent contract that Round 2 introduced and a later change
  had silently reverted. `attach_records` had been changed back to `nodes_by_key[...] or root`
  with an unconditional `return true`, re-homing dangling parents on the root and reporting a
  malformed `AttachNumeration` as a valid tree -- the `if not attach_ok` propagation the callers
  still carried had become dead code.
- New contract in `attach_records`:
  - Parent key present but pointing at a `SelfNumeration` not in the file (dangling) ->
    `missing_attachment_parent`, all dialects.
  - `entity_graph` records declaring `IsAttached=true` with no `AttachNumeration`
    (`require_explicit_parent`) -> `missing_attachment_parent`, restoring the Round 2 rule.
  - `[Vehicle]` / numeric `[Attached X]` / `[N]` with no `AttachNumeration` still attach to the
    implicit parent vehicle (root) -- that is a legitimate MenyooSP/SpinetheTic convention, not a
    fallback, and is intentionally preserved.
- `add_aux_sections` `missing_aux_target` failure is unchanged.

Test impact (Tests excluded from this pass per current scope, not modified here):
- `Tests/SpawnerParsers.lua` cases that codified the reverted fallback now contradict the
  restored contract and will fail until updated: dangling `[Vehicle]` parent (`~703-714`),
  dangling `entity_graph` parent (`~869-884`), `IsAttached=true` without `AttachNumeration`
  (`~885-896`). These should be rewritten to assert `nil, "missing_attachment_parent"`.

## 2026-06-25 Round 4 (P5.3 malformed attachment graphs)

- Closed the Round 2 residual risk "duplicate/self-referential `SelfNumeration` can still
  produce invalid attachment graphs". `attach_records` now rejects two more malformed shapes
  before building the tree, in every dialect:
  - Two sections with the same explicit `SelfNumeration` -> `duplicate_attachment_id`. The id
    is ambiguous (`nodes_by_key` kept only the last node, silently orphaning the earlier one),
    so any `AttachNumeration` pointing at it cannot be resolved deterministically. Only explicit
    `SelfNumeration` values are checked; name-derived keys are inherently unique per section.
  - A record whose `AttachNumeration` resolves to its own `SelfNumeration` -> `self_attachment_parent`
    (a node parented to itself is a cycle the entity-tree spawner cannot walk).
- `Tests/SpawnerParsers.lua` adds samples asserting `nil, "duplicate_attachment_id"` and
  `nil, "self_attachment_parent"` alongside the existing `missing_attachment_parent` case.
- Residual risk updated: malformed `SelfNumeration`/`AttachNumeration` graphs (missing,
  duplicate, self-referential) are now explicit failures, not silently-built invalid trees.
