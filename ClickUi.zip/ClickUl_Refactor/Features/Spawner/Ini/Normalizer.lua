local Normalizer = {}

local Parser = require("ClickUl_Refactor.Features.Spawner.Ini.Parser")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local MODEL_KEYS <const> = { "model", "hash", "modelhash", "vehicle" }
local WHEEL_COLOR_KEYS <const> = { "wheelcolour", "wheel colour", "wheelcolor", "wheel color", "wheelscolour", "wheels colour", "wheelscolor", "wheels color", "wheel" }

local function key_id(key)
    return tostring(key or ""):lower():gsub("[%s_%-%./]", "")
end

local function name_id(name)
    return tostring(name or ""):lower():gsub("%s+", "")
end

local function section_index(section)
    local index = {}
    for key, value in pairs(section or {}) do
        index[key_id(key)] = value
    end
    return index
end

local function value(section, aliases)
    local index = section_index(section)
    for _, alias in ipairs(aliases) do
        local found = index[key_id(alias)]
        if found ~= nil then return found end
    end
    return nil
end

local function number_value(section, aliases, default)
    return Util.to_number(value(section, aliases), default)
end

local function bool_value(section, aliases)
    local found = value(section, aliases)
    if found == nil then return nil end
    return Util.to_boolean(found)
end

local function model_value(section)
    local model = Util.trim(value(section, MODEL_KEYS))
    if model == "" then return nil end
    return model
end

local function entity_type_from_section(name, section)
    local explicit = value(section, { "type" })
    if explicit ~= nil then
        local compact_type = key_id(explicit)
        if compact_type == "veh" or compact_type == "vehicle" or compact_type == "car" then return "VEHICLE" end
        if compact_type == "ped" then return "PED" end
        if compact_type == "obj" or compact_type == "object" or compact_type == "prop" then return "OBJECT" end
        return tostring(Util.trim(explicit)):upper()
    end

    local compact = name_id(name)
    if compact == "vehicle" or compact == "car" or compact == "main" or compact == "delorean" or compact:match("^vehicle%d+$") or compact:match("^attachedvehicle%d*$") then return "VEHICLE" end
    if compact:match("^ped%d*$") or compact:match("^attachedped%d*$") then return "PED" end
    return "OBJECT"
end

local function position(section)
    local x = number_value(section, { "x", "posx" }, nil)
    local y = number_value(section, { "y", "posy" }, nil)
    local z = number_value(section, { "z", "posz" }, nil)
    if x == nil or y == nil or z == nil then return nil end
    return { x = x, y = y, z = z }
end

local function offset(section)
    return {
        x = number_value(section, { "offsetx", "xoffset", "x offset", "x" }, 0),
        y = number_value(section, { "offsety", "yoffset", "y offset", "y" }, 0),
        z = number_value(section, { "offsetz", "zoffset", "z offset", "z" }, 0),
    }
end

local function rotation(section)
    return {
        x = number_value(section, { "pitch", "rotx" }, 0),
        y = number_value(section, { "roll", "roty" }, 0),
        z = number_value(section, { "yaw", "rotz", "heading" }, nil),
    }
end

local function options(section)
    return {
        is_visible = bool_value(section, { "isvisible", "visible" }),
        has_collision = bool_value(section, { "collision" }),
        is_frozen = bool_value(section, { "frozen", "freeze", "froozen" }),
        has_gravity = bool_value(section, { "gravity", "hasgravity" }),
        is_invincible = bool_value(section, { "invincible", "isinvincible" }),
        alpha = number_value(section, { "opacitylevel", "opacity", "alpha" }, nil),
        health = number_value(section, { "health" }, nil),
        max_health = number_value(section, { "maxhealth" }, nil),
        bone_index = number_value(section, { "bone", "boneindex" }, nil),
    }
end

local function ensure_vehicle_attrs(node)
    node.vehicle_attributes = node.vehicle_attributes or {}
    return node.vehicle_attributes
end

local function ensure_paint(attrs)
    attrs.paint = attrs.paint or {}
    return attrs.paint
end

local function ensure_options(attrs)
    attrs.options = attrs.options or {}
    return attrs.options
end

local function ensure_neon(attrs)
    attrs.neon = attrs.neon or {}
    return attrs.neon
end

local function ensure_wheels(attrs)
    attrs.wheels = attrs.wheels or {}
    return attrs.wheels
end

local function set_number(target, key, source, aliases)
    local found = number_value(source, aliases, nil)
    if found ~= nil then target[key] = found end
end

local function set_bool(target, key, source, aliases)
    local found = bool_value(source, aliases)
    if found ~= nil then target[key] = found end
end

local function read_color(section)
    local r = number_value(section, { "r", "red" }, nil)
    local g = number_value(section, { "g", "green" }, nil)
    local b = number_value(section, { "b", "blue" }, nil)
    if r == nil or g == nil or b == nil then return nil end
    return { r = r, g = g, b = b }
end

local function use_custom_rgb(paint_index, paint_type)
    if paint_type == nil then return true end
    if paint_index ~= nil then return paint_type == 7 end
    return paint_type ~= 0
end

local function read_mods(attrs, section)
    attrs.mods = attrs.mods or {}
    for key, raw_value in pairs(section or {}) do
        local compact = key_id(key)
        local slot = compact:match("^m(%d+)$") or compact:match("^mod(%d+)$") or compact:match("^(%d+)$")
        if slot then attrs.mods[tonumber(slot)] = Util.to_number(raw_value, -1) end
    end
end

local function read_toggles(attrs, section)
    attrs.mods = attrs.mods or {}
    for key, raw_value in pairs(section or {}) do
        local compact = key_id(key)
        local slot = compact:match("^t(%d+)$") or compact:match("^toggle(%d+)$") or compact:match("^(%d+)$")
        if slot then attrs.mods[tonumber(slot)] = Util.to_boolean(raw_value) end
    end
end

local function read_extras(attrs, section)
    attrs.extras = attrs.extras or {}
    for key, raw_value in pairs(section or {}) do
        local compact = key_id(key)
        local extra = compact:match("^e(%d+)$") or compact:match("^extra(%d+)$") or compact:match("^(%d+)$")
        if extra then attrs.extras[tonumber(extra)] = Util.to_boolean(raw_value) end
    end
end

local function read_vehicle_section_attrs(node, section)
    if node.type ~= "VEHICLE" then return end
    local attrs = ensure_vehicle_attrs(node)
    local paint = ensure_paint(attrs)
    local opts = ensure_options(attrs)
    local neon = ensure_neon(attrs)
    local wheels = ensure_wheels(attrs)

    set_number(paint, "primary", section, { "primarypaint", "primary paint", "primary" })
    set_number(paint, "secondary", section, { "secondarypaint", "secondary paint", "secondary" })
    if number_value(section, { "pearlescent", "pearlescentcolour", "pearlescent colour", "pearl" }, nil)
        or number_value(section, WHEEL_COLOR_KEYS, nil) then
        paint.extra_colors = paint.extra_colors or {}
        set_number(paint.extra_colors, "pearlescent", section, { "pearlescent", "pearlescentcolour", "pearlescent colour", "pearl" })
        set_number(paint.extra_colors, "wheel", section, WHEEL_COLOR_KEYS)
    end

    local primary_rgb = {
        r = number_value(section, { "primaryr" }, nil),
        g = number_value(section, { "primaryg" }, nil),
        b = number_value(section, { "primaryb" }, nil),
    }
    local secondary_rgb = {
        r2 = number_value(section, { "secondaryr" }, nil),
        g2 = number_value(section, { "secondaryg" }, nil),
        b2 = number_value(section, { "secondaryb" }, nil),
    }
    local primary_custom_flag = number_value(section, { "primarypaintt", "primary paint t", "primarypainttype", "primary paint type" }, nil)
    local secondary_custom_flag = number_value(section, { "secondarypaintt", "secondary paint t", "secondarypainttype", "secondary paint type" }, nil)
    local use_primary_rgb = use_custom_rgb(paint.primary, primary_custom_flag)
    local use_secondary_rgb = use_custom_rgb(paint.secondary, secondary_custom_flag)
    if (use_primary_rgb and (primary_rgb.r or primary_rgb.g or primary_rgb.b))
        or (use_secondary_rgb and (secondary_rgb.r2 or secondary_rgb.g2 or secondary_rgb.b2)) then
        paint.vehicle_custom_color = paint.vehicle_custom_color or {}
        if use_primary_rgb then
            for key, raw in pairs(primary_rgb) do if raw ~= nil then paint.vehicle_custom_color[key] = raw end end
        end
        if use_secondary_rgb then
            for key, raw in pairs(secondary_rgb) do if raw ~= nil then paint.vehicle_custom_color[key] = raw end end
        end
    end

    set_number(attrs, "livery", section, { "livery", "vehiclelivery", "vehicle livery" })
    set_number(opts, "license_plate_type", section, { "plateindex", "plate index", "platetype", "plate", "numberplateindex", "number plate index", "numberplatetextindex", "number plate text index" })
    local plate = value(section, { "platetext", "plate text" })
    if plate ~= nil then opts.license_plate_text = tostring(plate) end
    set_number(opts, "window_tint", section, { "windowtint", "window tint", "tint" })
    set_bool(opts, "bulletproof_tires", section, { "bulletproof", "bulletprooftyres", "bulletproof tyres", "bulletprooftires" })
    set_bool(opts, "engine_on", section, { "engineon", "engine on", "isengineon", "is engine on" })
    set_number(opts, "radio_station", section, { "radio", "radiostation", "radio station" })
    set_bool(opts, "lights_on", section, { "lightson", "lights on", "headlightson", "headlights on" })
    local lights_state = number_value(section, { "lightsstate", "lights state", "lightstate", "light state" }, nil)
    if lights_state ~= nil then opts.lights_on = lights_state > 0 end
    set_bool(opts, "siren", section, { "siren", "sirenactive", "siren active" })
    set_number(opts, "roof_state", section, { "roofstate", "roof state" })
    set_number(opts, "headlight_multiplier", section, { "headlightmultiplier", "headlight multiplier", "headlightintensity", "headlight intensity" })

    neon.lights = neon.lights or {}
    local neon_enabled = number_value(section, { "neonenabled", "neon enabled" }, nil)
    if neon_enabled ~= nil then
        local enabled = neon_enabled ~= 0
        for i = 1, 4 do neon.lights[i] = enabled end
    end
    for i = 1, 4 do
        local zero_based = i - 1
        local enabled = bool_value(section, { "neon" .. i, "neon " .. i, "neonenabled" .. i, "neon" .. zero_based, "neon " .. zero_based, "neonenabled" .. zero_based })
        if enabled ~= nil then neon.lights[i] = enabled end
    end
    local neon_color = {
        r = number_value(section, { "neonr", "neonred", "neon red" }, nil),
        g = number_value(section, { "neong", "neongreen", "neon green" }, nil),
        b = number_value(section, { "neonb", "neonblue", "neon blue" }, nil),
    }
    if neon_color.r or neon_color.g or neon_color.b then neon.color = { r = neon_color.r or 0, g = neon_color.g or 0, b = neon_color.b or 0 } end

    set_number(wheels, "wheel_type", section, { "wheeltype", "wheel type", "wheelstype", "wheels type", "wheels" })
    set_bool(wheels, "custom_tires", section, { "customtyres", "custom tyres", "customtires", "custom tires" })
    local smoke = {
        r = number_value(section, { "smoker", "tyresmokered", "tyre smoke red" }, nil),
        g = number_value(section, { "smokeg", "tyresmokegreen", "tyre smoke green" }, nil),
        b = number_value(section, { "smokeb", "tyresmokeblue", "tyre smoke blue" }, nil),
    }
    if smoke.r or smoke.g or smoke.b then wheels.tire_smoke_color = { r = smoke.r or 0, g = smoke.g or 0, b = smoke.b or 0 } end

    attrs.dirt_level = number_value(section, { "dirt", "dirtlevel", "dirt level" }, attrs.dirt_level)
    paint.fade = number_value(section, { "paintfade", "paint fade" }, paint.fade)
    set_number(paint, "dashboard", section, { "dashcolor", "dash color", "dashboard", "dashboardcolor", "dashboard color" })
    set_number(paint, "interior", section, { "dashlightcolor", "dash light color", "interior", "interiorcolor", "interior color" })
    read_mods(attrs, section)
    read_toggles(attrs, section)
    read_extras(attrs, section)
end

local function read_vehicle_aux_attrs(node, suffix, section, flags)
    if node.type ~= "VEHICLE" then return end
    local attrs = ensure_vehicle_attrs(node)
    suffix = key_id(suffix)
    if suffix == "mods" then read_mods(attrs, section) return end
    if suffix == "toggles" then read_toggles(attrs, section) return end
    if suffix == "extras" then read_extras(attrs, section) return end

    local paint = ensure_paint(attrs)
    if suffix == "vehiclecolors" then
        set_number(paint, "primary", section, { "primary" })
        set_number(paint, "secondary", section, { "secondary" })
        return
    end
    if suffix == "extracolors" then
        paint.extra_colors = paint.extra_colors or {}
        set_number(paint.extra_colors, "pearlescent", section, { "pearl", "pearlescent" })
        set_number(paint.extra_colors, "wheel", section, WHEEL_COLOR_KEYS)
        return
    end
    if suffix == "customprimarycolor" then
        if flags and flags.iscustomprimary == false then return end
        local color_value = read_color(section)
        if color_value then
            paint.vehicle_custom_color = paint.vehicle_custom_color or {}
            paint.vehicle_custom_color.r = color_value.r
            paint.vehicle_custom_color.g = color_value.g
            paint.vehicle_custom_color.b = color_value.b
        end
        return
    end
    if suffix == "customsecondarycolor" then
        if flags and flags.iscustomsecondary == false then return end
        local color_value = read_color(section)
        if color_value then
            paint.vehicle_custom_color = paint.vehicle_custom_color or {}
            paint.vehicle_custom_color.r2 = color_value.r
            paint.vehicle_custom_color.g2 = color_value.g
            paint.vehicle_custom_color.b2 = color_value.b
        end
        return
    end

    local opts = ensure_options(attrs)
    if suffix == "numberplate" then
        local text = value(section, { "text" })
        if text ~= nil then opts.license_plate_text = tostring(text) end
        set_number(opts, "license_plate_type", section, { "index", "plate", "plateindex", "numberplateindex", "numberplatetextindex" })
        return
    end
    if suffix == "windowtint" then set_number(opts, "window_tint", section, { "index" }) return end
    if suffix == "wheeltype" then set_number(ensure_wheels(attrs), "wheel_type", section, { "index" }) return end
    if suffix == "tiresmoke" or suffix == "tyresmoke" then
        local color_value = read_color(section)
        if color_value then ensure_wheels(attrs).tire_smoke_color = color_value end
        return
    end
    if suffix == "neon" then
        local neon = ensure_neon(attrs)
        neon.lights = neon.lights or {}
        for i = 0, 3 do
            local enabled = bool_value(section, { "enabled" .. i })
            if enabled ~= nil then neon.lights[i + 1] = enabled end
        end
        return
    end
    if suffix == "neoncolor" then
        local color_value = read_color(section)
        if color_value then ensure_neon(attrs).color = color_value end
        return
    end
    if suffix == "paintfade" then attrs.paint.fade = number_value(section, { "paintfade" }, attrs.paint.fade) return end
    if suffix == "iscustomprimary" or suffix == "iscustomsecondary" then return end
end

local function node_from_entry(entry, role)
    local section = entry.values
    local model = model_value(section)
    if not model then return nil end
    local node = {
        source_section = entry.name,
        type = entity_type_from_section(entry.name, section),
        hash = model,
        options = options(section),
    }

    local pos = position(section)
    local rot = rotation(section)
    if role == "attached" then
        node.offset = offset(section)
        node.rotation = rot
    else
        node.position = pos
        node.world_rotation = rot
        node.options.rotation = rot
    end

    read_vehicle_section_attrs(node, section)
    return node
end

local function is_root_name(name)
    local compact = name_id(name)
    return compact == "vehicle" or compact == "car" or compact == "main" or compact == "delorean"
end

local function is_numeric_name(name)
    return name_id(name):match("^%d+$") ~= nil
end

local function is_attached_name(name)
    return name_id(name):match("^attached") ~= nil
end

local function graph_entity_name(name)
    local compact = name_id(name)
    local kind, id = compact:match("^(vehicle)(%d+)$")
    if kind then return kind, id end
    kind, id = compact:match("^(object)(%d+)$")
    if kind then return kind, id end
    kind, id = compact:match("^(ped)(%d+)$")
    if kind then return kind, id end
    return nil
end

local function aux_name(name)
    local compact = name_id(name)
    if compact == "vehiclemods" then return "vehicle", "mods" end
    if compact == "vehicletoggles" then return "vehicle", "toggles" end
    if compact == "vehicleextras" then return "vehicle", "extras" end
    if compact == "mods" then return "split", "mods" end
    if compact == "toggles" then return "split", "toggles" end
    if compact == "extras" then return "split", "extras" end
    local base, suffix = compact:match("^(vehicle%d+)(.+)$")
    if base then return base, suffix end
    return nil
end

local function add_aux_sections(root, nodes_by_name, parsed)
    local custom_flags = {}
    for _, entry in ipairs(parsed.entries or {}) do
        local target, suffix = aux_name(entry.name)
        if target and (suffix == "iscustomprimary" or suffix == "iscustomsecondary") then
            custom_flags[target] = custom_flags[target] or {}
            custom_flags[target][suffix] = bool_value(entry.values, { "bool" })
        end
    end

    for _, entry in ipairs(parsed.entries or {}) do
        local target, suffix = aux_name(entry.name)
        if target and suffix then
            local node = (target == "vehicle" or target == "split") and root or nodes_by_name[target]
            if not node then return nil, "missing_aux_target" end
            read_vehicle_aux_attrs(node, suffix, entry.values, custom_flags[target])
        end
    end
    return true
end

local function graph_parent_key(section)
    local parent = value(section, { "attachnumeration" })
    if parent == nil then return nil end
    return tostring(Util.trim(parent))
end

local function graph_self_key(entry)
    local key = Util.trim(value(entry.values, { "selfnumeration" }))
    if key == nil or key == "" then return name_id(entry.name) end
    return tostring(key)
end

local function graph_is_attached(section)
    return bool_value(section, { "isattached" }) == true
end

local function attach_records(root, root_record, records, nodes_by_key, require_explicit_parent)
    local seen_ids = {}
    for _, record in ipairs(records) do
        local explicit = record.entry and Util.trim(value(record.entry.values, { "selfnumeration" }))
        if explicit ~= nil and explicit ~= "" then
            if seen_ids[explicit] then return nil, "duplicate_attachment_id" end
            seen_ids[explicit] = true
        end
    end

    for _, record in ipairs(records) do
        if record ~= root_record then
            local parent = root
            if record.parent ~= nil then
                parent = nodes_by_key[tostring(record.parent)]
                if parent == nil then return nil, "missing_attachment_parent" end
                if parent == record.node then return nil, "self_attachment_parent" end
            elseif require_explicit_parent and record.attached then
                return nil, "missing_attachment_parent"
            end
            parent.children = parent.children or {}
            parent.children[#parent.children + 1] = record.node
        end
    end
    return true
end

local function normalize_vehicle(parsed)
    local root_entry = nil
    for _, entry in ipairs(parsed.entries or {}) do
        if is_root_name(entry.name) then
            root_entry = entry
            break
        end
    end
    if not root_entry then return nil, "missing_root_section" end

    local root = node_from_entry(root_entry, "root")
    if not root then return nil, "missing_model" end

    local records = {}
    local nodes_by_key = {}
    local nodes_by_name = {}
    local root_record = {
        entry = root_entry,
        node = root,
        key = graph_self_key(root_entry),
        parent = graph_parent_key(root_entry.values),
        attached = false,
    }
    records[#records + 1] = root_record
    nodes_by_key[root_record.key] = root
    nodes_by_name[name_id(root_entry.name)] = root

    for _, entry in ipairs(parsed.entries or {}) do
        if entry ~= root_entry and (is_attached_name(entry.name) or is_numeric_name(entry.name)) then
            local child = node_from_entry(entry, "attached")
            if child then
                local record = {
                    entry = entry,
                    node = child,
                    key = graph_self_key(entry),
                    parent = graph_parent_key(entry.values),
                    attached = true,
                }
                records[#records + 1] = record
                nodes_by_key[record.key] = child
                nodes_by_name[name_id(entry.name)] = child
            end
        end
    end
    local attach_ok, attach_error = attach_records(root, root_record, records, nodes_by_key)
    if not attach_ok then return nil, attach_error end
    local ok, aux_error = add_aux_sections(root, nodes_by_name, parsed)
    if not ok then return nil, aux_error end
    return root
end

local function normalize_numeric(parsed)
    local root_record = nil
    local records = {}
    local nodes_by_key = {}
    for _, entry in ipairs(parsed.entries or {}) do
        if is_numeric_name(entry.name) then
            local role = root_record and "attached" or "root"
            local node = node_from_entry(entry, role)
            if node then
                local record = {
                    entry = entry,
                    node = node,
                    key = graph_self_key(entry),
                    parent = graph_parent_key(entry.values),
                    attached = root_record ~= nil,
                }
                records[#records + 1] = record
                nodes_by_key[record.key] = node
                if not root_record then root_record = record end
            end
        end
    end
    if not root_record then return nil, "missing_model" end
    local root = root_record.node
    local attach_ok, attach_error = attach_records(root, root_record, records, nodes_by_key)
    if not attach_ok then return nil, attach_error end
    return root
end

local function normalize_split_vehicle(parsed)
    local model_entry = parsed.groups.Model and parsed.groups.Model[1]
    if not model_entry then return nil, "missing_root_section" end
    local root = node_from_entry({ name = "Vehicle", values = model_entry.values }, "root")
    if not root then return nil, "missing_model" end
    local ok, aux_error = add_aux_sections(root, {}, parsed)
    if not ok then return nil, aux_error end
    return root
end

local function normalize_entity_graph(parsed)
    local records = {}
    local nodes_by_key = {}
    local nodes_by_name = {}
    local root_record = nil

    for _, entry in ipairs(parsed.entries or {}) do
        local kind = graph_entity_name(entry.name)
        if kind then
            local role = graph_is_attached(entry.values) and "attached" or "root"
            local node = node_from_entry(entry, role)
            if node then
                local record = {
                    entry = entry,
                    node = node,
                    key = graph_self_key(entry),
                    parent = graph_parent_key(entry.values),
                    attached = graph_is_attached(entry.values),
                }
                records[#records + 1] = record
                nodes_by_key[record.key] = node
                nodes_by_name[name_id(entry.name)] = node
                if not record.attached and node.type == "VEHICLE" and not root_record then root_record = record end
                if not record.attached and not root_record then root_record = record end
            end
        end
    end

    if not root_record and records[1] then root_record = records[1] end
    if not root_record then return nil, "missing_root_section" end

    local root = root_record.node
    local attach_ok, attach_error = attach_records(root, root_record, records, nodes_by_key, true)
    if not attach_ok then return nil, attach_error end
    local ok, aux_error = add_aux_sections(root, nodes_by_name, parsed)
    if not ok then return nil, aux_error end
    return root
end

function Normalizer.normalize(parsed_or_content)
    local parsed = type(parsed_or_content) == "table" and parsed_or_content or Parser.parse(parsed_or_content)
    local format = Parser.detect(parsed)
    if format == "vehicle" then return normalize_vehicle(parsed) end
    if format == "entity_graph" then return normalize_entity_graph(parsed) end
    if format == "numeric_entities" then return normalize_numeric(parsed) end
    if format == "split_vehicle" then return normalize_split_vehicle(parsed) end
    return nil, format == "empty" and "empty_ini" or "unsupported_ini_format"
end

function Normalizer.detect(parsed_or_content)
    return Parser.detect(parsed_or_content)
end

return Normalizer
