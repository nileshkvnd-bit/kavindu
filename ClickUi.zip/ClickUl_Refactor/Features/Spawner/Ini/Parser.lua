local Parser = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function is_comment(line)
    return line:match("^%s*[#;]") ~= nil
end

local function new_section(result, name, line_number)
    local section = {
        name = name,
        line = line_number,
        values = {},
        order = {},
    }
    result.entries[#result.entries + 1] = section
    result.order[#result.order + 1] = name
    result.sections[name] = section.values
    result.groups[name] = result.groups[name] or {}
    result.groups[name][#result.groups[name] + 1] = section
    return section
end

local function set_value(section, key, value)
    section.values[key] = value
    section.order[#section.order + 1] = key
end

local function parse_key_value(line)
    local raw_key, value = line:match("^([^=]+)=(.*)$")
    if not raw_key then return nil end
    if raw_key:match("%s$") then value = tostring(value or ""):gsub("^%s+", "") end
    return Util.trim(raw_key), value or ""
end

local function parse_axis_value(line)
    local axis, value = line:match("^([xXyYzZ])%s*([%+%-]?[%d%.,_]+)%s*$")
    if not axis then return nil end
    return axis:lower(), value
end

function Parser.parse(content)
    local result = {
        sections = {},
        groups = {},
        entries = {},
        order = {},
    }
    local current = nil
    local line_number = 0

    local text = tostring(content or ""):gsub("\r\n", "\n"):gsub("\r", "\n") .. "\n"
    for raw_line in text:gmatch("([^\n]*)\n") do
        line_number = line_number + 1
        local line = raw_line:gsub("^\239\187\191", "")
        if not is_comment(line) then
            local trimmed = Util.trim(line)
            if trimmed and trimmed ~= "" then
                local section_name = trimmed:match("^%[(.-)%]$")
                if section_name then
                    current = new_section(result, section_name, line_number)
                elseif current then
                    local key, value = parse_key_value(line)
                    if not key then key, value = parse_axis_value(trimmed) end
                    if key and key ~= "" then set_value(current, key, value) end
                end
            end
        end
    end

    return result
end

local function lower_name(name)
    return tostring(name or ""):lower()
end

function Parser.detect(parsed_or_content)
    local parsed = type(parsed_or_content) == "table" and parsed_or_content or Parser.parse(parsed_or_content)
    local has_numeric = false
    local has_entity_graph = false
    local has_vehicle_root = false
    local has_split_model = false
    local first_entity = nil

    for _, entry in ipairs(parsed.entries or {}) do
        local name = lower_name(entry.name)
        first_entity = first_entity or name
        if name == "vehicle" or name == "car" or name == "main" or name == "delorean" then has_vehicle_root = true end
        if name:match("^%d+$") then has_numeric = true end
        if name == "allobjects" or name == "allvehicles" or name:match("^object%d+$") or name:match("^vehicle%d+$") or name:match("^ped%d+$") then
            has_entity_graph = true
        end
        if name == "model" then has_split_model = true end
    end

    if has_entity_graph then return "entity_graph" end
    if has_vehicle_root then return "vehicle" end
    if has_numeric then return "numeric_entities" end
    if has_split_model then return "split_vehicle" end
    return first_entity and "unknown" or "empty"
end

function Parser.get_type(content)
    return Parser.detect(content)
end

return Parser
