local PedParser = {}

local Xml = require("ClickUl_Refactor.Features.Spawner.Menyoo.Xml")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function child_text(block, tag)
    local node = Xml.node(block, tag)
    if not node then
        return nil
    end

    return Xml.text(node)
end

local function root_child(xml, tag)
    local root = Xml.root(xml)
    if not root then
        return nil
    end
    if root.name == tag then
        return root
    end

    return Xml.node(root, tag)
end

local function is_empty(tbl)
    return type(tbl) ~= "table" or next(tbl) == nil
end

local function number_alias(block, primary, fallback, default)
    local value = Xml.number(block, primary, nil)
    if value ~= nil then
        return value
    end
    return Xml.number(block, fallback, default)
end

local function parse_indexed_numbers(section)
    local result = {}
    if not section then return result end
    for _, child in ipairs(Xml.children(section)) do
        local id = child.name:match("^_(%d+)$")
        if id then
            result[tonumber(id)] = Util.to_number(Xml.text(child), 0.0)
        end
    end
    return result
end

local function parse_blend(section)
    if not section then return nil end
    return {
        shape_first = number_alias(section, "ShapeFatherId", "ShapeFirst", 0),
        shape_second = number_alias(section, "ShapeMotherId", "ShapeSecond", 0),
        shape_third = number_alias(section, "ShapeOverrideId", "ShapeThird", 0),
        skin_first = number_alias(section, "ToneFatherId", "SkinFirst", 0),
        skin_second = number_alias(section, "ToneMotherId", "SkinSecond", 0),
        skin_third = number_alias(section, "ToneOverrideId", "SkinThird", 0),
        mix_shape = number_alias(section, "ShapeVal", "ShapeMix", 0.0),
        mix_skin = number_alias(section, "ToneVal", "SkinMix", 0.0),
        mix_third = number_alias(section, "OverrideVal", "ThirdMix", 0.0),
        is_parent = Xml.bool(section, "IsP"),
    }
end

local function attr_number(attrs, ...)
    for i = 1, select("#", ...) do
        local value = Xml.attr(attrs, select(i, ...))
        if value ~= nil then return Util.to_number(value, nil) end
    end
    return nil
end

local function parse_overlay_csv(value)
    local parts = {}
    for part in tostring(value or ""):gmatch("([^,]+)") do
        parts[#parts + 1] = part
    end
    return {
        index = Util.to_number(parts[1], 255),
        opacity = Util.to_number(parts[2], 1.0),
        color = Util.to_number(parts[3], 0),
        color_id = Util.to_number(parts[3], nil),
        color2 = Util.to_number(parts[4], 0),
        secondary_color_id = Util.to_number(parts[4], nil),
    }
end

local function parse_overlays(section)
    local result = {}
    if not section then return result end
    for _, child in ipairs(Xml.children(section)) do
        local id = child.name:match("^_(%d+)$")
        if id then
            local overlay_id = tonumber(id)
            if next(child.attributes or {}) ~= nil then
                result[overlay_id] = {
                    index = attr_number(child, "index", "Index") or 255,
                    opacity = attr_number(child, "opacity", "Opacity") or 1.0,
                    color = attr_number(child, "colour", "color", "Colour", "Color") or 0,
                    color_id = attr_number(child, "colour", "color", "Colour", "Color"),
                    color2 = attr_number(child, "colourSecondary", "colorSecondary", "ColourSecondary", "ColorSecondary") or 0,
                    secondary_color_id = attr_number(child, "colourSecondary", "colorSecondary", "ColourSecondary", "ColorSecondary"),
                }
            else
                result[overlay_id] = parse_overlay_csv(Xml.text(child))
            end
        end
    end
    return result
end

local function apply_head_features(props, result)
    local head_features = Xml.node(props, "HeadFeatures")
    if head_features then
        result.HeadFeaturesWasInArray = Util.to_boolean(Xml.attr(head_features, "WasInArray"))
        result.BlendData = parse_blend(Xml.node(head_features, "ShapeAndSkinTone")) or result.BlendData
        result.HairColor = Xml.number(head_features, "HairColour", result.HairColor)
        result.HairHighlightColor = Xml.number(head_features, "HairColourStreaks", result.HairHighlightColor)
        result.EyeColor = Xml.number(head_features, "EyeColour", result.EyeColor)
        result.FacialFeatures = parse_indexed_numbers(Xml.node(head_features, "FacialFeatures"))
        result.HeadOverlays = parse_overlays(Xml.node(head_features, "Overlays"))
    end

    if not result.BlendData then
        result.BlendData = parse_blend(Xml.node(props, "BlendData"))
    end
    if is_empty(result.FacialFeatures) then
        result.FacialFeatures = parse_indexed_numbers(Xml.node(props, "FacialFeatures"))
    end
    if is_empty(result.HeadOverlays) then
        result.HeadOverlays = parse_overlays(Xml.node(props, "HeadOverlays"))
    end
end

local function parse_drawable_texture(section, default_drawable)
    local result = {}
    if not section then return result end

    for _, child in ipairs(Xml.children(section)) do
        local id = child.name:match("^_(%d+)$")
        if id then
            local value = Xml.text(child)
            local a, b = value:match("([^,]+),([^,]+)")
            result[tonumber(id)] = {
                drawable = Util.to_number(a or value, default_drawable),
                texture = Util.to_number(b, 0),
            }
        end
    end
    return result
end

local function parse_tattoo_logo_decals(section)
    local result = {}
    if not section then return result end

    for _, child in ipairs(Xml.children(section)) do
        local collection = Xml.attr(child, "collection") or child_text(child, "Collection")
        local value = Xml.attr(child, "value") or child_text(child, "Value")
        if collection ~= nil and collection ~= "" and value ~= nil and value ~= "" then
            result[#result + 1] = {
                collection = collection,
                value = value,
            }
        end
    end
    return result
end

local function parse_damage_packs(section)
    local result = {}
    if not section then return result end

    for _, child in ipairs(Xml.children(section)) do
        local value = Xml.text(child)
        if value ~= nil and value ~= "" then
            result[#result + 1] = value
        end
    end
    return result
end

local function parse_ped_config_flags(section)
    local result = {}
    if not section then return result end

    for _, child in ipairs(Xml.children(section)) do
        local id = child.name:match("^_(%d+)$")
        if id then
            result[tonumber(id)] = Xml.bool(child)
        end
    end
    return result
end

local function parse_particle_attributes(props)
    local asset = child_text(props, "PtfxLopAsset")
    local effect = child_text(props, "PtfxLopEffect")
    if not asset and not effect then return nil end
    return {
        ptfxLopAsset = asset,
        ptfxLopEffect = effect,
    }
end

function PedParser.ped_properties(xml)
    local props = root_child(xml, "PedProperties")
    if not props then return nil end
    local result = {
        PedComps = {},
        PedProps = {},
        FacialFeatures = {},
        HeadOverlays = {},
        TattooLogoDecals = {},
        DamagePacks = {},
        PedConfigFlags = {},
    }
    result.PedComps = parse_drawable_texture(Xml.node(props, "PedComps") or Xml.node(props, "Components"), 0)
    result.PedProps = parse_drawable_texture(Xml.node(props, "PedProps") or Xml.node(props, "Props"), -1)
    result.TattooLogoDecals = parse_tattoo_logo_decals(Xml.node(props, "TattooLogoDecals"))
    result.DamagePacks = parse_damage_packs(Xml.node(props, "DamagePacks"))
    result.PedConfigFlags = parse_ped_config_flags(Xml.node(props, "PedConfigFlags"))
    result.ParticleAttributes = parse_particle_attributes(props)
    result.HairColor = number_alias(props, "HairColour", "HairColor", nil)
    result.HairHighlightColor = number_alias(props, "HairColourStreaks", "HairHighlightColor", nil)
    result.EyeColor = number_alias(props, "EyeColour", "EyeColor", nil)
    result.IsStill = Xml.bool(props, "IsStill")
    if result.IsStill == nil then result.IsStill = true end
    result.CanRagdoll = Xml.bool(props, "CanRagdoll")
    result.HasShortHeight = Xml.bool(props, "HasShortHeight")
    result.IgnoreEvents = Xml.bool(props, "IgnoreEvents")
    result.CombatAbility = Xml.number(props, "CombatAbility", nil)
    result.CombatRange = Xml.number(props, "CombatRange", nil)
    result.CombatMovement = Xml.number(props, "CombatMovement", nil)
    result.Health = Xml.number(props, "Health", nil)
    result.MaxHealth = Xml.number(props, "MaxHealth", nil)
    result.Armour = number_alias(props, "Armour", "Armor", nil)
    result.CurrentWeapon = child_text(props, "CurrentWeapon")
    result.RelationshipGroup = child_text(props, "RelationshipGroup")
    result.RelationshipGroupAltered = Xml.bool(props, "RelationshipGroupAltered")
    result.ScenarioActive = Xml.bool(props, "ScenarioActive")
    result.ScenarioName = child_text(props, "ScenarioName")
    result.AnimActive = Xml.bool(props, "AnimActive")
    result.AnimDict = child_text(props, "AnimDict")
    result.AnimName = child_text(props, "AnimName")
    result.MovementGroupName = child_text(props, "MovementGroupName")
    result.WeaponMovementGroupName = child_text(props, "WeaponMovementGroupName")
    result.FacialMood = child_text(props, "FacialMood")
    result.PedVehicleSeat = Xml.number(props, "PedVehicleSeat", nil)
    apply_head_features(props, result)
    return result
end

function PedParser.outfit(xml)
    local block = root_child(xml, "OutfitPedData")
    if not block then return nil end

    local ped_properties = PedParser.ped_properties(block) or {}
    local clear_decals = Xml.bool(block, "ClearDecalOverlays")
    if clear_decals == nil then clear_decals = true end
    ped_properties.ClearDecalOverlays = clear_decals
    return {
        ModelHash = child_text(block, "ModelHash"),
        HashName = child_text(block, "HashName"),
        InitialHandle = Xml.number(block, "InitialHandle", nil),
        IsVisible = Xml.bool(block, "IsVisible"),
        OpacityLevel = Xml.number(block, "OpacityLevel", nil),
        PedProperties = ped_properties,
    }
end

return PedParser
