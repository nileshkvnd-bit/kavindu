local PlacementParser = {}

local Xml = require("ClickUl_Refactor.Features.Spawner.Menyoo.Xml")
local VehicleParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.VehicleParser")
local PedParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.PedParser")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local LEGACY_TYPE_MAP = {
    Prop = "3",
    prop = "3",
    Vehicle = "2",
    vehicle = "2",
    Ped = "1",
    ped = "1",
}

local ENTITY_TYPE_PED = "1"
local ENTITY_TYPE_VEHICLE = "2"
local ENTITY_TYPE_OBJECT = "3"

local function child_text(block, tag)
    local node = Xml.node(block, tag)
    if not node then
        return nil
    end

    return Xml.text(node)
end

local function attr_number(node, attr, default)
    return Util.to_number(Xml.attr(node, attr), default)
end

local function interior_coords(node)
    if Xml.attr(node, "X") ~= nil then
        return {
            x = attr_number(node, "X", 0.0),
            y = attr_number(node, "Y", 0.0),
            z = attr_number(node, "Z", 0.0),
        }
    end

    if Xml.node(node, "X") then
        return {
            x = Xml.number(node, "X", 0.0),
            y = Xml.number(node, "Y", 0.0),
            z = Xml.number(node, "Z", 0.0),
        }
    end

    return nil
end

local function interior_props(node)
    local props = {}
    for _, prop_node in ipairs(Xml.children(node, "InteriorProp")) do
        local name = Util.trim(Xml.attr(prop_node, "name"))
        if name and name ~= "" then
            props[#props + 1] = {
                name = name,
                enable = Xml.bool(prop_node, "enable"),
            }
        end
    end
    return props
end

local function interior_entries(container, tag, state_attr)
    local node = container and Xml.node(container, tag) or nil
    if not node then return {} end

    local entries = {}
    for _, interior_node in ipairs(Xml.children(node)) do
        entries[#entries + 1] = {
            id = Xml.number(interior_node, "id", nil),
            coords = interior_coords(interior_node),
            props = state_attr == "enable" and interior_props(interior_node) or nil,
            [state_attr] = Xml.bool(interior_node, state_attr),
        }
    end
    return entries
end

local function environment_interiors(block, root, tag, state_attr)
    local entries = interior_entries(block, tag, state_attr)
    if #entries > 0 or block == root then return entries end
    return interior_entries(root, tag, state_attr)
end

local function placement_type(block)
    local value = child_text(block, "Type")
    if value ~= nil and value ~= "" then
        return LEGACY_TYPE_MAP[value] or value
    end
    if Xml.node(block, "PedProperties") then
        return ENTITY_TYPE_PED
    end
    if Xml.node(block, "VehicleProperties") then
        return ENTITY_TYPE_VEHICLE
    end
    if Xml.node(block, "ObjectProperties") then
        return ENTITY_TYPE_OBJECT
    end
    return ENTITY_TYPE_OBJECT
end

local function position_rotation(block)
    local combined = Xml.node(block, "PositionRotation")
    if combined then
        return {
            X = Xml.number(combined, "X", nil),
            Y = Xml.number(combined, "Y", nil),
            Z = Xml.number(combined, "Z", nil),
            Pitch = Xml.number(combined, "Pitch", 0.0),
            Roll = Xml.number(combined, "Roll", 0.0),
            Yaw = Xml.number(combined, "Yaw", 0.0),
        }
    end

    local position = Xml.node(block, "Position")
    local rotation = Xml.node(block, "Rotation")
    if position or rotation then
        position = position or ""
        rotation = rotation or ""
        return {
            X = Xml.number(position, "X", nil),
            Y = Xml.number(position, "Y", nil),
            Z = Xml.number(position, "Z", nil),
            Pitch = Xml.number(rotation, "X", 0.0),
            Roll = Xml.number(rotation, "Y", 0.0),
            Yaw = Xml.number(rotation, "Z", 0.0),
        }
    end

    return {
        X = Xml.number(block, "X", nil),
        Y = Xml.number(block, "Y", nil),
        Z = Xml.number(block, "Z", nil),
        Pitch = Xml.number(block, "Pitch", 0.0),
        Roll = Xml.number(block, "Roll", 0.0),
        Yaw = Xml.number(block, "Yaw", 0.0),
    }
end

local function quaternion(block)
    local node = Xml.node(block, "Quaternion")
    if not node then return nil end
    return {
        X = Xml.number(node, "X", 0.0),
        Y = Xml.number(node, "Y", 0.0),
        Z = Xml.number(node, "Z", 0.0),
        W = Xml.number(node, "W", 1.0),
    }
end

local function visible_value(block)
    local value = Xml.bool(block, "IsVisible")
    if value ~= nil then return value end
    local ped_visible_value = Xml.bool(block, "PedVisible")
    if ped_visible_value ~= nil then return ped_visible_value end
    return nil
end

local function object_properties(block)
    local props = Xml.node(block, "ObjectProperties")
    if not props then return nil end

    local result = {}
    for _, child in ipairs(Xml.children(props)) do
        result[child.name] = Xml.text(child)
    end
    return result
end

local function particle_attributes_from(block)
    if not block then return nil end
    local asset_node = Xml.node(block, "PtfxLopAsset")
    local effect_node = Xml.node(block, "PtfxLopEffect")
    if not asset_node and not effect_node then return nil end
    return {
        ptfxLopAsset = asset_node and Xml.text(asset_node) or nil,
        ptfxLopEffect = effect_node and Xml.text(effect_node) or nil,
    }
end

local function particle_attributes(block)
    return particle_attributes_from(Xml.node(block, "PedProperties")) or particle_attributes_from(block)
end

local function task_vector(block, tag)
    local value = Xml.vector(block, tag)
    if not value then return nil end
    return {
        x = value.x,
        y = value.y,
        z = value.z,
    }
end

local function task_color(block)
    local color = Xml.node(block, "Colour")
    if not color then return nil end
    return {
        r = Xml.number(color, "R", 255),
        g = Xml.number(color, "G", 255),
        b = Xml.number(color, "B", 255),
        a = Xml.number(color, "A", 255),
    }
end

local function task_route(block)
    local route = Xml.node(block, "Route")
    if not route then return nil end

    local result = {}
    for _, child in ipairs(Xml.children(route, "Coord")) do
        local point = Xml.vector(child)
        if point then
            result[#result + 1] = {
                x = point.x,
                y = point.y,
                z = point.z,
            }
        end
    end
    if #result == 0 then return nil end
    return result
end

local function task_bool(block, tag)
    local node = Xml.node(block, tag)
    if not node and Xml.attr(block, tag) == nil then return nil end
    return Xml.bool(block, tag)
end

local function task_handle(block, tag)
    local value = child_text(block, tag)
    if value == nil or value == "" then value = Xml.attr(block, tag) end
    if value == nil or value == "" then return nil end
    if tostring(value):upper() == "PLAYER" then return "PLAYER" end
    return Util.to_number(value, nil)
end

local function entity_target(block, tag)
    local value = child_text(block, tag)
    if value == nil or value == "" then value = Xml.attr(block, tag) end
    if value == nil or value == "" then return nil end

    local normalized = tostring(value):upper()
    if normalized == "PLAYER" or normalized == "VEHICLE" then return normalized end
    return Util.to_number(value, nil)
end

local function task_sequence(block, default_auto_start)
    local ped_props = Xml.node(block, "PedProperties")
    local sequence_block = ped_props and Xml.node(ped_props, "TaskSequence") or nil
    sequence_block = sequence_block or Xml.node(block, "TaskSequence")
    if not sequence_block then return nil end

    local sequence = {
        tasks = {},
        autoStart = default_auto_start,
    }

    for _, task_block in ipairs(Xml.children(sequence_block)) do
        if task_block.name == "Task" then
            local task_type = Xml.number(task_block, "Type", nil)
            if task_type then
                local is_trigger_fx = task_type == 39
                local colour = task_color(task_block)
                if is_trigger_fx and not colour then
                    colour = { r = 255, g = 255, b = 255, a = 255 }
                end

                sequence.tasks[#sequence.tasks + 1] = {
                    Type = task_type,
                    Duration = Xml.number(task_block, "Duration", nil),
                    KeepTaskRunningAfterTime = Xml.number(task_block, "KeepTaskRunningAfterTime", nil),
                    IsLoopedTask = task_bool(task_block, "IsLoopedTask"),
                    Delay = Xml.number(task_block, "Delay", is_trigger_fx and 500 or 0),
                    AssetName = child_text(task_block, "AssetName") or (is_trigger_fx and "scr_michael2" or nil),
                    EffectName = child_text(task_block, "EffectName") or (is_trigger_fx and "scr_abattoir_ped_sliced" or nil),
                    Scale = Xml.number(task_block, "Scale", is_trigger_fx and 0.8 or 1.0),
                    BlipScale = Xml.number(task_block, "Scale", nil),
                    Label = child_text(task_block, "Label"),
                    BlipColour = Xml.number(task_block, "Colour", nil),
                    Alpha = Xml.number(task_block, "Alpha", nil),
                    Icon = Xml.number(task_block, "Icon", nil),
                    IsFlashing = task_bool(task_block, "IsFlashing"),
                    IsFriendly = task_bool(task_block, "IsFriendly"),
                    IsShortRange = task_bool(task_block, "IsShortRange"),
                    ShowRoute = task_bool(task_block, "ShowRoute"),
                    ShowNumber = Xml.number(task_block, "ShowNumber", nil),
                    AnimDict = child_text(task_block, "AnimDict"),
                    AnimName = child_text(task_block, "AnimName"),
                    Speed = Xml.number(task_block, "Speed", nil),
                    SpeedMultiplier = Xml.number(task_block, "SpeedMultiplier", nil),
                    Flag = Xml.number(task_block, "Flag", nil),
                    LockPos = Xml.bool(task_block, "LockPos"),
                    OverrideDurationToNormalSpeedAnimDuration = Xml.bool(task_block, "OverrideDurationToNormalSpeedAnimDuration"),
                    SpeechName = child_text(task_block, "SpeechName"),
                    VoiceName = child_text(task_block, "VoiceName"),
                    ParamName = child_text(task_block, "ParamName"),
                    ScenarioName = child_text(task_block, "ScenarioName"),
                    VehicleInitHandle = task_handle(task_block, "VehicleInitHandle"),
                    SeatIndex = Xml.number(task_block, "SeatIndex", nil),
                    IsRelative = task_bool(task_block, "IsRelative"),
                    Pitch = Xml.number(task_block, "Pitch", nil),
                    Roll = Xml.number(task_block, "Roll", nil),
                    Yaw = Xml.number(task_block, "Yaw", nil),
                    Heading = Xml.number(task_block, "Heading", nil),
                    Magnitude = Xml.number(task_block, "Magnitude", nil),
                    ForceType = Xml.number(task_block, "ForceType", nil),
                    SpeedInKmph = Xml.number(task_block, "SpeedInKmph", nil),
                    DrivingStyle = Xml.number(task_block, "DrivingStyle", nil),
                    OnGroundOnly = task_bool(task_block, "OnGroundOnly"),
                    TakeVehicleToo = task_bool(task_block, "TakeVehicleToo"),
                    Radius = Xml.number(task_block, "Radius", nil),
                    SearchRadius = Xml.number(task_block, "SearchRadius", nil),
                    MinDistance = Xml.number(task_block, "MinDistance", nil),
                    Warp = task_bool(task_block, "Warp"),
                    NewValue = Xml.number(task_block, "NewValue", nil),
                    FreezeType = Xml.number(task_block, "FreezeType", nil),
                    OpacityValue = Xml.number(task_block, "OpacityValue", nil),
                    HealthValue = Xml.number(task_block, "HealthValue", nil),
                    WeaponHash = Xml.number(task_block, "WeaponHash", nil),
                    CanPeakInCover = task_bool(task_block, "CanPeakInCover"),
                    AngularFrequency = Xml.number(task_block, "AngularFrequency", nil),
                    DampRatio = Xml.number(task_block, "DampRatio", nil),
                    TargetInitHandle = task_handle(task_block, "TargetInitHandle"),
                    Destination = task_vector(task_block, "Destination"),
                    TargetPos = task_vector(task_block, "TargetPos"),
                    Position = task_vector(task_block, "Position"),
                    Coord = task_vector(task_block, "Coord"),
                    CoverPos = task_vector(task_block, "CoverPos"),
                    Origin = task_vector(task_block, "Origin"),
                    RunwayStart = task_vector(task_block, "RunwayStart"),
                    RunwayEnd = task_vector(task_block, "RunwayEnd"),
                    OffsetVector = task_vector(task_block, "OffsetVector"),
                    Point = task_vector(task_block, "Point"),
                    Route = task_route(task_block),
                    Colour = colour,
                    RelativePosition = task_vector(task_block, "RelativePosition"),
                    RelativeRotation = task_vector(task_block, "RelativeRotation"),
                }
            end
        end
    end

    if #sequence.tasks == 0 then return nil end
    if sequence.autoStart == nil then sequence.autoStart = true end
    return sequence
end

local function model_hash(block, allow_legacy_model)
    local model = child_text(block, "ModelHash")
    if model or not allow_legacy_model then return model end
    return child_text(block, "HashName") or child_text(block, "Hash")
end

local function attachment_state(attachment, allow_legacy_model)
    local explicit = Xml.bool(attachment, "isAttached")
    if explicit ~= nil then return explicit end
    return allow_legacy_model == true
end

local function parse_block(block, default_auto_start, allow_legacy_model)
    local attachment = Xml.node(block, "Attachment")
    local entity_type = placement_type(block)
    local entity = {
        Type = entity_type,
        ModelHash = model_hash(block, allow_legacy_model),
        HashName = child_text(block, "HashName"),
        InitialHandle = Xml.number(block, "InitialHandle", nil),
        Dynamic = Xml.bool(block, "Dynamic"),
        IsVisible = visible_value(block),
        IsInvincible = Xml.bool(block, "IsInvincible"),
        FrozenPos = Xml.bool(block, "FrozenPos"),
        HasGravity = Xml.bool(block, "HasGravity"),
        IsOnFire = Xml.bool(block, "IsOnFire"),
        IsBulletProof = Xml.bool(block, "IsBulletProof"),
        IsFireProof = Xml.bool(block, "IsFireProof"),
        IsExplosionProof = Xml.bool(block, "IsExplosionProof"),
        IsCollisionProof = Xml.bool(block, "IsCollisionProof"),
        IsMeleeProof = Xml.bool(block, "IsMeleeProof"),
        IsDrownProof = Xml.bool(block, "IsDrownProof"),
        IsSteamProof = Xml.bool(block, "IsSteamProof"),
        IsOnlyDamagedByPlayer = Xml.bool(block, "IsOnlyDamagedByPlayer"),
        OpacityLevel = Xml.number(block, "OpacityLevel", nil),
        LodDistance = Xml.number(block, "LodDistance", nil),
        Health = Xml.number(block, "Health", nil),
        MaxHealth = Xml.number(block, "MaxHealth", nil),
        PositionRotation = position_rotation(block),
        Quaternion = quaternion(block),
        ParticleAttributes = particle_attributes(block),
        TaskSequence = task_sequence(block, default_auto_start),
    }
    if entity_type == ENTITY_TYPE_VEHICLE then
        entity.VehicleProperties = VehicleParser.vehicle_properties(block)
    elseif entity_type == ENTITY_TYPE_PED then
        entity.PedProperties = PedParser.ped_properties(block)
    elseif entity_type == ENTITY_TYPE_OBJECT then
        entity.ObjectProperties = object_properties(block)
    end
    if entity.HasGravity == nil then entity.HasGravity = true end
    if entity.FrozenPos == nil then entity.FrozenPos = not (entity.Dynamic == true) end
    if attachment then
        entity.Attachment = {
            isAttached = attachment_state(attachment, allow_legacy_model),
            AttachedTo = entity_target(attachment, "AttachedTo"),
            BoneIndex = Xml.number(attachment, "BoneIndex", -1),
            X = Xml.number(attachment, "X", 0.0),
            Y = Xml.number(attachment, "Y", 0.0),
            Z = Xml.number(attachment, "Z", 0.0),
            Pitch = Xml.number(attachment, "Pitch", 0.0),
            Roll = Xml.number(attachment, "Roll", 0.0),
            Yaw = Xml.number(attachment, "Yaw", 0.0),
        }
    end
    return entity
end

local function marker_vector(block, tag, defaults)
    local nested = tag and Xml.node(block, tag) or block
    local vector = nested and (Xml.vector(nested, "Position") or Xml.vector(nested)) or nil
    defaults = defaults or {}
    return {
        x = vector and vector.x or defaults.x or 0.0,
        y = vector and vector.y or defaults.y or 0.0,
        z = vector and vector.z or defaults.z or 0.0,
    }
end

local function marker_rotation(block)
    local position = Xml.node(block, "Position") or block
    local rotation = Xml.vector(position, "Rotation") or Xml.vector(block, "Rotation")
    return {
        x = rotation and rotation.x or Xml.number(position, "RotX", 0.0),
        y = rotation and rotation.y or Xml.number(position, "RotY", 0.0),
        z = rotation and rotation.z or Xml.number(position, "RotZ", 0.0),
    }
end

local function marker_attachment(block)
    local attachment = Xml.node(block, "Attachment")
    if not attachment then return nil end

    local init_handle = Xml.number(attachment, "InitHandle", nil)
    if not init_handle then return nil end

    local offset = Xml.vector(attachment, "Offset") or { x = 0.0, y = 0.0, z = 0.0 }
    local rotation = Xml.vector(attachment, "Rotation") or { x = 0.0, y = 0.0, z = 0.0 }
    return {
        InitHandle = init_handle,
        Offset = {
            x = Util.to_number(offset.x, 0.0),
            y = Util.to_number(offset.y, 0.0),
            z = Util.to_number(offset.z, 0.0),
        },
        Rotation = {
            x = Util.to_number(rotation.x, 0.0),
            y = Util.to_number(rotation.y, 0.0),
            z = Util.to_number(rotation.z, 0.0),
        },
    }
end

local function marker_destination(block)
    local destination = Xml.node(block, "Destination")
    if not destination then return nil end

    local position = marker_vector(destination)
    local rotation = marker_rotation(destination)
    return {
        LinkInitHandle = Xml.number(destination, "LinkInitHandle", 0),
        X = position.x,
        Y = position.y,
        Z = position.z,
        RotX = rotation.x,
        RotY = rotation.y,
        RotZ = rotation.z,
        Attachment = marker_attachment(destination),
    }
end

local function marker_color(block)
    local color = Xml.node(block, "Colour")
    return {
        r = Xml.number(color, "R", 0),
        g = Xml.number(color, "G", 0),
        b = Xml.number(color, "B", 0),
        a = Xml.number(color, "A", 0),
    }
end

local function parse_marker(block)
    local position = marker_vector(block, "Position")
    local rotation = marker_rotation(block)
    return {
        Name = child_text(block, "Name", ""),
        InitialHandle = Xml.number(block, "InitialHandle", nil),
        Type = Xml.number(block, "Type", 0),
        X = position.x,
        Y = position.y,
        Z = position.z,
        RotX = rotation.x,
        RotY = rotation.y,
        RotZ = rotation.z,
        Scale = Xml.number(block, "Scale", 0.0),
        ShowName = Xml.bool(block, "ShowName") == true,
        RotateContinuously = Xml.bool(block, "RotateContinuously") == true,
        AllowVehicles = Xml.bool(block, "AllowVehicles") == true,
        Colour = marker_color(block),
        Attachment = marker_attachment(Xml.node(block, "Position") or block),
        Destination = marker_destination(block),
        DestinationHeading = Xml.number(block, "DestinationHeading", 0.0),
    }
end

local function task_sequence_auto_start(root, container, default_value)
    if container then
        local value = Xml.bool(container, "StartTaskSequencesOnLoad")
        if value ~= nil then return value end
    end

    if root and root ~= container then
        local value = Xml.bool(root, "StartTaskSequencesOnLoad")
        if value ~= nil then return value end
    end

    return default_value
end

local function environment_node(block, root, tag)
    local node = Xml.node(block, tag)
    if not node and block ~= root then node = Xml.node(root, tag) end
    return node
end

local function required_coords(block)
    if not block then return nil end
    local x = Xml.number(block, "X", nil)
    local y = Xml.number(block, "Y", nil)
    local z = Xml.number(block, "Z", nil)
    if x == nil or y == nil or z == nil then return nil end
    return { x = x, y = y, z = z }
end

function PlacementParser.attachments(xml)
    local result = {}
    local root = Xml.root(xml)
    if not root then
        return result
    end

    local container = nil
    if root.name == "SpoonerAttachments" or root.name == "SpoonerPlacements" then
        container = root
    else
        container = Xml.node(root, "SpoonerAttachments") or Xml.node(root, "SpoonerPlacements")
    end

    local block = container or root
    local default_auto_start = task_sequence_auto_start(root, container, nil)
    if container then
        result.SetAttachmentsPersistentAndAddToSpoonerDatabase = Xml.bool(container, "SetAttachmentsPersistentAndAddToSpoonerDatabase")
    end

    for _, item in ipairs(Xml.children(block)) do
        if item.name == "Attachment" then
            result[#result + 1] = parse_block(item, default_auto_start)
        elseif item.name == "Placement" then
            result[#result + 1] = parse_block(item, default_auto_start)
        end
    end
    return result
end

function PlacementParser.map_placements(xml)
    local placements = {}
    local markers = {}
    local root = Xml.root(xml)
    if not root then
        return placements, markers
    end

    local map_objects = root.name == "Map" and Xml.node(root, "Objects") or nil
    if map_objects and not Xml.node(map_objects, "MapObject") then map_objects = nil end

    local container = root.name == "SpoonerPlacements" and root or Xml.node(root, "SpoonerPlacements")
    container = container or map_objects
    local block = container or root
    local default_auto_start = task_sequence_auto_start(root, container, true)
    for _, item in ipairs(Xml.children(block)) do
        if item.name == "Placement" or item.name == "MapObject" or item.name == "Attachment" then
            local allow_legacy_model = item.name == "MapObject" or item.name == "Attachment"
            placements[#placements + 1] = parse_block(item, default_auto_start, allow_legacy_model)
        elseif item.name == "Marker" then
            markers[#markers + 1] = parse_marker(item)
        end
    end
    return placements, markers
end

function PlacementParser.map_environment(xml)
    local root = Xml.root(xml)
    if not root then return {} end

    local block = root.name == "SpoonerPlacements" and root or Xml.node(root, "SpoonerPlacements") or root
    if root.name == "Map" then
        block = Xml.node(root, "Objects") or root
    end

    local timecycle = environment_node(block, root, "TimecycleModifier")
    local img_loading_coords = environment_node(block, root, "ImgLoadingCoords")
    local reference_coords = environment_node(block, root, "ReferenceCoords")
    local note = environment_node(block, root, "Note")
    local audio_file = environment_node(block, root, "AudioFile")
    local clear_database = Xml.bool(block, "ClearDatabase")
    if clear_database == nil and block ~= root then
        clear_database = Xml.bool(root, "ClearDatabase")
    end
    local clear_markers = Xml.bool(block, "ClearMarkers")
    if clear_markers == nil and block ~= root then
        clear_markers = Xml.bool(root, "ClearMarkers")
    end

    return {
        ClearDatabase = clear_database,
        ClearMarkers = clear_markers,
        ClearWorld = Xml.number(block, "ClearWorld", Xml.number(root, "ClearWorld", nil)),
        WeatherToSet = child_text(block, "WeatherToSet") or child_text(root, "WeatherToSet"),
        TimecycleModifier = timecycle and Xml.text(timecycle) or nil,
        TimecycleStrength = timecycle and Xml.number(timecycle, "strength", 1.0) or nil,
        ImgLoadingCoords = img_loading_coords and Xml.vector(img_loading_coords) or nil,
        ReferenceCoords = reference_coords and Xml.vector(reference_coords) or nil,
        Note = note and Xml.text(note) or nil,
        AudioFile = audio_file and {
            FileName = Xml.text(audio_file),
            Volume = Xml.number(audio_file, "volume", nil),
            Unsupported = true,
        } or nil,
        InteriorsToEnable = environment_interiors(block, root, "InteriorsToEnable", "enable"),
        InteriorsToCap = environment_interiors(block, root, "InteriorsToCap", "cap"),
    }
end

function PlacementParser.map_root_name(xml)
    local root = Xml.root(xml)
    return root and root.name or nil
end

function PlacementParser.map_reference_coords(xml)
    local root = Xml.root(xml)
    if not root then return nil end

    local ref = required_coords(Xml.node(root, "ReferenceCoords"))
    if ref then return ref end

    local metadata = Xml.node(root, "Metadata")
    if metadata then
        ref = required_coords(Xml.node(metadata, "TeleportPoint") or Xml.node(metadata, "LoadingPoint"))
        if ref then return ref end
    end

    local map_objects = root.name == "Map" and Xml.node(root, "Objects") or nil
    if map_objects then
        ref = required_coords(Xml.node(map_objects, "ReferenceCoords"))
        if ref then return ref end

        local first_object = Xml.node(map_objects, "MapObject")
        if first_object then return required_coords(Xml.node(first_object, "Position")) end
    end

    return nil
end

return PlacementParser
