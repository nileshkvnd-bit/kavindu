local IplParser = {}

local Xml = require("ClickUl_Refactor.Features.Spawner.Menyoo.Xml")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function root_child(xml, tag)
    local root = Xml.root(xml)
    if not root then
        return nil
    end
    if root.name == tag then
        return root
    end

    return Xml.node(root, tag)
end

local function list_from(xml, block_name)
    local list = {}
    local block = root_child(xml, block_name)
    if not block then return list end

    for _, child in ipairs(Xml.children(block)) do
        local trimmed = Util.trim(Xml.text(child))
        if trimmed and trimmed ~= "" then list[#list + 1] = trimmed end
    end
    return list
end

local function options_from(xml)
    local block = root_child(xml, "IPLsToLoad")
    return {
        load_mp_maps = block and Util.to_boolean(Xml.attr(block, "load_mp_maps")) or false,
        load_sp_maps = block and Util.to_boolean(Xml.attr(block, "load_sp_maps")) or false,
    }
end

function IplParser.ipls(xml)
    return list_from(xml, "IPLsToLoad"), list_from(xml, "IPLsToRemove"), options_from(xml)
end

return IplParser
