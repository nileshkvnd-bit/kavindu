local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")
local MenyooVehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooVehicleCustomizer")
local MenyooPedCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooPedCustomizer")
local ObjectCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.ObjectCustomizer")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local TaskSequence = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Runner")
local AttributeMapper = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttributeMapper")

local PlacementSpawner = {}

local function position(placement)
    local pos = placement.PositionRotation
    if not pos or pos.X == nil or pos.Y == nil or pos.Z == nil then return nil end
    return {
        x = pos.X,
        y = pos.Y,
        z = pos.Z,
    }
end

local function heading(placement)
    return placement.PositionRotation and placement.PositionRotation.Yaw or 0.0
end

local function register_handle(handle_map, initial_handle, handle)
    if not initial_handle then return end
    handle_map[initial_handle] = handle
    handle_map[tostring(initial_handle)] = handle
end

local function apply_options(handle, placement, settings)
    EntityOptions.apply(handle, {
        is_visible = placement.IsVisible,
        is_invincible = settings.entity_god_mode or placement.IsInvincible,
        is_frozen = placement.FrozenPos == nil and settings.spawn_frozen or placement.FrozenPos,
        has_gravity = placement.HasGravity,
        alpha = placement.OpacityLevel,
        is_on_fire = placement.IsOnFire,
        rotation = placement.PositionRotation,
        quaternion = placement.Quaternion,
        lod_dist = placement.LodDistance,
        health = placement.Health,
        max_health = placement.MaxHealth,
        is_bullet_proof = placement.IsBulletProof,
        is_fire_proof = placement.IsFireProof,
        is_explosion_proof = placement.IsExplosionProof,
        is_melee_proof = placement.IsMeleeProof,
        is_drown_proof = placement.IsDrownProof,
        is_steam_proof = placement.IsSteamProof,
        is_only_damaged_by_player = placement.IsOnlyDamagedByPlayer,
    })
end

local function apply_type_properties(handle, placement)
    if tostring(placement.Type) == "2" and placement.VehicleProperties then
        MenyooVehicleCustomizer.apply(handle, AttributeMapper.vehicle_properties(placement.VehicleProperties))
    elseif tostring(placement.Type) == "1" then
        MenyooPedCustomizer.apply_runtime_properties(handle, AttributeMapper.ped_properties(placement.PedProperties), placement.ModelHash)
    elseif tostring(placement.Type) == "3" and placement.ObjectProperties then
        ObjectCustomizer.apply(handle, AttributeMapper.object_properties(placement.ObjectProperties))
    end
end

local function restore_menyoo_load_state(handle, placement)
    EntityOptions.restore_load_state(handle, { is_dynamic = placement.Dynamic })
end

local function apply_menyoo_collision(handle, placement)
    EntityOptions.set_collision(handle, placement.IsCollisionProof ~= true, false)
end

local function seat_ped_in_parent_vehicle(child, parent, placement)
    if tostring(placement.Type) ~= "1" or type(placement.PedProperties) ~= "table" then return false end
    local ped_attributes = AttributeMapper.ped_properties(placement.PedProperties)
    local seat = tonumber(ped_attributes and ped_attributes.seat)
    if seat == nil or seat == -2 then return false end

    return Attachment.seat_ped_in_vehicle(child, parent, seat)
end

local function attachment_parent(attachment, handle_map)
    if not attachment then return nil end

    local attached_to = attachment.AttachedTo
    if attached_to == "PLAYER" then return EntityFactory.player_ped() end
    if attached_to == "VEHICLE" then return EntityFactory.player_vehicle() end
    return handle_map[attached_to] or handle_map[tostring(attached_to)]
end

function PlacementSpawner.spawn_one(placement, handle_map, created, settings, task_records)
    local model = placement.ModelHash
    if not model then return nil, "missing_model" end

    local coords = position(placement)
    if not coords then return nil, "missing_coords" end

    local handle, spawn_error = EntityFactory.spawn_by_type(placement.Type or "3", model, coords, heading(placement), placement.Dynamic)
    if not handle or handle == 0 then return nil, spawn_error or "spawn_failed" end

    created[#created + 1] = { handle = handle, type = placement.Type or "3" }
    register_handle(handle_map, placement.InitialHandle, handle)
    EntityFactory.set_coords_no_offset(handle, coords)
    EntityOptions.enter_load_state(handle)
    if tostring(placement.Type) == "2" then
        apply_type_properties(handle, placement)
        apply_options(handle, placement, settings)
    else
        apply_options(handle, placement, settings)
        apply_type_properties(handle, placement)
    end
    restore_menyoo_load_state(handle, placement)
    apply_menyoo_collision(handle, placement)
    if not settings or settings.enable_ptfx ~= false then Ptfx.start_menyoo_lop(handle, placement.ParticleAttributes) end
    if task_records and placement.TaskSequence then
        task_records[#task_records + 1] = { handle = handle, sequence = placement.TaskSequence }
    end
    return handle
end

function PlacementSpawner.spawn_all(placements, settings)
    local handle_map = {}
    local created = {}
    local task_records = {}
    local first_error = nil
    for _, placement in ipairs(placements or {}) do
        local _, err = PlacementSpawner.spawn_one(placement, handle_map, created, settings, task_records)
        first_error = first_error or err
    end
    return created, handle_map, first_error, task_records
end

function PlacementSpawner.start_task_sequences(task_records, handle_map)
    return TaskSequence.start_many(task_records or {}, handle_map)
end

function PlacementSpawner.attach_all(placements, handle_map)
    for _, placement in ipairs(placements or {}) do
        if placement.InitialHandle and placement.Attachment and placement.Attachment.isAttached == true and placement.Attachment.AttachedTo then
            local child = handle_map[placement.InitialHandle] or handle_map[tostring(placement.InitialHandle)]
            local parent = attachment_parent(placement.Attachment, handle_map)
            if child and parent then
                if seat_ped_in_parent_vehicle(child, parent, placement) then goto continue end
                local active_collision = placement.IsCollisionProof ~= true
                Attachment.attach(child, parent, placement.Attachment.BoneIndex or -1, {
                    x = placement.Attachment.X,
                    y = placement.Attachment.Y,
                    z = placement.Attachment.Z,
                }, {
                    x = placement.Attachment.Pitch,
                    y = placement.Attachment.Roll,
                    z = placement.Attachment.Yaw,
                }, { active_collision = active_collision, bone_is_index = true })
            end
        end
        ::continue::
    end
end

return PlacementSpawner
