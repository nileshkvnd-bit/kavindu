local MapSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Parser = require("ClickUl_Refactor.Features.Spawner.Menyoo.Parser")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local Ipl = require("ClickUl_Refactor.Features.Spawner.Core.Ipl")
local Blip = require("ClickUl_Refactor.Features.Spawner.Core.Blip")
local MapEnvironment = require("ClickUl_Refactor.Features.Spawner.Core.MapEnvironment")
local PlacementSpawner = require("ClickUl_Refactor.Features.Spawner.Menyoo.PlacementSpawner")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local WorldMarker = require("ClickUl_Refactor.Features.Spawner.Core.WorldMarker")

local MAP_RECORDS <const> = "menyoo_spawned_maps"
local ENTITY_RECORDS <const> = "menyoo_spawned_entities"
local OUTFIT_RECORDS <const> = "menyoo_spawned_outfits"

local function ref_coords(xml, placements)
    local ref = Parser.map_reference_coords(xml)
    if ref then return ref end

    local first = placements and placements[1]
    if first and first.PositionRotation
        and first.PositionRotation.X ~= nil
        and first.PositionRotation.Y ~= nil
        and first.PositionRotation.Z ~= nil then
        return {
            x = first.PositionRotation.X,
            y = first.PositionRotation.Y,
            z = first.PositionRotation.Z,
        }
    end
    return EntityFactory.player_coords()
end

local function cleanup_map(record)
    WorldMarker.stop(record)
    if record.reference_blip then
        Blip.remove(record.reference_blip)
        record.reference_blip = nil
    end
    return Ipl.cleanup_map(record)
end

local function basename_without_extension(path)
    path = tostring(path or "")
    local name = path:match("([^\\/]+)$") or path
    return name:match("^(.*)%.[^%.]*$") or name
end

local function clear_marker_record(record)
    WorldMarker.stop(record)
    record.markers = nil
    record.marker_handle_map = nil
    record.marker_initial_map = nil
    record.marker_thread_id = nil
    record.markers_active = false
    record.markers_stopped = true
end

local function clear_markers_in_range_record(center, radius)
    return function(record)
        if type(record) ~= "table" or type(record.markers) ~= "table" then return end

        local kept = {}
        local removed = false
        for _, marker in ipairs(record.markers) do
            if WorldMarker.is_marker_in_range(marker, record.marker_handle_map, center, radius) then
                removed = true
            else
                kept[#kept + 1] = marker
            end
        end
        if not removed then return end

        if #kept == 0 then
            clear_marker_record(record)
            return
        end
        WorldMarker.stop(record)
        WorldMarker.start(record, kept, record.marker_handle_map)
    end
end

local function remove_duplicate_markers_record(new_markers)
    return function(record)
        if type(record) ~= "table" or type(record.markers) ~= "table" then return end

        local kept = {}
        local removed = false
        for _, existing in ipairs(record.markers) do
            local duplicate = false
            for _, marker in ipairs(new_markers or {}) do
                if WorldMarker.same_marker(existing, marker) then
                    duplicate = true
                    break
                end
            end
            if duplicate then
                removed = true
            else
                kept[#kept + 1] = existing
            end
        end
        if not removed then return end

        if #kept == 0 then
            clear_marker_record(record)
            return
        end
        WorldMarker.stop(record)
        WorldMarker.start(record, kept, record.marker_handle_map)
    end
end

local function has_environment_actions(environment)
    return (environment.InteriorsToEnable and #environment.InteriorsToEnable > 0)
        or (environment.InteriorsToCap and #environment.InteriorsToCap > 0)
        or environment.ClearDatabase ~= nil
        or environment.ClearMarkers ~= nil
        or environment.ClearWorld ~= nil
        or environment.ImgLoadingCoords ~= nil
        or environment.ReferenceCoords ~= nil
        or environment.AudioFile ~= nil
        or environment.WeatherToSet ~= nil
        or environment.TimecycleModifier ~= nil
end

function MapSpawner.spawn_xml(xml, spawn_coords)
    if not xml or xml == "" then return nil, 0, "empty_content" end
    local placements, markers = Parser.map_placements(xml)
    local has_placements = placements and #placements > 0
    local has_markers = markers and #markers > 0
    local to_load, to_remove, ipl_options = Parser.ipls(xml)
    local has_ipl_lists = (to_load and #to_load > 0) or (to_remove and #to_remove > 0)
    local has_ipl_options = ipl_options and (ipl_options.load_mp_maps == true or ipl_options.load_sp_maps == true)
    local environment = Parser.map_environment(xml)
    if not has_placements and not has_markers and not has_ipl_lists and not has_ipl_options and not has_environment_actions(environment) then
        return nil, 0, "no_placements_or_markers"
    end

    local settings = Settings.get("menyoo_map")
    if settings.delete_old_map then MapSpawner.delete_all() end

    Ipl.remove_many(to_remove)

    local ref = spawn_coords or ref_coords(xml, placements)

    local map_state_entered = Ipl.enter_map_state(ipl_options)
    local loaded_ipls = {}
    for _, ipl in ipairs(to_load or {}) do
        if Ipl.request(ipl) then loaded_ipls[#loaded_ipls + 1] = ipl end
    end
    MapEnvironment.apply_interiors(environment)
    if map_state_entered then Ipl.leave_map_state(ipl_options) end

    MapEnvironment.set_weather(environment.WeatherToSet)
    MapEnvironment.set_timecycle(environment.TimecycleModifier, environment.TimecycleStrength)
    local clear_world_count = MapEnvironment.clear_world(environment.ReferenceCoords, environment.ClearWorld)
    if clear_world_count then MapSpawner.clear_markers_in_range(environment.ReferenceCoords, environment.ClearWorld) end
    if environment.ClearDatabase == true then MapSpawner.clear_database() end
    if environment.ClearMarkers == true then MapSpawner.clear_markers() end

    local loading_state = MapEnvironment.begin_loading(environment.ImgLoadingCoords)
    local created, handle_map, spawn_error, task_records = PlacementSpawner.spawn_all(placements or {}, settings)
    if has_placements and #created == 0 and spawn_error == "missing_coords" then
        MapEnvironment.finish_loading(loading_state, ref, settings.teleport_to_map)
        if loaded_ipls and #loaded_ipls > 0 then
            SpawnRegistry.add(MAP_RECORDS, {
                entities = created,
                attempted = placements and #placements or 0,
                refCoords = ref,
                reference_coords = environment.ReferenceCoords,
                loaded_ipls = loaded_ipls,
                ipl_options = ipl_options,
                spawn_error = spawn_error,
            })
        end
        return nil, 0, spawn_error
    end
    Runtime.yield(1000)
    PlacementSpawner.attach_all(placements or {}, handle_map)
    local task_error = PlacementSpawner.start_task_sequences(task_records, handle_map)
    spawn_error = spawn_error or task_error

    MapEnvironment.finish_loading(loading_state, ref, settings.teleport_to_map)

    local map_data = {
        entities = created,
        attempted = placements and #placements or 0,
        refCoords = ref,
        reference_coords = environment.ReferenceCoords,
        loaded_ipls = loaded_ipls,
        ipl_options = ipl_options,
        markers = markers,
        handle_map = handle_map,
        spawn_error = spawn_error,
        note = environment.Note,
        audio_file = environment.AudioFile,
        clear_database = environment.ClearDatabase == true,
    }
    if has_markers then MapSpawner.remove_duplicate_markers(markers) end
    SpawnRegistry.add(MAP_RECORDS, map_data)
    if has_markers then WorldMarker.start(map_data, markers, handle_map) end
    return map_data, #created, spawn_error
end

function MapSpawner.spawn_file(path, spawn_coords)
    local content, read_error = Fs.read_text(path)
    if not content then return nil, 0, read_error end
    local map_data, count, err = MapSpawner.spawn_xml(content, spawn_coords)
    if map_data then
        SpawnRegistry.update_last(MAP_RECORDS, function(map_data)
            map_data.file_path = path
            if map_data.reference_coords then
                local blip = Blip.create_coord(map_data.reference_coords, {
                    flashing = false,
                    scale = 0.8,
                    friendly = true,
                    sprite = 176,
                    colour = 2,
                    label = basename_without_extension(path),
                })
                if blip and blip ~= 0 then map_data.reference_blip = blip end
            end
        end)
    end
    return map_data, count, err
end

function MapSpawner.teleport_to_reference_xml(xml)
    if not xml or xml == "" then return false, "empty_content" end
    if Parser.map_root_name(xml) ~= "SpoonerPlacements" then return false, "missing_root" end
    local reference = Parser.map_reference_coords(xml)
    if not reference then return false, "missing_reference_coords" end
    if EntityFactory.teleport_player(reference, true) then return true, nil end
    return false, "teleport_failed"
end

function MapSpawner.teleport_to_reference_file(path)
    local content, read_error = Fs.read_text(path)
    if not content then return false, read_error end
    return MapSpawner.teleport_to_reference_xml(content)
end

function MapSpawner.delete(index)
    return SpawnRegistry.delete_entity_record_at(MAP_RECORDS, index, cleanup_map)
end

function MapSpawner.delete_all()
    return SpawnRegistry.delete_entity_records(MAP_RECORDS, cleanup_map)
end

function MapSpawner.clear_database()
    local count = 0
    count = count + SpawnRegistry.delete_entity_records(MAP_RECORDS, cleanup_map)
    count = count + SpawnRegistry.delete_entity_records(ENTITY_RECORDS)
    count = count + SpawnRegistry.delete_outfits(OUTFIT_RECORDS)
    Runtime.yield(0)
    return count
end

function MapSpawner.clear_markers()
    return SpawnRegistry.update_records(MAP_RECORDS, clear_marker_record)
end

function MapSpawner.clear_markers_in_range(center, radius)
    if not center or not radius then return 0 end
    return SpawnRegistry.update_records(MAP_RECORDS, clear_markers_in_range_record(center, radius))
end

function MapSpawner.remove_duplicate_markers(markers)
    if type(markers) ~= "table" or #markers == 0 then return 0 end
    return SpawnRegistry.update_records(MAP_RECORDS, remove_duplicate_markers_record(markers))
end

function MapSpawner.get_spawned()
    return SpawnRegistry.list(MAP_RECORDS)
end

return MapSpawner
