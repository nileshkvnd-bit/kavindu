local OutfitSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Parser = require("ClickUl_Refactor.Features.Spawner.Menyoo.Parser")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local MenyooPedCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooPedCustomizer")
local PedAppearance = require("ClickUl_Refactor.Features.Spawner.Core.PedAppearance")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local AttachmentSpawner = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttachmentSpawner")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")
local AttributeMapper = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttributeMapper")

local OUTFIT_RECORDS <const> = "menyoo_spawned_outfits"
local SWAP_SETTLE_MS <const> = 0

local function spawn_attachments(xml, outfit, target_ped, spawn_coords, settings)
    local parent_map = AttachmentSpawner.create_parent_map(outfit.InitialHandle, target_ped)
    local attachment_defs = Parser.attachments(xml)
    local attachments_persistent = attachment_defs.SetAttachmentsPersistentAndAddToSpoonerDatabase == true
    local attachments, err = AttachmentSpawner.spawn_many(attachment_defs, parent_map, spawn_coords, {
        active_collision = not settings.disable_collision,
        default_parent = target_ped,
        use_position_rotation = false,
        apply_entity_options = true,
        apply_type_properties = true,
        start_task_sequences = attachments_persistent,
    })
    return attachments, err
end

function OutfitSpawner.spawn_xml(xml, opts)
    local outfit = Parser.outfit(xml)
    if not outfit then return nil, nil, "not_outfit" end

    opts = opts or {}
    local settings = Settings.get("menyoo_outfit")
    if settings.delete_old_outfit and not opts.is_preview then OutfitSpawner.delete_all() end

    if not outfit.ModelHash then return nil, nil, "missing_model" end

    local player_ped = EntityFactory.player_ped()
    if not player_ped or player_ped == 0 then return nil, nil, "missing_player_ped" end

    local mode = opts.spawn_mode or settings.spawn_mode or Settings.OUTFIT_SPAWN_MODE.APPLY_TO_PLAYER
    local spawn_coords = opts.spawn_coords or EntityFactory.forward_spawn_coords(2.0) or EntityFactory.player_coords()
    local builds_standalone_ped = mode == Settings.OUTFIT_SPAWN_MODE.SPAWN_PED
        or mode == Settings.OUTFIT_SPAWN_MODE.CHANGE_PLAYER_MODEL
    local target_ped = player_ped
    local spawned_ped = nil

    if builds_standalone_ped then
        local spawn_error
        spawned_ped, spawn_error = EntityFactory.spawn_ped(outfit.ModelHash, spawn_coords, EntityFactory.player_heading(), 26)
        if not spawned_ped or spawned_ped == 0 then return nil, nil, spawn_error or "spawn_failed" end
        target_ped = spawned_ped
        PedAppearance.apply_default_components(target_ped)
    end

    local ptfx_entities = nil
    local ped_attributes = AttributeMapper.ped_properties(outfit.PedProperties)
    if ped_attributes then
        if ped_attributes.clear_decal_overlays == nil then
            ped_attributes.clear_decal_overlays = true
        end
        local apply_opts = {
            components = settings.apply_components ~= false,
            props = settings.apply_props ~= false,
            decals = settings.apply_decals ~= false,
            damage_packs = settings.apply_damage_packs ~= false,
            head_features = builds_standalone_ped or settings.apply_head_features == true,
        }
        MenyooPedCustomizer.apply_outfit(target_ped, ped_attributes, outfit.ModelHash, apply_opts)
        if builds_standalone_ped then
            MenyooPedCustomizer.apply_runtime_properties(target_ped, ped_attributes, outfit.ModelHash, apply_opts)
        end
        if ped_attributes.particle_attributes then
            Ptfx.start_menyoo_lop(target_ped, ped_attributes.particle_attributes)
            ptfx_entities = { target_ped }
        end
    end
    EntityOptions.apply(target_ped, {
        alpha = outfit.OpacityLevel,
    })

    local attachments, attachment_error = {}, nil
    if settings.apply_attachments ~= false then
        attachments, attachment_error = spawn_attachments(xml, outfit, target_ped, spawn_coords, settings)
    end

    if mode == Settings.OUTFIT_SPAWN_MODE.CHANGE_PLAYER_MODEL then
        EntityFactory.yield(SWAP_SETTLE_MS)
        EntityFactory.swap_player_to_ped(spawned_ped)
        EntityFactory.yield(0)
        local new_player_ped = EntityFactory.player_ped()
        if new_player_ped == spawned_ped and player_ped ~= spawned_ped and EntityFactory.exists(player_ped) then
            EntityFactory.delete(player_ped)
        end
        target_ped = new_player_ped
        spawned_ped = nil
    end

    SpawnRegistry.add(OUTFIT_RECORDS, {
        spawned_ped = spawned_ped,
        attachments = attachments,
        ptfx_entities = ptfx_entities,
        attached_to_player = mode ~= Settings.OUTFIT_SPAWN_MODE.SPAWN_PED,
        file_path = opts.file_path,
    })

    return target_ped, attachments, attachment_error
end

function OutfitSpawner.spawn_file(path, opts)
    local content, read_error = Fs.read_text(path)
    if not content then return nil, nil, read_error end
    opts = opts or {}
    opts.file_path = path
    return OutfitSpawner.spawn_xml(content, opts)
end

function OutfitSpawner.delete(index)
    return SpawnRegistry.delete_outfit_at(OUTFIT_RECORDS, index)
end

function OutfitSpawner.delete_all()
    return SpawnRegistry.delete_outfits(OUTFIT_RECORDS)
end

function OutfitSpawner.get_spawned()
    return SpawnRegistry.list(OUTFIT_RECORDS)
end

return OutfitSpawner
