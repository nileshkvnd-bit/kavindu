local Parser = {}

local VehicleParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.VehicleParser")
local PedParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.PedParser")
local PlacementParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.PlacementParser")
local IplParser = require("ClickUl_Refactor.Features.Spawner.Menyoo.IplParser")

Parser.vehicle_properties = VehicleParser.vehicle_properties
Parser.vehicle = VehicleParser.vehicle
Parser.attachments = PlacementParser.attachments
Parser.map_placements = PlacementParser.map_placements
Parser.map_environment = PlacementParser.map_environment
Parser.map_root_name = PlacementParser.map_root_name
Parser.map_reference_coords = PlacementParser.map_reference_coords
Parser.outfit = PedParser.outfit
Parser.ipls = IplParser.ipls

return Parser
