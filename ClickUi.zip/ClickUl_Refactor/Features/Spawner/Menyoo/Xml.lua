local Xml = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local table_insert = table.insert
local table_concat = table.concat
local type = type
local string_sub = string.sub
local string_find = string.find
local string_char = string.char
local string_byte = string.byte
local trim = Util.trim
local to_number = Util.to_number
local to_boolean = Util.to_boolean
local BYTE_SPACE = 32
local BYTE_TAB = 9
local BYTE_LF = 10
local BYTE_CR = 13
local BYTE_EQUALS = 61
local BYTE_SLASH = 47
local BYTE_GT = 62
local BYTE_QUOTE = 34
local BYTE_APOS = 39
local BYTE_MINUS = 45
local BYTE_EXCLAMATION = 33
local BYTE_QUESTION = 63

local ENTITY_MAP = {
    amp = "&",
    apos = "'",
    gt = ">",
    lt = "<",
    quot = '"',
}

local last_source = nil
local last_document = nil

local function is_node(value)
    return type(value) == "table" and value.__xml_node == true
end

local function is_document(value)
    return type(value) == "table" and value.__xml_document == true
end

local function is_xml_tree(value)
    return type(value) == "table" and (value.__xml_node == true or value.__xml_document == true)
end

local function is_space_byte(value)
    return value == BYTE_SPACE or value == BYTE_LF or value == BYTE_CR or value == BYTE_TAB
end

local function skip_spaces(text, index)
    local length = #text
    while index <= length and is_space_byte(string_byte(text, index)) do
        index = index + 1
    end
    return index
end

local function has_non_space(text, start_index, end_index)
    if start_index > end_index then return false end
    local found = string_find(text, "[^ \t\r\n]", start_index)
    return found ~= nil and found <= end_index
end

local function decode_codepoint(value, base, original)
    local codepoint = tonumber(value, base)
    if not codepoint or codepoint < 0 or codepoint > 0x10FFFF then
        return original
    end
    if codepoint >= 0xD800 and codepoint <= 0xDFFF then
        return original
    end
    if codepoint <= 0x7F then
        return string_char(codepoint)
    end
    if codepoint <= 0x7FF then
        return string_char(
            0xC0 + math.floor(codepoint / 0x40),
            0x80 + (codepoint % 0x40)
        )
    end
    if codepoint <= 0xFFFF then
        return string_char(
            0xE0 + math.floor(codepoint / 0x1000),
            0x80 + (math.floor(codepoint / 0x40) % 0x40),
            0x80 + (codepoint % 0x40)
        )
    end

    return string_char(
        0xF0 + math.floor(codepoint / 0x40000),
        0x80 + (math.floor(codepoint / 0x1000) % 0x40),
        0x80 + (math.floor(codepoint / 0x40) % 0x40),
        0x80 + (codepoint % 0x40)
    )
end

local function decode_entities(text)
    if text == nil or text == "" then
        return text or ""
    end

    text = tostring(text)
    if not string_find(text, "&", 1, true) then
        return text
    end

    text = text:gsub("&#x([%da-fA-F]+);", function(value)
        return decode_codepoint(value, 16, "&#x" .. value .. ";")
    end)
    text = text:gsub("&#(%d+);", function(value)
        return decode_codepoint(value, 10, "&#" .. value .. ";")
    end)
    local decoded = text:gsub("&([%a]+);", function(name)
        return ENTITY_MAP[name] or "&" .. name .. ";"
    end)
    return decoded
end

local function parse_name(text, index)
    index = skip_spaces(text, index)

    local start_index = index
    local length = #text
    while index <= length do
        local value = string_byte(text, index)
        if is_space_byte(value) or value == BYTE_EQUALS or value == BYTE_SLASH or value == BYTE_GT then
            break
        end
        index = index + 1
    end

    if index == start_index then
        return nil, index
    end

    return string_sub(text, start_index, index - 1), index
end

local function parse_attribute_value(text, index)
    index = skip_spaces(text, index)

    local quote = string_byte(text, index)
    if quote == BYTE_QUOTE or quote == BYTE_APOS then
        local end_index = string_find(text, string_char(quote), index + 1, true)
        if not end_index then
            return decode_entities(string_sub(text, index + 1)), #text + 1
        end
        return decode_entities(string_sub(text, index + 1, end_index - 1)), end_index + 1
    end

    local start_index = index
    local length = #text
    while index <= length do
        local value = string_byte(text, index)
        if is_space_byte(value) or value == BYTE_SLASH or value == BYTE_GT then
            break
        end
        index = index + 1
    end

    return decode_entities(string_sub(text, start_index, index - 1)), index
end

local function parse_attributes(text, index)
    local attributes = nil
    local length = #text

    index = index or 1
    while index <= length do
        index = skip_spaces(text, index)

        local current = string_byte(text, index)
        if not current or current == BYTE_SLASH or current == BYTE_GT then
            break
        end

        local name
        name, index = parse_name(text, index)
        if not name then
            index = index + 1
        else
            index = skip_spaces(text, index)
            if string_byte(text, index) == BYTE_EQUALS then
                local value
                value, index = parse_attribute_value(text, index + 1)
                attributes = attributes or {}
                attributes[name] = value
            else
                attributes = attributes or {}
                attributes[name] = ""
            end
        end
    end

    return attributes
end

local function find_tag_end(source, start_index)
    local quote = nil
    local index = start_index + 1
    local length = #source

    while index <= length do
        local value = string_byte(source, index)
        if quote then
            if value == quote then
                quote = nil
            end
        elseif value == BYTE_QUOTE or value == BYTE_APOS then
            quote = value
        elseif value == BYTE_GT then
            return index
        end
        index = index + 1
    end

    return nil
end

local function is_self_closing_tag(source, tag_end)
    local index = tag_end - 1
    while index > 1 and is_space_byte(string_byte(source, index)) do
        index = index - 1
    end
    return string_byte(source, index) == BYTE_SLASH
end

local function parse_close_tag_name(source, start_index, end_index)
    local name_start = skip_spaces(source, start_index + 2)
    local name_end = end_index - 1
    while name_end >= name_start and is_space_byte(string_byte(source, name_end)) do
        name_end = name_end - 1
    end
    if name_end < name_start then
        return nil
    end
    return string_sub(source, name_start, name_end)
end

local function create_document(source)
    return {
        __xml_document = true,
        children = {},
        inner_end = #source,
        inner_start = 1,
        source = source,
    }
end

local function create_node(source, name, attributes, outer_start, open_end, self_closing)
    local inner_start = open_end + 1
    return {
        __xml_node = true,
        attributes = attributes,
        inner_end = self_closing and open_end or nil,
        inner_start = inner_start,
        name = name,
        outer_end = self_closing and open_end or nil,
        outer_start = outer_start,
        self_closing = self_closing == true,
        source = source,
    }
end

local function append_text(node, text, decode)
    if text == nil or text == "" then
        return
    end

    local text_parts = node.text_parts
    if not text_parts then
        text_parts = {}
        node.text_parts = text_parts
    end

    if decode == false then
        table_insert(text_parts, text)
        return
    end

    table_insert(text_parts, decode_entities(text))
end

local function close_node(stack, tag_name, close_start, close_end)
    for index = #stack, 2, -1 do
        local node = stack[index]
        node.inner_end = close_start - 1
        node.outer_end = close_end
        stack[index] = nil

        if node.name == tag_name then
            return
        end
    end
end

local function parse_open_tag(source, start_index, end_index)
    local self_closing = is_self_closing_tag(source, end_index)
    local name, attr_start = parse_name(source, start_index + 1)
    if not name then
        return nil
    end

    return name, parse_attributes(source, attr_start), self_closing
end

local function finalize_document(document)
    local source_length = #document.source
    for index = #document.children, 1, -1 do
        local node = document.children[index]
        if node.inner_end == nil then
            node.inner_end = source_length
            node.outer_end = source_length
        end
    end
end

local function parse_source(source)
    source = tostring(source or "")
    if source == last_source and last_document then
        return last_document
    end

    local document = create_document(source)
    local stack = { document }
    local position = 1
    local length = #source

    while position <= length do
        local tag_start = string_find(source, "<", position, true)
        if not tag_start then
            if has_non_space(source, position, length) then
                append_text(stack[#stack], string_sub(source, position))
            end
            break
        end

        if tag_start > position and has_non_space(source, position, tag_start - 1) then
            append_text(stack[#stack], string_sub(source, position, tag_start - 1))
        end

        local marker = string_byte(source, tag_start + 1)
        if marker == BYTE_EXCLAMATION then
            if string_byte(source, tag_start + 2) == BYTE_MINUS
                and string_byte(source, tag_start + 3) == BYTE_MINUS
            then
                local comment_end = string_find(source, "-->", tag_start + 4, true)
                position = comment_end and comment_end + 3 or length + 1
            elseif string_find(source, "<![CDATA[", tag_start, true) == tag_start then
                local cdata_end = string_find(source, "]]>", tag_start + 9, true)
                if cdata_end then
                    append_text(stack[#stack], string_sub(source, tag_start + 9, cdata_end - 1), false)
                    position = cdata_end + 3
                else
                    append_text(stack[#stack], string_sub(source, tag_start + 9), false)
                    position = length + 1
                end
            else
                local directive_end = find_tag_end(source, tag_start)
                position = directive_end and directive_end + 1 or length + 1
            end
        else
            if marker == BYTE_QUESTION then
                local instruction_end = string_find(source, "?>", tag_start + 2, true)
                position = instruction_end and instruction_end + 2 or length + 1
            elseif marker == BYTE_SLASH then
                local tag_end = find_tag_end(source, tag_start)
                if not tag_end then
                    break
                end

                local name = parse_close_tag_name(source, tag_start, tag_end)
                close_node(stack, name, tag_start, tag_end)
                position = tag_end + 1
            else
                local tag_end = find_tag_end(source, tag_start)
                if not tag_end then
                    append_text(stack[#stack], string_sub(source, tag_start))
                    break
                end

                local name, attributes, self_closing = parse_open_tag(source, tag_start, tag_end)
                if name then
                    local node = create_node(source, name, attributes, tag_start, tag_end, self_closing)
                    local parent = stack[#stack]
                    local children = parent.children
                    if not children then
                        children = {}
                        parent.children = children
                    end
                    table_insert(children, node)

                    if not self_closing then
                        table_insert(stack, node)
                    end
                else
                    append_text(stack[#stack], string_sub(source, tag_start, tag_end))
                end

                position = tag_end + 1
            end
        end
    end

    while #stack > 1 do
        local node = stack[#stack]
        node.inner_end = length
        node.outer_end = length
        stack[#stack] = nil
    end

    finalize_document(document)
    last_source = source
    last_document = document
    return document
end

local function node_text(node)
    if not is_xml_tree(node) then
        return ""
    end

    local cached = node.text_value
    if cached ~= nil then
        return cached
    end

    local parts = node.text_parts
    local value = ""
    if parts then
        value = #parts == 1 and parts[1] or table_concat(parts)
    end

    value = trim(value) or ""
    node.text_value = value
    return value
end

local function visit_nodes(node, tag, out)
    for _, child in ipairs(node.children or {}) do
        if child.name == tag then
            table_insert(out, child)
        end
        visit_nodes(child, tag, out)
    end
end

local function tree_for(value)
    if is_xml_tree(value) then
        return value
    end

    return parse_source(value)
end

local function indexed_children(root, tag)
    if not tag then return root.children or {} end

    local index = root.child_index
    if not index then
        index = {}
        for _, child in ipairs(root.children or {}) do
            local named = index[child.name]
            if not named then
                named = {}
                index[child.name] = named
            end
            named[#named + 1] = child
        end
        root.child_index = index
    end
    return index[tag] or {}
end

local function child_nodes(value, tag)
    local root = tree_for(value)
    return indexed_children(root, tag)
end

local function nodes_for(value, tag)
    if not tag then
        return {}
    end

    local nodes = {}
    visit_nodes(tree_for(value), tag, nodes)
    return nodes
end

function Xml.parse(xml)
    return parse_source(xml)
end

function Xml.node(xml, tag)
    if not tag then
        return nil
    end

    return indexed_children(tree_for(xml), tag)[1]
end

function Xml.children(xml, tag)
    return child_nodes(xml, tag)
end

function Xml.find(xml, tag)
    return nodes_for(xml, tag)[1]
end

function Xml.descendants(xml, tag)
    return nodes_for(xml, tag)
end

function Xml.root(xml)
    local root = tree_for(xml)
    if is_document(root) then
        return (root.children or {})[1]
    end

    return root
end

function Xml.text(xml)
    if not is_xml_tree(xml) then
        return ""
    end

    return node_text(xml)
end







function Xml.attr(node, attr)
    if not is_node(node) or not attr then return nil end
    local attributes = node.attributes
    return attributes and attributes[attr] or nil
end



function Xml.vector(xml, tag)
    local block = xml
    if tag then
        block = Xml.node(xml, tag)
    end
    if not block then return nil end

    return {
        x = Xml.number(block, "X", 0.0),
        y = Xml.number(block, "Y", 0.0),
        z = Xml.number(block, "Z", 0.0),
    }
end

function Xml.rotation(xml, tag)
    local block = xml
    if tag then
        block = Xml.node(xml, tag)
    end
    if not block then return nil end

    return {
        x = Xml.number(block, "Pitch", Xml.number(block, "X", 0.0)),
        y = Xml.number(block, "Roll", Xml.number(block, "Y", 0.0)),
        z = Xml.number(block, "Yaw", Xml.number(block, "Z", 0.0)),
    }
end

local function tagged_value(xml, tag)
    local root = tree_for(xml)
    local node = indexed_children(root, tag)[1]
    if node then
        return node_text(node)
    end

    local attributes = root.attributes
    return attributes and attributes[tag] or nil
end

function Xml.bool(xml, tag)
    local value = nil
    if tag then
        value = tagged_value(xml, tag)
    elseif is_xml_tree(xml) then
        value = node_text(xml)
    end

    if value == nil or value == "" then
        return nil
    end

    return to_boolean(value)
end

function Xml.number(xml, tag, default)
    local value = nil
    if tag then
        value = tagged_value(xml, tag)
    elseif is_xml_tree(xml) then
        value = node_text(xml)
    end

    return to_number(value, default)
end

return Xml
