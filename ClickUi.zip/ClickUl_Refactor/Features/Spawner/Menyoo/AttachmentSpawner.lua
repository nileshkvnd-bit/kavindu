local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local Attachment = require("ClickUl_Refactor.Features.Spawner.Core.Attachment")
local MenyooVehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooVehicleCustomizer")
local MenyooPedCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooPedCustomizer")
local ObjectCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.ObjectCustomizer")
local Ptfx = require("ClickUl_Refactor.Features.Spawner.Core.Ptfx")
local TaskSequence = require("ClickUl_Refactor.Features.Spawner.Core.TaskSequenceRuntime.Runner")
local AttributeMapper = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttributeMapper")

local AttachmentSpawner = {}

local function register_parent(parent_map, initial_handle, handle)
    if not initial_handle then return end
    parent_map[initial_handle] = handle
    parent_map[tostring(initial_handle)] = handle
end

local function is_attached(att)
    return att.Attachment and att.Attachment.isAttached == true
end

local function spawn_coords(att, fallback_coords, use_position_rotation)
    local coords = fallback_coords or EntityFactory.player_coords()
    if is_attached(att) then return coords end
    local position = att.PositionRotation
    if use_position_rotation == false or not position then return coords end
    if not coords and (position.X == nil or position.Y == nil or position.Z == nil) then return nil end
    return {
        x = position.X or coords.x,
        y = position.Y or coords.y,
        z = position.Z or coords.z,
    }
end

local function spawn_heading(att, use_position_rotation)
    if is_attached(att) then return 0.0 end
    if use_position_rotation == false or not att.PositionRotation then return 0.0 end
    return att.PositionRotation.Yaw or 0.0
end

local function apply_entity_options(handle, att, options)
    EntityOptions.apply(handle, {
        is_visible = att.IsVisible,
        is_invincible = att.IsInvincible,
        alpha = att.OpacityLevel,
        is_on_fire = att.IsOnFire,
        lod_dist = att.LodDistance,
        health = att.Health,
        max_health = att.MaxHealth,
        is_bullet_proof = att.IsBulletProof,
        is_fire_proof = att.IsFireProof,
        is_explosion_proof = att.IsExplosionProof,
        is_melee_proof = att.IsMeleeProof,
        is_drown_proof = att.IsDrownProof,
        is_steam_proof = att.IsSteamProof,
        is_only_damaged_by_player = att.IsOnlyDamagedByPlayer,
    })
end

local function apply_type_properties(handle, att)
    if tostring(att.Type) == "2" and att.VehicleProperties then
        MenyooVehicleCustomizer.apply(handle, AttributeMapper.vehicle_properties(att.VehicleProperties))
    elseif tostring(att.Type) == "1" then
        MenyooPedCustomizer.apply_runtime_properties(handle, AttributeMapper.ped_properties(att.PedProperties), att.ModelHash)
    elseif tostring(att.Type) == "3" and att.ObjectProperties then
        ObjectCustomizer.apply(handle, AttributeMapper.object_properties(att.ObjectProperties))
    end
end

local function apply_menyoo_collision(handle, att, options)
    local has_collision = true
    if options and options.active_collision == false then has_collision = false end
    if att.IsCollisionProof == true then has_collision = false end
    EntityOptions.set_collision(handle, has_collision, false)
end

local function parent_for(att, parent_map, default_parent)
    if not att.Attachment then return nil end

    local attached_to = att.Attachment.AttachedTo
    if attached_to == "PLAYER" then return EntityFactory.player_ped() end
    if attached_to == "VEHICLE" then return default_parent end
    return parent_map[attached_to] or parent_map[tostring(attached_to)] or default_parent
end

local function seat_ped_in_parent_vehicle(handle, att, parent)
    if tostring(att.Type) ~= "1" or type(att.PedProperties) ~= "table" then return false end
    local ped_attributes = AttributeMapper.ped_properties(att.PedProperties)
    local seat = tonumber(ped_attributes and ped_attributes.seat)
    if seat == nil or seat == -2 then return false end

    return Attachment.seat_ped_in_vehicle(handle, parent, seat)
end

local function attach_to_parent(handle, att, parent_map, default_parent, active_collision)
    local parent = parent_for(att, parent_map, default_parent)
    if seat_ped_in_parent_vehicle(handle, att, parent) then return end
    if not att.Attachment or att.Attachment.isAttached ~= true then return end
    if not parent then return end
    if att.IsCollisionProof ~= nil then active_collision = active_collision and not att.IsCollisionProof end
    Attachment.attach(handle, parent, att.Attachment.BoneIndex or -1, {
        x = att.Attachment.X,
        y = att.Attachment.Y,
        z = att.Attachment.Z,
    }, {
        x = att.Attachment.Pitch,
        y = att.Attachment.Roll,
        z = att.Attachment.Yaw,
    }, { active_collision = active_collision, bone_is_index = true })
end

function AttachmentSpawner.create_parent_map(initial_handle, root)
    local parent_map = {}
    register_parent(parent_map, initial_handle, root)
    return parent_map
end

function AttachmentSpawner.spawn(att, parent_map, fallback_coords, created, options, task_records)
    if type(att) ~= "table" then return nil, "invalid_attachment" end
    options = options or {}

    local model = att.ModelHash
    if not model then return nil, "missing_model" end

    local coords = spawn_coords(att, fallback_coords, options.use_position_rotation)
    if not coords then return nil, "missing_coords" end

    local handle, spawn_error = EntityFactory.spawn_by_type(
        att.Type or "3",
        model,
        coords,
        spawn_heading(att, options.use_position_rotation),
        att.Dynamic,
        true
    )
    if not handle or handle == 0 then return nil, spawn_error or "spawn_failed" end

    created[#created + 1] = handle
    register_parent(parent_map, att.InitialHandle, handle)

    EntityOptions.enter_load_state(handle)

    if tostring(att.Type) == "2" then
        if options.apply_type_properties then apply_type_properties(handle, att) end
        if options.apply_entity_options then apply_entity_options(handle, att, options) end
    else
        if options.apply_entity_options then apply_entity_options(handle, att, options) end
        if options.apply_type_properties then apply_type_properties(handle, att) end
    end

    EntityOptions.restore_load_state(handle, AttributeMapper.entity_load_state(att))
    apply_menyoo_collision(handle, att, options)

    if options.enable_ptfx ~= false then Ptfx.start_menyoo_lop(handle, att.ParticleAttributes) end
    if task_records and att.TaskSequence then
        task_records[#task_records + 1] = { handle = handle, sequence = att.TaskSequence }
    end
    return handle
end

function AttachmentSpawner.spawn_many(attachments, parent_map, fallback_coords, options)
    local created = {}
    local spawned = {}
    local task_records = {}
    local models_used = {}
    local first_error = nil
    for _, att in ipairs(attachments or {}) do
        local handle, err = AttachmentSpawner.spawn(att, parent_map, fallback_coords, created, options, task_records)
        if handle then
            spawned[#spawned + 1] = { handle = handle, attachment = att }
            if att.ModelHash ~= nil then models_used[att.ModelHash] = true end
        end
        first_error = first_error or err
    end
    options = options or {}
    for _, record in ipairs(spawned) do
        attach_to_parent(record.handle, record.attachment, parent_map, options.default_parent, options.active_collision)
    end
    for model in pairs(models_used) do
        EntityFactory.release_model(model)
    end
    if options.start_task_sequences == true then
        first_error = first_error or TaskSequence.start_many(task_records, parent_map)
    end
    return created, first_error
end

return AttachmentSpawner
