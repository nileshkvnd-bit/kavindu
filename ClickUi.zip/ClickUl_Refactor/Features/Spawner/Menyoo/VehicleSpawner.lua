local VehicleSpawner = {}

local Fs = require("ClickUl_Refactor.Adapters.Fs")
local Parser = require("ClickUl_Refactor.Features.Spawner.Menyoo.Parser")
local Settings = require("ClickUl_Refactor.Features.Spawner.Core.Settings")
local EntityFactory = require("ClickUl_Refactor.Features.Spawner.Core.EntityFactory")
local EntityOptions = require("ClickUl_Refactor.Features.Spawner.Core.EntityOptions")
local VehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.VehicleCustomizer")
local VehiclePreset = require("ClickUl_Refactor.Features.Spawner.Core.VehiclePreset")
local VehicleSpawnSettings = require("ClickUl_Refactor.Features.Spawner.Core.VehicleSpawnSettings")
local MenyooVehicleCustomizer = require("ClickUl_Refactor.Features.Spawner.Core.MenyooVehicleCustomizer")
local AttachmentSpawner = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttachmentSpawner")
local AttributeMapper = require("ClickUl_Refactor.Features.Spawner.Menyoo.AttributeMapper")
local SpawnRegistry = require("ClickUl_Refactor.Features.Spawner.Core.SpawnRegistry")

local ENTITY_RECORDS <const> = "menyoo_spawned_entities"

local apply_pre_xml_settings <const> = function(vehicle, settings)
    if settings.max_performance then VehicleCustomizer.apply_max_performance(vehicle) end
    if settings.upgraded_vehicle then VehicleCustomizer.apply_max_visual_upgrades(vehicle) end
end

local apply_saved_properties <const> = function(vehicle, vehicle_props, settings)
    if settings.random_color then
        vehicle_props.Colours = vehicle_props.Colours or {}
        vehicle_props.Colours.IsPrimaryColourCustom = false
        vehicle_props.Colours.Primary = math.random(0, 159)
        vehicle_props.Colours.IsSecondaryColourCustom = false
        vehicle_props.Colours.Secondary = math.random(0, 159)
    end
    if settings.random_livery then
        local count = VehicleCustomizer.get_livery_count(vehicle)
        if count > 0 then vehicle_props.Livery = math.random(0, count - 1) end
    end
    if settings.vehicle_engine_on and vehicle_props.EngineOn == nil then vehicle_props.EngineOn = true end
    MenyooVehicleCustomizer.apply(vehicle, AttributeMapper.vehicle_properties(vehicle_props))
end

local apply_post_xml_settings <const> = function(vehicle, settings, vehicle_props)
    if settings.vehicle_god_mode then VehicleCustomizer.set_invincible(vehicle, true) end
    if settings.clean_vehicle and vehicle_props.DirtLevel == nil then VehicleCustomizer.clean_vehicle(vehicle) end
    if settings.bulletproof_tires then VehicleCustomizer.set_bulletproof_tires(vehicle, true) end
    if settings.radio_off then VehicleCustomizer.set_radio_enabled(vehicle, false) end
end

local apply_driver_visibility <const> = function(vehicle, visible)
    if visible == nil then return false end
    return VehicleCustomizer.set_driver_visible(vehicle, visible)
end

local entity_record <const> = function(vehicle, attachments)
    local entities = { vehicle }
    for _, attachment in ipairs(attachments or {}) do
        entities[#entities + 1] = attachment
    end
    return { entities = entities }
end

function VehicleSpawner.spawn_xml(xml, spawn_coords)
    if not xml or xml == "" then return 0, {}, "empty_content" end

    local data = Parser.vehicle(xml)
    if not data then return 0, {}, "missing_root" end

    local model = data.ModelHash
    if not model then return 0, {}, "missing_model" end

    local settings = Settings.get("menyoo")
    local saved_speed = VehicleSpawnSettings.captured_speed(settings)
    if settings.delete_old_vehicle then VehicleSpawner.delete_all() end

    spawn_coords = spawn_coords or EntityFactory.forward_spawn_coords(5.0)
    local vehicle, err = EntityFactory.spawn_vehicle(model, spawn_coords, 0.0)
    if not vehicle or vehicle == 0 then return 0, {}, err end
    EntityFactory.set_heading_to_player(vehicle)
    if settings.spawn_plane_in_air then EntityFactory.raise_aircraft_if_needed(vehicle, 30.0) end

    EntityOptions.enter_load_state(vehicle)

    local props = data.VehicleProperties
    apply_pre_xml_settings(vehicle, settings)
    apply_saved_properties(vehicle, props, settings)
    VehiclePreset.apply(vehicle, settings, false)
    apply_post_xml_settings(vehicle, settings, props)
    EntityOptions.apply(vehicle, {
        alpha = data.OpacityLevel,
        is_visible = data.IsVisible,
        is_invincible = data.IsInvincible,
        has_collision = true,
        is_on_fire = data.IsOnFire,
        lod_dist = data.LodDistance,
        health = data.Health,
        max_health = data.MaxHealth,
        is_bullet_proof = data.IsBulletProof,
        is_fire_proof = data.IsFireProof,
        is_explosion_proof = data.IsExplosionProof,
        is_melee_proof = data.IsMeleeProof,
        is_drown_proof = data.IsDrownProof,
        is_steam_proof = data.IsSteamProof,
        is_only_damaged_by_player = data.IsOnlyDamagedByPlayer,
    })
    local parent_map = AttachmentSpawner.create_parent_map(data.InitialHandle, vehicle)
    local attachment_defs = Parser.attachments(xml)
    local attachments_persistent = attachment_defs.SetAttachmentsPersistentAndAddToSpoonerDatabase == true
    local attachments, attachment_error = AttachmentSpawner.spawn_many(attachment_defs, parent_map, spawn_coords, {
        active_collision = not settings.disable_collision,
        default_parent = vehicle,
        apply_entity_options = true,
        apply_type_properties = true,
        enable_ptfx = settings.enable_ptfx,
        start_task_sequences = attachments_persistent,
    })

    EntityOptions.restore_load_state(vehicle, {
        has_gravity = data.HasGravity,
        is_dynamic = true,
        is_frozen = data.FrozenPos == true,
    })
    apply_driver_visibility(vehicle, data.IsDriverVisible)

    local record = entity_record(vehicle, attachments)
    EntityFactory.clear_internal_collisions(record.entities)
    SpawnRegistry.add(ENTITY_RECORDS, record)

    if settings.in_vehicle then
        EntityFactory.yield(200)
        EntityFactory.put_player_in_vehicle(vehicle)
        if saved_speed > 0 then VehicleCustomizer.set_forward_speed(vehicle, saved_speed) end
    end

    return vehicle, attachments, attachment_error
end

function VehicleSpawner.spawn_file(path, spawn_coords)
    local content, read_error = Fs.read_text(path)
    if not content then return 0, {}, read_error end
    local vehicle, attachments, err = VehicleSpawner.spawn_xml(content, spawn_coords)
    if vehicle and vehicle ~= 0 then
        SpawnRegistry.update_last(ENTITY_RECORDS, function(record)
            record.file_path = path
        end)
    end
    return vehicle, attachments, err
end

function VehicleSpawner.delete(index)
    return SpawnRegistry.delete_entity_record_at(ENTITY_RECORDS, index)
end

function VehicleSpawner.delete_all()
    return SpawnRegistry.delete_entity_records(ENTITY_RECORDS)
end

function VehicleSpawner.get_spawned()
    return SpawnRegistry.list(ENTITY_RECORDS)
end

return VehicleSpawner
