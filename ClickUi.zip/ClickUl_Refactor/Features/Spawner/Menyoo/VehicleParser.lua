local VehicleParser = {}

local Xml = require("ClickUl_Refactor.Features.Spawner.Menyoo.Xml")
local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local function child_text(block, tag)
    local node = Xml.node(block, tag)
    if not node then
        return nil
    end

    return Xml.text(node)
end

local function root_child(xml, tag)
    local root = Xml.root(xml)
    if not root then
        return nil
    end
    if root.name == tag then
        return root
    end

    return Xml.node(root, tag)
end

local function bool_or(block, tag, default)
    local value = Xml.bool(block, tag)
    if value == nil then return default end
    return value
end

local function split_csv_numbers(value)
    local result = {}
    for part in tostring(value or ""):gmatch("([^,]+)") do
        result[#result + 1] = Util.to_number(part, 0)
    end
    return result
end

local function parse_mod_value(value)
    local text = Util.trim(value)
    if text == "" then
        return { mod = -1, variation = 0 }
    end

    if not text:find(",", 1, true) then
        return Util.to_boolean(text)
    end

    local values = split_csv_numbers(text)
    return {
        mod = values[1] or -1,
        variation = values[2] or 0,
    }
end

local function parse_indexed_bool_block(xml, tag)
    local block = Xml.node(xml, tag)
    if not block then return nil end

    local result = {}
    for _, child in ipairs(Xml.children(block)) do
        local id = child.name:match("^_(%d+)$")
        result[id and tonumber(id) or child.name] = Util.to_boolean(Xml.text(child))
    end
    return result
end

local function parse_flat_indexed_numbers(xml, prefix, max_index)
    local result = {}
    for index = 0, max_index do
        local value = Xml.number(xml, prefix .. tostring(index), nil)
        if value ~= nil then result[index] = value end
    end
    if next(result) == nil then return nil end
    return result
end

local function parse_colours(xml)
    local colours = Xml.node(xml, "Colours")
    if not colours then return nil end
    return {
        Primary = Xml.number(colours, "Primary", nil),
        Secondary = Xml.number(colours, "Secondary", nil),
        Pearl = Xml.number(colours, "Pearl", nil),
        Rim = Xml.number(colours, "Rim", nil),
        Mod1_a = Xml.number(colours, "Mod1_a", nil),
        Mod1_b = Xml.number(colours, "Mod1_b", nil),
        Mod1_c = Xml.number(colours, "Mod1_c", nil),
        Mod2_a = Xml.number(colours, "Mod2_a", nil),
        Mod2_b = Xml.number(colours, "Mod2_b", nil),
        LrXenonHeadlights = Xml.number(colours, "LrXenonHeadlights", nil),
        LrInterior = Xml.number(colours, "LrInterior", nil),
        LrDashboard = Xml.number(colours, "LrDashboard", nil),
        IsPrimaryColourCustom = Xml.bool(colours, "IsPrimaryColourCustom"),
        IsSecondaryColourCustom = Xml.bool(colours, "IsSecondaryColourCustom"),
        Cust1_R = Xml.number(colours, "Cust1_R", 0),
        Cust1_G = Xml.number(colours, "Cust1_G", 0),
        Cust1_B = Xml.number(colours, "Cust1_B", 0),
        Cust2_R = Xml.number(colours, "Cust2_R", 0),
        Cust2_G = Xml.number(colours, "Cust2_G", 0),
        Cust2_B = Xml.number(colours, "Cust2_B", 0),
        tyreSmoke_R = Xml.number(colours, "tyreSmoke_R", nil),
        tyreSmoke_G = Xml.number(colours, "tyreSmoke_G", nil),
        tyreSmoke_B = Xml.number(colours, "tyreSmoke_B", nil),
    }
end

local function parse_mods(xml)
    local mods = Xml.node(xml, "Mods")
    if not mods then return nil end
    local result = {}
    for _, child in ipairs(Xml.children(mods)) do
        local id = child.name:match("^_(%d+)$")
        if id then
            result[tonumber(id)] = parse_mod_value(Xml.text(child))
        end
    end
    return result
end

local function parse_neons(xml)
    local neons = Xml.node(xml, "Neons")
    if not neons then return nil end
    return {
        Left = Xml.bool(neons, "Left"),
        Right = Xml.bool(neons, "Right"),
        Front = Xml.bool(neons, "Front"),
        Back = Xml.bool(neons, "Back"),
        R = Xml.number(neons, "R", nil),
        G = Xml.number(neons, "G", nil),
        B = Xml.number(neons, "B", nil),
    }
end

local function legacy_vehicle_properties(xml)
    local primary = Xml.number(xml, "PrimaryColor", nil)
    local secondary = Xml.number(xml, "SecondaryColor", nil)
    local siren = Xml.bool(xml, "SirensActive")
    if primary == nil and secondary == nil and siren == nil then return {} end

    return {
        Colours = (primary ~= nil or secondary ~= nil) and {
            Primary = primary,
            Secondary = secondary,
        } or nil,
        SirenActive = siren,
    }
end

function VehicleParser.vehicle_properties(xml)
    local props = root_child(xml, "VehicleProperties")
    if not props then return legacy_vehicle_properties(xml) end
    return {
        Colours = parse_colours(props),
        Mods = parse_mods(props),
        ModExtras = parse_indexed_bool_block(props, "ModExtras"),
        Neons = parse_neons(props),
        Livery = Xml.number(props, "Livery", nil),
        NumberPlateText = child_text(props, "NumberPlateText"),
        NumberPlateIndex = Xml.number(props, "NumberPlateIndex", nil),
        WheelType = Xml.number(props, "WheelType", nil),
        WheelsInvisible = Xml.bool(props, "WheelsInvisible"),
        WindowTint = Xml.number(props, "WindowTint", nil),
        DirtLevel = Xml.number(props, "DirtLevel", nil),
        EngineOn = Xml.bool(props, "EngineOn"),
        LightsOn = Xml.bool(props, "LightsOn"),
        SirenActive = Xml.bool(props, "SirenActive"),
        RoofState = Xml.number(props, "RoofState", nil),
        PaintFade = Xml.number(props, "PaintFade", nil),
        ReducedGrip = Xml.bool(props, "ReducedGrip"),
        HeadlightIntensity = Xml.number(props, "HeadlightIntensity", nil),
        HeadlightMultiplier = Xml.number(props, "HeadlightMultiplier", nil),
        BulletProofTyres = Xml.bool(props, "BulletProofTyres"),
        Tyres = parse_flat_indexed_numbers(props, "Tyres_", 7),
        TyresBursted = parse_indexed_bool_block(props, "TyresBursted"),
        Doors = parse_flat_indexed_numbers(props, "Doors_", 7),
        DoorsOpen = parse_indexed_bool_block(props, "DoorsOpen"),
        DoorsBroken = parse_indexed_bool_block(props, "DoorsBroken"),
        IsRadioLoud = Xml.bool(props, "IsRadioLoud"),
        EngineSoundName = child_text(props, "EngineSoundName"),
        LockStatus = Xml.number(props, "LockStatus", nil),
        RpmMultiplier = Xml.number(props, "RpmMultiplier", nil),
        TorqueMultiplier = Xml.number(props, "TorqueMultiplier", nil),
        MaxSpeed = Xml.number(props, "MaxSpeed", nil),
        EngineHealth = Xml.number(props, "EngineHealth", nil),
    }
end

function VehicleParser.vehicle(xml)
    local root = Xml.root(xml)
    if not root then return nil end

    return {
        ModelHash = child_text(root, "ModelHash"),
        InitialHandle = Xml.number(root, "InitialHandle", nil),
        IsDriverVisible = Xml.bool(root, "IsDriverVisible"),
        OpacityLevel = Xml.number(root, "OpacityLevel", nil),
        IsVisible = Xml.bool(root, "IsVisible"),
        IsInvincible = Xml.bool(root, "IsInvincible"),
        FrozenPos = Xml.bool(root, "FrozenPos"),
        HasGravity = bool_or(root, "HasGravity", true),
        IsOnFire = Xml.bool(root, "IsOnFire"),
        LodDistance = Xml.number(root, "LodDistance", nil),
        Health = Xml.number(root, "Health", nil),
        MaxHealth = Xml.number(root, "MaxHealth", nil),
        IsCollisionProof = Xml.bool(root, "IsCollisionProof"),
        IsBulletProof = Xml.bool(root, "IsBulletProof"),
        IsFireProof = Xml.bool(root, "IsFireProof"),
        IsExplosionProof = Xml.bool(root, "IsExplosionProof"),
        IsMeleeProof = Xml.bool(root, "IsMeleeProof"),
        IsDrownProof = Xml.bool(root, "IsDrownProof"),
        IsSteamProof = Xml.bool(root, "IsSteamProof"),
        IsOnlyDamagedByPlayer = Xml.bool(root, "IsOnlyDamagedByPlayer"),
        VehicleProperties = VehicleParser.vehicle_properties(root),
    }
end

return VehicleParser
