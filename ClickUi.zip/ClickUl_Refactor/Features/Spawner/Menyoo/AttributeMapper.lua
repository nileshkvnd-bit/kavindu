local AttributeMapper = {}

local Util = require("ClickUl_Refactor.Features.Spawner.Core.Util")

local MENYOO_MOVEMENT_CLIPSET_TRANSITION <const> = 0.25

local function set_from(target, key, source, ...)
    if target[key] ~= nil then return end
    target[key] = Util.first_present(source, ...)
end

function AttributeMapper.ped_properties(props)
    if type(props) ~= "table" then return nil end

    local attrs = Util.copy_table(props)
    set_from(attrs, "components", props, "components", "PedComps")
    set_from(attrs, "props", props, "props", "PedProps")
    set_from(attrs, "blend_data", props, "blend_data", "HeadBlend", "BlendData")
    set_from(attrs, "head_features_was_in_array", props, "head_features_was_in_array", "HeadFeaturesWasInArray", "WasInArray")
    set_from(attrs, "hair_color", props, "hair_color", "HairColor")
    set_from(attrs, "hair_highlight_color", props, "hair_highlight_color", "HairHighlightColor")
    set_from(attrs, "eye_color", props, "eye_color", "EyeColor")
    set_from(attrs, "head_overlays", props, "head_overlays", "HeadOverlays")
    set_from(attrs, "facial_features", props, "facial_features", "FacialFeatures")
    set_from(attrs, "decorations", props, "decorations", "Decorations", "TattooLogoDecals")
    set_from(attrs, "damage_packs", props, "damage_packs", "DamagePacks")
    set_from(attrs, "ped_config_flags", props, "ped_config_flags", "PedConfigFlags")
    set_from(attrs, "clear_decal_overlays", props, "clear_decal_overlays", "ClearDecalOverlays")
    if attrs.has_short_height == nil and Util.to_boolean(props.HasShortHeight) then attrs.has_short_height = true end
    set_from(attrs, "can_ragdoll", props, "can_ragdoll", "CanRagdoll")
    if attrs.can_ragdoll == nil then attrs.can_ragdoll = true end
    if attrs.ragdoll_on_collision == nil then
        if props.CanRagdoll ~= nil then
            attrs.ragdoll_on_collision = Util.to_boolean(props.CanRagdoll)
        else
            attrs.ragdoll_on_collision = false
        end
    end
    set_from(attrs, "is_still", props, "is_still", "IsStill")
    set_from(attrs, "ignore_events", props, "ignore_events", "IgnoreEvents")
    set_from(attrs, "combat_ability", props, "combat_ability", "CombatAbility")
    set_from(attrs, "combat_range", props, "combat_range", "CombatRange")
    set_from(attrs, "combat_movement", props, "combat_movement", "CombatMovement")
    set_from(attrs, "health", props, "health", "Health")
    set_from(attrs, "max_health", props, "max_health", "MaxHealth")
    set_from(attrs, "armor", props, "armor", "Armor", "Armour")
    set_from(attrs, "current_weapon", props, "current_weapon", "CurrentWeapon")
    set_from(attrs, "relationship_group", props, "relationship_group", "RelationshipGroup")
    set_from(attrs, "scenario_active", props, "scenario_active", "ScenarioActive")
    set_from(attrs, "scenario", props, "scenario", "ScenarioName")
    set_from(attrs, "animation_active", props, "animation_active", "AnimActive")
    set_from(attrs, "movement_clipset", props, "movement_clipset", "MovementClipset", "MovementGroupName")
    set_from(attrs, "weapon_movement_clipset", props, "weapon_movement_clipset", "WeaponMovementClipset", "WeaponMovementGroupName")
    set_from(attrs, "facial_mood", props, "facial_mood", "FacialMood")
    set_from(attrs, "seat", props, "seat", "PedVehicleSeat")
    set_from(attrs, "particle_attributes", props, "particle_attributes", "ParticleAttributes")

    if attrs.movement_clipset_transition == nil and props.MovementGroupName ~= nil then
        attrs.movement_clipset_transition = MENYOO_MOVEMENT_CLIPSET_TRANSITION
    end
    if type(attrs.animation) ~= "table" and (props.AnimDict or props.AnimName) then
        attrs.animation = {
            dict = props.AnimDict,
            name = props.AnimName,
            blend_in = 8.0,
            blend_out = 1.0,
            duration = -1,
            flags = 1,
            playback_rate = 1.0,
        }
    end

    attrs.PedComps = nil
    attrs.PedProps = nil
    attrs.HeadBlend = nil
    attrs.BlendData = nil
    attrs.HeadFeaturesWasInArray = nil
    attrs.WasInArray = nil
    attrs.HairColour = nil
    attrs.HairColourStreaks = nil
    attrs.HairColor = nil
    attrs.HairHighlightColor = nil
    attrs.EyeColor = nil
    attrs.HeadOverlays = nil
    attrs.FacialFeatures = nil
    attrs.Decorations = nil
    attrs.TattooLogoDecals = nil
    attrs.DamagePacks = nil
    attrs.PedConfigFlags = nil
    attrs.MovementGroupName = nil
    attrs.MovementClipset = nil
    attrs.WeaponMovementGroupName = nil
    attrs.WeaponMovementClipset = nil
    attrs.ScenarioName = nil
    attrs.AnimDict = nil
    attrs.AnimName = nil
    attrs.ClearDecalOverlays = nil
    attrs.HasShortHeight = nil
    attrs.CanRagdoll = nil
    attrs.IsStill = nil
    attrs.IgnoreEvents = nil
    attrs.CombatAbility = nil
    attrs.CombatRange = nil
    attrs.CombatMovement = nil
    attrs.Health = nil
    attrs.MaxHealth = nil
    attrs.Armor = nil
    attrs.Armour = nil
    attrs.CurrentWeapon = nil
    attrs.RelationshipGroup = nil
    attrs.ScenarioActive = nil
    attrs.AnimActive = nil
    attrs.FacialMood = nil
    attrs.PedVehicleSeat = nil
    attrs.ParticleAttributes = nil
    return attrs
end

function AttributeMapper.object_properties(props)
    if type(props) ~= "table" then return nil end

    local attrs = Util.copy_table(props)
    attrs.object_tint = Util.first_present(attrs, "object_tint", "texture_variation", "tint_index", "TextureVariation")
    attrs.TextureVariation = nil
    attrs.texture_variation = nil
    attrs.tint_index = nil
    return attrs
end

function AttributeMapper.entity_load_state(data)
    if type(data) ~= "table" then return {} end
    return {
        has_gravity = data.HasGravity,
        is_dynamic = data.Dynamic,
        is_frozen = data.FrozenPos,
    }
end

function AttributeMapper.vehicle_properties(vp)
    if type(vp) ~= "table" then return nil end

    local attrs = {
        vehicle_attributes = {
            extras = vp.ModExtras,
            mods = vp.Mods,
            livery = vp.Livery,
            dirt_level = vp.DirtLevel,
            paint = {
                fade = vp.PaintFade,
            },
            options = {
                license_plate_text = vp.NumberPlateText,
                license_plate_type = vp.NumberPlateIndex,
                window_tint = vp.WindowTint,
                bulletproof_tires = vp.BulletProofTyres,
                engine_on = vp.EngineOn,
                engine_health = vp.EngineHealth,
                lights_on = vp.LightsOn,
                siren = vp.SirenActive,
                radio_loud = vp.IsRadioLoud,
                lock_status = vp.LockStatus,
                roof_state = vp.RoofState,
                headlight_multiplier = vp.HeadlightMultiplier,
            },
            wheels = {
                wheel_type = vp.WheelType,
            },
            neon = {},
        },
        tyre_states = vp.Tyres,
        burst_tyres = vp.TyresBursted,
        reduced_grip = vp.ReducedGrip,
        engine_sound_name = vp.EngineSoundName,
        wheels_invisible = vp.WheelsInvisible,
        runtime_modifiers = {
            top_speed_multiplier = vp.RpmMultiplier,
            torque_multiplier = vp.TorqueMultiplier,
            max_speed = vp.MaxSpeed,
            headlight_multiplier = vp.HeadlightIntensity,
        },
        doors = vp.Doors,
        doors_open = vp.DoorsOpen,
        doors_broken = vp.DoorsBroken,
    }

    local colors = vp.Colours
    local vehicle_attributes = attrs.vehicle_attributes
    if type(colors) == "table" then
        if colors.Primary ~= nil or colors.IsPrimaryColourCustom ~= nil then
            vehicle_attributes.paint.primary = {
                vehicle_standard_color = colors.Primary,
                is_custom = colors.IsPrimaryColourCustom,
                custom_color = {
                    r = colors.Cust1_R,
                    g = colors.Cust1_G,
                    b = colors.Cust1_B,
                },
            }
        end
        if colors.Secondary ~= nil or colors.IsSecondaryColourCustom ~= nil then
            vehicle_attributes.paint.secondary = {
                vehicle_standard_color = colors.Secondary,
                is_custom = colors.IsSecondaryColourCustom,
                custom_color = {
                    r = colors.Cust2_R,
                    g = colors.Cust2_G,
                    b = colors.Cust2_B,
                },
            }
        end
        if colors.Mod1_a ~= nil then
            vehicle_attributes.paint.mod_1 = {
                color_type = colors.Mod1_a,
                color = colors.Mod1_b,
                pearlescent = colors.Mod1_c,
            }
        end
        if colors.Mod2_a ~= nil then
            vehicle_attributes.paint.mod_2 = {
                color_type = colors.Mod2_a,
                color = colors.Mod2_b,
            }
        end
        if colors.Pearl ~= nil or colors.Rim ~= nil then
            vehicle_attributes.paint.extra_colors = {
                pearlescent = colors.Pearl,
                wheel = colors.Rim,
            }
        end
        vehicle_attributes.paint.interior = colors.LrInterior
        vehicle_attributes.paint.dashboard = colors.LrDashboard
        vehicle_attributes.options.headlight_color = colors.LrXenonHeadlights
        if colors.tyreSmoke_R ~= nil then
            vehicle_attributes.wheels.tire_smoke_color = {
                r = colors.tyreSmoke_R,
                g = colors.tyreSmoke_G,
                b = colors.tyreSmoke_B,
            }
        end
    end

    if type(vp.Neons) == "table" then
        vehicle_attributes.neon.lights = {
            left = vp.Neons.Left,
            right = vp.Neons.Right,
            front = vp.Neons.Front,
            back = vp.Neons.Back,
        }
        if vp.Neons.R ~= nil then
            vehicle_attributes.neon.color = {
                r = vp.Neons.R,
                g = vp.Neons.G,
                b = vp.Neons.B,
            }
        end
    end

    return attrs
end

return AttributeMapper
