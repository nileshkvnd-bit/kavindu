local DeathBarriers = {}

local Script = require("ClickUl_Refactor.Adapters.Script")
local FeatureThread = require("ClickUl_Refactor.Core.FeatureThread")
local ScriptGlobalIds = require("ClickUl_Refactor.Core.ScriptGlobalIds")

local state = {
    enabled = false,
}

local function tick()
    if not ScriptGlobalIds.ambience_verified() then return end
    Script.write_global_int(ScriptGlobalIds.DISABLE_DEATH_BARRIERS, 1)
end

local thread = FeatureThread.new(tick)

local function release()
    if not ScriptGlobalIds.ambience_verified() then return end
    Script.write_global_int(ScriptGlobalIds.DISABLE_DEATH_BARRIERS, 0)
end

function DeathBarriers.set_enabled(value)
    local enable = value and true or false
    if enable == state.enabled then return end
    state.enabled = enable
    if enable then
        thread.start()
    else
        thread.stop()
        release()
    end
end

function DeathBarriers.is_enabled()
    return state.enabled
end

function DeathBarriers.on_shutdown()
    DeathBarriers.set_enabled(false)
end

return DeathBarriers
