local DeathBarriers = require("ClickUl_Refactor.Features.Game.Core.DeathBarriers")

local DisablePage = {}

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

local hint = {}
local hint_language = nil

local function barrier_hint()
    local active = lang.get_language()
    if hint_language ~= active then
        hint.text = _T("Death Barriers")
        hint.description = _T("Suppress freemode's out-of-bounds script kill")
        hint_language = active
    end
    return hint
end

function DisablePage.init(ctx)
    ui = assert(ctx.ui, "[Game.DisablePage] ui is required")
    lang = assert(ctx.lang, "[Game.DisablePage] lang is required")
end

function DisablePage.draw()
    ui.Group(_T("Disable"), function()
        local enabled = DeathBarriers.is_enabled()
        local next_enabled = ui.Checkbox(_T("Death Barriers"), enabled, barrier_hint())
        if next_enabled ~= enabled then DeathBarriers.set_enabled(next_enabled) end
    end)
end

return DisablePage
