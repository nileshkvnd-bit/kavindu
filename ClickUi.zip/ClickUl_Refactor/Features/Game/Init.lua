local orbital_cannon = require("ClickUl_Refactor.Features.OrbitalCannon.Init")
local autokill = require("ClickUl_Refactor.Features.AutoKill.Init")
local disable_page = require("ClickUl_Refactor.Features.Game.DisablePage")
local death_barriers = require("ClickUl_Refactor.Features.Game.Core.DeathBarriers")

local Game = {}

local ui
local lang
local logger

function Game.init(ctx)
    ui = assert(ctx.ui, "[Game] ui is required")
    lang = assert(ctx.lang, "[Game] lang is required")
    logger = assert(ctx.logger, "[Game] logger is required")
    local settings = assert(ctx.settings, "[Game] settings is required")

    orbital_cannon.init({ ui = ui, lang = lang, logger = logger })
    autokill.init({ ui = ui, lang = lang, logger = logger, settings = settings })
    disable_page.init({ ui = ui, lang = lang })
    logger.info("Features.Game", "Game module initialized")
    return true
end

local function draw_left()
    autokill.draw()
    disable_page.draw()
end

function Game.draw()
    ui.DualColumn(draw_left, orbital_cannon.draw)
end

function Game.on_menu_open()
    orbital_cannon.on_menu_open()
end

function Game.on_menu_close()
    orbital_cannon.on_menu_close()
end

function Game.on_shutdown()
    orbital_cannon.on_shutdown()
    autokill.on_shutdown()
    death_barriers.on_shutdown()
end

return Game
