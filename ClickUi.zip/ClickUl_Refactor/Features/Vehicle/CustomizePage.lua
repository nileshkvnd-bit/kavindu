local Spawner = require("ClickUl_Refactor.Features.Spawner.Init")

local CustomizePage = {}

local ui
local lang

local cache = { vehicle = nil }

local NAME_BUDGET_PER_FRAME <const> = 12
local frame_budget = 0

local function _T(text)
    return lang and lang.get(text) or text
end

local function translate_list(items)
    local out = {}
    for i = 1, #(items or {}) do out[i] = _T(items[i]) end
    return out
end

local function clamp_index(value, size)
    if value == nil or value < 0 then return 1 end
    local index = value + 1
    if index > size then return size end
    if index < 1 then return 1 end
    return index
end

local function stock_index(value, count)
    if value == nil or value < 0 then return 1 end
    local index = value + 2
    local max_index = count + 1
    if index > max_index then return max_index end
    return index
end

local function index_options(stock_label, count, prefix)
    local options = { stock_label }
    for i = 1, count do options[i + 1] = prefix .. " " .. tostring(i) end
    return options
end

local function init_named_options(prefix, count)
    local options = { _T("Stock") }
    for v = 0, count - 1 do options[v + 2] = prefix .. " " .. tostring(v + 1) end
    return options
end

local function named_entry(slot, count, current, prefix)
    return { slot = slot, count = count, current = current,
             options = init_named_options(prefix, count), resolved = 0, resolved_set = {} }
end

local function combo_index_for(current, size)
    local index = (current == nil or current < 0) and 1 or (current + 2)
    if index > size then return size end
    if index < 1 then return 1 end
    return index
end

local function resolve_pending(vehicle, entries)
    for _, e in ipairs(entries) do
        if e.resolved and e.resolved < e.count then
            while e.resolved < e.count and frame_budget > 0 do
                local name = Spawner.VehicleEditor.mod_name(vehicle, e.slot, e.resolved)
                if name and name ~= "" then e.options[e.resolved + 2] = name end
                e.resolved = e.resolved + 1
                frame_budget = frame_budget - 1
            end
            if frame_budget <= 0 then return end
        end
    end
end

local function named_combo_widget(vehicle, e, label, apply)
    local index = combo_index_for(e.current, #e.options)
    local new_index = ui.Combo(label, index, e.options)
    if new_index ~= index then
        e.current = new_index - 2
        apply(vehicle, e.current)
    end
end

local function named_slider_widget(vehicle, e, label_key, id, apply)
    local count = #e.options - 1
    local raw = (e.current and e.current >= 0) and e.current or -1
    if raw >= 0 and not e.resolved_set[raw] then
        local name = Spawner.VehicleEditor.mod_name(vehicle, e.slot, raw)
        if name and name ~= "" then e.options[raw + 2] = name end
        e.resolved_set[raw] = true
    end
    local current_name = (raw < 0 and e.options[1] or e.options[raw + 2]) or ("#" .. tostring(raw))
    local new_raw = ui.Slider(_T(label_key) .. ": " .. tostring(current_name) .. "##" .. id, raw, -1, count - 1, 1)
    if new_raw ~= raw then
        e.current = new_raw
        apply(vehicle, e.current)
    end
end

local function ensure(vehicle)
    if vehicle == cache.vehicle then return end
    cache.vehicle = vehicle
    cache.sec = {}
    cache.colors = {
        custom_primary = { r = 255, g = 255, b = 255, a = 255 },
        custom_secondary = { r = 0, g = 0, b = 0, a = 255 },
        tire_smoke = { r = 255, g = 255, b = 255, a = 255 },
    }
    cache.names = {
        wheel_types = Spawner.VehicleEditor.wheel_type_names(),
        window_tints = translate_list(Spawner.VehiclePreset.window_tints()),
        plate_types = translate_list(Spawner.VehiclePreset.plate_types()),
        xenon_colors = translate_list(Spawner.VehiclePreset.xenon_names()),
        smoke_colors = translate_list(Spawner.VehiclePreset.smoke_names()),
        neon_colors = translate_list(Spawner.VehiclePreset.neon_names()),
    }
    cache.xenon_color = 0
    cache.neon_on = false
    Spawner.VehicleEditor.prepare(vehicle)
end

local function sec(id, builder)
    local data = cache.sec[id]
    if data == nil then
        data = builder() or {}
        cache.sec[id] = data
    end
    return data
end

local function section(title, body)
    ui.Group(_T(title), body)
end

local function build_mods(vehicle, category)
    local mods = {}
    for _, def in ipairs(Spawner.VehicleEditor.indexed_slots()) do
        if def.category == category then
            local mod = Spawner.VehicleEditor.slot_state(vehicle, def.slot)
            if mod then
                local name = Spawner.VehicleEditor.slot_category_name(def.slot)
                    or Spawner.VehicleEditor.slot_name_dynamic(vehicle, def.slot)
                    or _T(def.key)
                mod.label = name .. "##cmod_" .. def.slot
                mod.options = init_named_options(name, mod.count)
                mod.resolved = 0
                mods[#mods + 1] = mod
            end
        end
    end
    return mods
end

local function mod_widget(vehicle, mod)
    named_combo_widget(vehicle, mod, mod.label, function(v, val) Spawner.VehicleEditor.set_mod(v, mod.slot, val) end)
end

local function index_combo_widget(vehicle, label, id, store, apply)
    local new_index = ui.Combo(_T(label) .. "##cust_" .. id, store.index, store.options)
    if new_index ~= store.index then
        store.index = new_index
        apply(vehicle, new_index - 2)
    end
end

local function toggle_widget(vehicle, data, label, key, apply)
    local value = ui.Checkbox(_T(label), data[key] and true or false)
    if value ~= data[key] then
        data[key] = value
        apply(vehicle, value)
    end
end

local color_name_cache = {}

local function color_names_for(vehicle, paint_type)
    local cached = color_name_cache[paint_type]
    if cached then return cached end
    local names = Spawner.VehicleEditor.scan_color_names(vehicle, paint_type)
    if #names > 0 then color_name_cache[paint_type] = names end
    return names
end

local CATEGORY_GXT <const> = {
    Classic = "CMOD_COL1_1",
    Matte = "CMOD_COL1_5",
    Metals = "CMOD_COL1_4",
    Chameleon = "CMOD_COL1_7",
}
local category_label_cache = {}

local function category_label(cat_key)
    local cached = category_label_cache[cat_key]
    if cached ~= nil then return cached end
    local gxt = CATEGORY_GXT[cat_key]
    local name = gxt and Spawner.VehicleEditor.gxt_text(gxt) or nil
    category_label_cache[cat_key] = name or false
    return name
end

local category_labels_cache = nil
local category_labels_cache_lang = nil

local function category_labels(cat_keys)
    local lang_code = lang.get_language()
    if category_labels_cache and category_labels_cache_lang == lang_code then return category_labels_cache end
    local labels = {}
    for _, key in ipairs(cat_keys) do
        labels[#labels + 1] = category_label(key)
    end
    category_labels_cache = labels
    category_labels_cache_lang = lang_code
    return labels
end

local function color_combo_widget(vehicle, data, label, id, key, apply)
    local lang_code = lang.get_language()
    local cat_keys = Spawner.VehiclePreset.color_category_keys()
    local cur = data[key] or 0
    local cat = Spawner.VehiclePreset.color_category_of(lang_code, cur)
    local new_cat = ui.Combo(_T(label) .. " " .. _T("Category") .. "##ccat_" .. id, cat, category_labels(cat_keys))
    if new_cat ~= cat then
        local group = Spawner.VehicleEditor.standard_color_category(lang_code, cat_keys[new_cat])
        local color = group.indices[1] or 0
        data[key] = color
        apply(vehicle, color)
        return
    end
    local group = Spawner.VehicleEditor.standard_color_category(lang_code, cat_keys[cat])
    local labels = group.labels
    if cat_keys[cat] == "Chameleon" then
        labels = color_names_for(vehicle, 6)
    end
    local pos = 1
    for i = 1, #group.indices do
        if group.indices[i] == cur then pos = i break end
    end
    local new_pos = ui.Combo(_T(label) .. "##cust_" .. id, pos, labels)
    if new_pos ~= pos then
        local color = group.indices[new_pos]
        data[key] = color
        apply(vehicle, color)
    end
end

local INTERIOR_COLOR_CATEGORY <const> = "Classic"
local function flat_color_combo_widget(vehicle, data, label, id, key, apply)
    local group = Spawner.VehicleEditor.standard_color_category(lang.get_language(), INTERIOR_COLOR_CATEGORY)
    local cur = data[key] or 0
    local pos = 1
    for i = 1, #group.indices do
        if group.indices[i] == cur then pos = i break end
    end
    local new_pos = ui.Combo(_T(label) .. "##cust_" .. id, pos, group.labels)
    if new_pos ~= pos then
        local color = group.indices[new_pos]
        data[key] = color
        apply(vehicle, color)
    end
end

local function color_widget(vehicle, label, id, color_key, apply)
    if ui.ColorPicker(_T(label) .. "##cclr_" .. id, cache.colors, color_key) then
        local c = cache.colors[color_key]
        apply(vehicle, c.r, c.g, c.b)
    end
end

local function build_wheels(vehicle)
    local w = Spawner.VehicleEditor.read_wheels(vehicle)
    local front = w.front or { count = 0, current = -1 }
    local back = w.back or { count = 0, current = -1 }
    return {
        wheel_type = w.wheel_type or 0,
        custom = false,
        front = named_entry(23, front.count, front.current, _T("Wheel")),
        back = named_entry(24, back.count, back.current, _T("Wheel")),
    }
end

local function build_liveries(vehicle)
    local l = Spawner.VehicleEditor.read_liveries(vehicle)
    local lc = l.livery_count or 0
    local l2c = l.livery2_count or 0
    local livery = named_entry(48, lc, l.livery, Spawner.VehicleEditor.slot_category_name(48))
    return {
        livery = livery,
        name_entries = { livery },
        roof = { options = index_options(_T("Stock"), l2c, _T("Roof Livery")), index = stock_index(l.livery2, l2c) },
    }
end

local function build_horn(vehicle)
    local state = Spawner.VehicleEditor.horn_state(vehicle)
    if not state then return { categories = {} } end
    local categories, cat_names = {}, {}
    for _, def in ipairs(Spawner.VehicleEditor.horn_categories()) do
        local indices = {}
        for _, idx in ipairs(def.indices) do
            if idx < state.count then indices[#indices + 1] = idx end
        end
        if #indices > 0 then
            categories[#categories + 1] = { indices = indices }
            cat_names[#cat_names + 1] = _T(def.key)
        end
    end
    if #categories > 0 then table.insert(categories[1].indices, 1, -1) end
    local cat_index = 1
    for i, cat in ipairs(categories) do
        for _, idx in ipairs(cat.indices) do
            if idx == state.current then cat_index = i break end
        end
    end
    return { categories = categories, cat_names = cat_names, slot = Spawner.VehicleEditor.horn_slot(),
             current = state.current, cat_index = cat_index, names = {} }
end

local function draw_horn(vehicle)
    local d = sec("horn", function() return build_horn(vehicle) end)
    if #d.categories == 0 then return end
    section("Horn", function()
        local new_cat = ui.Combo(_T("Horn Category") .. "##cust_horncat", d.cat_index, d.cat_names)
        if new_cat ~= d.cat_index then d.cat_index = new_cat end
        local cat = d.categories[d.cat_index]
        local pos = 1
        for i, idx in ipairs(cat.indices) do
            if idx == d.current then pos = i break end
        end
        local cur_idx = cat.indices[pos]
        local cur_name
        if cur_idx < 0 then
            cur_name = _T("Stock")
        else
            cur_name = d.names[cur_idx]
            if cur_name == nil then
                cur_name = Spawner.VehicleEditor.mod_name(vehicle, d.slot, cur_idx) or ("#" .. tostring(cur_idx))
                d.names[cur_idx] = cur_name
            end
        end
        local new_pos = ui.Slider(Spawner.VehicleEditor.slot_category_name(14) .. ": " .. tostring(cur_name) .. "##cust_horn", pos, 1, #cat.indices, 1)
        if new_pos ~= pos then
            local idx = cat.indices[new_pos]
            d.current = idx
            Spawner.VehicleEditor.set_mod(vehicle, d.slot, idx)
        end
    end)
end

local function draw_performance(vehicle)
    section("Performance", function()
        local d = sec("perf", function()
            return { mods = build_mods(vehicle, "performance"), turbo = Spawner.VehicleEditor.toggle_on(vehicle, 18) }
        end)
        resolve_pending(vehicle, d.mods)
        for _, mod in ipairs(d.mods) do mod_widget(vehicle, mod) end
        toggle_widget(vehicle, d, "Turbo", "turbo", function(v, on) Spawner.VehicleEditor.toggle_mod(v, 18, on) end)
    end)
end

local function draw_cosmetic(vehicle)
    local d = sec("cosmetic", function() return { mods = build_mods(vehicle, "cosmetic") } end)
    if #d.mods == 0 then return end
    section("Cosmetic", function()
        resolve_pending(vehicle, d.mods)
        for _, mod in ipairs(d.mods) do mod_widget(vehicle, mod) end
    end)
end

local function draw_wheels(vehicle)
    section("Wheels", function()
        local d = sec("wheels", function() return build_wheels(vehicle) end)
        local wt_index = clamp_index(d.wheel_type, #cache.names.wheel_types)
        local new_wt = ui.Combo(_T("Wheel Type") .. "##cust_wt", wt_index, cache.names.wheel_types)
        if new_wt ~= wt_index then
            Spawner.VehicleEditor.set_wheel_type(vehicle, new_wt - 1)
            cache.sec["wheels"] = nil
            return
        end
        local has_back = (d.back.count or 0) > 0
        named_slider_widget(vehicle, d.front, has_back and "Front Wheels" or "Wheel", "cust_fw", function(v, val) Spawner.VehicleEditor.set_wheel(v, 23, val, d.custom) end)
        if has_back then
            named_slider_widget(vehicle, d.back, "Back Wheels", "cust_bw", function(v, val) Spawner.VehicleEditor.set_wheel(v, 24, val, d.custom) end)
        end
        local custom = ui.Checkbox(_T("Custom Tires"), d.custom and true or false)
        if custom ~= d.custom then
            d.custom = custom
            Spawner.VehicleEditor.set_wheel(vehicle, 23, d.front.current, custom)
            if has_back then Spawner.VehicleEditor.set_wheel(vehicle, 24, d.back.current, custom) end
        end
    end)
end

local finish_options_cache = nil
local finish_options_cache_lang = nil

local function finish_options()
    local lang_code = lang.get_language()
    if finish_options_cache and finish_options_cache_lang == lang_code then return finish_options_cache end
    local options = {}
    for _, f in ipairs(Spawner.VehicleEditor.color_finishes()) do
        options[#options + 1] = Spawner.VehicleEditor.finish_name(f.type)
    end
    finish_options_cache = options
    finish_options_cache_lang = lang_code
    return options
end

local function valid_finish_type(finishes, paint_type)
    for _, f in ipairs(finishes) do
        if f.type == paint_type then return paint_type end
    end
    return finishes[1].type
end

local function paint_color_widget(vehicle, store, which, finish_label, color_label, id)
    local finishes = Spawner.VehicleEditor.color_finishes()
    store.type = valid_finish_type(finishes, store.type or 0)
    local fi = clamp_index(store.type, #finishes)
    local new_fi = ui.Combo(_T(finish_label) .. "##cpf_" .. id, fi, finish_options())
    if new_fi ~= fi then
        store.type = finishes[new_fi].type
        store.index = 0
        Spawner.VehicleEditor.set_mod_color(vehicle, which, store.type, store.index)
    end
    local names = color_names_for(vehicle, store.type or 0)
    if #names == 0 then return end
    local ci = clamp_index(store.index, #names)
    local new_ci = ui.Combo(_T(color_label) .. "##cpc_" .. id, ci, names)
    if new_ci ~= ci then
        store.index = new_ci - 1
        Spawner.VehicleEditor.set_mod_color(vehicle, which, store.type, store.index)
    end
end

local function build_paint(vehicle)
    local extra = Spawner.VehicleEditor.read_paint(vehicle)
    if extra.custom_primary then
        cache.colors.custom_primary = { r = extra.custom_primary.r, g = extra.custom_primary.g, b = extra.custom_primary.b, a = 255 }
    end
    if extra.custom_secondary then
        cache.colors.custom_secondary = { r = extra.custom_secondary.r, g = extra.custom_secondary.g, b = extra.custom_secondary.b, a = 255 }
    end
    return {
        primary = Spawner.VehicleEditor.get_mod_color(vehicle, 1) or { type = 0, index = 0 },
        secondary = Spawner.VehicleEditor.get_mod_color(vehicle, 2) or { type = 0, index = 0 },
        pearlescent = extra.pearlescent,
        wheel_color = extra.wheel_color,
        interior = extra.interior,
        dashboard = extra.dashboard,
    }
end

local function draw_primary_color(vehicle)
    section("Primary Tone", function()
        local d = sec("paint", function() return build_paint(vehicle) end)
        paint_color_widget(vehicle, d.primary, 1, "Primary Paint", "Primary Color", "pri")
        color_widget(vehicle, "Custom Primary", "pri", "custom_primary", function(v, r, g, b) Spawner.VehicleEditor.set_custom_primary(v, r, g, b) end)
        color_combo_widget(vehicle, d, "Pearlescent", "pearl", "pearlescent", function(v, val) Spawner.VehicleEditor.set_pearlescent(v, val) end)
    end)
end

local function draw_secondary_color(vehicle)
    section("Secondary Tone", function()
        local d = sec("paint", function() return build_paint(vehicle) end)
        paint_color_widget(vehicle, d.secondary, 2, "Secondary Paint", "Secondary Color", "sec")
        color_widget(vehicle, "Custom Secondary", "sec", "custom_secondary", function(v, r, g, b) Spawner.VehicleEditor.set_custom_secondary(v, r, g, b) end)
    end)
end

local function draw_other_colors(vehicle)
    section("Other Colors", function()
        local d = sec("paint", function() return build_paint(vehicle) end)
        color_combo_widget(vehicle, d, "Wheel Color", "wclr", "wheel_color", function(v, val) Spawner.VehicleEditor.set_wheel_color(v, val) end)
        flat_color_combo_widget(vehicle, d, "Interior Color", "int", "interior", function(v, val) Spawner.VehicleEditor.set_interior(v, val) end)
        flat_color_combo_widget(vehicle, d, "Dashboard Color", "dash", "dashboard", function(v, val) Spawner.VehicleEditor.set_dashboard(v, val) end)
    end)
end

local function draw_liveries(vehicle)
    local d = sec("liveries", function() return build_liveries(vehicle) end)
    local has_livery = (d.livery.count or 0) > 0
    local has_roof = #d.roof.options > 1
    if not (has_livery or has_roof) then return end
    section("Liveries", function()
        if has_livery then
            resolve_pending(vehicle, d.name_entries)
            named_combo_widget(vehicle, d.livery, Spawner.VehicleEditor.slot_category_name(48) .. "##cust_liv", function(v, value) Spawner.VehicleEditor.set_livery(v, value) end)
        end
        if has_roof then
            index_combo_widget(vehicle, "Roof Livery", "roof", d.roof, function(v, value) Spawner.VehicleEditor.set_roof_livery(v, value) end)
        end
    end)
end

local function lights_data(vehicle)
    return sec("lights", function()
        local data = Spawner.VehicleEditor.read_lights(vehicle)
        cache.neon_on = data.neon and true or false
        local nc = data.neon_color
        if nc and nc.r then cache.neon_index = Spawner.VehiclePreset.neon_preset_index(nc.r, nc.g, nc.b) end
        local xc = data.xenon_color
        if type(xc) == "number" and xc >= 0 and xc <= 12 then cache.xenon_color = xc end
        return data
    end)
end

local function draw_lights(vehicle)
    section("Lights", function()
        local d = lights_data(vehicle)
        toggle_widget(vehicle, d, "Xenon Headlights", "xenon", function(v, on) Spawner.VehicleEditor.set_xenon_enabled(v, on) end)
        if d.xenon then
            local cur_xc = cache.xenon_color or 0
            local xc_name = cache.names.xenon_colors[cur_xc + 2] or tostring(cur_xc)
            local xc = ui.Slider(_T("Xenon Color") .. ": " .. xc_name .. "##cust_xc", cur_xc, 0, 12, 1)
            if xc ~= cur_xc then
                cache.xenon_color = xc
                Spawner.VehicleEditor.set_xenon_color(vehicle, xc)
            end
        end
        local neon_on = ui.Checkbox(_T("Neon Lights"), cache.neon_on and true or false)
        if neon_on ~= cache.neon_on then
            cache.neon_on = neon_on
            Spawner.VehicleEditor.set_neon_enabled(vehicle, neon_on)
        end
        if cache.neon_on then
            local names = cache.names.neon_colors
            local sel = cache.neon_index or 1
            if sel > #names then sel = #names end
            local cur_name = names[sel] or tostring(sel)
            local new_sel = ui.Slider(_T("Neon Color") .. ": " .. cur_name .. "##cust_neon", sel, 1, #names, 1)
            if new_sel ~= sel then
                cache.neon_index = new_sel
                Spawner.VehiclePreset.apply_neon_preset(vehicle, new_sel)
            end
        end
    end)
end

local function draw_windows(vehicle)
    section("Windows", function()
        local d = lights_data(vehicle)
        local wt = clamp_index(d.window_tint, #cache.names.window_tints)
        local new_t = ui.Combo(_T("Window Tint") .. "##cust_tint", wt, cache.names.window_tints)
        if new_t ~= wt then
            d.window_tint = new_t - 1
            Spawner.VehicleEditor.set_window_tint(vehicle, new_t - 1)
        end
    end)
end

local function draw_tyres(vehicle)
    section("Tyres", function()
        local d = sec("tyres", function()
            local t = Spawner.VehicleEditor.read_tyres(vehicle)
            if t.smoke_color then
                cache.colors.tire_smoke = { r = t.smoke_color.r, g = t.smoke_color.g, b = t.smoke_color.b, a = 255 }
                t.smoke_index = Spawner.VehiclePreset.smoke_preset_index(t.smoke_color.r, t.smoke_color.g, t.smoke_color.b)
            end
            return t
        end)
        toggle_widget(vehicle, d, "Bulletproof Tires", "bulletproof", function(v, on) Spawner.VehicleEditor.set_bulletproof(v, on) end)
        toggle_widget(vehicle, d, "Drift Tires", "drift", function(v, on) Spawner.VehicleEditor.set_drift(v, on) end)
        toggle_widget(vehicle, d, "Tire Smoke", "tyre_smoke", function(v, on) Spawner.VehicleEditor.set_tire_smoke_enabled(v, on) end)
        if d.tyre_smoke then
            local names = cache.names.smoke_colors
            local sel = d.smoke_index or 1
            if sel > #names then sel = #names end
            local cur_name = names[sel] or tostring(sel)
            local new_sel = ui.Slider(_T("Tire Smoke Color") .. ": " .. cur_name .. "##cust_smoke", sel, 1, #names, 1)
            if new_sel ~= sel then
                d.smoke_index = new_sel
                local rgb = Spawner.VehiclePreset.apply_smoke_preset(vehicle, new_sel)
                if rgb then cache.colors.tire_smoke = { r = rgb.r, g = rgb.g, b = rgb.b, a = 255 } end
            end
            color_widget(vehicle, "Custom Smoke Color", "smoke", "tire_smoke", function(v, r, g, b) Spawner.VehicleEditor.set_tire_smoke_color(v, r, g, b) end)
        end
    end)
end

local function draw_plate(vehicle)
    section("License Plate", function()
        local d = sec("plate", function() return Spawner.VehicleEditor.read_plate(vehicle) end)
        local new_text = ui.TextInput(_T("Plate Text") .. "##cust_plate", d.plate_text or "", 8)
        if new_text ~= d.plate_text then
            d.plate_text = new_text
            Spawner.VehicleEditor.set_plate_text(vehicle, new_text)
        end
        local pi = clamp_index(d.plate_index, #cache.names.plate_types)
        local new_pi = ui.Combo(_T("Plate Style") .. "##cust_pstyle", pi, cache.names.plate_types)
        if new_pi ~= pi then
            d.plate_index = new_pi - 1
            Spawner.VehicleEditor.set_plate_type(vehicle, new_pi - 1)
        end
    end)
end

local function draw_extras(vehicle)
    local d = sec("extras", function() return Spawner.VehicleEditor.read_extras(vehicle) end)
    if not next(d) then return end
    section("Extras", function()
        for id = 1, Spawner.VehicleEditor.extra_slots() do
            if d[id] ~= nil then
                local value = ui.Checkbox(_T("Extra") .. " " .. tostring(id) .. "##cust_extra_" .. id, d[id])
                if value ~= d[id] then
                    d[id] = value
                    Spawner.VehicleEditor.set_extra(vehicle, id, value)
                end
            end
        end
    end)
end

local function refresh_mod_currents(vehicle, id)
    local d = cache.sec[id]
    if not d or not d.mods then return end
    for _, mod in ipairs(d.mods) do
        local state = Spawner.VehicleEditor.slot_state(vehicle, mod.slot)
        if state then mod.current = state.current end
    end
end

local function draw_quick(vehicle)
    section("Quick Actions", function()
        ui.Row({
            function()
                if ui.Button(_T("Max Performance")) then
                    Spawner.VehicleEditor.max_performance(vehicle)
                    refresh_mod_currents(vehicle, "perf")
                    local perf = cache.sec["perf"]
                    if perf then perf.turbo = Spawner.VehicleEditor.toggle_on(vehicle, 18) end
                    cache.sec["tyres"] = nil
                    ui.notify(_T("Max Performance"), "Success")
                end
            end,
            function()
                if ui.Button(_T("Max Visual")) then
                    Spawner.VehicleEditor.max_visual(vehicle)
                    refresh_mod_currents(vehicle, "cosmetic")
                    local liv = cache.sec["liveries"]
                    if liv and liv.livery then
                        local state = Spawner.VehicleEditor.slot_state(vehicle, liv.livery.slot)
                        if state then liv.livery.current = state.current end
                    end
                    cache.sec["horn"] = nil
                    ui.notify(_T("Max Visual"), "Success")
                end
            end,
        })
        ui.Row({
            function()
                if ui.Button(_T("Repair")) then
                    Spawner.VehicleEditor.repair(vehicle)
                    ui.notify(_T("Repair"), "Success")
                end
            end,
            function()
                if ui.Button(_T("Clean")) then
                    Spawner.VehicleEditor.clean(vehicle)
                    ui.notify(_T("Clean"), "Success")
                end
            end,
        })
    end)
end

function CustomizePage.init(ctx)
    ui = assert(ctx.ui, "[Vehicle.CustomizePage] ui is required")
    lang = assert(ctx.lang, "[Vehicle.CustomizePage] lang is required")
end

function CustomizePage.draw()
    local vehicle = Spawner.VehicleEditor.current_vehicle()
    if vehicle == 0 then
        cache.vehicle = nil
        ui.Text(_T("Enter a vehicle to customise it"))
        return
    end
    ensure(vehicle)
    frame_budget = NAME_BUDGET_PER_FRAME

    ui.DualColumn(
        function()
            draw_primary_color(vehicle)
            draw_secondary_color(vehicle)
            draw_other_colors(vehicle)
            draw_lights(vehicle)
            draw_wheels(vehicle)
            draw_tyres(vehicle)
        end,
        function()
            draw_quick(vehicle)
            draw_performance(vehicle)
            draw_cosmetic(vehicle)
            draw_horn(vehicle)
            draw_liveries(vehicle)
            draw_windows(vehicle)
            draw_plate(vehicle)
            draw_extras(vehicle)
        end
    )
end

return CustomizePage
