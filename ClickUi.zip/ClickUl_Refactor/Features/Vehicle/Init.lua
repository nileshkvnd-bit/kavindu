local customize_page = require("ClickUl_Refactor.Features.Vehicle.CustomizePage")
local homing = require("ClickUl_Refactor.Features.HomingMissiles.Init")

local Vehicle = {}

local ui
local lang
local logger

local function _T(text)
    return lang and lang.get(text) or text
end

local MAIN_TABS <const> = { "Homing Missiles", "Customize" }

local state = {
    main_tab = 1,
}

function Vehicle.init(ctx)
    ui = assert(ctx.ui, "[Vehicle] ui is required")
    lang = assert(ctx.lang, "[Vehicle] lang is required")
    logger = assert(ctx.logger, "[Vehicle] logger is required")
    local settings = assert(ctx.settings, "[Vehicle] settings is required")
    local hotkeys = assert(ctx.hotkeys, "[Vehicle] hotkeys is required")
    local action_registry = assert(ctx.action_registry, "[Vehicle] action_registry is required")
    local favorites = assert(ctx.favorites, "[Vehicle] favorites is required")

    customize_page.init({ ui = ui, lang = lang })
    homing.init({
        ui = ui,
        lang = lang,
        logger = logger,
        settings = settings,
        hotkeys = hotkeys,
        action_registry = action_registry,
        favorites = favorites,
    })

    logger.info("Features.Vehicle", "Vehicle module initialized")
    return true
end

function Vehicle.draw()
    local tabs = {}
    for i = 1, #MAIN_TABS do tabs[i] = _T(MAIN_TABS[i]) end
    state.main_tab = ui.SubTabBar(tabs, state.main_tab)

    if state.main_tab == 2 then
        customize_page.draw()
    else
        homing.draw()
    end
end

function Vehicle.on_menu_open()
    homing.on_menu_open()
end

function Vehicle.on_menu_close()
    homing.on_menu_close()
end

function Vehicle.on_shutdown()
    homing.on_shutdown()
end

return Vehicle
