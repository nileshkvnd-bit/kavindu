local GeneralPage = {}

local CannonRuntime = require("ClickUl_Refactor.Features.OrbitalCannon.Core.CannonRuntime")

local math_floor = math.floor
local math_sqrt = math.sqrt

local ui
local lang

local function _T(text)
    return lang and lang.get(text) or text
end

function GeneralPage.init(ctx)
    ui = assert(ctx.ui, "[OrbitalCannon.GeneralPage] ui is required")
    lang = assert(ctx.lang, "[OrbitalCannon.GeneralPage] lang is required")
end

local function start(mode)
    local ok, err = CannonRuntime.start(mode)
    if ok then
        ui.notify(_T("Orbital Cannon started"), "Success")
    else
        ui.notify(_T("Orbital Cannon failed") .. ": " .. _T(tostring(err)), "Error")
    end
end

local COMBO_REFRESH_DRAWS <const> = 30
local combo_items = {}
local combo_ids = {}
local combo_count = 0
local combo_refresh = 0

local function rebuild_target_combo()
    local slots, n = CannonRuntime.lockable_players()
    combo_count = n
    combo_items[1] = _T("Nearest")
    for i = 1, n do
        local slot = slots[i]
        combo_ids[i] = slot.id
        combo_items[i + 1] = ("%s (%dm)"):format(tostring(slot.name), math_floor(math_sqrt(slot.d)))
    end
    for i = n + 2, #combo_items do combo_items[i] = nil end
    for i = n + 1, #combo_ids do combo_ids[i] = nil end
end

local function draw_target_combo(snapshot)
    combo_refresh = combo_refresh - 1
    if combo_refresh <= 0 then
        rebuild_target_combo()
        combo_refresh = COMBO_REFRESH_DRAWS
    end
    if combo_count == 0 then return end

    local want = snapshot.preferred_player_id
    if snapshot.running and snapshot.target_player_id then
        want = snapshot.target_player_id
    end
    local selected = 1
    if want then
        for i = 1, combo_count do
            if combo_ids[i] == want then
                selected = i + 1
                break
            end
        end
    end

    local new_index = ui.Combo(_T("Target") .. "##orb_target", selected, combo_items)
    if new_index and new_index ~= selected then
        if new_index <= 1 then
            CannonRuntime.set_target_player(nil)
        else
            CannonRuntime.set_target_player(combo_ids[new_index - 1])
        end
        combo_refresh = 0
    end
end

function GeneralPage.draw()
    local snapshot = CannonRuntime.snapshot()

    ui.Group(_T("Orbital Cannon"), function()
        if not snapshot.running or snapshot.mode == "auto" then
            draw_target_combo(snapshot)
        end

        if snapshot.running then
            if ui.Button(_T("Stop Orbital Cannon")) then
                CannonRuntime.request_stop()
            end
        else
            if ui.Button(_T("Start Orbital Cannon Auto Lock")) then
                start("target_lock_on")
            end
            if ui.Button(_T("Start Orbital Cannon Free Aim")) then
                start("free_cam")
            end
        end
    end)
end

return GeneralPage
