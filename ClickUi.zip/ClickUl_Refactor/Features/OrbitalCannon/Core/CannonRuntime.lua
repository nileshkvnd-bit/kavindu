local CannonRuntime = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Input = require("ClickUl_Refactor.Adapters.Input")
local Game = require("ClickUl_Refactor.Adapters.Game")
local Menu = require("ClickUl_Refactor.Adapters.Menu")
local Players = require("ClickUl_Refactor.Adapters.Players")
local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
local HudDraw = require("ClickUl_Refactor.Core.HudDraw")
local Explosion = require("ClickUl_Refactor.Features.OrbitalCannon.Core.Explosion")

local WHITE_FULL <const> = { r = 255, g = 255, b = 255, a = 255 }
local WHITE_DIM <const> = { r = 255, g = 255, b = 255, a = 220 }

local PLAYER_CONTROL <const> = 0
local FRONTEND_CONTROL <const> = 2
local INPUT_ATTACK <const> = 24
local INPUT_VEH_ATTACK <const> = 69
local INPUT_FRONTEND_CANCEL <const> = 202
local INPUT_CURSOR_SCROLL_UP <const> = 241
local INPUT_CURSOR_SCROLL_DOWN <const> = 242
local INPUT_SCRIPT_LEFT_AXIS_X <const> = 218
local INPUT_SCRIPT_LEFT_AXIS_Y <const> = 219
local INPUT_SCRIPT_RIGHT_AXIS_Y <const> = 221

local SOUND_SET <const> = "dlc_xm_orbital_cannon_sounds"
local AUDIO_BANK <const> = "DLC_CHRISTMAS2017/XM_ION_CANNON"

local MODE_FREE <const> = "free"
local MODE_AUTO <const> = "auto"

local STATE = {
    inactive = "inactive",
    starting = "starting",
    active = "active",
    firing = "firing",
    exiting = "exiting",
}

local EXIT_MAX_MS <const> = 2000
local ZOOM_SOUND_MS <const> = 250

local DISABLED_CONTROLS <const> = {
    1, 2, 14, 15, 16, 17, 24, 37, 69, 70, 75, 81, 82, 83, 84, 85, 99, 100,
    122, 140, 141, 142, 143, 200, 202, 218, 219, 220, 221, 241, 242, 257, 263, 264,
}

local FOV_LEVELS <const> = { 100.0, 80.0, 60.0, 40.0, 20.0 }
local MOVE_SPEED <const> = { 90.0, 60.0, 50.0, 25.0, 10.0 }
local MIN_X <const> = -4000.0
local MAX_X <const> = 4000.0
local MIN_Y <const> = -4000.0
local MAX_Y <const> = 8000.0
local CHARGE_MS <const> = 3000
local FIRE_MS <const> = 3000
local FIRE_SOUND_ARM_MS <const> = 250
local STOP_AFTER_FIRE_MS <const> = 1200
local TARGET_SCAN_DISTANCE <const> = 5000.0

local SF_STATE_CHARGE <const> = 4
local SF_STATE_COUNTDOWN <const> = 5

local logger = nil
local lang = nil
local thread_id = nil

local function _T(text)
    return lang and lang.get(text) or text
end

local state = {
    status = STATE.inactive,
    mode = MODE_FREE,
    cam = 0,
    zoom_level = 1,
    cam_pos = nil,
    target = nil,
    target_position = nil,
    scaleform = 0,
    instructional_scaleform = 0,
    instr_built_kbm = nil,
    started_at = 0,
    charge_started_at = 0,
    fire_started_at = 0,
    fired_at = 0,
    counting = false,
    did_fire = false,
    ready_cue_played = false,
    can_zoom = true,
    can_cycle = true,
    target_name = nil,
    preferred_id = nil,
    menu_open = false,
    frozen_entity = 0,
    session_ped = 0,
    exit_started_at = 0,
    sound_background = -1,
    sound_charge = -1,
    sound_fire = -1,
    sound_zoom = -1,
    zoom_stop_at = 0,
}

local function now()
    return Runtime.get_tick_count()
end

local function set_state(next_state)
    state.status = next_state
    state.started_at = now()
end

local function log_error(message, extra)
    if logger then
        logger.error("Features.OrbitalCannon", message, extra)
    end
end

local function my_ped()
    return Players.local_ped()
end

local function my_pos()
    return Players.local_coords()
end

local ORBITAL_KILLS_PATH <const> = "Weapon > Mods > Orbital Kills"
local orbital_kills_opt = nil
local orbital_kills_owned = false

local function orbital_kills_option()
    if not orbital_kills_opt then
        orbital_kills_opt = Menu.find(ORBITAL_KILLS_PATH)
    end
    return orbital_kills_opt
end

local function enable_orbital_kills()
    local opt = orbital_kills_option()
    if not opt then return end
    if Menu.get_value(opt) then return end
    Menu.set_value(opt, true)
    orbital_kills_owned = true
end

local function disable_orbital_kills()
    if not orbital_kills_owned then return end
    orbital_kills_owned = false
    local opt = orbital_kills_option()
    if not opt then return end
    Menu.set_value(opt, false)
    Menu.invoke(opt)
end

local function play_cue(name)
    Native.call("play_sound_frontend", -1, name, SOUND_SET, true)
end

local function start_sound(slot, name)
    if state[slot] ~= -1 then return end
    local id = Native.call("get_sound_id")
    if id == nil or id == -1 then return end
    state[slot] = id
    Native.call("play_sound_frontend", id, name, SOUND_SET, true)
end

local function stop_sound(slot)
    local id = state[slot]
    if not id or id == -1 then return end
    Native.call("stop_sound", id)
    Native.call("release_sound_id", id)
    state[slot] = -1
end

local function stop_all_sounds()
    stop_sound("sound_background")
    stop_sound("sound_charge")
    stop_sound("sound_fire")
    stop_sound("sound_zoom")
end

local function keep_player_collision_loaded()
    local ped = my_ped()
    if not ped or ped == 0 then return end
    if Native.call("has_collision_loaded_around_entity", ped) then return end
    local pos = my_pos()
    if not pos then return end
    Native.call("request_collision_at_coord", pos.x, pos.y, pos.z)
end

local function freeze_player()
    local target = Players.local_teleport_target()
    if not target or target == 0 then return end
    state.frozen_entity = target
    Native.call("freeze_entity_position", target, true)
end

local function unfreeze_player()
    local entity = state.frozen_entity
    state.frozen_entity = 0
    if not entity or entity == 0 then return end
    if not Game.entity_exists(entity) then return end
    Native.call("freeze_entity_position", entity, false)
end

local function player_collision_ready()
    local ped = my_ped()
    if not ped or ped == 0 then return true end
    return Native.call("has_collision_loaded_around_entity", ped) and true or false
end

local function clamp(value, min_value, max_value)
    if value < min_value then return min_value end
    if value > max_value then return max_value end
    return value
end

local function copy_vec3(position)
    if not position then return nil end
    return { x = position.x or 0.0, y = position.y or 0.0, z = position.z or 0.0 }
end

local function get_z_pos(position)
    if position.y >= 1000.0 and position.y <= 1700.0 and position.x >= -700.0 and position.x <= 1100.0 then
        return 500.0
    end
    if position.y >= 3600.0 and position.y <= 4100.0 and position.x >= -1700.0 and position.x <= -700.0 then
        return 550.0
    end
    if position.y >= 4880.0 and position.y <= 6150.0 and position.x >= -500.0 and position.x <= 1900.0 then
        return 850.0
    end
    return 400.0
end

local function ground_target(position)
    local found, z = Native.get_ground_z_for_3d_coord(position.x, position.y, 1000.0)
    if found and z then return { x = position.x, y = position.y, z = z } end
    return { x = position.x, y = position.y, z = position.z - 400.0 }
end

local function remove_thread()
    if not thread_id then return end
    local current = thread_id
    thread_id = nil
    Runtime.remove_thread(current)
end

local function disable_controls()
    for i = 1, #DISABLED_CONTROLS do
        Input.disable_control(PLAYER_CONTROL, DISABLED_CONTROLS[i], true)
    end
    Native.call("hide_hud_and_radar_this_frame")
    Native.call("thefeed_hide_this_frame")
end

local function destroy_camera()
    Native.call("render_script_cams", false, false, 0, true, false, 0)
    if state.cam ~= 0 and Native.call("does_cam_exist", state.cam) then
        Native.call("set_cam_active", state.cam, false)
        Native.call("destroy_cam", state.cam, false)
    end
    state.cam = 0
end

local function release_scaleform(handle)
    if not handle or handle == 0 then return 0 end
    local ptr = Pointer.int_with_value(handle)
    Native.call("set_scaleform_movie_as_no_longer_needed", ptr)
    Pointer.free(ptr)
    return 0
end

local function begin_scaleform(handle, method)
    return Native.call("begin_scaleform_movie_method", handle, method)
end

local function end_scaleform()
    Native.call("end_scaleform_movie_method")
end

local function scaleform_ready(handle)
    return handle ~= 0 and Native.call("has_scaleform_movie_loaded", handle)
end

local function set_scaleform_state(value)
    if not scaleform_ready(state.scaleform) then return end
    begin_scaleform(state.scaleform, "SET_STATE")
    Native.call("scaleform_movie_method_add_param_int", value)
    end_scaleform()
end

local function set_scaleform_zoom()
    if not scaleform_ready(state.scaleform) then return end
    local normalized = (state.zoom_level - 1) / (#FOV_LEVELS - 1)
    begin_scaleform(state.scaleform, "SET_ZOOM_LEVEL")
    Native.call("scaleform_movie_method_add_param_float", normalized)
    end_scaleform()
end

local function set_scaleform_countdown(countdown)
    if not scaleform_ready(state.scaleform) then return end
    begin_scaleform(state.scaleform, "SET_COUNTDOWN")
    Native.call("scaleform_movie_method_add_param_int", countdown or 0)
    end_scaleform()
end

local function draw_orbital_scaleform(charge, countdown)
    if state.scaleform == 0 then
        state.scaleform = Native.call("request_scaleform_movie", "ORBITAL_CANNON_CAM")
        return
    end
    if not scaleform_ready(state.scaleform) then return end

    set_scaleform_state(state.counting and SF_STATE_COUNTDOWN or SF_STATE_CHARGE)
    set_scaleform_countdown(countdown or 0)

    begin_scaleform(state.scaleform, "SET_CHARGING_LEVEL")
    Native.call("scaleform_movie_method_add_param_float", charge or 0.0)
    end_scaleform()

    Native.call("set_script_gfx_draw_order", 0)
    HudDraw.draw_scaleform_fullscreen(state.scaleform, WHITE_FULL)
end

local function add_instructional_slot(slot, control, label)
    begin_scaleform(state.instructional_scaleform, "SET_DATA_SLOT")
    Native.call("scaleform_movie_method_add_param_int", slot)
    Native.call("scaleform_movie_method_add_param_player_name_string", Native.call("get_control_instructional_buttons_string", FRONTEND_CONTROL, control, true) or "")
    if Native.call("does_text_label_exist", label) then
        Native.call("begin_text_command_scaleform_string", label)
        Native.call("end_text_command_scaleform_string")
    else
        Native.call("scaleform_movie_method_add_param_texture_name_string", label)
    end
    Native.call("scaleform_movie_method_add_param_bool", false)
    Native.call("scaleform_movie_method_add_param_int", control)
    end_scaleform()
end

local function draw_instructional_buttons()
    if state.instructional_scaleform == 0 then
        state.instructional_scaleform = Native.call("request_scaleform_movie", "instructional_buttons")
        state.instr_built_kbm = nil
        return
    end
    if not scaleform_ready(state.instructional_scaleform) then return end

    local kbm = Input.using_keyboard_and_mouse()
    if state.instr_built_kbm ~= kbm then
        begin_scaleform(state.instructional_scaleform, "CLEAR_ALL")
        end_scaleform()

        begin_scaleform(state.instructional_scaleform, "TOGGLE_MOUSE_BUTTONS")
        Native.call("scaleform_movie_method_add_param_bool", true)
        end_scaleform()

        local slot = 0
        add_instructional_slot(slot, INPUT_FRONTEND_CANCEL, "HUD_INPUT3")
        slot = slot + 1

        if kbm then
            add_instructional_slot(slot, INPUT_CURSOR_SCROLL_DOWN, "ORB_CAN_ZOOMO")
            slot = slot + 1
            add_instructional_slot(slot, INPUT_CURSOR_SCROLL_UP, "ORB_CAN_ZOOMI")
            slot = slot + 1
        else
            add_instructional_slot(slot, INPUT_SCRIPT_RIGHT_AXIS_Y, "ORB_CAN_ZOOM")
            slot = slot + 1
        end

        add_instructional_slot(slot, INPUT_ATTACK, "ORB_CAN_FIRE")

        if state.mode == MODE_AUTO then
            slot = slot + 1
            add_instructional_slot(slot, INPUT_SCRIPT_LEFT_AXIS_X, _T("Switch Target"))
        end

        begin_scaleform(state.instructional_scaleform, "SET_BACKGROUND_COLOUR")
        Native.call("scaleform_movie_method_add_param_int", 0)
        Native.call("scaleform_movie_method_add_param_int", 0)
        Native.call("scaleform_movie_method_add_param_int", 0)
        Native.call("scaleform_movie_method_add_param_int", 80)
        end_scaleform()

        state.instr_built_kbm = kbm
    end

    begin_scaleform(state.instructional_scaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
    end_scaleform()

    HudDraw.draw_scaleform_fullscreen(state.instructional_scaleform, WHITE_DIM)
end

local function cleanup()
    stop_all_sounds()
    Native.call("stop_audio_scene", "dlc_xm_orbital_cannon_camera_active_scene")
    Native.call("release_named_script_audio_bank", AUDIO_BANK)
    if Native.call("animpostfx_is_running", "MP_OrbitalCannon") then
        Native.call("animpostfx_stop", "MP_OrbitalCannon")
    end
    Native.call("clear_focus")
    Native.call("network_set_in_free_cam_mode", false)
    Native.call("clear_override_weather")
    Native.call("clear_timecycle_modifier")
    Native.call("cascade_shadows_set_aircraft_mode", false)
    Native.call("display_radar", true)
    destroy_camera()
    state.scaleform = release_scaleform(state.scaleform)
    state.instructional_scaleform = release_scaleform(state.instructional_scaleform)
    state.instr_built_kbm = nil
    keep_player_collision_loaded()
    unfreeze_player()
    disable_orbital_kills()
    state.cam_pos = nil
    state.target = nil
    state.target_position = nil
    state.target_name = nil
    state.preferred_id = nil
    state.counting = false
    state.did_fire = false
    state.ready_cue_played = false
    state.zoom_stop_at = 0
    state.exit_started_at = 0
    state.zoom_level = 1
    state.status = STATE.inactive
end


local target_pos_buf = { x = 0.0, y = 0.0, z = 0.0 }

local function hold_position(coords)
    target_pos_buf.x = coords.x
    target_pos_buf.y = coords.y
    target_pos_buf.z = coords.z
    state.target_position = target_pos_buf
    return target_pos_buf
end

local function snapshot_entry(list, id)
    for i = 1, #list do
        if list[i].id == id then return list[i] end
    end
    return nil
end

local cand_pool = {}
local cand_count = 0

local function by_cand_dist(a, b)
    return a.d < b.d
end

local function collect_candidates(list, origin, me_id)
    cand_count = 0
    for i = 1, #list do
        local entry = list[i]
        if entry.exists and entry.detailed and entry.id ~= me_id then
            cand_count = cand_count + 1
            local slot = cand_pool[cand_count]
            if not slot then
                slot = {}
                cand_pool[cand_count] = slot
            end
            local c = entry.coords
            local dx, dy, dz = c.x - origin.x, c.y - origin.y, c.z - origin.z
            slot.id = entry.id
            slot.d = dx * dx + dy * dy + dz * dz
            slot.name = entry.name
            slot.x, slot.y, slot.z = c.x, c.y, c.z
        end
    end
    for i = cand_count + 1, #cand_pool do cand_pool[i].d = math.huge end
    if cand_count > 1 then table.sort(cand_pool, by_cand_dist) end
    return cand_count
end

local function set_target_slot(slot)
    state.target = { id = slot.id }
    state.target_name = slot.name
    target_pos_buf.x, target_pos_buf.y, target_pos_buf.z = slot.x, slot.y, slot.z
    state.target_position = target_pos_buf
end

local function clear_target()
    state.target = nil
    state.target_position = nil
    state.target_name = nil
end

local function update_target()
    if state.mode ~= MODE_AUTO then
        clear_target()
        return nil
    end

    local origin = my_pos()
    if not origin then return state.target_position end
    local list = Players.session_snapshot(origin, TARGET_SCAN_DISTANCE)

    local held = state.target
    if held then
        local entry = snapshot_entry(list, held.id)
        if entry and entry.exists and entry.detailed then
            state.target_name = entry.name
            return hold_position(entry.coords)
        end
        clear_target()
    end

    if collect_candidates(list, origin, Players.local_id()) == 0 then return nil end
    local pick = cand_pool[1]
    local preferred = state.preferred_id
    if preferred and preferred ~= pick.id then
        for i = 2, cand_count do
            if cand_pool[i].id == preferred then
                pick = cand_pool[i]
                break
            end
        end
    end
    set_target_slot(pick)
    return state.target_position
end

local function cycle_target(step)
    local origin = my_pos()
    if not origin then return end
    local list = Players.session_snapshot(origin, TARGET_SCAN_DISTANCE)
    local n = collect_candidates(list, origin, Players.local_id())
    if n == 0 then return end

    local index = 0
    local held = state.target
    if held then
        for i = 1, n do
            if cand_pool[i].id == held.id then
                index = i
                break
            end
        end
    end
    index = index + step
    if index < 1 then
        index = n
    elseif index > n then
        index = 1
    end
    set_target_slot(cand_pool[index])
    state.preferred_id = cand_pool[index].id
    play_cue("menu_select")
end

local CYCLE_PUSH <const> = 0.5
local CYCLE_REARM <const> = 0.2

local function update_target_cycle()
    if state.mode ~= MODE_AUTO or state.did_fire then return end
    local axis = Input.disabled_normal(FRONTEND_CONTROL, INPUT_SCRIPT_LEFT_AXIS_X)
    if state.can_cycle then
        if axis > CYCLE_PUSH then
            cycle_target(1)
            state.can_cycle = false
        elseif axis < -CYCLE_PUSH then
            cycle_target(-1)
            state.can_cycle = false
        end
    elseif math.abs(axis) <= CYCLE_REARM then
        state.can_cycle = true
    end
end

function CannonRuntime.lockable_players()
    local origin = my_pos()
    if not origin then return cand_pool, 0 end
    local list = Players.session_snapshot(origin, TARGET_SCAN_DISTANCE)
    return cand_pool, collect_candidates(list, origin, Players.local_id())
end

function CannonRuntime.set_target_player(id)
    state.preferred_id = id
    if state.status == STATE.inactive or state.mode ~= MODE_AUTO then return true end
    if not id then
        clear_target()
        return true
    end
    local origin = my_pos()
    if not origin then return false end
    local list = Players.session_snapshot(origin, TARGET_SCAN_DISTANCE)
    local entry = snapshot_entry(list, id)
    if id == Players.local_id() or not (entry and entry.exists and entry.detailed) then
        return false
    end
    state.target = { id = id }
    state.target_name = entry.name
    hold_position(entry.coords)
    play_cue("menu_select")
    return true
end

local function initial_camera_position()
    local target_pos = update_target()
    if target_pos then
        local z = get_z_pos(target_pos)
        if target_pos.z > z - 100.0 then z = target_pos.z + 100.0 end
        return { x = target_pos.x, y = target_pos.y, z = z }
    end
    local pos = my_pos() or { x = 0.0, y = 0.0, z = 0.0 }
    return { x = pos.x, y = pos.y, z = get_z_pos(pos) }
end

local function create_camera()
    state.cam_pos = initial_camera_position()
    state.cam = Native.call("create_cam", "DEFAULT_SCRIPTED_CAMERA", false)
    Native.call("set_cam_coord", state.cam, state.cam_pos.x, state.cam_pos.y, state.cam_pos.z)
    Native.call("set_cam_rot", state.cam, -90.0, 0.0, 0.0, 2)
    Native.call("set_cam_fov", state.cam, FOV_LEVELS[state.zoom_level])
    Native.call("set_cam_active", state.cam, true)
    Native.call("render_script_cams", true, false, 0, true, true, 0)
end

local function begin_session()
    keep_player_collision_loaded()
    freeze_player()
    Native.call("request_script_audio_bank", AUDIO_BANK, false, -1)
    Native.call("start_audio_scene", "dlc_xm_orbital_cannon_camera_active_scene")
    Native.call("set_override_weather", "Clear")
    Native.call("clear_timecycle_modifier")
    Native.call("cascade_shadows_set_aircraft_mode", true)
    Native.call("display_radar", false)
    Native.call("animpostfx_play", "MP_OrbitalCannon", 0, true)
    create_camera()
    state.scaleform = Native.call("request_scaleform_movie", "ORBITAL_CANNON_CAM")
    state.instructional_scaleform = Native.call("request_scaleform_movie", "instructional_buttons")
    set_scaleform_zoom()
    Native.call("network_set_in_free_cam_mode", true)
    play_cue("menu_select")
    start_sound("sound_background", "background_loop")
    if state.mode == MODE_AUTO then start_sound("sound_charge", "cannon_activating_loop") end
    enable_orbital_kills()
    state.session_ped = my_ped() or 0
    set_state(STATE.active)
    state.charge_started_at = state.started_at
end

local function pump_zoom_sound()
    if state.zoom_stop_at ~= 0 and now() >= state.zoom_stop_at then
        stop_sound("sound_zoom")
        state.zoom_stop_at = 0
    end
end

local function update_zoom()
    local changed = false
    if Input.using_keyboard_and_mouse() then
        if Input.disabled_just_pressed(FRONTEND_CONTROL, INPUT_CURSOR_SCROLL_UP) and state.zoom_level < #FOV_LEVELS then
            state.zoom_level = state.zoom_level + 1
            changed = true
        elseif Input.disabled_just_pressed(FRONTEND_CONTROL, INPUT_CURSOR_SCROLL_DOWN) and state.zoom_level > 1 then
            state.zoom_level = state.zoom_level - 1
            changed = true
        end
    else
        local zoom_axis = Input.disabled_normal(FRONTEND_CONTROL, INPUT_SCRIPT_RIGHT_AXIS_Y)
        if state.can_zoom and zoom_axis > 0.3 and state.zoom_level < #FOV_LEVELS then
            state.zoom_level = state.zoom_level + 1
            state.can_zoom = false
            changed = true
        elseif state.can_zoom and zoom_axis < -0.3 and state.zoom_level > 1 then
            state.zoom_level = state.zoom_level - 1
            state.can_zoom = false
            changed = true
        elseif math.abs(zoom_axis) <= 0.1 then
            state.can_zoom = true
        end
    end
    if not changed then return end
    Native.call("set_cam_fov", state.cam, FOV_LEVELS[state.zoom_level])
    set_scaleform_zoom()
    start_sound("sound_zoom", "zoom_out_loop")
    state.zoom_stop_at = now() + ZOOM_SOUND_MS
end

local function update_camera()
    if state.cam == 0 or not state.cam_pos then return end

    local dt = math.max(Runtime.delta_time() or 0.016, 0.001)
    local step = (state.status == STATE.firing and 50.0 or (35.0 + MOVE_SPEED[state.zoom_level])) * dt
    local target_pos = update_target()

    if target_pos and not state.did_fire then
        local z = get_z_pos(target_pos)
        if target_pos.z > z - 100.0 then z = target_pos.z + 100.0 end
        state.cam_pos.x = target_pos.x
        state.cam_pos.y = target_pos.y
        state.cam_pos.z = z
    elseif not state.menu_open then
        local axis_x = Input.disabled_normal(FRONTEND_CONTROL, INPUT_SCRIPT_LEFT_AXIS_X)
        local axis_y = Input.disabled_normal(FRONTEND_CONTROL, INPUT_SCRIPT_LEFT_AXIS_Y)
        if math.abs(axis_x) > 0.1 then
            state.cam_pos.x = clamp(state.cam_pos.x + axis_x * step, MIN_X, MAX_X)
        end
        if math.abs(axis_y) > 0.1 then
            state.cam_pos.y = clamp(state.cam_pos.y - axis_y * step, MIN_Y, MAX_Y)
        end
        state.cam_pos.z = get_z_pos(state.cam_pos)
    end

    Native.call("set_cam_coord", state.cam, state.cam_pos.x, state.cam_pos.y, state.cam_pos.z)
    Native.call("set_cam_rot", state.cam, -90.0, 0.0, 0.0, 2)
    Native.call("request_collision_at_coord", state.cam_pos.x, state.cam_pos.y, state.cam_pos.z)
    Native.call("set_game_pauses_for_streaming", false)
    Native.call("set_focus_pos_and_vel", state.cam_pos.x, state.cam_pos.y, state.cam_pos.z + 50.0, 0.0, 0.0, 0.0)
end

local function charge_progress()
    if state.mode == MODE_FREE then return 1.0 end
    return math.min(1.0, (now() - state.charge_started_at) / CHARGE_MS)
end

local function draw_hud()
    local progress = charge_progress()
    if progress >= 1.0 and not state.ready_cue_played then
        stop_sound("sound_charge")
        play_cue("cannon_active")
        state.ready_cue_played = true
    end

    local countdown = nil
    if state.counting then
        countdown = math.max(0, 3 - math.floor((now() - state.fire_started_at) / 1000))
    end

    draw_orbital_scaleform(progress, countdown)

    if state.mode == MODE_AUTO and state.target and state.target_name then
        local res = Runtime.resolution()
        HudDraw.overlay_text(_T("Target") .. ": " .. tostring(state.target_name),
            res.x * 0.5, res.y * 0.86, 22, WHITE_DIM, "center")
    end

    draw_instructional_buttons()
end

local function fire_target_position()
    if state.target_position then return copy_vec3(state.target_position) end
    return ground_target(state.cam_pos)
end

local function fire_once()
    if state.did_fire then return end
    local ok, err = Explosion.fire(fire_target_position())
    if not ok then log_error("fire failed", { error = err }) end
    if state.cam ~= 0 then Native.call("shake_cam", state.cam, "GAMEPLAY_EXPLOSION_SHAKE", 1.5) end
    state.did_fire = true
    state.fired_at = now()
    set_state(STATE.firing)
end

local function update_fire()
    if state.did_fire then return end
    if charge_progress() < 1.0 then return end

    local pressed = Input.disabled_pressed(PLAYER_CONTROL, INPUT_ATTACK) or Input.disabled_pressed(PLAYER_CONTROL, INPUT_VEH_ATTACK)
    if pressed and not state.counting then
        state.counting = true
        state.fire_started_at = now()
        Native.call("set_control_shake", PLAYER_CONTROL, 1000, 50)
        return
    end

    if not pressed and state.counting then
        state.counting = false
        stop_sound("sound_fire")
        return
    end

    if state.counting then
        local held_ms = now() - state.fire_started_at
        if held_ms >= FIRE_SOUND_ARM_MS then
            start_sound("sound_fire", "cannon_charge_fire_loop")
        end
        if held_ms >= FIRE_MS then
            state.counting = false
            stop_sound("sound_fire")
            fire_once()
        end
    end
end

local function begin_exit()
    if state.status == STATE.exiting or state.status == STATE.inactive then return end
    state.exit_started_at = now()
    local pos = my_pos()
    if pos then
        Native.call("clear_focus")
        Native.call("set_focus_pos_and_vel", pos.x, pos.y, pos.z, 0.0, 0.0, 0.0)
        Native.call("request_collision_at_coord", pos.x, pos.y, pos.z)
    end
    set_state(STATE.exiting)
end

local function tick()
    if state.status == STATE.inactive then
        remove_thread()
        return
    end

    if state.status == STATE.starting then
        begin_session()
        return
    end

    disable_controls()
    keep_player_collision_loaded()

    if state.status == STATE.exiting then
        if player_collision_ready() or now() - state.exit_started_at >= EXIT_MAX_MS then
            CannonRuntime.stop()
        end
        return
    end

    local ped = my_ped()
    if ped == 0 or ped ~= state.session_ped or not Players.local_alive() then
        begin_exit()
        return
    end

    pump_zoom_sound()

    if not state.menu_open then
        if Input.disabled_just_pressed(PLAYER_CONTROL, INPUT_FRONTEND_CANCEL) then
            begin_exit()
            return
        end
        update_zoom()
        update_target_cycle()
        update_fire()
    elseif state.counting then
        state.counting = false
        stop_sound("sound_fire")
    end

    update_camera()
    draw_hud()

    if state.status == STATE.firing and now() - state.fired_at >= STOP_AFTER_FIRE_MS then
        begin_exit()
    end
end

function CannonRuntime.init(ctx)
    logger = ctx and ctx.logger or logger
    lang = ctx and ctx.lang or lang
end

function CannonRuntime.start(mode)
    if state.status ~= STATE.inactive then return false, "already_running" end
    state.mode = mode == "target_lock_on" and MODE_AUTO or MODE_FREE
    state.zoom_level = 1
    state.target = nil
    state.target_position = nil
    state.target_name = nil
    state.counting = false
    state.did_fire = false
    state.ready_cue_played = false
    state.can_zoom = true
    state.can_cycle = true
    state.frozen_entity = 0
    state.session_ped = 0
    state.exit_started_at = 0
    state.zoom_stop_at = 0
    state.sound_background = -1
    state.sound_charge = -1
    state.sound_fire = -1
    state.sound_zoom = -1
    state.fire_started_at = 0
    state.fired_at = 0
    state.charge_started_at = 0
    set_state(STATE.starting)
    thread_id = Runtime.create_thread(tick)
    return true
end

function CannonRuntime.request_stop()
    if state.status == STATE.inactive then return false, "not_running" end
    begin_exit()
    return true
end

function CannonRuntime.stop()
    if state.status == STATE.inactive and not thread_id then return false, "not_running" end
    remove_thread()
    cleanup()
    return true
end

function CannonRuntime.on_menu_open()
    state.menu_open = true
end

function CannonRuntime.on_menu_close()
    state.menu_open = false
end

function CannonRuntime.on_shutdown()
    CannonRuntime.stop()
end

function CannonRuntime.is_running()
    return state.status ~= STATE.inactive
end

function CannonRuntime.snapshot()
    return {
        running = CannonRuntime.is_running(),
        status = state.status,
        mode = state.mode,
        zoom_level = state.zoom_level,
        target_player_id = state.target and state.target.id or nil,
        preferred_player_id = state.preferred_id,
        counting = state.counting,
        did_fire = state.did_fire,
    }
end

return CannonRuntime
