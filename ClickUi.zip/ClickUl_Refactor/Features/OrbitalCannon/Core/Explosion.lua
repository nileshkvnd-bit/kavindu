local Explosion = {}

local Native = require("ClickUl_Refactor.Adapters.Native")
local Request = require("ClickUl_Refactor.Adapters.Request")
local Players = require("ClickUl_Refactor.Adapters.Players")
local ScriptThreadSpoof = require("ClickUl_Refactor.Core.ScriptThreadSpoof")
local Util = require("ClickUl_Refactor.Core.Util")

local EXP_TAG_ORBITAL_CANNON <const> = 59
local PTFX_ASSET <const> = "scr_xm_orbital"
local PTFX_EFFECT <const> = "scr_xm_orbital_blast"
local AUDIO_REF <const> = 0
local AUDIO_NAME <const> = "DLC_XM_Explosions_Orbital_Cannon"

local function play_fx(position)
    Request.particle(PTFX_ASSET)
    Native.call("use_particle_fx_asset", PTFX_ASSET)
    Native.call(
        "start_networked_particle_fx_non_looped_at_coord",
        PTFX_EFFECT,
        position.x,
        position.y,
        position.z,
        0.0,
        0.0,
        0.0,
        1.0,
        false,
        false,
        false,
        true
    )
end

function Explosion.fire(position)
    position = Util.required_vector3(position)
    if not position then return false, "invalid_position" end

    local owner = Players.local_ped()
    local ok, err = pcall(ScriptThreadSpoof.with_orbital_thread_hash, function()
        Native.add_owned_explosion(
            owner,
            position,
            EXP_TAG_ORBITAL_CANNON,
            1.0,
            true,
            false,
            1.0
        )
    end)
    if not ok then return false, tostring(err) end

    play_fx(position)
    Native.call("play_sound_from_coord", -1, AUDIO_NAME, position.x, position.y, position.z, AUDIO_REF, true, 0, false)
    return true
end

return Explosion
