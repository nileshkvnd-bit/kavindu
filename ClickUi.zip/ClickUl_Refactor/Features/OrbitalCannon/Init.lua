local GeneralPage = require("ClickUl_Refactor.Features.OrbitalCannon.GeneralPage")
local CannonRuntime = require("ClickUl_Refactor.Features.OrbitalCannon.Core.CannonRuntime")

local OrbitalCannon = {}

function OrbitalCannon.init(ctx)
    local ui = assert(ctx.ui, "[OrbitalCannon] ui is required")
    local lang = assert(ctx.lang, "[OrbitalCannon] lang is required")
    local logger = assert(ctx.logger, "[OrbitalCannon] logger is required")

    CannonRuntime.init({ logger = logger, lang = lang })
    GeneralPage.init({ ui = ui, lang = lang })

    logger.info("Features.OrbitalCannon", "OrbitalCannon module initialized")
    return true
end

function OrbitalCannon.draw()
    GeneralPage.draw()
end

function OrbitalCannon.on_menu_open()
    CannonRuntime.on_menu_open()
end

function OrbitalCannon.on_menu_close()
    CannonRuntime.on_menu_close()
end

function OrbitalCannon.on_shutdown()
    CannonRuntime.on_shutdown()
end

return OrbitalCannon
