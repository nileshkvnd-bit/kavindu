local Events = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local events_api <const> = contract.table(events, "events")
local events_event <const> = contract.table(events_api.event, "events.event")
local events_subscribe <const> = contract.func(events_api.subscribe, "events.subscribe")
local events_unsubscribe <const> = contract.func(events_api.unsubscribe, "events.unsubscribe")

Events.event = {
    scroll = contract.value(events_event.scroll, "events.event.scroll"),
    key_press = contract.value(events_event.key_press, "events.event.key_press"),
    char_press = contract.value(events_event.char_press, "events.event.char_press"),
}

function Events.subscribe(event_type, callback)
    return events_subscribe(event_type, callback)
end

function Events.unsubscribe(id)
    return events_unsubscribe(id)
end

return Events
