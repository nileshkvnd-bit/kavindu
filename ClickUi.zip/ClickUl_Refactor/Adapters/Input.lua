local Input = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")
local Native = require("ClickUl_Refactor.Adapters.Native")


local PLAYER_CONTROL_GROUP <const> = 0
local BLOCKED_CONTROLS <const> = {
    1, 2,
    24, 257,
    140, 141,
    69, 70, 92,
    114, 331,
    14, 15,
    16, 17, 37,
    99, 100,
    81, 82, 83, 84, 85,
    332, 333,
}

local input_api <const> = contract.table(input, "input")
local input_show_cursor <const> = contract.func(input_api.show_cursor, "input.show_cursor")
local input_disable_input <const> = contract.func(input_api.disable_input, "input.disable_input")
local input_key <const> = contract.func(input_api.key, "input.key")
local input_mouse <const> = contract.func(input_api.mouse, "input.mouse")
local input_mouse_position <const> = contract.func(input_api.mouse_position, "input.mouse_position")
local input_is_mouse_within <const> = contract.func(input_api.is_mouse_within, "input.is_mouse_within")
local input_set_clipboard_text <const> = contract.func(input_api.set_clipboard_text, "input.set_clipboard_text")
local input_get_clipboard_text <const> = contract.func(input_api.get_clipboard_text, "input.get_clipboard_text")

function Input.show_cursor(show)
    return input_show_cursor(show)
end

function Input.disable_input(disable)
    local result = input_disable_input(disable)
    if disable then
        for i = 1, #BLOCKED_CONTROLS do
            Input.disable_control(PLAYER_CONTROL_GROUP, BLOCKED_CONTROLS[i], true)
        end
    end
    return result
end

function Input.disable_control(input_group, control, disabled)
    return Native.call("disable_control_action", input_group, control, disabled and true or false)
end

function Input.disabled_pressed(input_group, control)
    return Native.call("is_disabled_control_pressed", input_group, control) and true or false
end

function Input.disabled_just_pressed(input_group, control)
    return Native.call("is_disabled_control_just_pressed", input_group, control) and true or false
end

function Input.disabled_normal(input_group, control)
    return Native.call("get_disabled_control_normal", input_group, control) or 0.0
end

function Input.unbound_normal(input_group, control)
    return Native.call("get_control_unbound_normal", input_group, control) or 0.0
end

function Input.using_keyboard_and_mouse()
    return Native.call("is_using_keyboard_and_mouse") and true or false
end

function Input.key(vk)
    return input_key(vk)
end

function Input.mouse(vk)
    return input_mouse(vk)
end

function Input.mouse_position()
    return input_mouse_position()
end

function Input.is_mouse_within(position, scale)
    return input_is_mouse_within(position, scale)
end

function Input.set_clipboard_text(text)
    return input_set_clipboard_text(text)
end

function Input.get_clipboard_text()
    return input_get_clipboard_text()
end

return Input
