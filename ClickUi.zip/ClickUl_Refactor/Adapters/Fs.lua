local Fs = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")
local Json = require("ClickUl_Refactor.Adapters.Json")

local paths_api <const> = contract.table(paths, "paths")
local dirs_api <const> = contract.table(dirs, "dirs")
local file_api <const> = contract.table(file, "file")

local paths_script <const> = contract.value(paths_api.script, "paths.script")
local dirs_create <const> = contract.func(dirs_api.create, "dirs.create")
local dirs_exists <const> = contract.func(dirs_api.exists, "dirs.exists")
local dirs_list <const> = contract.func(dirs_api.list, "dirs.list")
local dirs_scan <const> = contract.func(dirs_api.scan, "dirs.scan")
local file_exists <const> = contract.func(file_api.exists, "file.exists")
local file_open <const> = contract.func(file_api.open, "file.open")
local file_remove <const> = contract.func(file_api.remove, "file.remove")

local ROOT_NAME <const> = "ClickUl_Refactor\\"

local function ensure_slash(path)
    path = tostring(path)
    if not path:match("[\\/]$") then path = path .. "\\" end
    return path
end

function Fs.script_dir()
    return ensure_slash(paths_script)
end

function Fs.root_dir()
    return Fs.script_dir() .. ROOT_NAME
end

function Fs.join(...)
    local parts = { ... }
    local result = tostring(parts[1] or "")
    for i = 2, #parts do
        local part = tostring(parts[i] or "")
        if result ~= "" and not result:match("[\\/]$") then result = result .. "\\" end
        result = result .. part:gsub("^[\\/]+", "")
    end
    return result
end

function Fs.ensure_dir(path)
    path = tostring(path or ""):gsub("/", "\\")
    local current = ""
    for segment in path:gmatch("[^\\]+") do
        current = current == "" and segment or (current .. "\\" .. segment)
        if not current:match("^%a:$") and not dirs_exists(current) then
            dirs_create(current)
        end
    end
    return true
end

function Fs.exists(path)
    return file_exists(path) or dirs_exists(path)
end

function Fs.remove(path)
    if not file_exists(path) then return false end
    return file_remove(path) and true or false
end

function Fs.read_text(path)
    if not file_exists(path) then return nil, "missing_file" end
    local handle = file_open(path, { create_if_not_exists = false, append = false })
    if handle and handle.valid then return handle.text end
    return nil, "open_failed"
end

function Fs.write_text(path, text)
    local handle = file_open(path, { create_if_not_exists = true, append = false })
    if handle and handle.valid then
        handle.text = tostring(text or "")
        return true
    end
    return false
end

function Fs.append_text(path, text)
    local handle = file_open(path, { create_if_not_exists = true, append = true })
    if handle and handle.valid then
        handle.text = tostring(text or "")
        return true
    end
    return false
end

function Fs.read_json_value(path)
    if not file_exists(path) then return nil, "missing_file" end
    local handle = file_open(path, { create_if_not_exists = false, append = false })
    if not handle or not handle.valid then return nil, "open_failed" end
    local text = handle.text
    if type(text) ~= "string" then return nil, "open_failed" end
    local value, err = Json.decode(text)
    if value == nil then return nil, err or "decode_failed" end
    return value
end

local function normalize_extension(extension)
    if extension == nil or extension == "" then return extension end
    extension = tostring(extension)
    if extension:sub(1, 1) == "." then return extension end
    return "." .. extension
end

function Fs.list(path, extension)
    return dirs_list(path, normalize_extension(extension))
end

function Fs.scan(path)
    return dirs_scan(path)
end

function Fs.config_dir() return Fs.join(Fs.root_dir(), "Config\\") end
function Fs.themes_dir() return Fs.join(Fs.root_dir(), "Themes\\") end
function Fs.images_dir() return Fs.join(Fs.root_dir(), "Images\\") end
function Fs.fonts_dir() return Fs.join(Fs.root_dir(), "Fonts\\") end
function Fs.languages_dir() return Fs.join(Fs.root_dir(), "languages\\") end
function Fs.logs_dir() return Fs.join(Fs.root_dir(), "logs\\") end

return Fs
