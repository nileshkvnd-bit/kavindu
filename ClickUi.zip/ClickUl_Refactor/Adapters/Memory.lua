local Memory = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local memory_api <const> = contract.table(memory, "memory")
local memory_base <const> = contract.func(memory_api.base, "memory.base")
local memory_scan <const> = contract.func(memory_api.scan, "memory.scan")

function Memory.base()
    return memory_base()
end

function Memory.scan(signature, module)
    return memory_scan(signature, module)
end

function Memory.add(address, offset)
    return address:add(offset)
end

function Memory.rip(address, op_size, insn_size)
    return address:rip(op_size, insn_size)
end

function Memory.ptr(address)
    return address.as_ptr
end

function Memory.value(address)
    return address and address.value or nil
end

function Memory.float(address)
    if not address then return nil end
    return address.float
end

function Memory.uint32(address)
    return address.uint32
end

function Memory.uint16(address)
    return address.uint16
end

function Memory.set_uint32(address, value)
    address.uint32 = value
end

function Memory.uint64(address)
    return address.uint64
end

function Memory.set_uint64(address, value)
    address.uint64 = value
end

return Memory
