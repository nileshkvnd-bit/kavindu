local menu_adapter = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local menu_api <const> = contract.table(menu, "menu")
local menu_find <const> = contract.func(menu_api.find, "menu.find")

function menu_adapter.find(path)
    return menu_find(path)
end

function menu_adapter.get_value(opt)
    return opt.value
end

function menu_adapter.set_value(opt, value)
    opt.value = value
end

function menu_adapter.get_toggle(opt)
    return opt.toggle
end

function menu_adapter.set_toggle(opt, value)
    opt.toggle = value
end

function menu_adapter.invoke(opt)
    return opt:invoke()
end

return menu_adapter
