local Gui = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")
local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")

local gui_api <const> = contract.table(gui, "gui")
local vec2_ctor <const> = contract.func(vec2, "vec2")
local color_ctor <const> = contract.func(color, "color")

Gui.justify = contract.table(gui_api.justify, "gui.justify")
Gui.rounding = contract.table(gui_api.rounding, "gui.rounding")

local gui_push_clip <const> = contract.func(gui_api.push_clip, "gui.push_clip")
local gui_pop_clip <const> = contract.func(gui_api.pop_clip, "gui.pop_clip")
local gui_line <const> = contract.func(gui_api.line, "gui.line")
local gui_circle <const> = contract.func(gui_api.circle, "gui.circle")
local gui_image <const> = contract.func(gui_api.image, "gui.image")
local gui_image_rounded <const> = contract.func(gui_api.image_rounded, "gui.image_rounded")
local gui_rebuild <const> = contract.func(gui_api.rebuild, "gui.rebuild")
local gui_load_image <const> = contract.func(gui_api.load_image, "gui.load_image")
local gui_load_font <const> = contract.func(gui_api.load_font, "gui.load_font")
local gui_text_size <const> = contract.func(gui_api.text_size, "gui.text_size")
local gui_text <const> = contract.func(gui_api.text, "gui.text")
local gui_rect <const> = contract.func(gui_api.rect, "gui.rect")

local vec2_cache = {}
local color_cache = {}
local vec2_order = {}
local color_order = {}
local VEC2_LIMIT <const> = 4096
local COLOR_LIMIT <const> = 2048

local math_floor <const> = math.floor

local function clamp_byte(v)
    v = math_floor(v or 0)
    if v < 0 then return 0 end
    if v > 255 then return 255 end
    return v
end

local function color_hash(r, g, b, a)
    return r + (g * 256) + (b * 65536) + (a * 16777216)
end

local function remove_vec2_entry(cache, entry)
    local bucket = cache[entry[1]]
    if bucket then bucket[entry[2]] = nil end
end

function Gui.vec2(x, y)
    x = math_floor((x or 0) + 0.5)
    y = math_floor((y or 0) + 0.5)
    local bucket = vec2_cache[x]
    if bucket then
        local cached = bucket[y]
        if cached then return cached end
    else
        bucket = {}
        vec2_cache[x] = bucket
    end

    local value = vec2_ctor(x, y)
    bucket[y] = value
    vec2_order[#vec2_order + 1] = { x, y }
    CacheUtils.evict_ordered(vec2_cache, vec2_order, VEC2_LIMIT, 0.25, remove_vec2_entry)
    return value
end

function Gui.vec2_raw(x, y)
    return vec2_ctor(math.floor((x or 0) + 0.5), math.floor((y or 0) + 0.5))
end

function Gui.color(r, g, b, a)
    r = clamp_byte(r == nil and 255 or r)
    g = clamp_byte(g == nil and 255 or g)
    b = clamp_byte(b == nil and 255 or b)
    a = clamp_byte(a == nil and 255 or a)
    local key = color_hash(r, g, b, a)
    local cached = color_cache[key]
    if cached then return cached end

    local value = color_ctor(r, g, b, a)
    color_cache[key] = value
    color_order[#color_order + 1] = key
    CacheUtils.evict_ordered(color_cache, color_order, COLOR_LIMIT, 0.25)
    return value
end

function Gui.push_clip(pos, scale) return gui_push_clip(pos, scale) end
function Gui.pop_clip() return gui_pop_clip() end
function Gui.line(from, to, thickness, col) return gui_line(from, to, thickness, col) end
function Gui.circle(pos, radius, col) return gui_circle(pos, radius, col) end
function Gui.image(texture, pos, scale, col) return gui_image(texture, pos, scale, col) end
function Gui.image_rounded(texture, pos, scale, col, rounding, flags) return gui_image_rounded(texture, pos, scale, col, rounding, flags) end
function Gui.rebuild() return gui_rebuild() end
function Gui.load_image(path) return gui_load_image(path) end
function Gui.load_font(path, scale) return gui_load_font(path, scale) end
function Gui.text_size(text, scale, options) return gui_text_size(text, scale, options) end
function Gui.text(str) return gui_text(str) end
function Gui.rect(pos, scale) return gui_rect(pos, scale) end

function Gui.clear_caches()
    vec2_cache = {}
    color_cache = {}
    vec2_order = {}
    color_order = {}
end

return Gui
