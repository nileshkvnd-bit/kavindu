local Players = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")
local Util = require("ClickUl_Refactor.Core.Util")

local players_api <const> = contract.table(players, "players")
local players_me <const> = contract.func(players_api.me, "players.me")
local players_list <const> = contract.func(players_api.list, "players.list")

local function local_player()
    return contract.value(players_me(), "players.me()")
end

local function field(player, name)
    local value = player[name]
    if value ~= nil then return value end
    return contract.value(nil, "players.me()." .. name)
end

local function active_ped_context()
    local me = local_player()
    local exists = field(me, "exists")
    local ped = field(me, "ped")
    if not exists or ped == 0 then return nil, nil end
    return me, ped
end

function Players.local_id()
    return field(local_player(), "id")
end

function Players.local_ped()
    return field(local_player(), "ped")
end

function Players.local_coords()
    local me = active_ped_context()
    if not me then return nil end
    local coords = Util.required_vector3(field(me, "coords"))
    return contract.value(coords, "players.me().coords vector")
end

function Players.local_alive()
    local me = local_player()
    if not field(me, "exists") then return false end
    return me.alive and true or false
end

function Players.local_heading()
    local me = active_ped_context()
    if not me then return nil end
    return field(me, "heading")
end

function Players.local_vehicle()
    local me = local_player()
    if not field(me, "in_vehicle") then return 0 end
    return field(me, "vehicle")
end

function Players.local_driver_vehicle()
    local me = local_player()
    if not field(me, "in_vehicle") then return 0 end
    if not me.driver then return 0 end
    return field(me, "vehicle")
end

local function player_to_snapshot(p)
    return {
        id = p.id,
        name = p.name or "",
        ped = p.ped,
        exists = p.exists and true or false,
        alive = p.alive and true or false,
        in_vehicle = p.in_vehicle and true or false,
        in_interior = p.in_interior and true or false,
        vehicle = p.vehicle or 0,
        model = p.model or 0,
        vehicle_model = p.vehicle_model or 0,
        coords = Util.vector3(p.coords),
        friend = p.friend and true or false,
        in_ceo = p.in_ceo and true or false,
        gang_id = p.gang_id or 0,
    }
end

local slot_proxies = nil
local proxy_by_id = nil

local function ensure_slot_proxies()
    if slot_proxies and #slot_proxies > 0 then return slot_proxies end
    local list = contract.value(players_list(), "players.list()")
    slot_proxies = {}
    proxy_by_id = {}
    for i = 1, #list do
        local p = list[i]
        slot_proxies[i] = p
        proxy_by_id[p.id] = p
    end
    return slot_proxies
end

function Players.seed()
    ensure_slot_proxies()
end

local SNAPSHOT_IDENTITY_MS <const> = 400
local IDENTITY_BUDGET <const> = 3

local snapshot_entries = {}
local snapshot_list = {}

local function fill_snapshot(entry, p, now, may_refresh_identity, detail_coords, detail_dist_sq)
    entry.id = p.id
    if not p.exists then
        entry.exists = false
        entry.ped = 0
        entry.identity_ms = nil
        return false
    end
    entry.exists = true
    entry.ped = p.ped

    local source = p.coords
    local coords = entry.coords
    if source then
        coords.x = source.x or 0.0
        coords.y = source.y or 0.0
        coords.z = source.z or 0.0
    end

    if detail_dist_sq then
        local dx = coords.x - detail_coords.x
        local dy = coords.y - detail_coords.y
        local dz = coords.z - detail_coords.z
        if dx * dx + dy * dy + dz * dz > detail_dist_sq then
            entry.detailed = false
            return false
        end
        entry.in_interior = p.in_interior and true or false
        if entry.in_interior then
            entry.detailed = false
            return false
        end
        entry.alive = p.alive and true or false
        if not entry.alive then
            entry.detailed = false
            return false
        end
    else
        entry.in_interior = p.in_interior and true or false
        entry.alive = p.alive and true or false
    end
    entry.detailed = true

    entry.in_vehicle = p.in_vehicle and true or false
    entry.driver = p.driver and true or false
    entry.vehicle = p.vehicle or 0
    entry.vehicle_model = p.vehicle_model or 0

    local age = entry.identity_ms and (now - entry.identity_ms) or nil
    local due = not age or age >= SNAPSHOT_IDENTITY_MS or age < 0
    if due and (may_refresh_identity or not entry.identity_ms) then
        entry.name = p.name or ""
        entry.model = p.model or 0
        entry.friend = p.friend and true or false
        entry.in_ceo = p.in_ceo and true or false
        entry.gang_id = p.gang_id or 0
        entry.identity_ms = now
        return true
    end
    return false
end

function Players.session_snapshot(detail_coords, detail_dist)
    local proxies = ensure_slot_proxies()
    local now = Runtime.get_tick_count()
    local detail_dist_sq = detail_coords and detail_dist and (detail_dist * detail_dist) or nil

    local count = #proxies
    local identity_budget = IDENTITY_BUDGET
    for i = 1, count do
        local p = proxies[i]
        local entry = snapshot_entries[p.id]
        if not entry then
            entry = { coords = { x = 0.0, y = 0.0, z = 0.0 } }
            snapshot_entries[p.id] = entry
        end
        if fill_snapshot(entry, p, now, identity_budget > 0, detail_coords, detail_dist_sq) then
            identity_budget = identity_budget - 1
        end
        snapshot_list[i] = entry
    end
    for i = count + 1, #snapshot_list do snapshot_list[i] = nil end
    return snapshot_list
end

function Players.player_snapshot(player_id)
    if type(player_id) ~= "number" or player_id < 0 then return nil end
    ensure_slot_proxies()
    local p = proxy_by_id[player_id]
    if not p or not p.exists then return nil end
    return player_to_snapshot(p)
end

function Players.local_org_info()
    local me = local_player()
    return {
        id = field(me, "id"),
        in_ceo = me.in_ceo and true or false,
        gang_id = me.gang_id or 0,
    }
end

function Players.local_teleport_target()
    local me = local_player()
    if field(me, "in_vehicle") then
        local vehicle = field(me, "vehicle")
        if vehicle ~= 0 then return vehicle end
    end
    return field(me, "ped")
end

function Players.local_teleport_target_is_vehicle()
    local me = local_player()
    if not field(me, "in_vehicle") then return false end
    return field(me, "vehicle") ~= 0
end

return Players
