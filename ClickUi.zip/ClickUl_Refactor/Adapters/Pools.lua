local Pools = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local pools_api <const> = contract.table(pools, "pools")
local game_api <const> = contract.table(game, "game")
local pools_ped <const> = contract.func(pools_api.ped, "pools.ped")
local pools_object <const> = contract.func(pools_api.object, "pools.object")
local pools_vehicle <const> = contract.func(pools_api.vehicle, "pools.vehicle")
local guid_from_entity <const> = contract.func(game_api.guid_from_entity, "game.guid_from_entity")

local function handles_from_address_pool(pool_fn, require_valid_guid)
    local result = {}
    local addresses = pool_fn(require_valid_guid)
    for _, address in ipairs(addresses) do
        local handle = guid_from_entity(address)
        if handle and handle ~= 0 then
            result[#result + 1] = handle
        end
    end
    return result
end

function Pools.ped_handles(require_valid_guid)
    return handles_from_address_pool(pools_ped, require_valid_guid)
end

function Pools.object_handles(require_valid_guid)
    return handles_from_address_pool(pools_object, require_valid_guid)
end

function Pools.vehicle_handles(require_valid_guid)
    return handles_from_address_pool(pools_vehicle, require_valid_guid)
end

function Pools.entity_handles(require_valid_guid)
    local result = Pools.ped_handles(require_valid_guid)
    for _, handle in ipairs(Pools.vehicle_handles(require_valid_guid)) do
        result[#result + 1] = handle
    end
    for _, handle in ipairs(Pools.object_handles(require_valid_guid)) do
        result[#result + 1] = handle
    end
    return result
end

return Pools
