local Pointer = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local pointer_int_ctor <const> = contract.func(pointer_int, "pointer_int")
local pointer_float_ctor <const> = contract.func(pointer_float, "pointer_float")
local pointer_scr_vec3_ctor <const> = contract.func(pointer_scr_vec3, "pointer_scr_vec3")

function Pointer.int()
    return pointer_int_ctor()
end

function Pointer.float()
    return pointer_float_ctor()
end

function Pointer.scr_vec3()
    return pointer_scr_vec3_ctor()
end

function Pointer.int_with_value(value)
    local ptr = Pointer.int()
    ptr.value = value
    return ptr
end

function Pointer.free(ptr)
    if ptr and ptr.free then ptr:free() end
end

function Pointer.int_value(ptr, default)
    if ptr and ptr.value ~= nil then return ptr.value end
    return default
end

function Pointer.float_value(ptr, default)
    if ptr and ptr.value ~= nil then return ptr.value end
    return default
end

function Pointer.scr_vec3_value(ptr, default)
    if ptr and ptr.value ~= nil then return ptr.value end
    return default
end

return Pointer
