local Game = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local game_api <const> = contract.table(game, "game")
local vec3_ctor <const> = contract.func(vec3, "vec3")
local network_unregister_entity <const> = contract.func(game_api.network_unregister_entity, "game.network_unregister_entity")
local local_unregister_entity <const> = contract.func(game_api.local_unregister_entity, "game.local_unregister_entity")
local entity_from_guid <const> = contract.func(game_api.entity_from_guid, "game.entity_from_guid")
local is_ptfx_playing_at_coords <const> = contract.func(game_api.is_ptfx_playing_at_coords, "game.is_ptfx_playing_at_coords")
local is_session_free_roam <const> = contract.func(game_api.is_session_free_roam, "game.is_session_free_roam")

local function to_vec3(coords)
    return vec3_ctor(coords.x, coords.y, coords.z)
end

function Game.network_unregister_entity(handle, locally)
    return network_unregister_entity(handle, locally)
end

function Game.local_unregister_entity(handle)
    return local_unregister_entity(handle)
end

function Game.entity_from_guid(handle)
    return entity_from_guid(handle)
end

function Game.entity_exists(handle)
    if not handle or handle == 0 then return false end
    return entity_from_guid(handle).value ~= 0
end

function Game.is_ptfx_playing_at_coords(asset, effect, coords, radius)
    return is_ptfx_playing_at_coords(asset, effect, to_vec3(coords), radius)
end

function Game.is_session_free_roam()
    return is_session_free_roam() and true or false
end

local MISSION_REFRESH_CALLS <const> = 60
local mission_calls_left = 0
local mission_cached = false

function Game.in_mission()
    mission_calls_left = mission_calls_left - 1
    if mission_calls_left < 0 then
        mission_calls_left = MISSION_REFRESH_CALLS - 1
        mission_cached = not is_session_free_roam()
    end
    return mission_cached
end

return Game
