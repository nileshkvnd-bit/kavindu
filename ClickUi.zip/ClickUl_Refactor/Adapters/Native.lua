local Native = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local native_api <const> = contract.table(require("natives"), "natives")
local get_entity_coords <const> = 0x3FEF770D40960D5A
local get_entity_forward_vector <const> = 0x0A794A5A57F8DF91
local get_entity_model <const> = 0x9F47B058362C84B5
local set_object_tint_index <const> = 0x971DA0055324D033
local set_vehicle_xenon_light_color_index <const> = 0xE41033B25D003A07
local get_display_name_from_vehicle_model <const> = 0xB215AAC32D25D019
local get_filename_for_audio_conversation <const> = 0x7B5280EBA9840C72
local attach_entity_to_entity <const> = 0x6B9BBD38AB0796DF
local get_vehicle_number_plate_text <const> = 0x7CE1CCB9B293020E
local get_offset_from_entity_in_world_coords <const> = 0x1899F328B0E12848
local get_entity_rotation <const> = 0xAFBD61CC738D9EB9
local get_entity_velocity <const> = 0x4805D2B1D8CF94A9
local get_final_rendered_cam_coord <const> = 0xA200EB1EE790F448
local get_final_rendered_cam_rot <const> = 0x5B4E4C817FCC2DFB
local get_ped_bone_coords <const> = 0x17C07FC640E86B4E
local set_vehicle_livery2 <const> = 0xA6D3A8750DC73270
local get_vehicle_livery2 <const> = 0x60190048C0764A26
local get_vehicle_livery2_count <const> = 0x5ECB40269053C0D4
local get_mod_text_label <const> = 0x8935624F8C5592CC
local get_mod_slot_name <const> = 0x51F0FEB9F6AE98C0
local get_vehicle_mod_color_1_name <const> = 0xB45085B721EFD38C
local trigger_siren_audio <const> = 0x66C3FB05206041BA
local set_siren_bypass_mp_driver_check <const> = 0xF584CF8529B51434
local get_first_blip_info_id <const> = 0x1BEDE233E6CD2A1F
local get_next_blip_info_id <const> = 0x14F96AA50D6FBEA7
local get_blip_coords <const> = 0x586AFE3FF72D996E
local get_blip_colour <const> = 0xDF729E8D20CF7327
local get_blip_sprite <const> = 0x1FC877464A04FC4F
local get_blip_info_id_entity_index <const> = 0x4BA4E2553AFEDC2C
local does_blip_exist <const> = 0xA6DB27D19ECBB7DA
local get_ped_target_from_combat_ped <const> = 0x32C27A11307B01CC
local draw_marker_sphere <const> = 0x799017F9E3B10112
local get_cam_coord <const> = 0xBAC038F7459AE5AE
local get_cam_rot <const> = 0x7D304C1C955E3E12
local hard_attach_cam_to_entity <const> = 0x202A5ED9CE01D6E7
local set_vehicle_homing_lockedonto_state <const> = 0x407DC5E97DB1A4D3
local add_owned_explosion <const> = 0x172AA1B624FA1013
local shoot_single_bullet_between_coords_ignore_entity_new <const> = 0xBFE5756E7407064A
local begin_scaleform_movie_method <const> = 0xF6E48914C7A8694E
local begin_text_command_scaleform_string <const> = 0x80338406F3475E55
local does_text_label_exist <const> = 0xAC09CA973C564252
local draw_scaleform_movie_fullscreen <const> = 0x0DF606929C105BE1
local end_scaleform_movie_method <const> = 0xC6796A8FFA375E53
local end_text_command_scaleform_string <const> = 0x362E2D3FE93A9959
local get_control_instructional_buttons_string <const> = 0x0499D7B09FC9B407
local has_scaleform_movie_loaded <const> = 0x85F01B8D5B90570E
local request_scaleform_movie <const> = 0x11FE353CF9733E6F
local scaleform_movie_method_add_param_bool <const> = 0xC58424BA936EB458
local scaleform_movie_method_add_param_float <const> = 0xD69736AAE04DB51A
local scaleform_movie_method_add_param_int <const> = 0xC3D0841A0CC546A6
local scaleform_movie_method_add_param_player_name_string <const> = 0xE83A3E3557A56640
local scaleform_movie_method_add_param_texture_name_string <const> = 0xBA7148484BD90365
local set_scaleform_movie_as_no_longer_needed <const> = 0x1D132D614DD86811
local set_script_gfx_draw_order <const> = 0x61BB1D9B3A95D802
local invoker_api <const> = contract.table(invoker, "invoker")
local invoker_call <const> = contract.func(invoker_api.call, "invoker.call")
local scr_vec3_ctor <const> = contract.func(scr_vec3, "scr_vec3")

local invoker_native <const> = function(hash, ...)
    return invoker_call(hash, ...)
end

local INVOKER_SPECIALS <const> = {
    get_entity_coords = true,
    get_entity_forward_vector = true,
    get_entity_model = true,
    set_object_tint_index = true,
    set_vehicle_xenon_light_color_index = true,
    get_display_name_from_vehicle_model = true,
    get_filename_for_audio_conversation = true,
    attach_entity_to_entity = true,
    get_vehicle_number_plate_text = true,
    get_offset_from_entity_in_world_coords = true,
    get_entity_rotation = true,
    get_entity_velocity = true,
    get_final_rendered_cam_coord = true,
    get_final_rendered_cam_rot = true,
    get_ped_bone_coords = true,
    set_vehicle_livery2 = true,
    get_vehicle_livery2 = true,
    get_vehicle_livery2_count = true,
    get_mod_text_label = true,
    get_mod_slot_name = true,
    get_vehicle_mod_color_1_name = true,
    trigger_siren_audio = true,
    set_siren_bypass_mp_driver_check = true,
    get_first_blip_info_id = true,
    get_next_blip_info_id = true,
    get_blip_coords = true,
    get_blip_colour = true,
    get_blip_sprite = true,
    get_blip_info_id_entity_index = true,
    does_blip_exist = true,
    get_ped_target_from_combat_ped = true,
    draw_marker_sphere = true,
    get_cam_coord = true,
    get_cam_rot = true,
    hard_attach_cam_to_entity = true,
    set_vehicle_homing_lockedonto_state = true,
    add_owned_explosion = true,
    shoot_single_bullet_between_coords_ignore_entity_new = true,
    begin_scaleform_movie_method = true,
    begin_text_command_scaleform_string = true,
    does_text_label_exist = true,
    draw_scaleform_movie_fullscreen = true,
    end_scaleform_movie_method = true,
    end_text_command_scaleform_string = true,
    get_control_instructional_buttons_string = true,
    has_scaleform_movie_loaded = true,
    request_scaleform_movie = true,
    scaleform_movie_method_add_param_bool = true,
    scaleform_movie_method_add_param_float = true,
    scaleform_movie_method_add_param_int = true,
    scaleform_movie_method_add_param_player_name_string = true,
    scaleform_movie_method_add_param_texture_name_string = true,
    set_scaleform_movie_as_no_longer_needed = true,
    set_script_gfx_draw_order = true,
}

local function invoker_special(name)
    if not INVOKER_SPECIALS[name] then return nil end
    return Native[name]
end

local resolved = {}

function Native.require(name)
    local cached = resolved[name]
    if cached then return cached end
    local fn = invoker_special(name) or native_api[name]
    fn = contract.func(fn, "natives." .. tostring(name))
    resolved[name] = fn
    return fn
end

function Native.call(name, ...)
    return Native.require(name)(...)
end

function Native.get_entity_coords(entity, alive)
    return invoker_native(get_entity_coords, entity, alive and true or false).scr_vec3
end

function Native.get_entity_forward_vector(entity)
    return invoker_native(get_entity_forward_vector, entity).scr_vec3
end

function Native.get_entity_model(entity)
    return invoker_native(get_entity_model, entity).int & 0xFFFFFFFF
end

function Native.set_object_tint_index(object, texture_variation)
    return invoker_native(set_object_tint_index, object, texture_variation)
end

function Native.set_vehicle_xenon_light_color_index(vehicle, color_index)
    return invoker_native(set_vehicle_xenon_light_color_index, vehicle, color_index)
end

function Native.set_vehicle_livery2(vehicle, livery_index)
    return invoker_native(set_vehicle_livery2, vehicle, livery_index)
end

function Native.get_vehicle_livery2(vehicle)
    return invoker_native(get_vehicle_livery2, vehicle).int
end

function Native.get_vehicle_livery2_count(vehicle)
    return invoker_native(get_vehicle_livery2_count, vehicle).int
end

function Native.get_mod_text_label(vehicle, mod_type, mod_value)
    local result = invoker_native(get_mod_text_label, vehicle, mod_type, mod_value)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.get_mod_slot_name(vehicle, mod_type)
    local result = invoker_native(get_mod_slot_name, vehicle, mod_type)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.get_vehicle_mod_color_1_name(vehicle, spec)
    local result = invoker_native(get_vehicle_mod_color_1_name, vehicle, spec and true or false)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.trigger_siren_audio(vehicle)
    return invoker_native(trigger_siren_audio, vehicle)
end

function Native.set_siren_bypass_mp_driver_check(vehicle, toggle)
    return invoker_native(set_siren_bypass_mp_driver_check, vehicle, toggle and true or false)
end

function Native.get_display_name_from_vehicle_model(model_hash)
    local result = invoker_native(get_display_name_from_vehicle_model, model_hash)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.get_filename_for_audio_conversation(conversation_name)
    local result = invoker_native(get_filename_for_audio_conversation, conversation_name)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.get_vehicle_number_plate_text(vehicle)
    local result = invoker_native(get_vehicle_number_plate_text, vehicle)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.get_offset_from_entity_in_world_coords(entity, offset_x, offset_y, offset_z)
    return invoker_native(get_offset_from_entity_in_world_coords, entity, offset_x, offset_y, offset_z).scr_vec3
end

function Native.get_entity_rotation(entity, rotation_order)
    return invoker_native(get_entity_rotation, entity, rotation_order).scr_vec3
end

function Native.get_entity_velocity(entity)
    return invoker_native(get_entity_velocity, entity).scr_vec3
end

function Native.get_final_rendered_cam_coord()
    return invoker_native(get_final_rendered_cam_coord).scr_vec3
end

function Native.get_final_rendered_cam_rot(rotation_order)
    return invoker_native(get_final_rendered_cam_rot, rotation_order).scr_vec3
end

function Native.get_ped_bone_coords(ped, bone_id, offset_x, offset_y, offset_z)
    return invoker_native(get_ped_bone_coords, ped, bone_id, offset_x, offset_y, offset_z).scr_vec3
end

function Native.attach_entity_to_entity(child, parent, bone, offset, rotation, detach_when_dead, detach_when_ragdoll, active_collision, use_basic_attach_if_ped, rot_order, attach_offset_is_relative, mark_as_no_longer_needed)
    return invoker_native(
        attach_entity_to_entity,
        child,
        parent,
        bone,
        scr_vec3_ctor(offset.x, offset.y, offset.z),
        scr_vec3_ctor(rotation.x, rotation.y, rotation.z),
        detach_when_dead and true or false,
        detach_when_ragdoll and true or false,
        active_collision and true or false,
        use_basic_attach_if_ped and true or false,
        rot_order or 2,
        attach_offset_is_relative ~= false,
        mark_as_no_longer_needed and true or false
    )
end

function Native.get_first_blip_info_id(blip_sprite)
    return invoker_native(get_first_blip_info_id, blip_sprite).int
end

function Native.get_next_blip_info_id(blip_sprite)
    return invoker_native(get_next_blip_info_id, blip_sprite).int
end

function Native.get_blip_coords(blip)
    return invoker_native(get_blip_coords, blip).scr_vec3
end

function Native.get_blip_colour(blip)
    return invoker_native(get_blip_colour, blip).int
end

function Native.get_blip_sprite(blip)
    return invoker_native(get_blip_sprite, blip).int
end

function Native.get_blip_info_id_entity_index(blip)
    return invoker_native(get_blip_info_id_entity_index, blip).int
end

function Native.does_blip_exist(blip)
    return invoker_native(does_blip_exist, blip).bool
end

function Native.get_ped_target_from_combat_ped(ped, force_los_check)
    return invoker_native(get_ped_target_from_combat_ped, ped, force_los_check and true or false).int
end

function Native.draw_marker_sphere(position, radius, red, green, blue, alpha)
    return invoker_native(
        draw_marker_sphere,
        scr_vec3_ctor(position.x, position.y, position.z),
        radius,
        red,
        green,
        blue,
        alpha
    )
end

function Native.get_cam_coord(cam)
    return invoker_native(get_cam_coord, cam).scr_vec3
end

function Native.get_cam_rot(cam, rotation_order)
    return invoker_native(get_cam_rot, cam, rotation_order).scr_vec3
end

function Native.hard_attach_cam_to_entity(cam, entity, x_rot, y_rot, z_rot, x_offset, y_offset, z_offset, is_relative)
    return invoker_native(
        hard_attach_cam_to_entity,
        cam,
        entity,
        x_rot,
        y_rot,
        z_rot,
        x_offset,
        y_offset,
        z_offset,
        is_relative and true or false
    )
end

function Native.set_vehicle_homing_lockedonto_state(vehicle, state)
    return invoker_native(set_vehicle_homing_lockedonto_state, vehicle, state)
end

function Native.add_owned_explosion(ped, position, explosion_type, damage_scale, audible, invisible, camera_shake)
    return invoker_native(
        add_owned_explosion,
        ped,
        scr_vec3_ctor(position.x, position.y, position.z),
        explosion_type,
        damage_scale,
        audible and true or false,
        invisible and true or false,
        camera_shake
    )
end

function Native.shoot_single_bullet_between_coords_ignore_entity_new(start_pos, end_pos, damage, p7, weapon_hash, owner_ped, is_audible, is_invisible, speed, ignore_entity, p14, p15, p16, p17, p18, p19)
    return invoker_native(
        shoot_single_bullet_between_coords_ignore_entity_new,
        scr_vec3_ctor(start_pos.x, start_pos.y, start_pos.z),
        scr_vec3_ctor(end_pos.x, end_pos.y, end_pos.z),
        damage,
        p7,
        weapon_hash,
        owner_ped,
        is_audible and true or false,
        is_invisible and true or false,
        speed,
        ignore_entity,
        p14,
        p15,
        p16,
        p17,
        p18,
        p19
    )
end

function Native.begin_scaleform_movie_method(scaleform, method)
    return invoker_native(begin_scaleform_movie_method, scaleform, method).bool
end

function Native.begin_text_command_scaleform_string(component_type)
    return invoker_native(begin_text_command_scaleform_string, component_type)
end

function Native.does_text_label_exist(gxt)
    return invoker_native(does_text_label_exist, gxt).bool
end

function Native.draw_scaleform_movie_fullscreen(scaleform, red, green, blue, alpha, unk)
    return invoker_native(draw_scaleform_movie_fullscreen, scaleform, red, green, blue, alpha, unk or 0)
end

function Native.end_scaleform_movie_method()
    return invoker_native(end_scaleform_movie_method)
end

function Native.end_text_command_scaleform_string()
    return invoker_native(end_text_command_scaleform_string)
end

function Native.get_control_instructional_buttons_string(control_type, control, p2)
    local result = invoker_native(get_control_instructional_buttons_string, control_type, control, p2 and true or false)
    if result.int64 == 0 then return nil end
    return result.str
end

function Native.has_scaleform_movie_loaded(scaleform)
    return invoker_native(has_scaleform_movie_loaded, scaleform).bool
end

function Native.request_scaleform_movie(scaleform_name)
    return invoker_native(request_scaleform_movie, scaleform_name).int
end

function Native.scaleform_movie_method_add_param_bool(value)
    return invoker_native(scaleform_movie_method_add_param_bool, value and true or false)
end

function Native.scaleform_movie_method_add_param_float(value)
    return invoker_native(scaleform_movie_method_add_param_float, value)
end

function Native.scaleform_movie_method_add_param_int(value)
    return invoker_native(scaleform_movie_method_add_param_int, value)
end

function Native.scaleform_movie_method_add_param_player_name_string(value)
    return invoker_native(scaleform_movie_method_add_param_player_name_string, value)
end

function Native.scaleform_movie_method_add_param_texture_name_string(value)
    return invoker_native(scaleform_movie_method_add_param_texture_name_string, value)
end

function Native.set_scaleform_movie_as_no_longer_needed(scaleform_handle)
    return invoker_native(set_scaleform_movie_as_no_longer_needed, scaleform_handle)
end

function Native.set_script_gfx_draw_order(layer)
    return invoker_native(set_script_gfx_draw_order, layer)
end

function Native.has(name)
    return type(native_api[name]) == "function" or type(invoker_special(name)) == "function"
end

function Native.run_task_sequence(ped, build_fn)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local sequence = Pointer.int()
    local sequence_id = nil
    local ok, err = xpcall(function()
        Native.call("open_sequence_task", sequence)
        sequence_id = Pointer.int_value(sequence, 0)
        build_fn(sequence_id)
        Native.call("close_sequence_task", sequence_id)
        Native.call("task_perform_sequence", ped, sequence_id)
    end, debug.traceback)

    local clear_ok, clear_err = true, nil
    if sequence_id ~= nil then
        clear_ok, clear_err = xpcall(function()
            Native.call("clear_sequence_task", sequence)
        end, debug.traceback)
    end
    Pointer.free(sequence)

    if not ok then error(err, 0) end
    if not clear_ok then error(clear_err, 0) end
end

function Native.delete_entity(entity)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local p = Pointer.int_with_value(entity)
    local ok, err = xpcall(function()
        Native.call("delete_entity", p)
    end, debug.traceback)
    Pointer.free(p)
    if not ok then error(err, 0) end
end

function Native.get_ground_z_for_3d_coord(x, y, z)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local ground = Pointer.float()
    local found = false
    local ok, err = xpcall(function()
        found = Native.call("get_ground_z_for_3d_coord", x, y, z, ground, false) and true or false
    end, debug.traceback)
    local ground_z = Pointer.float_value(ground, nil)
    Pointer.free(ground)
    if not ok then error(err, 0) end
    if not found then return false, nil end
    return true, ground_z
end

function Native.ground_z_shapetest(x, y, z_hint, ignore_entity)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local handle = Native.call(
        "start_expensive_synchronous_shape_test_los_probe",
        x + 0.0, y + 0.0, z_hint + 0.0,
        x + 0.0, y + 0.0, -200.0,
        511,
        ignore_entity or 0,
        7
    )
    if not handle or handle == 0 then return false, nil end

    local hit = Pointer.int()
    local end_point = Pointer.scr_vec3()
    local normal = Pointer.scr_vec3()
    local entity_hit = Pointer.int()
    local ground_z = nil
    local ok, err = xpcall(function()
        local state = Native.call("get_shape_test_result", handle, hit, end_point, normal, entity_hit)
        if state == 2 and Pointer.int_value(hit, 0) ~= 0 then
            local hit_point = Pointer.scr_vec3_value(end_point, nil)
            ground_z = hit_point and hit_point.z or nil
        end
    end, debug.traceback)
    Pointer.free(hit)
    Pointer.free(end_point)
    Pointer.free(normal)
    Pointer.free(entity_hit)
    if not ok then error(err, 0) end
    if ground_z == nil then return false, nil end
    return true, ground_z
end

function Native.water_height(x, y, z)
    local Pointer = require("ClickUl_Refactor.Adapters.Pointer")
    local height = Pointer.float()
    local found = false
    local ok, err = xpcall(function()
        found = Native.call("get_water_height", x + 0.0, y + 0.0, z + 0.0, height) and true or false
    end, debug.traceback)
    local water_z = Pointer.float_value(height, nil)
    Pointer.free(height)
    if not ok then error(err, 0) end
    if not found then return false, nil end
    return true, water_z
end

return Native
