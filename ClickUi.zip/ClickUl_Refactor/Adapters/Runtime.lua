local Runtime = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local util_api <const> = contract.table(util, "util")
local game_api <const> = contract.table(game, "game")
local util_create_job <const> = contract.func(util_api.create_job, "util.create_job")
local util_create_thread <const> = contract.func(util_api.create_thread, "util.create_thread")
local util_remove_thread <const> = contract.func(util_api.remove_thread, "util.remove_thread")
local util_yield <const> = contract.func(util_api.yield, "util.yield")
local util_get_tick_count <const> = contract.func(util_api.get_tick_count, "util.get_tick_count")
local game_delta <const> = contract.func(game_api.delta, "game.delta")
local game_resolution <const> = contract.func(game_api.resolution, "game.resolution")

function Runtime.create_job(fn)
    return util_create_job(fn)
end

function Runtime.create_thread(fn)
    return util_create_thread(fn)
end

function Runtime.remove_thread(thread_id)
    return util_remove_thread(thread_id)
end

function Runtime.yield(ms)
    return util_yield(ms)
end

function Runtime.get_tick_count()
    return util_get_tick_count()
end

function Runtime.now()
    return util_get_tick_count() / 1000
end

function Runtime.delta_time()
    return game_delta()
end

local resolution_cache = nil

function Runtime.resolution()
    if not resolution_cache then
        resolution_cache = game_resolution()
    end
    return resolution_cache
end

return Runtime
