local Hash = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local joaat_fn <const> = contract.func(joaat, "joaat")

function Hash.joaat(text)
    return joaat_fn(text)
end

return Hash
