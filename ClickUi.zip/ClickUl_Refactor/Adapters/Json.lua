local json_adapter = {}
local json_encoder = require("ClickUl_Refactor.Core.JsonEncoder")
local json_decoder = require("ClickUl_Refactor.Core.JsonDecoder")

function json_adapter.encode_document(tbl, indent)
    return json_encoder.encode(tbl, indent or 2)
end

function json_adapter.decode(text)
    return json_decoder.decode(text)
end

return json_adapter
