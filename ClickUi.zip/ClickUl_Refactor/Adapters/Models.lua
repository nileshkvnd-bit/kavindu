local Models = {}

local contract = require("ClickUl_Refactor.Adapters.Contract")
local Native = require("ClickUl_Refactor.Adapters.Native")
local CacheUtils = require("ClickUl_Refactor.Core.CacheUtils")

local VEHICLE_CLASS_KEYS <const> = {
    "compacts",
    "sedans",
    "suvs",
    "coupes",
    "muscle",
    "sports_classics",
    "sports",
    "super",
    "motorcycles",
    "off_road",
    "industrial",
    "utility",
    "vans",
    "cycles",
    "boats",
    "helicopters",
    "planes",
    "service",
    "emergency",
    "military",
    "commercial",
    "trains",
    "open_wheel",
}

local models_api <const> = contract.table(models, "models")
local vehicle_classes_api <const> = contract.table(models_api.vehicle, "models.vehicle")
local vehicles_fn <const> = contract.func(models_api.vehicles, "models.vehicles")
local vehicles_from_class_fn <const> = contract.func(models_api.vehicles_from_class, "models.vehicles_from_class")
local VEHICLE_DISPLAY_NAME_CACHE_LIMIT <const> = 2048
local vehicle_display_name_cache = {}
local vehicle_display_name_cache_order = {}
local vehicle_display_name_cache_count = 0

local valid_vehicle_label <const> = function(label)
    return type(label) == "string" and label ~= "" and label ~= "CARNOTFOUND"
end

local cache_vehicle_display_name <const> = function(model_hash, name)
    name = tostring(name)
    if vehicle_display_name_cache[model_hash] == nil then
        vehicle_display_name_cache_count = CacheUtils.evict_ordered(
            vehicle_display_name_cache,
            vehicle_display_name_cache_order,
            VEHICLE_DISPLAY_NAME_CACHE_LIMIT,
            nil,
            nil,
            vehicle_display_name_cache_count,
            true
        )
        vehicle_display_name_cache_order[#vehicle_display_name_cache_order + 1] = model_hash
        vehicle_display_name_cache_count = vehicle_display_name_cache_count + 1
    end
    vehicle_display_name_cache[model_hash] = name
    return name
end

function Models.vehicles()
    return vehicles_fn()
end

function Models.vehicle_classes()
    local classes = {}
    for i = 1, #VEHICLE_CLASS_KEYS do
        local key = VEHICLE_CLASS_KEYS[i]
        local value = vehicle_classes_api[key]
        if value ~= nil then
            classes[#classes + 1] = {
                key = key,
                value = value,
            }
        end
    end
    return classes
end

function Models.vehicles_from_class(class_key)
    local class_value = vehicle_classes_api[class_key]
    if class_value == nil then return {} end
    return vehicles_from_class_fn(class_value)
end

function Models.vehicle_display_name(model_hash)
    local raw_hash = model_hash
    model_hash = tonumber(model_hash)
    if not model_hash then return tostring(raw_hash) end

    local cached = vehicle_display_name_cache[model_hash]
    if cached then return cached end

    local label = Native.get_display_name_from_vehicle_model(model_hash)
    if not valid_vehicle_label(label) then return cache_vehicle_display_name(model_hash, model_hash) end

    local name = Native.get_filename_for_audio_conversation(label)
    if type(name) == "string" and name ~= "" then return cache_vehicle_display_name(model_hash, name) end

    return cache_vehicle_display_name(model_hash, label)
end

return Models
