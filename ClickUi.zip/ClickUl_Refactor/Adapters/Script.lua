local Script = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")

local script_api <const> = contract.table(script, "script")
local script_running <const> = contract.func(script_api.running, "script.running")
local script_execute_as <const> = contract.func(script_api.execute_as, "script.execute_as")
local script_globals <const> = contract.func(script_api.globals, "script.globals")
local script_locals <const> = contract.func(script_api.locals, "script.locals")
local script_program <const> = contract.func(script_api.program, "script.program")

function Script.running(name)
    return script_running(name) and true or false
end

function Script.execute_as(name, callback)
    return script_execute_as(name, callback)
end

function Script.globals(base)
    return script_globals(base)
end

function Script.read_global_int(index)
    return script_globals(index).int32
end

function Script.write_global_int(index, value)
    script_globals(index).int32 = value
end

function Script.locals(name, base)
    return script_locals(name, base)
end

function Script.program(name)
    return script_program(name)
end

return Script
