local contract = {}

local function fail(name)
    error("Lexis API missing: " .. name, 3)
end

function contract.table(value, name)
    if type(value) ~= "table" then fail(name) end
    return value
end

function contract.func(value, name)
    if type(value) ~= "function" then fail(name) end
    return value
end

function contract.value(value, name)
    if value == nil then fail(name) end
    return value
end

return contract
