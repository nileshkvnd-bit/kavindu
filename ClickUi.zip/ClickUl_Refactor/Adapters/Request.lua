local Request = {}
local contract = require("ClickUl_Refactor.Adapters.Contract")
local Native = require("ClickUl_Refactor.Adapters.Native")
local Runtime = require("ClickUl_Refactor.Adapters.Runtime")

local request_api <const> = contract.table(request, "request")
local request_control <const> = contract.func(request_api.control, "request.control")
local request_model <const> = contract.func(request_api.model, "request.model")
local request_anim <const> = contract.func(request_api.anim, "request.anim")
local request_dict <const> = contract.func(request_api.dict, "request.dict")
local request_particle <const> = contract.func(request_api.particle, "request.particle")
local request_weapon <const> = contract.func(request_api.weapon, "request.weapon")

local function can_yield()
    local _, is_main = coroutine.running()
    return not is_main
end

local function request_native_asset(request_name, check_name, asset, timeout)
    if not asset or asset == "" then return false end
    Native.call(request_name, asset)
    if Native.call(check_name, asset) then return true end
    if not can_yield() then return false end

    local timeout_ms = math.floor(((timeout or 1.0) * 1000) + 0.5)
    local deadline = Runtime.get_tick_count() + timeout_ms
    while Runtime.get_tick_count() <= deadline do
        Runtime.yield(10)
        if Native.call(check_name, asset) then return true end
    end
    return false
end

function Request.model(model)
    return request_model(model)
end

function Request.control(entity, force_ownership)
    return request_control(entity, force_ownership)
end

function Request.anim(animation)
    return request_anim(animation)
end

function Request.dict(dictionary)
    return request_dict(dictionary)
end

function Request.anim_set(animation_set)
    return request_native_asset("request_anim_set", "has_anim_set_loaded", animation_set, 1.0)
end

function Request.particle(asset)
    return request_particle(asset)
end

function Request.weapon(model)
    return request_weapon(model)
end

return Request
